import { defineConfig } from 'vitest/config';
import { BaseSequencer, type TestSpecification } from 'vitest/node';

/**
 * Test dosyaları ortak bir veritabanını sırayla kullanır. Vitest'in varsayılan sırası önbellekteki sürelere göre değişebildiği
 * için sıra sabitlendi: V2 dosyaları V2'de geçtikleri sırayla (büyükten küçüğe: f, e, g, d, b, c), V2.1 dosyası (h) en sonda.
 * Böylece yeni testler eski testlerin verisini etkilemez ve sonuçlar her çalıştırmada aynıdır.
 */
const ORDER = ['f_v2', 'e_acceptance', 'g_review', 'd_integrations', 'b_core', 'c_agents', 'h_v21'];
class FixedOrderSequencer extends BaseSequencer {
  async sort(files: TestSpecification[]) {
    const rank = (f: TestSpecification) => { const i = ORDER.findIndex((n) => f.moduleId.includes(n)); return i < 0 ? ORDER.length : i; };
    return [...files].sort((a, b) => rank(a) - rank(b) || a.moduleId.localeCompare(b.moduleId));
  }
}

const DB = 'bays_test';
export default defineConfig({
  test: {
    globalSetup: ['tests/globalSetup.ts'],
    fileParallelism: false,
    sequence: { sequencer: FixedOrderSequencer },
    testTimeout: 30000,
    hookTimeout: 60000,
    env: {
      RUN_MODE: 'simulation',
      EGRESS_ENABLED: 'false',
      DATABASE_URL_OWNER: `postgres://postgres:postgres_local_dev@localhost:5432/${DB}`,
      DATABASE_URL_APP: `postgres://bays_app:bays_app_local_dev@localhost:5432/${DB}`,
      DATABASE_URL_AUDITOR: `postgres://bays_auditor:bays_auditor_local_dev@localhost:5432/${DB}`,
      TEST_DB_NAME: DB,
      FOUNDER_WHATSAPP_NUMBER: '905550000000',
      WHATSAPP_APP_SECRET: 'test_app_secret_not_real',
      WHATSAPP_VERIFY_TOKEN: 'test_verify_token_not_real',
      N8N_SHARED_SECRET: 'test_n8n_secret_not_real',
      FOUNDER_TOKEN_SHA256: 'd7143753c5eed95683513514900cbaf4e2c8c5bd93c7290840f333ceeb9c2bdf',
    },
  },
});
