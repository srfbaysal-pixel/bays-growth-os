# Maliyet hesabı: formül ve gereken girdiler

**Gerçek veriye dayalı maliyet hesabı yoktur**: hiçbir ücretli sağlayıcı çağrılmadı, fatura yok, kur girilmedi. Bu yüzden aşağıda yalnız formül ve girdiler verilir. `npm run cost:estimate` bugün "Toplam: hesaplanamadı (3 kalemin fiyatı/kuru bilinmiyor)" der — bu doğru sonuçtur; bilinmeyen kalem sıfır sayılmaz.

## Formül

Aylık tahmini gider (TL) = Σ kalemler, her kalem:

```
model çağrısı  = gün × çağrı/gün × (girdi_token × girdi_fiyatı + çıktı_token × çıktı_fiyatı) / 1.000.000 × kur
arama          = gün × arama/gün × önbellek_dışı_oranı × istek_fiyatı × kur
sayfa okuma    = 0 (kendi sunucumuzdan; barındırma kaleminde)
WhatsApp       = gün × pencere_dışı_rapor/gün × şablon_fiyatı (TL veya kur)
barındırma     = aylık sabit
```

- `gün` = 30 (`config/usage_profile.json`), `kur` = `config/pricing.json → fx` (kaynak + tarih zorunlu).
- Bütçe uygulaması: her dış çağrıdan önce **tahmini üst sınır rezerve edilir**, çağrıdan sonra gerçek tutarla uzlaştırılır. Aylık toplam 5.000 TL hedefe yaklaşınca (%70, %90) uyarı; 10.000 TL kesin üst sınırda yeni ücretli iş başlamaz. Üst sınırı yalnız kurucu `.env`'de değiştirebilir.

## Örnek hesap (yalnız araştırma kalemi; kur bilinmediği için sembolik)

Brave Search: 1.000 istek 5 USD → istek başı 0,005 USD (Brave'in Search planı; aylık 5 USD ücretsiz kredi var ama bütçeden düşülmez, temkinli liste fiyatı kullanılır).

```
günlük üst sınır: RESEARCH_MAX_QUERIES_PER_DAY = 8
aylık arama     : 30 × 8 = 240 istek (önbellek isabeti bunu azaltır; 7 gün önbellek)
aylık USD       : 240 × 0,005 = 1,20 USD (ücretsiz kredi düşülmeden)
aylık TL        : 1,20 × KUR   ← KUR sizden
```

Model kalemi için aynı yaklaşım: `usage_profile.json`'daki varsayım (strateji 2 çağrı/gün × 6.000 girdi + 1.500 çıktı token; müşteri geliştirme 6 çağrı/gün × 3.000 + 800 …) × seçeceğiniz modelin resmî token fiyatı × kur.

## Sizden gereken girdiler

| Girdi | Nereye | Not |
|---|---|---|
| Model kimlikleri ve resmî token fiyatları (kaynak URL + tarih) | `config/pricing.json` | Fiyatsız model canlıda çağrılmaz |
| USD/TL (ve gerekirse EUR/TL) kuru, kaynağı, tarihi | `pricing.json → fx` | Döviz kalemleri kur olmadan başlamaz |
| Brave hesabındaki plan ve kalan kredi | panel notu | Anahtar ≠ kredi |
| WhatsApp utility şablonunun Türkiye fiyatı | `pricing.json` | 24 saat penceresi dışı raporlar |
| Sunucu aylık bedeli | `pricing.json → hosting:server` | Sabit gider |
| Gerçek kullanım hacmi (aday/gün, temas/hafta) | `usage_profile.json` | Varsayım pilot sonrası gerçek sayıyla güncellenir |
| Sağlayıcı faturaları (aylık) | uzlaştırma | Tahmin değil, fatura gerçek gideri belirler |
