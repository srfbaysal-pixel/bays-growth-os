# Beş ajanın iş akışı, uzmanlık kaynakları ve değerlendirme raporu

Tarih: 14.10.2026 · Rol sürümleri: `*.v2` · Uzmanlık sürümleri: `expertise.<rol>.v1` · Rubrik: `quality_rubric.v1`

Beş rol beş ayrı ücretli model demek değildir: her rol `MODEL_ECONOMY` veya `MODEL_STRONG` takma adına bağlanır; teslimde ikisi de `mock`. Her ajan çağrısı `agent_runs` tablosuna rol sürümü + uzmanlık sürümü (`strategy.v2+expertise.strategy.v1` gibi), model, maliyet ve koruma sonucu ile yazılır.

## 1. Günlük iş akışı (kalıcı kuyruk üzerinde)

```
08:00 daily_plan (kök görev, gün anahtarlı)
  └─ research_discover ── strateji ─────────── araştırma sağlayıcısı (kapalı/fixture/Brave) + güvenli okuyucu
       ├─ lead_assess × yeni aday ─ müşteri geliştirme ─ uygunluk (kaynaktaki sinyal + hizmet eşleşmesi)
       │    └─ contact_send ─ müşteri geliştirme ─ izinli e-posta | manuel görev | ertele (sessiz saat) | engel
       │         └─ follow_up_check (gün sonra) ─ yanıt yoksa takip taslağı → contact_send
       └─ strategy_plan ─ strateji ─ bağlam: ölçüm, yayın, araştırma, CRM, maliyet, demo, deney, kural, denetim, eksik veri
            └─ campaign_plan ─ kampanya ─ plan → içerik + müşteri geliştirme + kurucu işleri
                 └─ content_create ─ içerik ─ taslak + koruma
                      └─ distribution_schedule ─ kampanya ─ saat seçimi (deney kolu → geçerli kural → varsayılan)
                           └─ publish_due (runAt = planlanan saat) → yayın | not_due | missed→bir kez yeniden plan
                                └─ reconcile_publication (sonuç belirsizse; kör tekrar yok)
Gelen yanıt (imzalı webhook / manuel giriş) → reply_classify ─ müşteri geliştirme
       ├─ "istemiyorum" → tüm markalarda iletişim yasağı + aday kaybedildi
       └─ görüşmeye açık → nitelikli fırsat + görüşme kaydı + WhatsApp/panel kurucu kararı
20:00 evening ─ denetçi ─ deterministik denetim + (önemli bulguda) ikinci görüş + deney değerlendirme → kural
       └─ günün darboğazı + somut düzeltme işi (açık aynı iş varsa yenisi açılmaz) + günlük rapor
Pazar 20:00 weekly ─ haftalık rapor + uluslararası açılım kapısı
```

## 2. Roller

| Rol | Girdi | Çıktı | Yapamayacakları |
|---|---|---|---|
| Strateji | `buildStrategyContext` (14 gün, marka bazlı, eksik veri listesi) | Hedefler: hedef, gerekçe, dayanak (`basis_refs`), görevler, beklenen ölçüm, maliyet sınırı, durdurma koşulu, hipotez işareti; `decision_changes`, `data_gaps`, `research_focus` | Bağlamda olmayan sayı yazmak (`invented_number`), dayanaksız hedef (`objective_without_basis`), ücretli reklam, bütçe artışı |
| İçerik | Kampanya özeti, hizmet kartları, marka dili | LinkedIn metni, hashtag, görsel özeti, iletişim taslağı | Fiyat/teslim süresi, referans, kanıtsız başarı, geliştirmedeki hizmeti hazır gibi sunmak |
| Kampanya | Plan, deney, geçerli kurallar | Yayın saati ve dayanağı, manuel LinkedIn görevleri | Saat gelmeden yayın, LinkedIn mesaj/davet otomasyonu |
| Müşteri geliştirme | Kaynaklı aday (sinyal alıntısıyla), yanıt metni | Uygunluk puanı, kişiselleştirilmiş taslak, yanıt sınıfı, fırsat devri (ihtiyaç + bilinmeyenler) | Kaynakta olmayan sinyal/iletişim, taslağı "gönderildi" saymak, kurucu yerine görüşme saati vermek |
| Denetçi (bağımsız) | Olay kaydı, yayınlar, temaslar, bütçe, araştırma, strateji çıktısı | Bulgular (kanıt kimliği, kök neden, düzeltme), günün darboğazı | Kendi ürettiği işi denetlemek; bulguyu "çözüldü" diye kapatmak |

Denetçinin V2'de eklenen kontrolleri: kaynaksız aday (`unsourced_lead`), strateji tutarsızlığı (`strategy_inconsistency`: veri yokken başarı iddiası, hedef–dayanak uyumsuzluğu), günün darboğazı (`top_bottleneck`: hunideki en dar aşama + somut iş; demo yokluğu içerikle kapatılamaz).

## 3. Uygulanan öğrenme

- Deney: tek değişken, karıştırıcı listesi (saat denemesinde içerik/format zorunlu), gerekçeli örnek eşiği.
- Sonuç `supported` ise denetçi yapısal kural yazar: `{rule_type, value, scope, basis, causal_claim:false}`. `rule_type` zorunlu; yalnız `publish_time`, `content_type_priority`, `outreach_cta` öğrenilebilir. Bütçe, iletişim sınırı, onay politikası öğrenilemez.
- `resolveRule`: kapsam özgüllüğü > tazelik > sürüm; çelişkide varsayılan + olay kaydı. Simülasyon kuralı canlıda kullanılmaz.
- Geri alma (`rollbackMethod`) kuralı düşürür → sonraki planda varsayılana dönülür (V2-09).
- Simülasyonda gözlenen: gün 1–14 deney kolları (12:30/09:00 dengeli), gün 15 `supported`, gün 16 yayın saati 09:00 "rule:linkedin:publish_time v1 uygulandı". Bu ÖRNEK ölçümle üretilmiştir; gerçek etkileşim hakkında bilgi vermez.

## 4. Uzmanlık rehberleri ve kaynakları

Rehberler `src/agents/expertise/<rol>.md`; her biri sürüm, gözden geçirme tarihi (2026-10-14), sonraki gözden geçirme (2027-04-14), güncelleme yöntemi ve kaynak listesi taşır. Kurallar davranış olarak yazılmıştır (ör. "her hedefte dayanak kimliği yaz"), yalnız uzun metin değildir.

| Rol | Kaynaklar |
|---|---|
| Strateji | Kotler & Keller, *Marketing Management* (16. baskı, 2021) · Christensen ve ark., *Competing Against Luck* (2016) · McClure, AARRR (2007) |
| İçerik | Handley, *Everybody Writes* (2. baskı, 2022) · Heath & Heath, *Made to Stick* (2007) · TDK Yazım Kılavuzu |
| Kampanya | Kohavi, Tang & Xu, *Trustworthy Online Controlled Experiments* (2020) · LinkedIn Posts API / Share on LinkedIn belgeleri (learn.microsoft.com, kontrol 14.10.2026) |
| Müşteri geliştirme | Blank, *The Four Steps to the Epiphany* (2005) · Fitzpatrick, *The Mom Test* (2013) · Rackham, *SPIN Selling* (1988) · 6698 sayılı KVKK ve 6563 sayılı Kanun (uygulama ayrıntısı hukukça doğrulanmalı) |
| Denetçi | IIA, *Global Internal Audit Standards* (2024; yürürlük 9 Ocak 2025) · Kohavi ve ark. (2020) |

Güncelleme yöntemi: kurucu onaylı sürüm artışı → `npm run eval:quality` (ve anahtar varsa `:live`) yeniden çalıştırılır → `eval_runs`'ta eski/yeni sürüm karşılaştırılır. `EXPERTISE=off` ile rehbersiz karşılaştırma yapılabilir.

## 5. Değerlendirme

### 5.1 Koruma seti (V1'den korunan, adı dürüstçe "koruma")
`npm run eval` → **13/13**. Sabit metinlerde deterministik koruma katmanını sınar (kanıtsız başarı, sahte referans, fiyat taahhüdü, talimat enjeksiyonu…). **Ajan kalitesi ölçmez.**

### 5.2 Kalite seti (V2, yeni)
- 20 senaryo, rol başına 4 (strateji, içerik, kampanya, müşteri geliştirme, denetçi): veri yok, itiraz önde, yanıt yok, demo yok, sinyalli/sinyalsiz aday, "istemiyorum", görüşmeye açık, çift yayın, çoklu bulgu, güven kanıtı…
- Ölçütler (sonuçlardan önce kaydedildi, 14.10.2026 11:00): kaynak doğruluğu, Türkiye bağlamı, hizmet uyumu, somut öneri, doğal Türkçe, kişiselleştirme, veriden karar, belirsizlik, maliyet disiplini, koruma.
- Eşikler: senaryo = listelenen tüm ölçütler; set ≥ %80; rol başına ≥ 3/4; hakem modeli ortalaması ≥ 3,5 **bilgi amaçlı, karar verici değil** (modelin kendi çıktısını beğenmesi tek kanıt sayılmaz).
- Her çalıştırma `eval_runs`'a kip, model, talimat sürümü, girdi özeti, sonuç ve maliyetle yazılır.

| Kip | Komut | Sonuç (14.10.2026) | Anlamı |
|---|---|---|---|
| Mock sözleşme | `npm run eval:quality` | 20/20, her rol 4/4 | Değerlendirme altyapısı, ölçüt kodu ve çıktı sözleşmeleri çalışıyor. **Model kalitesini göstermez.** |
| Gerçek model | `RUN_MODE=eval npm run eval:quality:live` | **BEKLEMEDE** — EGRESS kapalı, modeller mock, anahtar yok | Gerçek ajan kalitesi ve uzmanlık rehberinin etkisi **sınanmadı**. |

Gerçek model sınamasından sonra okunacak sorular: hangi ölçütte düşüyor (özellikle doğal Türkçe ve kişiselleştirme), `EXPERTISE=off` ile fark var mı, maliyet/senaryo ne kadar.
