# Test raporu

Oluşturulma: **14.10.2026 19:35:58** (Europe/Istanbul) · Node v22.22.0 · psql (PostgreSQL) 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

Sürüm: **2.1.1** · Komut: `npm run test:report` (içinde `vitest run`, `tsx src/cli.ts eval`, `eval-quality`, `node tools/validate-n8n.mjs`) · Test dosyası sırası sabit (vitest.config.ts)

Sonuç: **107 geçti, 0 başarısız** (toplam 107).

## Test türleri

| Tür | Kapsam | Durum |
| --- | --- | --- |
| Mock / simülasyon testi | Aşağıdaki tüm testler. Gerçek PostgreSQL 16 üzerinde, RLS ve veritabanı rolleri dahil; dış sağlayıcılar mock/fixture; e-posta çift gönderim testleri yerel sahte HTTP sunucusuyla (127.0.0.1). | Çalıştırıldı |
| Canlı entegrasyon testi | LinkedIn yayını, WhatsApp gönderimi, n8n akışı, model sağlayıcısı, e-posta, Brave araştırma, gerçek web sayfası okuma | **Çalıştırılmadı** — hesap/anahtar yok, kod gereği engelli |
| Henüz çalıştırılamayan kontroller | Docker imajlarıyla `docker compose up` (bu ortamda Docker Hub erişimi 403), n8n'e import edip çalıştırma, gerçek model çıktısıyla değerlendirme seti, sağlayıcı faturasıyla maliyet uzlaştırması | Canlıya geçiş listesinde |

## Şartname §11 zorunlu kabul testleri

| # | Test | Sonuç | Süre (ms) |
| --- | --- | --- | --- |
| KT-01 | İki markanın veri, anahtar, rapor ve kuyruğu karışmaz | ✓ geçti | 184 |
| KT-02 | Aynı olay/görev iki kez geldiğinde çift yayın/mesaj olmaz | ✓ geçti | 737 |
| KT-03 | Belirsiz dış işlem sonucu tekrar gönderilmeden uzlaştırılır | ✓ geçti | 48 |
| KT-04 | Yetkisiz, süresi dolmuş veya tekrarlı WhatsApp kararı yürütülmez | ✓ geçti | 96 |
| KT-05 | Eşzamanlı gider rezervasyonları bütçeyi aşamaz; bilinmeyen fiyat engellenir | ✓ geçti | 341 |
| KT-06 | Anahtar yokken mock çalışır ve gerçek dış işlem yapılamaz | ✓ geçti | 12 |
| KT-07 | Durdurma çalışan ve kuyruktaki işleri kapsar | ✓ geçti | 50 |
| KT-08 | Yanlış vaat, sahte referans ve prompt injection tespit edilir/engellenir | ✓ geçti | 70 |
| KT-09 | Az veya eksik veride kesin performans hükmü verilmez | ✓ geçti | 62 |
| KT-10 | Ham olaydan rapora ve denetim bulgusuna kanıt izi bulunur | ✓ geçti | 476 |
| KT-11 | Bağlantı iptali, kota hatası ve webhook tekrarı doğru ele alınır | ✓ geçti | 99 |
| KT-12 | Öğrenme değişikliği sürümlenir ve geri alınır | ✓ geçti | 36 |
| KT-13 | Kişisel veri silme ve yedekten geri yükleme senaryosu çalışır | ✓ geçti | 1432 |
| KT-14 | Kaynağı belirsiz gelir ve mock sonuç canlı başarı olarak raporlanmaz | ✓ geçti | 81 |

## V2 görev dosyası §9 — 18 yeni kabul testi

| # | Test | Sonuç | Süre (ms) |
| --- | --- | --- | --- |
| V2-01 | günlük tetikleme fixture araştırmayı çağırır; kaynaklı aday üretip CRM'e taşır | ✓ geçti | 1470 |
| V2-02 | aynı kaynak/işletmenin yeniden keşfi mükerrer aday ve ilk temas üretmez | ✓ geçti | 634 |
| V2-03 | kanıtsız ihtiyaç/iletişim uydurulmaz; araştırma engeli rapora yansır | ✓ geçti | 50 |
| V2-04 | müşteri geliştirme ve kampanya görevleri günlük döngüde gerçekten yürütülür | ✓ geçti | 7 |
| V2-05 | izinli test kanalından gelen yanıt fırsata ve kurucu kararına dönüşür; tekrar yanıt mükerrer işlem üretmez | ✓ geçti | 313 |
| V2-06 | manuel gönderim/yanıt kaydı zinciri doğru devam ettirir; taslak gönderilmiş sayılmaz | ✓ geçti | 118 |
| V2-07 | strateji girdisi ölçüm, denetim, maliyet ve CRM özetlerini içerir; marka izolasyonu korunur | ✓ geçti | 36 |
| V2-08 | farklı performans kanıtı planı gerekçeli değiştirir; bilinmeyen veri sonuç uydurtmaz | ✓ geçti | 121 |
| V2-09 | onaylanmış deney kuralı sonraki zamanlamayı değiştirir; geri alma eski davranışı getirir | ✓ geçti | 37 |
| V2-10 | sahte saatle: planlanan saatten önce yayın çağrısı yok; saat gelince bir kez | ✓ geçti | 211 |
| V2-11 | iki worker, çökme ve yeniden başlama: doğru sahiplenme, yayımlanmış işi tekrar göndermez | ✓ geçti | 232 |
| V2-12 | geçici hata zamanında yeniden denenir; kalıcı hata ve sınır aşımı hata kuyruğuna gider | ✓ geçti | 109 |
| V2-13 | belirsiz yayın sonucu kör tekrar yerine uzlaştırmaya gider; geç/tekrar callback doğru işlenir | ✓ geçti | 138 |
| V2-14 | bütçe, kredi bitişi, fiyat bilinmemesi ve durdurma yeni dış çağrı yollarında uygulanır | ✓ geçti | 207 |
| V2-15 | talimat enjeksiyonu, SSRF ve marka sızıntısı saldırı örnekleri engellenir | ✓ geçti | 9 |
| V2-16 | 16 günlük fixture senaryosu araştırmadan plana, zamanlı yayına, ölçüme, öğrenmeye ve değişen davranışa ulaşır | ✓ geçti | 8616 |
| V2-17 | ikinci senaryo keşiften yanıta, fırsata ve kurucu kararına ulaşır; tüm fixture veriler ÖRNEK işaretli | ✓ geçti | 8 |
| V2-18 | gerçek model kalite değerlendirmesi ayrı komutla çalışır; anahtar yokken açık bekleyen durumu verir | ✓ geçti | 722 |

## Bağımsız V2 incelemesi düzeltme testleri

| # | Test | Sonuç | Süre (ms) |
| --- | --- | --- | --- |
| R-01 | belirsiz sonuç (5xx/zaman aşımı) "sending" kaydında kalır; yeniden denemede tekrar gönderilmez, doğrulama görevi açılır | ✓ geçti | 164 |
| R-02 | kesin hata (4xx) "failed" olur ve yeniden denenebilir; başarılı denemede tek kayıt "sent" olur | ✓ geçti | 91 |
| R-03 | yan etki sırasında çökme: kira kaybı sinyali varsa dış çağrı yapılmaz; sonraki deneme kör tekrar yerine doğrulamaya gider | ✓ geçti | 42 |
| R-04 | büyük harfli Türkçe "İSTEMİYORUM" iletişim yasağına dönüşür (tr-TR küçük harf) | ✓ geçti | 85 |
| R-05 | aynı yanıt için sınıflandırma ikinci kez çalışsa da ikinci fırsat/karar açılmaz | ✓ geçti | 230 |
| R-06 | şehir Türkçe kelime sınırıyla, telefon 0/+90 önekiyle ve yazıldığı biçimde çıkarılır | ✓ geçti | 14 |
| R-07 | yalnız işletmenin kendi alan adındaki e-posta doğrulanmış kişi olur; üçüncü taraf adres kişi yapılmaz | ✓ geçti | 76 |
| R-08 | IPv6 özel/tünel/ayrılmış biçimleri ve DNS rebinding reddedilir; küresel adresler kabul edilir | ✓ geçti | 3 |
| R-09 | robots.txt: kendi ajan grubu öncelikli, ardışık User-agent tek grup, en uzun eşleşme ve Allow | ✓ geçti | 2 |
| R-10 | çalışma sırasında verilen durdurma sonraki aramayı ve sayfa okumayı keser | ✓ geçti | 42 |
| R-11 | canlı deney simülasyon zamanlamasını (veya tersi) etkilemez | ✓ geçti | 15 |
| R-12 | eski worker kira kaybından sonra durum yazamaz; uzun işte kira kaybı handler'a iptal sinyali olarak ulaşır | ✓ geçti | 1098 |
| R-13 | manuel yanıt uç noktası başka markanın adayını kabul etmez | ✓ geçti | 139 |
| R-14 | gelen yanıt ve sınıflandırma görevi aynı işlemde; yeniden teslim eksik görevi tamamlar, çift görev açmaz | ✓ geçti | 48 |
| R-15 | yalnız e-posta kanalı durdurulduğunda ilk temas engellenir, diğer kanallar etkilenmez | ✓ geçti | 20 |

## V2.1 düzeltme testleri (önce kırmızı yazıldı, sonra düzeltildi)

| # | Test | Sonuç | Süre (ms) |
| --- | --- | --- | --- |
| M-01 | yetkisiz ölçüm girişi ve imzasız webhook reddedilir | ✓ geçti | 155 |
| M-02 | başka markanın yayınına ölçüm yazılamaz (API ve webhook) | ✓ geçti | 41 |
| M-03 | geçersiz değer, eksik kanıt, gelecek zaman ve ÖRNEK yayın reddedilir; eksik değer sıfır sayılmaz | ✓ geçti | 109 |
| M-04 | aynı ölçümün tekrar teslimi örnek sayısını şişirmez (webhook teslim kimliği ve aynı içerik) | ✓ geçti | 82 |
| M-05 | kümülatif güncelleme: yeni anlık görüntü günceli değiştirir, eski geç gelen tarihçeye düşer, örnek sayısı değişmez | ✓ geçti | 65 |
| M-06 | gerçek ölçüm doğru deney koluna bağlanır; aynı gönderinin birden çok ölçümü tek örnek sayılır; strateji bağlamına ulaşır | ✓ geçti | 168 |
| M-07 | n8n akışındaki imzalama kodu servisin kabul ettiği gövdeyi üretir; aynı öğe ikinci kez gönderilince tekrar sayılır (n8n çalıştırılmadan, kod düğümü Node ile çalıştırıldı) | ✓ geçti | 39 |
| K-01 | aynı markada örnek ve gerçek veri: canlı strateji bağlamı yalnız gerçek veriyi, örnek bağlam yalnız örneği görür | ✓ geçti | 58 |
| K-02 | kip bilinmeyen eski kayıt canlı sayılmaz; yeni kayıt kip belirtmeden yazılamaz | ✓ geçti | 27 |
| K-03 | aynı gün simülasyondan canlıya geçişte canlı kök görev ayrı açılır, örnek görev canlı worker tarafından alınmaz | ✓ geçti | 40 |
| K-04 | bekleyen örnek gönderim görevi, e-posta bağlantısı canlıyken bile canlı kanaldan yürütülmez | ✓ geçti | 51 |
| K-05 | örnek araştırma önbelleği canlı süreçte kullanılmaz | ✓ geçti | 582 |
| K-06 | canlı görev örnek kampanyaya, örnek adaya veya örnek kanıta bağlanmaz | ✓ geçti | 27 |
| K-07 | kalite değerlendirmesi operasyon görevlerini ve müşteri/performans verisini kirletmez | ✓ geçti | 965 |
| O-01 | "İSTEMİYORUM": model çağrılmadan yanıtla aynı işlemde iletişim yasağı, aday kaybı ve bekleyen takiplerin iptali | ✓ geçti | 80 |
| O-02 | model anahtarı yok / model hatası / bütçe dolu iken de açık ret kaydedilir | ✓ geçti | 207 |
| O-03 | belirsiz ifade kesin ret sayılmaz; mevcut sınıflandırma yoluna gider | ✓ geçti | 101 |
| O-04 | açık ret yanıtının tekrar teslimi yeni fırsat, karar veya çelişkili durum üretmez | ✓ geçti | 70 |
| O-05 | Türkçe karakterle başlayan çekince ("önce") kelime sınırında tanınır: "Fiyat istemiyorum, önce demo" ret sayılmaz; açık retler korunur | ✓ geçti | 279 |
| B-01 | dış çağrı öncesi engel (fiyat bilinmiyor, egress engeli) rezervasyonu bırakır veya hiç açmaz | ✓ geçti | 79 |
| B-02 | sağlayıcı isteği aldıktan sonra zaman aşımı: rezervasyon "belirsiz" kalır, toplamda sayılır, kurucuya uzlaştırma işi açılır | ✓ geçti | 76 |
| B-03 | belirsiz sunucu hatası (5xx) belirsiz; kesin ret (4xx) ücretlenmedi sayılıp bırakılır | ✓ geçti | 74 |
| B-04 | tekrar denenen her çağrı ayrı izlenir; tekrarlı uzlaştırma iki kez gider yazmaz | ✓ geçti | 191 |
| B-05 | aynı desen model çağrısında: 5xx belirsiz kalır, 4xx bırakılır | ✓ geçti | 81 |
| B-06 | aynı sınıflandırma tüm ücretli adaptörlerde: Brave/Anthropic/OpenAI hata biçimleri ve WhatsApp şablon sonucu | ✓ geçti | 23 |

## Kalite değerlendirmesi (20 senaryo, rol başına 4)

Mock sözleşme kipi — **model kalitesi değildir**; yalnız çıktı sözleşmesi, korumalar ve puanlama kodunun çalıştığını gösterir:

```
Kip: mock_contract · durum: done · model: mock:mock-strong
✓ S1-veri-yok [strategy] 
✓ S2-itiraz-onde [strategy] 
✓ S3-yanit-yok [strategy] 
✓ S4-demo-yok [strategy] 
✓ C1-ihtiyac [content] 
✓ C2-itiraz [content] 
✓ C3-gelistirmede-hizmet [content] 
✓ C4-gorusme-daveti [content] 
✓ D1-planli-saat [distribution] 
✓ D2-linkedin-mesaj [distribution] 
✓ D3-deney-kolu [distribution] 
✓ D4-baglanti-daveti [distribution] 
✓ CD1-sinyalli-aday [customer_dev] 
✓ CD2-sinyalsiz-aday [customer_dev] 
✓ CD3-istemiyorum [customer_dev] 
✓ CD4-gorusmeye-acik [customer_dev] 
✓ A1-cift-yayin [auditor] 
✓ A2-bulgu-yok [auditor] 
✓ A3-coklu-bulgu [auditor] 
✓ A4-guven-kaniti [auditor] 
Geçme oranı: 100% · rol bazında: {"strategy":{"pass":4,"total":4},"content":{"pass":4,"total":4},"distribution":{"pass":4,"total":4},"customer_dev":{"pass":4,"total":4},"auditor":{"pass":4,"total":4}} · eşik sağlandı: evet
MOCK SÖZLEŞME TESTİ: değerlendirme altyapısı ve puanlama çalışıyor. Bu sonuç gerçek model kalitesini GÖSTERMEZ; uzmanlık rehberinin davranışa etkisi mock ile ölçülemez.
```

Gerçek model kipi (`npm run eval:quality:live`) — anahtar/canlı model yokken beklenen sonuç BEKLEMEDE'dir:

```
Kip: live_model · durum: pending
BEKLEMEDE: gerçek model değerlendirmesi çalıştırılmadı — EGRESS_ENABLED=true değil; economy modeli mock (gerçek model tanımlı değil); strong modeli mock (gerçek model tanımlı değil); model API anahtarı yok. Model kalitesi sınanmadı.
```

## Tüm testler

| Dosya | Test | Sonuç |
| --- | --- | --- |
| b_core.test.ts | [T5] eşzamanlı 20 rezervasyon (her biri 400 TL) aylık 5.000 TL hedefini aşamaz | ✓ |
| b_core.test.ts | [T5] iki markanın giderleri aynı toplam sınıra sayılır | ✓ |
| b_core.test.ts | [T5] bilinmeyen fiyat ve bilinmeyen kur engellenir, sıfır sayılmaz | ✓ |
| b_core.test.ts | uyarılar %70 ve %90 eşiklerinde üretilir; uzlaştırma iki kez deftere yazılmaz | ✓ |
| b_core.test.ts | simülasyon fiyatı canlı kipte kullanılamaz | ✓ |
| b_core.test.ts | bütçe artışı kurucu kararı ister ve 10.000 TL kesin sınırı aşamaz | ✓ |
| b_core.test.ts | [T4] yetkisiz numara, süresi dolmuş, tekrarlı, yanlış nonce ve belirsiz yanıt yürütülmez | ✓ |
| b_core.test.ts | serbest metin tanımsız işlem yetkisine dönüşmez | ✓ |
| b_core.test.ts | [T2-çekirdek] aynı idempotency anahtarı ikinci görevi oluşturmaz; döngü algılanır | ✓ |
| b_core.test.ts | [T7-çekirdek] marka durdurması kuyruktaki işleri kapsar; yeniden başlatma kurucu ister | ✓ |
| b_core.test.ts | [T1-çekirdek] RLS: bir markanın oturumu diğer markanın kayıtlarını göremez/yazamaz | ✓ |
| b_core.test.ts | denetçi rolü müşteri/yayın/maliyet kayıtlarını değiştiremez | ✓ |
| b_core.test.ts | uygulama rolü maliyet defterini ve olay günlüğünü değiştiremez; zincir bütün | ✓ |
| b_core.test.ts | [T12-çekirdek] bilgi sürümlenir, geri alınır; politika ajan tarafından değiştirilemez; süresi geçen bilgi bağlama girmez | ✓ |
| b_core.test.ts | markalar arası yalnız kişisel veri içermeyen özet paylaşılır ve hedef markada hipotez olur | ✓ |
| c_agents.test.ts | strateji rolü şemaya uygun plan üretir; kanıtsız öncelik hipotez olarak işaretlenir | ✓ |
| c_agents.test.ts | [T8] sahte referans, kanıtsız başarı oranı ve kesin teslim vaadi engellenir | ✓ |
| c_agents.test.ts | [T1/T8] marka karışması tespit edilir | ✓ |
| c_agents.test.ts | [T8] dış içerikteki talimat girişimi bağlamdan çıkarılır ve kaydedilir | ✓ |
| c_agents.test.ts | geçersiz model çıktısı görev başına 6 çağrı sınırında durur | ✓ |
| c_agents.test.ts | aynı işletme iki kez aday olmaz; iletişim istemeyenler tüm kampanyalarda uygulanır | ✓ |
| c_agents.test.ts | mükerrer ilk temas engellenir; nitelikli fırsat bilinmeyenleri taşır; doğrulanmamış gelir kampanyaya bağlanamaz | ✓ |
| c_agents.test.ts | [T9] az veride kesin hüküm verilmez; saat denemesi format karıştırıcısı ister | ✓ |
| c_agents.test.ts | [ekilmiş hata] denetçi çift yayın, sahte referans ve iletişim tercihi ihlalini bulur, ikinci doğrulamayla durdurur | ✓ |
| d_integrations.test.ts | [T2] aynı yayın olayı iki kez gelirse tek kayıt ve tek uzak gönderi olur | ✓ |
| d_integrations.test.ts | [T3] zaman aşımında yayın tekrar gönderilmez; uzlaştırma uzak kaydı bulur | ✓ |
| d_integrations.test.ts | [T3] istek hiç ulaşmadıysa uzlaştırma "başarısız" der ve otomatik yeniden göndermez | ✓ |
| d_integrations.test.ts | [T11] kota hatası bağlantıyı "degraded" yapar; sonraki yayın manuel göreve düşer; erişim iptali uyarı üretir | ✓ |
| d_integrations.test.ts | [T7] kanal durdurması kuyruktaki yayını yürütmez | ✓ |
| d_integrations.test.ts | [T6] anahtar yokken / simülasyon kipinde gerçek HTTP isteği yapılamaz | ✓ |
| d_integrations.test.ts | webhook doğrulama, imza, tekrar önleme ve buton kararı | ✓ |
| d_integrations.test.ts | [T4] yetkisiz numaradan gelen buton yanıtı karar yürütmez | ✓ |
| d_integrations.test.ts | bildirim aynı anahtarla iki kez gitmez; WhatsApp yoksa e-posta yedeği bir kez çalışır; "okundu" karar değildir | ✓ |
| d_integrations.test.ts | kurucu token olmadan API erişimi yok; erişim günlüğe yazılır; canlıya geçiş doğrulama ister | ✓ |
| e_acceptance.test.ts | KT-01 İki markanın veri, anahtar, rapor ve kuyruğu karışmaz | ✓ |
| e_acceptance.test.ts | KT-02 Aynı olay/görev iki kez geldiğinde çift yayın/mesaj olmaz | ✓ |
| e_acceptance.test.ts | KT-03 Belirsiz dış işlem sonucu tekrar gönderilmeden uzlaştırılır | ✓ |
| e_acceptance.test.ts | KT-04 Yetkisiz, süresi dolmuş veya tekrarlı WhatsApp kararı yürütülmez | ✓ |
| e_acceptance.test.ts | KT-05 Eşzamanlı gider rezervasyonları bütçeyi aşamaz; bilinmeyen fiyat engellenir | ✓ |
| e_acceptance.test.ts | KT-06 Anahtar yokken mock çalışır ve gerçek dış işlem yapılamaz | ✓ |
| e_acceptance.test.ts | KT-07 Durdurma çalışan ve kuyruktaki işleri kapsar | ✓ |
| e_acceptance.test.ts | KT-08 Yanlış vaat, sahte referans ve prompt injection tespit edilir/engellenir | ✓ |
| e_acceptance.test.ts | KT-09 Az veya eksik veride kesin performans hükmü verilmez | ✓ |
| e_acceptance.test.ts | KT-10 Ham olaydan rapora ve denetim bulgusuna kanıt izi bulunur | ✓ |
| e_acceptance.test.ts | KT-11 Bağlantı iptali, kota hatası ve webhook tekrarı doğru ele alınır | ✓ |
| e_acceptance.test.ts | KT-12 Öğrenme değişikliği sürümlenir ve geri alınır | ✓ |
| e_acceptance.test.ts | KT-13 Kişisel veri silme ve yedekten geri yükleme senaryosu çalışır | ✓ |
| e_acceptance.test.ts | KT-14 Kaynağı belirsiz gelir ve mock sonuç canlı başarı olarak raporlanmaz | ✓ |
| e_acceptance.test.ts | Senaryo 2 (uçtan uca): müşteri adayından görüşme fırsatına ve kurucu kararına | ✓ |
| f_v2.test.ts | V2-01 günlük tetikleme fixture araştırmayı çağırır; kaynaklı aday üretip CRM'e taşır | ✓ |
| f_v2.test.ts | V2-02 aynı kaynak/işletmenin yeniden keşfi mükerrer aday ve ilk temas üretmez | ✓ |
| f_v2.test.ts | V2-03 kanıtsız ihtiyaç/iletişim uydurulmaz; araştırma engeli rapora yansır | ✓ |
| f_v2.test.ts | V2-04 müşteri geliştirme ve kampanya görevleri günlük döngüde gerçekten yürütülür | ✓ |
| f_v2.test.ts | V2-05 izinli test kanalından gelen yanıt fırsata ve kurucu kararına dönüşür; tekrar yanıt mükerrer işlem üretmez | ✓ |
| f_v2.test.ts | V2-06 manuel gönderim/yanıt kaydı zinciri doğru devam ettirir; taslak gönderilmiş sayılmaz | ✓ |
| f_v2.test.ts | V2-07 strateji girdisi ölçüm, denetim, maliyet ve CRM özetlerini içerir; marka izolasyonu korunur | ✓ |
| f_v2.test.ts | V2-08 farklı performans kanıtı planı gerekçeli değiştirir; bilinmeyen veri sonuç uydurtmaz | ✓ |
| f_v2.test.ts | V2-09 onaylanmış deney kuralı sonraki zamanlamayı değiştirir; geri alma eski davranışı getirir | ✓ |
| f_v2.test.ts | V2-10 sahte saatle: planlanan saatten önce yayın çağrısı yok; saat gelince bir kez | ✓ |
| f_v2.test.ts | V2-11 iki worker, çökme ve yeniden başlama: doğru sahiplenme, yayımlanmış işi tekrar göndermez | ✓ |
| f_v2.test.ts | V2-12 geçici hata zamanında yeniden denenir; kalıcı hata ve sınır aşımı hata kuyruğuna gider | ✓ |
| f_v2.test.ts | V2-13 belirsiz yayın sonucu kör tekrar yerine uzlaştırmaya gider; geç/tekrar callback doğru işlenir | ✓ |
| f_v2.test.ts | V2-14 bütçe, kredi bitişi, fiyat bilinmemesi ve durdurma yeni dış çağrı yollarında uygulanır | ✓ |
| f_v2.test.ts | V2-15 talimat enjeksiyonu, SSRF ve marka sızıntısı saldırı örnekleri engellenir | ✓ |
| f_v2.test.ts | V2-16 16 günlük fixture senaryosu araştırmadan plana, zamanlı yayına, ölçüme, öğrenmeye ve değişen davranışa ulaşır | ✓ |
| f_v2.test.ts | V2-17 ikinci senaryo keşiften yanıta, fırsata ve kurucu kararına ulaşır; tüm fixture veriler ÖRNEK işaretli | ✓ |
| f_v2.test.ts | V2-18 gerçek model kalite değerlendirmesi ayrı komutla çalışır; anahtar yokken açık bekleyen durumu verir | ✓ |
| g_review.test.ts | R-01 belirsiz sonuç (5xx/zaman aşımı) "sending" kaydında kalır; yeniden denemede tekrar gönderilmez, doğrulama görevi açılır | ✓ |
| g_review.test.ts | R-02 kesin hata (4xx) "failed" olur ve yeniden denenebilir; başarılı denemede tek kayıt "sent" olur | ✓ |
| g_review.test.ts | R-03 yan etki sırasında çökme: kira kaybı sinyali varsa dış çağrı yapılmaz; sonraki deneme kör tekrar yerine doğrulamaya gider | ✓ |
| g_review.test.ts | R-04 büyük harfli Türkçe "İSTEMİYORUM" iletişim yasağına dönüşür (tr-TR küçük harf) | ✓ |
| g_review.test.ts | R-05 aynı yanıt için sınıflandırma ikinci kez çalışsa da ikinci fırsat/karar açılmaz | ✓ |
| g_review.test.ts | R-06 şehir Türkçe kelime sınırıyla, telefon 0/+90 önekiyle ve yazıldığı biçimde çıkarılır | ✓ |
| g_review.test.ts | R-07 yalnız işletmenin kendi alan adındaki e-posta doğrulanmış kişi olur; üçüncü taraf adres kişi yapılmaz | ✓ |
| g_review.test.ts | R-08 IPv6 özel/tünel/ayrılmış biçimleri ve DNS rebinding reddedilir; küresel adresler kabul edilir | ✓ |
| g_review.test.ts | R-09 robots.txt: kendi ajan grubu öncelikli, ardışık User-agent tek grup, en uzun eşleşme ve Allow | ✓ |
| g_review.test.ts | R-10 çalışma sırasında verilen durdurma sonraki aramayı ve sayfa okumayı keser | ✓ |
| g_review.test.ts | R-11 canlı deney simülasyon zamanlamasını (veya tersi) etkilemez | ✓ |
| g_review.test.ts | R-12 eski worker kira kaybından sonra durum yazamaz; uzun işte kira kaybı handler'a iptal sinyali olarak ulaşır | ✓ |
| g_review.test.ts | R-13 manuel yanıt uç noktası başka markanın adayını kabul etmez | ✓ |
| g_review.test.ts | R-14 gelen yanıt ve sınıflandırma görevi aynı işlemde; yeniden teslim eksik görevi tamamlar, çift görev açmaz | ✓ |
| g_review.test.ts | R-15 yalnız e-posta kanalı durdurulduğunda ilk temas engellenir, diğer kanallar etkilenmez | ✓ |
| h_v21.test.ts | M-01 yetkisiz ölçüm girişi ve imzasız webhook reddedilir | ✓ |
| h_v21.test.ts | M-02 başka markanın yayınına ölçüm yazılamaz (API ve webhook) | ✓ |
| h_v21.test.ts | M-03 geçersiz değer, eksik kanıt, gelecek zaman ve ÖRNEK yayın reddedilir; eksik değer sıfır sayılmaz | ✓ |
| h_v21.test.ts | M-04 aynı ölçümün tekrar teslimi örnek sayısını şişirmez (webhook teslim kimliği ve aynı içerik) | ✓ |
| h_v21.test.ts | M-05 kümülatif güncelleme: yeni anlık görüntü günceli değiştirir, eski geç gelen tarihçeye düşer, örnek sayısı değişmez | ✓ |
| h_v21.test.ts | M-06 gerçek ölçüm doğru deney koluna bağlanır; aynı gönderinin birden çok ölçümü tek örnek sayılır; strateji bağlamına ulaşır | ✓ |
| h_v21.test.ts | M-07 n8n akışındaki imzalama kodu servisin kabul ettiği gövdeyi üretir; aynı öğe ikinci kez gönderilince tekrar sayılır (n8n çalıştırılmadan, kod düğümü Node ile çalıştırıldı) | ✓ |
| h_v21.test.ts | K-01 aynı markada örnek ve gerçek veri: canlı strateji bağlamı yalnız gerçek veriyi, örnek bağlam yalnız örneği görür | ✓ |
| h_v21.test.ts | K-02 kip bilinmeyen eski kayıt canlı sayılmaz; yeni kayıt kip belirtmeden yazılamaz | ✓ |
| h_v21.test.ts | K-03 aynı gün simülasyondan canlıya geçişte canlı kök görev ayrı açılır, örnek görev canlı worker tarafından alınmaz | ✓ |
| h_v21.test.ts | K-04 bekleyen örnek gönderim görevi, e-posta bağlantısı canlıyken bile canlı kanaldan yürütülmez | ✓ |
| h_v21.test.ts | K-05 örnek araştırma önbelleği canlı süreçte kullanılmaz | ✓ |
| h_v21.test.ts | K-06 canlı görev örnek kampanyaya, örnek adaya veya örnek kanıta bağlanmaz | ✓ |
| h_v21.test.ts | K-07 kalite değerlendirmesi operasyon görevlerini ve müşteri/performans verisini kirletmez | ✓ |
| h_v21.test.ts | O-01 "İSTEMİYORUM": model çağrılmadan yanıtla aynı işlemde iletişim yasağı, aday kaybı ve bekleyen takiplerin iptali | ✓ |
| h_v21.test.ts | O-02 model anahtarı yok / model hatası / bütçe dolu iken de açık ret kaydedilir | ✓ |
| h_v21.test.ts | O-03 belirsiz ifade kesin ret sayılmaz; mevcut sınıflandırma yoluna gider | ✓ |
| h_v21.test.ts | O-04 açık ret yanıtının tekrar teslimi yeni fırsat, karar veya çelişkili durum üretmez | ✓ |
| h_v21.test.ts | O-05 Türkçe karakterle başlayan çekince ("önce") kelime sınırında tanınır: "Fiyat istemiyorum, önce demo" ret sayılmaz; açık retler korunur | ✓ |
| h_v21.test.ts | B-01 dış çağrı öncesi engel (fiyat bilinmiyor, egress engeli) rezervasyonu bırakır veya hiç açmaz | ✓ |
| h_v21.test.ts | B-02 sağlayıcı isteği aldıktan sonra zaman aşımı: rezervasyon "belirsiz" kalır, toplamda sayılır, kurucuya uzlaştırma işi açılır | ✓ |
| h_v21.test.ts | B-03 belirsiz sunucu hatası (5xx) belirsiz; kesin ret (4xx) ücretlenmedi sayılıp bırakılır | ✓ |
| h_v21.test.ts | B-04 tekrar denenen her çağrı ayrı izlenir; tekrarlı uzlaştırma iki kez gider yazmaz | ✓ |
| h_v21.test.ts | B-05 aynı desen model çağrısında: 5xx belirsiz kalır, 4xx bırakılır | ✓ |
| h_v21.test.ts | B-06 aynı sınıflandırma tüm ücretli adaptörlerde: Brave/Anthropic/OpenAI hata biçimleri ve WhatsApp şablon sonucu | ✓ |

## Ajan değerlendirme seti (deterministik koruma katmanı, mock)

```
✓ kaynakli-teklif-anlatimi → ok
✓ kanitsiz-ozellik-reddi → readiness_overclaim, offer_not_sellable
✓ sahte-referans-reddi → fake_reference
✓ kanitsiz-basari-orani → unverified_success_claim
✓ fiyat-ve-teslim-taahhudu → delivery_commitment, price_commitment
✓ gecmis-kurum → legacy_institution
✓ ihtiyaca-uygun-mesaj → ok
✓ genel-toplu-mesaj → generic_message, need_not_addressed, template_phrasing
✓ yanlis-strateji-hipotezi → unsupported_priority, unknown_evidence_ref, unsourced_finding
✓ kotu-niyetli-dis-talimat → prompt_injection
✓ kotu-niyetli-dis-talimat-tr → prompt_injection
✓ zararsiz-dis-icerik → ok
✓ marka-karismasi → brand_mixing

13/13 · Deterministik koruma katmanı değerlendirmesi (mock). Gerçek model çıktısı değerlendirmesi değildir.
```

## n8n JSON doğrulaması

```
✓ bays-email-fallback.json: 4 node kontrol edildi
✓ bays-email-inbound.json: 3 node kontrol edildi
✓ bays-linkedin-adapter.json: 6 node kontrol edildi
✓ bays-linkedin-status.json: 4 node kontrol edildi
✓ bays-metrics-push.json: 4 node kontrol edildi
✓ bays-scheduler.json: 9 node kontrol edildi

n8n-nodes-base 2.43.2 ile 30 node doğrulandı; hata: 0
```
