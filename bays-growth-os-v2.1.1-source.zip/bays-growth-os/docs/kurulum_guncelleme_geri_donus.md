# Kurulum, güncelleme (V1 → V2 → V2.1) ve geri dönüş rehberi

Bu rehberdeki komutların hepsi bu teslimde **yerel PostgreSQL 16 + Node 22** ile gerçekten çalıştırıldı (14.10.2026). Docker imajları bu ortamda çekilemediği için (Docker Hub 403) `docker compose up` **çalıştırılmadı**; yalnız `docker compose config` ile yapı doğrulandı. Sizin sunucunuzda ilk iş Docker yolunu denemek olmalı.

Üç kip birbirinden ayrıdır ve komutları da ayrıdır:

| Kip | Ne yapar | Dış ağ |
|---|---|---|
| `RUN_MODE=simulation` (varsayılan) | Mock model, fixture araştırma, mock LinkedIn/WhatsApp/e-posta. Tüm kayıtlar ÖRNEK işaretli. | Hiç yok (küresel fetch koruması) |
| `RUN_MODE=eval` | Yalnız gerçek model kalite değerlendirmesi. Yayın, mesaj, araştırma çağrısı engelli. | Yalnız model sağlayıcısı |
| `RUN_MODE=live` + `EGRESS_ENABLED=true` | Bağlantısı `live` olan adaptörler dışarı çıkabilir. Her dış çağrıdan önce bütçe ve durdurma denetlenir. | Yalnız `live` adaptörlerin izinli hostları |

## 1. Temiz kurulum

### Docker ile (önerilen, sizin sunucunuzda denenmeli)
```bash
unzip bays-growth-os-v2.zip && cd bays-growth-os
cp .env.example .env            # en az: 3 DB parolası, N8N_SHARED_SECRET, FOUNDER_TOKEN_SHA256
docker compose up -d --build    # postgres + app (API/panel) + worker + n8n
docker compose logs -f worker   # "[zamanlayıcı] tetiklendi: daily-plan" ve görev satırları
docker compose exec app npx tsx src/cli.ts simulate   # 16 günlük ÖRNEK senaryo
```
Panel: `http://SUNUCU:8080/panel` · n8n: `http://SUNUCU:5678`

### Docker olmadan (bu teslimde doğrulanan yol)
```bash
npm ci
export DATABASE_URL_OWNER=postgres://postgres:PAROLA@localhost:5432/bays
export DATABASE_URL_APP=postgres://bays_app:PAROLA@localhost:5432/bays
export DATABASE_URL_AUDITOR=postgres://bays_auditor:PAROLA@localhost:5432/bays
npm run typecheck
npm run migrate && npm run seed
npm run worker                  # sürekli worker (SCHEDULER=on ile 08:00/20:00/Pazar takvimi kendisi)
npm start                       # ayrı terminalde API + panel
```

### Temiz klasör sınaması — bu teslimde gerçekten çalıştırılan sıra
| Adım | Komut | Sonuç |
|---|---|---|
| Aç | `unzip` (node_modules, .cache, .env yok) | 3,0 MB |
| Bağımlılık | `npm ci` | 0 güvenlik açığı |
| Tür denetimi | `npx tsc --noEmit` | hata yok |
| Göç | `npm run migrate` (boş veritabanı) | 001, 002, 003 uygulandı |
| Seed | `npm run seed` | 4 marka (yalnız BaysSystems aktif) |
| Worker | `SCHEDULER=on node --import tsx src/cli.ts worker` (40 sn, sonra SIGTERM) | Zamanlayıcı daily-plan'ı tetikledi; 12 görev `done` (araştırma → 3 aday → strateji → 3 temas → kampanya → içerik → zamanlama); `publish_due` ve 2 `follow_up_check` gelecek saate `queued`; SIGTERM'de "elindeki iş bitince çıkacak" → temiz çıkış |
| Test | `npx vitest run` | 82/82 geçti (V2); V2.1 temiz klasör sonucu için `docs/teslim_raporu_v21.md` |
| Simülasyon | `npm run sim:fresh` | Gün 16 yayın saati kuraldan geldi; Senaryo 2 kurucu kararına ulaştı |
| n8n | `npm run n8n:validate` | 26 node, 0 hata (n8n-nodes-base 2.43.2 tanımına karşı; **n8n'de çalıştırma değildir**) |

Not: `npx tsx … worker` ile başlatılan süreç SIGTERM'de npx tarafından erken öldürülüyordu; bu nedenle `npm run worker` ve Docker servisi `node --import tsx` kullanır.

## 2. V1 → V2 güncelleme (mevcut verinizi koruyarak)

V2 göçü (`003_v2.sql`) yalnız **ekler**: yeni tablolar, yeni sütunlar, iki genişletilmiş durum kısıtı. V1 verisi silinmez veya dönüştürülmez.

```bash
# 0) Worker/uygulama durdurun (V1'de worker yoktu; API'yi durdurmanız yeterli)
# 1) YEDEK — atlamayın
pg_dump "$DATABASE_URL_OWNER" -Fc -f bays_v1_$(date +%Y%m%d_%H%M).dump
# 2) V2 kodunu açın (.env'inizi koruyun) ve yeni değişkenleri .env'e ekleyin (bkz. .env.example "--- V2 ---")
npm ci
npm run migrate        # yalnız 003_v2.sql uygulanır
npm run seed           # idempotent; araştırma bağlantı satırları ve hizmet kartı alanları eklenir
npm run drain          # bekleyen iş varsa yürütür
npm run cycle:daily -- --drain   # bir günlük V2 zinciri
npm run worker         # sürekli çalıştırma
```

**Bu teslimde sınandı:** V1 ZIP'i ayrı veritabanında kuruldu, V1 simülasyonu çalıştırıldı (68 görev, 16 yayın, 2 aday). Ardından V2 kodu aynı veritabanına uygulandı: yalnız `003_v2.sql` çalıştı, V1'in 68 görevi, 16 yayını ve etkileşimleri korunarak kaldı; V2 günlük zinciri aynı veritabanında çalıştı (araştırma → aday → strateji → temas → içerik → zamanlama).

V1'den kalan dikkat noktaları:
- V1 etkileşimleri `recorded` durumundadır; V2 bunları da "temas yapılmış" sayar ve aynı adaya ikinci ilk temas açmaz (temkinli tercih).
- V1'de çalışan n8n zamanlayıcısı varsa ve worker'da da `SCHEDULER=on` ise aynı gün ikinci kez iş açılmaz (gün anahtarı). Yine de tek tetik kaynağı seçmeniz önerilir.

## 2b. V2 → V2.1 güncelleme

V2.1 göçü (`004_v21.sql`) veri silmez. Yaptığı değişiklikler:
- Ölçüm tablosuna güncel anlık görüntü ve teslim kimliği sütunlarını ekler.
- Kip bazlı tekillik kısıtları ve görev amacı (`purpose`) sütununu ekler.
- Belirsiz gider durumunu ekler.
- Kipi bilinmeyen eski kayıtları işaretler: veritabanında canlı işlem kanıtı yoksa `mode_unknown=true` olur.

```bash
pg_dump "$DATABASE_URL_OWNER" -Fc -f bays_v2_$(date +%Y%m%d_%H%M).dump   # YEDEK
npm ci
npm run migrate          # yalnız 004_v21.sql
npm run seed
npm run drain
npm run cycle:daily -- --drain
```
Kontrol için şu sorguyu çalıştırın: `SELECT value FROM settings WHERE key IN ('schema.version','migration.004.live_proof')`. Sonuç `"2.1"` ve `{"live_proof": false}` olmalı. `live_proof` true çıkarsa eski kayıtlar işaretlenmemiştir; kurucu gözden geçirmesi gerekir.

**Bu teslimde sınandı:**
- V2 ZIP'i ayrı veritabanında kuruldu ve V2 simülasyonu çalıştırıldı: 145 görev, 32 ölçüm, 3 aday, 16 araştırma çalıştırması ve canlı işaretli 33 denetim bulgusu oluştu. Bu bulgular V2'nin bir hatasıydı.
- Bu veritabanına V2.1 göçü uygulandı. Yalnız `004` çalıştı, `live_proof=false` çıktı. 33 bulgu "kipi bilinmeyen" olarak işaretlendi ve raporda ayrı gösterildi. 32 ölçümün tamamı güncel kaldı (yayın başına bir mock ölçüm vardı). Ardından V2.1 günlük döngüsü 6 görevi hatasız yürüttü.
- V1 kaynaklı veritabanı (V1 → V2) da V2.1'e taşındı.

## 2c. V2.1 → V2 geri dönüş

Tercih edilen yol, `004` öncesi yedeği geri yüklemektir:
`pg_restore --clean --if-exists -d "$DATABASE_URL_OWNER" bays_v2_….dump`

Yedek yoksa geri dönüş betiğini çalıştırın:
```bash
psql "$DATABASE_URL_OWNER" -v ON_ERROR_STOP=1 -f tools/rollback/004_v21_down.sql
```
Betiğin yaptıkları:
- Kip bazlı tekillikte çakışan örnek kayıtların anahtarına `:ornek` ekler.
- `uncertain` rezervasyonları `expired` yapar; V2 de bunları toplamda sayar.
- `reconcile_cost` işlerini `fix_bottleneck` olarak saklar.
- V2.1 sütunlarını kaldırır.

Ölçüm tarihçe satırları kalır, ama V2 bunları ayrı örnek sayar. Bu V2'nin bilinen davranışıdır.

**Bu teslimde sınandı:** V2.1'e güncellenmiş veritabanının kopyasına betik uygulandı. V2 kodu `migrate` (yeni göç yok), `drain` ve günlük raporu hatasız çalıştırdı. Ardından V2.1 kodu `004`'ü yeniden uyguladı; yukarı → aşağı → yukarı döngüsü çalışıyor.

## 3. Geri dönüş (V2 → V1)

**Tercih edilen yol: yedekten geri yükleme** (göç öncesi tam durum):
```bash
docker compose stop worker app     # veya yerel süreçleri durdurun
pg_restore --clean --if-exists -d "$DATABASE_URL_OWNER" bays_v1_YYYYMMDD_HHMM.dump
# V1 kodunu yeniden açıp başlatın
```
Not: Yedekten sonra yapılan kişisel veri silmelerini yeniden uygulamak için `npm run restore:reapply-erasures` (V1'den beri vardır).

**Yedek yoksa: şema geri dönüş betiği** `tools/rollback/003_v2_down.sql`
```bash
psql "$DATABASE_URL_OWNER" -v ON_ERROR_STOP=1 -f tools/rollback/003_v2_down.sql
```
- Siler: araştırma kayıtları, manuel işler, değerlendirme kayıtları (V2'ye özgü).
- Dönüştürür: `missed` yayınlar → `cancelled`; `running` görevler → `queued`.
- Korur: adaylar, kişiler, temaslar, yayınlar, görevler, bütçe, olay kaydı.

**Bu teslimde sınandı:** güncellenmiş veritabanının kopyasına betik uygulandı → V1 kodu `migrate` (yeni göç yok), günlük döngü ve günlük raporu hatasız çalıştırdı → ardından V2 kodu `003`'ü yeniden uyguladı (yukarı–aşağı–yukarı döngüsü çalışıyor).

## 4. Komutlar — kipe göre ayrılmış

### Simülasyon (dış işlem yok)
| Komut | İş |
|---|---|
| `npm run sim:fresh` | Veritabanını sıfırlar + 16 günlük senaryo (yalnız boş/test veritabanında) |
| `npm run simulate` | Mevcut veritabanında senaryo |
| `npm test` / `npm run test:report` | 82 test / `docs/test_raporu.md` |
| `npm run eval` | 13 deterministik koruma testi (adı "koruma seti"; model kalitesi değildir) |
| `npm run eval:quality` | 20 senaryoluk kalite seti, **mock sözleşme kipi** |

### Gerçek model değerlendirmesi (yalnız model çağrısı)
```bash
# .env: MODEL_STRONG / MODEL_ECONOMY / MODEL_JUDGE gerçek model, anahtar, config/pricing.json'da fiyat + kur
RUN_MODE=eval EGRESS_ENABLED=true npm run eval:quality:live
# karşılaştırma (uzmanlık rehberinin etkisi):
RUN_MODE=eval EGRESS_ENABLED=true EXPERTISE=off npm run eval:quality:live
```
Anahtar yoksa sonuç `BEKLEMEDE` olur ve `eval_runs` tablosuna öyle yazılır; "model kalitesi sınandı" denmez.

### Canlı (kurucu kararıyla, bağlantı bağlantı)
```bash
RUN_MODE=live EGRESS_ENABLED=true npm run worker
```
Canlıya geçiş yalnız `.env` değişikliği değildir: her bağlantı panelde `configured → verified → live` adımlarından geçer; müşteri e-postası ayrıca `CUSTOMER_EMAIL_LIVE=true` ister. Ayrıntı: `docs/canliya_gecis_kontrol_listesi.md`.

## 5. Durdurma ve yeniden başlatma
Bkz. `docs/pilot_raporlar_durdurma.md` §3.
