# V2.1 teslim raporu ve final hüküm

Tarih: 14.10.2026 · Paket: `bays-growth-os-v2.1.zip` · Sürüm: 2.1.1 (`package.json`, `/health`; şema sürümü `settings.schema.version` = 2.1, 2.1.1'de şema değişmedi)
Ortam: Node 22, PostgreSQL 16 (yerel), Docker yok.

## Dört bulgunun durumu

Ayrıntılar `docs/v21_duzeltme_matrisi.md` dosyasında. Her bulgu için önce regresyon testi yazıldı; bu testler düzeltmeden önce 22'nin 21'inde kırmızıydı, sonra düzeltme yapıldı.

| Bulgu | Kod tamam | Test ortamında doğrulandı | Canlı bağlantıda doğrulandı |
|---|---|---|---|
| 1. Gerçek ölçümlerin sisteme alınması (API, panel, imzalı n8n; doğrulama, tekrar teslim, kümülatif güncelleme, doğru deney kolu) | Evet | Evet — M-01…M-07 | Hayır. Gerçek LinkedIn ölçümü girilmedi. n8n akışı içe aktarılıp çalıştırılmadı; yalnız yapısı ve imza uyumu sınandı. Panel ekranı tarayıcıda denenmedi; API'si testli. |
| 2. Simülasyon, değerlendirme ve canlı ayrımı (bağlam, kanıt, aday, kampanya, manuel iş, önbellek, kuyruk, eski kayıt koruması) | Evet | Evet — K-01…K-07; V2 verili veritabanında göç | Hayır. Gerçek canlı veri yok. |
| 3. Açık iletişim reddi modelden önce (aynı işlemde yasak, kayıp, bekleyen işlerin iptali; idempotent; 2.1.1: Türkçe kelime sınırı) | Evet | Evet — O-01…O-05, R-04 | Hayır. Gerçek e-posta yanıtı alınmadı. |
| 4. Belirsiz ücretli çağrı uzlaştırması (araştırma, model, WhatsApp şablonu) | Evet | Evet — B-01…B-06 | Hayır. Gerçek sağlayıcı çağrısı ve fatura yok. WhatsApp şablon yolu yalnız sınıflandırma düzeyinde test edildi. |

## Gerçekten çalıştırılan doğrulamalar

| Komut | Sonuç |
|---|---|
| `npx tsc --noEmit` | Hata yok |
| `npm test` (2.1.1, geliştirme klasörü ve temiz klasör) | **107/107 geçti**: 49 V1 + 18 V2 + 15 V2 inceleme + 25 V2.1 |
| Temiz klasör: ZIP aç → `npm ci` → tsc → boş veritabanına `migrate` (001–004) → `seed` → worker 40 sn → `vitest` → `sim:fresh` | 0 güvenlik açığı. Worker zamanlayıcıyı tetikledi ve 12 görevi bitirdi; SIGTERM'de temiz çıktı. **107/107** test geçti (2.1.1 paketiyle yeniden yapıldı). Simülasyonda 16. günün yayın saati kuraldan geldi; Senaryo 2 kurucu kararına ulaştı. |
| `npm run eval` | 13/13. Bu koruma setidir, model kalitesini ölçmez. |
| `npm run eval:quality` | 20/20 mock sözleşme. **Model kalitesi değildir.** |
| `RUN_MODE=eval npm run eval:quality:live` | **BEKLEMEDE**: model anahtarı yok, EGRESS kapalı, modeller mock. |
| `npm run n8n:validate` | 30 düğüm, 0 hata. Yalnız yapı kontrolü; n8n'de çalıştırma değildir. |
| `docker compose config` | Geçerli. **`docker compose up` çalıştırılmadı**: Docker Hub erişimi bu ortamda 403. |
| `GET /health` | `{"ok":true,"mode":"simulation","version":"2.1.1"}` |
| V2 verili veritabanı → V2.1 göçü | Yalnız 004 uygulandı. `live_proof=false`. V2'nin canlı diye yazdığı 33 simülasyon denetim bulgusu "kipi bilinmeyen" olarak ayrıldı. Ardından V2.1 günlük döngüsü 6 görevi hatasız yürüttü. |
| V2.1 → V2 geri dönüş (`tools/rollback/004_v21_down.sql`) → yeniden V2.1 | V2 kodu migrate, drain ve raporu hatasız çalıştırdı; V2.1 göçü yeniden uygulandı. |
| V1 → V2 → V2.1 | Göç hatasız. |
| `npm run cost:estimate` | "Hesaplanamadı (3 kalemin fiyatı/kuru bilinmiyor)". Bilinmeyen sıfır sayılmadı. |

## Korunan kararlar

Beş ajan rolü, çoklu marka, n8n köprüsü, WhatsApp karar akışı, ücretli reklamın kapalı olması, 5.000 TL hedef / 10.000 TL kesin üst sınır, kurucu yetkileri, durdurma mekanizmaları ve LinkedIn mesaj/davetlerinin manuel kalması korundu. Kodda, test çıktısında ve ZIP'te anahtar yok; testlerdeki sırlar `*_not_real` yer tutucularıdır.

## Kalan sınırlar

- Canlı bağlantıların hiçbiri sınanmadı: LinkedIn yayını ve analizi, WhatsApp, SMTP/IMAP, Brave, model sağlayıcıları.
- LinkedIn analiz verisine erişiminiz doğrulanmadı. Ölçüm şimdilik elle ya da kendi n8n akışınızdan gelir.
- Açık ret ifade listesi kural tabanlı. Listede olmayan ifadeler model yoluna gider; model yokken bu yanıtlar sınıflandırılamaz ve görev yeniden denenir.
- Belirsiz giderin kesin tutarını kurucu sağlayıcı panelinden veya faturadan girer; otomatik fatura eşleştirmesi yok.
- Canlı işlem kanıtı olan bir veritabanında eski kayıtlar otomatik "kipi bilinmeyen" işaretlenmez; kurucu gözden geçirmesi gerekir.
- Bekleyen diğer kip görevleri silinmez veya iptal edilmez, yalnız yürütülmez ve raporda görünür.
- Test dosyası sırası sabitlendi, çünkü V2'den kalan bir test (KT-10) sıraya bağımlıydı.

**Müşteri ve gelir:** Simülasyondaki aday, yanıt, fırsat ve ölçüm sayıları ÖRNEK veridir. V2.1'in müşteri bulduğu veya gelir getireceği bu sonuçlardan çıkarılamaz.
