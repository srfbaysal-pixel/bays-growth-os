# Mimari ve veri modeli

## Bileşenler

```
 n8n 2.43.4 (zamanlayıcı, webhook, mevcut yayın akışları)
   │  imzalı HTTP (X-Bays-Signature, HMAC-SHA256)
   ▼
 TypeScript servis (Node 22, Fastify 5)  ──►  PostgreSQL 16 (RLS, ayrı roller, değişmez günlük)
   ├─ orchestrator/   günlük plan · akşam denetim/rapor · haftalık değerlendirme · müşteri hattı
   ├─ agents/         5 rol (sürümlü talimat + JSON şema) · koruma katmanı · mock/canlı sağlayıcı
   ├─ core/           görev kuyruğu · yetki · bütçe · durdurma · bilgi merkezi · karar · gizlilik · yedek
   ├─ crm/            aday · aşama · iletişim istemeyenler · fırsat · gelir
   ├─ learning/       deney · değerlendirme · kurala yükseltme / geri alma
   ├─ auditor/        bağımsız denetim (ayrı DB rolü, yalnız bulgu/durdurma yazar)
   ├─ integrations/   egress koruması · LinkedIn (mock/API/n8n) · WhatsApp Cloud · yetenek matrisi
   ├─ notify/         WhatsApp → e-posta (n8n) yedeği, dedupe
   ├─ reports/        günlük/haftalık rapor (mock ve canlı ayrı)
   └─ api/ + panel/   kurucu paneli (mobil, vanilla HTML/JS) · webhook uçları
```

Neden bu yapı: n8n yatırımı korunur (takvim, webhook, mevcut LinkedIn akışı); karar verilmesi gereken her şey (yetki, bütçe, idempotency, denetim) test edilebilir TypeScript servisindedir; kalıcı kayıt PostgreSQL'dedir. Mevcut repo paylaşılmadığı için göç/uyarlama gerekmedi; repo gelirse bu yapıya uyarlama raporu ayrıca hazırlanmalıdır.

## Akış (günlük)

08:00 `daily-plan`: araştırma kaydı (kaynak + geçerlilik süresi) → strateji ajanı (dış metin yalnız veri; talimat girişimi ayıklanır) → içerik ajanı → deterministik koruma (ihlalde tek düzeltme; olmazsa `blocked`) → dağıtım ajanı → yayın kuyruğu (idempotent) → adaptör.
20:00 `daily-report`: belirsiz yayın uzlaştırma → denetim (+ önemli bulguda ikinci görüş) → deney değerlendirme → rapor → WhatsApp (yedek e-posta).
Pazar 20:00 `weekly-review`: haftalık rapor (deneyler, bilgi değişiklikleri, darboğazlar).

Her adım bir **görev**dir: `(marka, idempotency_key)` benzersiz; aynı tetik ikinci kez gelirse iş yeniden yapılmaz. Görev başına ≤6 model çağrısı, geçici hatada ≤3 deneme, üstel bekleme, hata kuyruğu, aynı parmak izinde 24 saatte >3 görevde döngü algılama.

## Güvenlik modeli

| Katman | Uygulama |
| --- | --- |
| Marka izolasyonu | Tüm marka tablolarında RLS: oturumda `app.brand_id`. Sistem işleri (`app.scope=system`) yalnız bütçe toplamı, global durdurma/rapor için. Gizli değerler `BRAND_<SLUG>_*` adıyla yalnız ilgili markaya okunur. |
| Roller | `bays_app`: maliyet defteri ve olay günlüğüne yalnız ekleme; denetim bulgusunu yazamaz. `bays_auditor`: her şeyi okur; yalnız bulgu, durdurma, olay yazar. Migration sahibi ayrı. |
| Günlük bütünlüğü | `operation_events` her satırda önceki satırın özetini taşır (tetikleyici); denetçi zinciri doğrular. |
| Dış çıkış | `egressFetch`: RUN_MODE=live + EGRESS_ENABLED=true + adaptör `live` + anahtar + izinli host olmadan istek yok. Global `fetch` da kilitli. |
| Webhook | WhatsApp: ham gövde üzerinden HMAC-SHA256 (App Secret), sabit zamanlı karşılaştırma, mesaj kimliğiyle tekrar önleme. n8n: paylaşılan sırla HMAC. |
| Kurucu girişi | Bearer token; sunucuda yalnız SHA-256 özeti. Tüm API çağrıları `access_log`'a (IP özetlenmiş). |
| Kişisel veri | Silme: alanlar boşaltılır, etkileşim içeriği karartılır, özet iletişim istemeyenlere eklenir, veritabanı dışı silme kaydı tutulur (geri yüklemede yeniden uygulanır). Saklama: kayıp/beklemedeki adaylarda 365 gün (yapılandırılabilir). |

Bilinen sınır: RLS, uygulama kodunun oturum ayarına dayanır; `bays_app` rolüyle bağlanan kod `app.scope=system` ayarlayabilir. Bu, kod hatalarına karşı ikinci katmandır, kötü niyetli koda karşı değil.

## Bütçe

Hedef 5.000 TL (`BUDGET_TARGET_TRY`), kesin üst sınır 10.000 TL (`BUDGET_HARD_CAP_TRY`). Aktif sınır yalnız onaylı `budget.change_limit` kurucu kararıyla değişir ve üst sınırı aşamaz; üst sınırın kendisi ajan/panelle değiştirilemez (yetki tablosunda `forbidden`). Rezervasyon: ay+kip için danışma kilidi altında `gerçekleşen + uzlaştırılmamış rezervasyon + yeni tahmin ≤ sınır`. Uyarılar %70/%90. Canlı kipte günlük pilot sınırı ayrıca. Süresi dolan rezervasyon toplamda sayılmaya devam eder (temkinli). Simülasyon gideri ayrı havuzdadır ve raporda "gerçek gider değil" yazılır.

## Veri modeli

Asgari 23 tablo (şartname §5) + yardımcılar. Ayrıntı: `migrations/001_core.sql`.

| Tablo | Amaç | Önemli alanlar |
| --- | --- | --- |
| brands / brand_profiles | Marka ve sürümlü profil | status (active/draft/disabled), profile jsonb |
| offers | Hizmet kaydı | readiness: user_declared · demo · test_verified · in_development · not_for_sale |
| evidence | Kanıt (kaynak URL, test, ölçüm, kurucu beyanı) | uri, valid_until, is_sample |
| knowledge_versions | Bilgi merkezi | kind: raw_research · hypothesis · verified_rule · policy · shared_method_summary; version, validity, source |
| campaigns / tasks / assets | Kampanya, görev, üretilen içerik | idempotency_key, model_calls, guard_result |
| publications | Yayın | status (queued/sending/outcome_unknown/published/failed/manual_required/halted), is_simulated, external_id |
| leads / contacts / interactions | CRM | stage (11 aşama), business_key (mükerrer önleme), erased_at |
| meetings / opportunities | Görüşme ve fırsat | unknowns, attribution, revenue_verified_by_founder |
| experiments / metrics | Deney ve ölçüm | sample_condition (gerekçeli), source (mock/live/manual/n8n) |
| audit_findings | Denetim bulguları | severity, evidence_refs, second_review, halt_id |
| approval_requests | Kurucu kararları | code, nonce, options, expires_at |
| cost_ledger / budget_reservations | Gider defteri ve rezervasyon | mode (live/simulation), fx kaynağı/tarihi |
| channel_connections | Bağlantılar | status (disconnected/mock/configured/verified/live/degraded), capabilities |
| suppression_entries | İletişim istemeyenler | key_hash, scope (brand/all_brands) |
| operation_events | Değişmez işlem günlüğü | prev_hash, hash |
| agent_runs, inbound_webhooks, outbound_notifications, erasure_log, access_log, settings, halts | Yardımcı | — |

## Beş rol

| Rol | Sürüm | Model kademesi | Araç izinleri | Çıktı şeması |
| --- | --- | --- | --- | --- |
| Strateji ve koordinasyon | strategy.v1 | güçlü | research.sourced, draft.create, experiment.start | weekly_plan, audience, daily_tasks, campaign_brief, experiment, findings |
| Marka ve içerik | content.v1 | ekonomik | draft.create | post_text, hashtags, image_brief, video_script, claims_used |
| Kampanya ve dağıtım | distribution.v1 | ekonomik | publish.routine | schedule, manual_tasks, experiment_arm |
| Müşteri geliştirme | customer_dev.v1 | ekonomik | classify, draft.create, contact.first, reply.routine | lead_assessment, outreach, reply_classification, handoff |
| Bağımsız iç denetim | auditor.v1 | güçlü | report.generate | findings (darboğaz alanıyla), halt_recommendation |

Talimatlar ve şemalar: `src/agents/roles.ts`. Değerlendirme vakaları: `evals/cases.json`. Aynı sağlayıcının farklı rollerde çalışması tam bağımsızlık değildir; bu yüzden denetim deterministik kontrollerle ve ham kayıttan ikinci sorguyla yapılır, model görüşü ek katmandır.
