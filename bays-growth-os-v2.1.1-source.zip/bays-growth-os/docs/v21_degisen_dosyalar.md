# V2 → V2.1 karşılaştırması: değişen dosyalar ve eklenen testler

Karşılaştırma: `bays-growth-os-v2.zip` (V2) ile bu paket. Komut: `diff -rq` (node_modules, .cache, reports hariç). Tarih: 14.10.2026.

## Yeni dosyalar

- `docs/teslim_raporu_v21.md`
- `docs/v21_degisen_dosyalar.md`
- `docs/v21_duzeltme_matrisi.md`
- `migrations/004_v21.sql`
- `n8n/bays-metrics-push.json`
- `src/core/callOutcome.ts`
- `src/crm/optout.ts`
- `src/metrics/ingest.ts`
- `tests/h_v21.test.ts`
- `tools/rollback/004_v21_down.sql`

## Değişen dosyalar

- `README.md`
- `docs/canliya_gecis_kontrol_listesi.md`
- `docs/eksik_baglantilar.md`
- `docs/kurulum_guncelleme_geri_donus.md`
- `docs/n8n_adaptor_sozlesmesi.md`
- `docs/pilot_raporlar_durdurma.md`
- `docs/test_raporu.md`
- `package-lock.json`
- `package.json`
- `panel/index.html`
- `src/agents/providers.ts`
- `src/agents/runner.ts`
- `src/agents/strategyContext.ts`
- `src/api/server.ts`
- `src/auditor/auditor.ts`
- `src/core/budget.ts`
- `src/core/tasks.ts`
- `src/crm/crm.ts`
- `src/crm/manual.ts`
- `src/crm/outreach.ts`
- `src/evals/quality.ts`
- `src/integrations/whatsapp.ts`
- `src/learning/experiments.ts`
- `src/notify/notifier.ts`
- `src/orchestrator/chain.ts`
- `src/research/providers.ts`
- `src/research/research.ts`
- `src/worker/worker.ts`
- `tests/g_review.test.ts`
- `tools/build-n8n.mjs`
- `tools/test-report.mjs`
- `vitest.config.ts`

## Eklenen testler (tests/h_v21.test.ts, 25 test)

- M-01 yetkisiz ölçüm girişi ve imzasız webhook reddedilir
- M-02 başka markanın yayınına ölçüm yazılamaz (API ve webhook)
- M-03 geçersiz değer, eksik kanıt, gelecek zaman ve ÖRNEK yayın reddedilir; eksik değer sıfır sayılmaz
- M-04 aynı ölçümün tekrar teslimi örnek sayısını şişirmez (webhook teslim kimliği ve aynı içerik)
- M-05 kümülatif güncelleme: yeni anlık görüntü günceli değiştirir, eski geç gelen tarihçeye düşer, örnek sayısı değişmez
- M-06 gerçek ölçüm doğru deney koluna bağlanır; aynı gönderinin birden çok ölçümü tek örnek sayılır; strateji bağlamına ulaşır
- M-07 n8n akışındaki imzalama kodu servisin kabul ettiği gövdeyi üretir; aynı öğe ikinci kez gönderilince tekrar sayılır (n8n çalıştırılmadan, kod düğümü Node ile çalıştırıldı)
- K-01 aynı markada örnek ve gerçek veri: canlı strateji bağlamı yalnız gerçek veriyi, örnek bağlam yalnız örneği görür
- K-02 kip bilinmeyen eski kayıt canlı sayılmaz; yeni kayıt kip belirtmeden yazılamaz
- K-03 aynı gün simülasyondan canlıya geçişte canlı kök görev ayrı açılır, örnek görev canlı worker tarafından alınmaz
- K-04 bekleyen örnek gönderim görevi, e-posta bağlantısı canlıyken bile canlı kanaldan yürütülmez
- K-05 örnek araştırma önbelleği canlı süreçte kullanılmaz
- K-06 canlı görev örnek kampanyaya, örnek adaya veya örnek kanıta bağlanmaz
- K-07 kalite değerlendirmesi operasyon görevlerini ve müşteri/performans verisini kirletmez
- O-01 "İSTEMİYORUM": model çağrılmadan yanıtla aynı işlemde iletişim yasağı, aday kaybı ve bekleyen takiplerin iptali
- O-02 model anahtarı yok / model hatası / bütçe dolu iken de açık ret kaydedilir
- O-03 belirsiz ifade kesin ret sayılmaz; mevcut sınıflandırma yoluna gider
- O-04 açık ret yanıtının tekrar teslimi yeni fırsat, karar veya çelişkili durum üretmez
- O-05 (2.1.1) Türkçe karakterle başlayan çekince ("önce") kelime sınırında tanınır: "Fiyat istemiyorum, önce demo" ret sayılmaz; açık retler korunur
- B-01 dış çağrı öncesi engel (fiyat bilinmiyor, egress engeli) rezervasyonu bırakır veya hiç açmaz
- B-02 sağlayıcı isteği aldıktan sonra zaman aşımı: rezervasyon "belirsiz" kalır, toplamda sayılır, kurucuya uzlaştırma işi açılır
- B-03 belirsiz sunucu hatası (5xx) belirsiz; kesin ret (4xx) ücretlenmedi sayılıp bırakılır
- B-04 tekrar denenen her çağrı ayrı izlenir; tekrarlı uzlaştırma iki kez gider yazmaz
- B-05 aynı desen model çağrısında: 5xx belirsiz kalır, 4xx bırakılır
- B-06 aynı sınıflandırma tüm ücretli adaptörlerde: Brave/Anthropic/OpenAI hata biçimleri ve WhatsApp şablon sonucu

## V2 testlerinde yapılan değişiklikler

Ayrıntı ve gerekçe: `docs/v21_duzeltme_matrisi.md` → "Testlerde yapılan değişiklikler". Hiçbir test kaldırılmadı, hiçbir beklenti gevşetilmedi.
