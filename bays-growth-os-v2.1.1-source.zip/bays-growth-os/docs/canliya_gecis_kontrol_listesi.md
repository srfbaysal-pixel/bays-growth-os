# Canlıya geçiş kontrol listesi (sınırlı pilot)

Kod teslimi canlıya geçiş değildir. Her madde işaretlenmeden `RUN_MODE=live` yapmayın.

## A. Bağımsız inceleme
- [ ] `docs/teslim_raporu_v2.md` ve `docs/v2_duzeltme_matrisi.md` → "Kalan sınır" sütunları okundu, kabul edildi
- [ ] Kod incelemesi ikinci bir geliştirici veya ayrı bir inceleme oturumuyla tekrarlandı
- [ ] `npm test` sizin ortamınızda 107/107 geçti; `npm run n8n:validate` hata vermedi
- [ ] V1/V2 verisi varsa: göç öncesi `pg_dump` alındı; `docs/kurulum_guncelleme_geri_donus.md` §2/§2b uygulandı; `migration.004.live_proof` değeri gözden geçirildi

## B. Altyapı
- [ ] `docker compose up --build` sizin sunucunuzda çalıştı; `/health` → `{"ok":true,"mode":"simulation","version":"2.1.1"}`; `docker compose logs worker` görev satırları gösteriyor; `docker compose stop worker` temiz çıkış yaptı
- [ ] HTTPS ve geçerli sertifika (WhatsApp webhook şartı); panel yalnız HTTPS üzerinden
- [ ] PostgreSQL ve n8n portları dışarı kapalı (compose yalnız 127.0.0.1'e açar)
- [ ] Otomatik günlük yedek + yedekten geri yükleme bir kez denendi; `data/erasure-ledger.jsonl` ayrı yerde saklanıyor
- [ ] `.env` dosyası depoda değil; parolalar ve sırlar güçlü ve benzersiz

## C. Bütçe
- [ ] `config/pricing.json` tüm kullanılacak kalemler için kaynak + tarihle dolduruldu
- [ ] `npm run cost:estimate` toplamı "hesaplanamadı" değil ve hedefin (5.000 TL) altında
- [ ] Sağlayıcı hesaplarında harcama limiti ve otomatik kredi yükleme kapalı
- [ ] Günlük pilot sınırı (`BUDGET_DAILY_PILOT_LIMIT_TRY`) belirlendi

## D. Bağlantılar (her biri için configured → verified → live)
- [ ] WhatsApp: webhook doğrulandı, imzalı test mesajı işlendi, test karar talebi butonla onaylandı ve **başka bir numaradan** gelen yanıt reddedildi
- [ ] LinkedIn: tek bir test gönderisi (ör. "yalnız bana görünür" mümkünse) yayınlandı ve kayıt `published` oldu; zaman aşımı senaryosunda tekrar gönderilmediği görüldü
- [ ] n8n zamanlayıcısı imzalı çağrıyla servisi tetikledi
- [ ] E-posta yedeği bir kez çalıştı
- [ ] `RUN_MODE=eval npm run eval:quality:live` çalıştı; eşik (≥%80, rol başına ≥3/4) sağlandı; `EXPERTISE=off` karşılaştırması kaydedildi
- [ ] Araştırma: Brave anahtarı + kur girildi; tek günlük canlı araştırma çalıştı; kurucu 10 adayı kaynağından elle kontrol etti (uydurma alan yok)
- [ ] Gelen e-posta: IMAP akışı bir test yanıtını doğru adaya eşledi; aynı ileti ikinci kez geldiğinde yeni işlem açılmadı
- [ ] Müşteri e-postası (yalnız açılacaksa): 6563/KVKK değerlendirmesi yapıldı; kendi adresinize test adayıyla gönderim → `sent`; n8n 5xx döndüğünde tekrar gönderilmediği ve doğrulama görevi açıldığı görüldü

- [ ] Ölçüm: panelden bir gerçek gönderiye ölçüm girildi; aynı değer ikinci kez girilince "tekrar" döndü; deney değerlendirmesi yayın başına tek örnek saydı
- [ ] Canlıya geçmeden önce raporda "Kip ayrımı" satırı kontrol edildi: bekleyen ÖRNEK görevler canlı worker tarafından yürütülmez
- [ ] Panel → Manuel işler'de açık "reconcile_cost" (belirsiz gider) işi kalmadı

## E. İçerik ve iletişim
- [ ] Marka dili örnekleri `brand_profiles`'a yeni sürüm olarak eklendi
- [ ] En az bir hizmet için çalışan demo/test kaydı eklendi (yoksa içerik demo iddiası kullanamaz)
- [ ] `docs/kampanya_plani_pilot.md` gözden geçirildi; pilot hacmi ve eşikler onaylandı
- [ ] İlk temas günlük sınırı, takip sayısı ve sessiz saatler onaylandı
- [ ] Görüşme kapasitesi tanımlandı (`founder.meeting_capacity_per_week`)

## F. Pilot sırasında (ilk 2 hafta)
- [ ] Her gün 20:00 raporu okundu; "SİMÜLASYON" etiketi canlı kayıtlarda yok; huni satırlarında "(ÖRNEK …)" sayıları canlı sayılarla karışmıyor
- [ ] Manuel işler (özellikle `verify_publication`) her gün kapatıldı
- [ ] Denetim bulguları ve durdurmalar gözden geçirildi; yanlış alarmlar `false_positive` işaretlendi
- [ ] Gerçek gider sağlayıcı faturasıyla haftalık uzlaştırıldı
- [ ] Pilot sonunda görüşme/gelir verisiyle hedefler güncellendi (teknik kabul satış kanıtı değildir)

## Acil durum
Panel → Durdurma → "Tümü (global)". Kuyruktaki ve çalışan işler durur; yeniden başlatma kurucu yetkisi ister.
