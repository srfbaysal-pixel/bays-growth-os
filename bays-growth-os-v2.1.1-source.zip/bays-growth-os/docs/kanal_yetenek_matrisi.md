# Kanal ve sağlayıcı yetenek / doğrulama matrisi

Belge kontrol tarihi: **14 Ekim 2026**. "Belgeye göre" sütunu resmî belgeden okunanı, "Sistemdeki durum" bu teslimde ne yapıldığını gösterir. Gerçek hesap izinleri **hiçbir kanalda doğrulanmadı** (hesap erişimi yok). Bu tablo `src/integrations/capabilities.ts` içinde makine okunur olarak da bulunur.

Durum anahtarı: `disconnected` · `mock` · `configured` · `verified` · `live` · `degraded`. Tüm kanallar teslimde `mock` veya `disconnected`.

## LinkedIn

| Yetenek | Belgeye göre | Sistemdeki durum |
| --- | --- | --- |
| Üye adına yayın | `w_member_social`; "Share on LinkedIn" ürünü Developer Portal'dan eklenir. Posts API: `POST https://api.linkedin.com/rest/posts`, `Linkedin-Version: YYYYMM`, `X-Restli-Protocol-Version: 2.0.0`; 201 yanıtında gönderi kimliği `x-restli-id` başlığında. Üye için günlük 150 istek sınırı. | Adaptör kodlandı (`linkedin-api`), `mock`. Canlı için OAuth token + kişi URN gerekli. |
| Şirket sayfası adına yayın | `w_organization_social`; sayfada ADMINISTRATOR / CONTENT_ADMIN vb. rol gerekir. | Aynı adaptör, `author` = organization URN. Doğrulanmadı. |
| Yayın ölçümü (üye gönderileri) | `r_member_social` **kısıtlı**, yalnız onaylı kullanıcılar. | Otomatik ölçüm yok; ölçüm `manual` giriş veya n8n geri bildirimi olarak tasarlandı. |
| Mesaj gönderme | Messages API **onaylı iş ortaklarına kısıtlı**; her mesaj üyenin eylemine bağlı olmalı, otomatik/zamanlı gönderim uygun değil. | **Desteklenmiyor** → taslak + kurucuya manuel görev. |
| Bağlantı daveti | Invitations API **onaylı iş ortaklarına kısıtlı**. | **Desteklenmiyor** → manuel görev. |
| Mevcut n8n LinkedIn akışı | Kullanıcı beyanı; incelenmedi. | `n8n-linkedin` adaptörü: imzalı webhook sözleşmesi + sonuç geri çağrısı. Akışınız bu sözleşmeye bağlanınca `configured` olur. |

Not: LinkedIn sayfası Marketing sürüm 202510'un 15 Ekim 2026'da kaldırılacağını yazıyor; `LINKEDIN_API_VERSION` yapılandırmadan gelir, canlıya geçişte güncel sürümü seçin.

Kaynaklar: [Posts API](https://learn.microsoft.com/en-us/linkedin/marketing/community-management/shares/posts-api) (güncelleme 2026-05-13) · [Share on LinkedIn](https://learn.microsoft.com/en-us/linkedin/consumer/integrations/self-serve/share-on-linkedin) (2025-02-05) · [Messages](https://learn.microsoft.com/en-us/linkedin/shared/integrations/communications/messages) · [Invitations](https://learn.microsoft.com/en-us/linkedin/shared/integrations/communications/invitations)

## WhatsApp (kurucu raporu ve karar kanalı)

| Yetenek | Belgeye göre | Sistemdeki durum |
| --- | --- | --- |
| Webhook doğrulama | GET: `hub.mode=subscribe`, `hub.verify_token`, `hub.challenge` geri döndürülür. | Kodlandı, testli. |
| Webhook imzası | `X-Hub-Signature-256: sha256=<HMAC-SHA256(App Secret, gövde)>`. | Ham gövde üzerinden, sabit zamanlı karşılaştırma ile kodlandı, testli. |
| Karar butonları | `POST /<PHONE_NUMBER_ID>/messages`, `type: interactive`, en fazla **3 buton**, başlık ≤20, id ≤256 karakter; yanıt webhook'ta `interactive.button_reply.id`. | Karar talepleri bu kurala göre üretilir; 3'ten fazla seçenekte panel bağlantısı. |
| Ücretlendirme | 1 Temmuz 2025'ten beri mesaj başı fiyat. Kullanıcı yazınca 24 saatlik hizmet penceresi açılır; pencere içinde şablonsuz mesajlar ve utility şablonları ücretsiz; pencere dışında yalnız şablon ve ücretli. Türkiye fiyatı belgede metin olarak yok (oran tablosunda). | Pencere dışı rapor için onaylı **utility şablonu** gerekir; fiyatı yapılandırmaya girilmeden pencere dışı gönderim engellenir. |
| Mesaj durumları | sent / delivered / read / failed webhook'ları. | Kaydedilir; "gönderildi" ≠ "okundu" ≠ "karar verildi". |

Kaynaklar: [Webhooks getting started](https://developers.facebook.com/docs/graph-api/webhooks/getting-started) · [Set up webhooks](https://developers.facebook.com/docs/whatsapp/cloud-api/guides/set-up-webhooks) · [Reply buttons](https://developers.facebook.com/docs/whatsapp/cloud-api/messages/interactive-reply-buttons-messages) · [Pricing](https://developers.facebook.com/docs/whatsapp/pricing)

## Instagram

| Yetenek | Belgeye göre | Sistemdeki durum |
| --- | --- | --- |
| Gönderi / Reels yayını | Profesyonel hesap; `instagram_business_content_publish` (veya Facebook Login ile `instagram_content_publish`); 24 saatte API ile yayın sınırı (belgede 100 ve 50 rakamları çelişiyor, `content_publishing_limit` ile kontrol edilmeli). | Yetenek kaydı var, adaptör `disconnected`. |
| İlk mesaj | Yayın belgesinde yok; ayrıca doğrulanmalı. | Desteklenmiyor varsayıldı. |

Kaynak: [Content publishing](https://developers.facebook.com/docs/instagram-platform/content-publishing)

## X

| Yetenek | Belgeye göre | Sistemdeki durum |
| --- | --- | --- |
| Gönderi | Kullandıkça öde, önceden kredi; standart gönderi 0,015 USD, URL içeren gönderi 0,200 USD; ücretsiz katman belirtilmemiş. | `disconnected`. Fiyatlar bilgi amaçlı; sistem fiyatı otomatik almaz, yapılandırmaya kaynak/tarihle girilmeli. |

Kaynak: [X API pricing](https://docs.x.com/x-api/getting-started/pricing)

## Web ve e-posta

| Kanal | Durum |
| --- | --- |
| Web (site ziyaretleri) | Ölçüm adaptörü yer tutucu, `disconnected`; analitik aracı seçilmedi. |
| E-posta (yedek rapor) | SMTP adaptörü `mock`; SMTP bilgisi verilince `configured`. Karar yürütmez, yalnız rapor. |
| E-posta (müşteriye ilk temas/takip, V2) | Kod hazır; varsayılan **kapalı** (`CUSTOMER_EMAIL_LIVE=false`). Açıkken: doğrulanmış alıcı, iletişim yasağı, takip sınırı, sessiz saat, `sending` işaretiyle çift gönderim koruması. Kapalıyken manuel görev. |
| E-posta (gelen yanıt, V2) | n8n IMAP akışı + imzalı webhook; yedek olarak panelden manuel giriş. |

## Araştırma (V2)

| Sağlayıcı | Durum | Not (kontrol 14.10.2026) |
| --- | --- | --- |
| Brave Search API | Adaptör kodlandı; `disconnected`, anahtar yok | Resmî web arama API'si; Search planı 1.000 istek 5 USD, aylık 5 USD kredi (brave.com/search/api; üçüncü taraf fiyat takibi Ağustos 2026'da aynı rakamları gösteriyor). Ek abonelik gerektirmez. `country=TR`, `search_lang=tr` desteği ilk canlı çağrıda doğrulanacak. |
| Fixture (ÖRNEK) | Test ve simülasyon | `.invalid` alan adları; ağ çağrısı yok |
| Tavily | Uygulanmadı | Alternatif olarak not edildi |
| Google Custom Search JSON API | Seçilmedi | Yeni müşterilere kapalı; 1 Ocak 2027 itibarıyla kapanacağı bildiriliyor (ikincil kaynaklar, 14.10.2026) |
| Güvenli sayfa okuyucu | Kodlandı | Yalnız http/https 80/443; özel/yerel/IPv6 tünel adresleri ve DNS rebinding reddi; en fazla 3 yönlendirme; 1 MB; 10 sn; robots.txt (RFC 9309); 401/403/429 aşılmaz |

## Model sağlayıcıları

| Sağlayıcı | Sistemdeki durum |
| --- | --- |
| Mock (deterministik) | Varsayılan; gerçek çağrı yok, gider 0 ve `simülasyon` olarak işaretli. |
| Anthropic, OpenAI | İstek sözleşmesi kodlandı; anahtar + fiyat + `live` durumu olmadan çağrı yapılamaz. |
| Google/Gemini, xAI | Yapılandırma yer tutucusu; hesap/ürün ayrımı doğrulanmadı. Gemini ile Google ayrı sağlayıcı varsayılmadı. |
| Görsel / video (Kling vb.) | Gerçek API sözleşmesi doğrulanmadığı için **eklenmedi**. |
