# Teslim raporu — BaysSystems Growth OS V1

Tarih: 14 Ekim 2026 · Kip: **simülasyon** · Hazırlayan: Claude (Opus 5.5) · Bağımsız kod incelemesi: ayrı bir ajan oturumu (aşağıda)

## 1. Ne kodlandı

| Alan | İçerik | Konum |
| --- | --- | --- |
| Çoklu marka çekirdeği | 23 asgari + 7 yardımcı tablo, RLS ile marka izolasyonu, ayrı uygulama/denetçi DB rolleri, değişmez maliyet defteri ve sıra numaralı özet zincirli işlem günlüğü | `migrations/`, `src/db/` |
| Bilgi merkezi | Ham araştırma / hipotez / doğrulanmış kural / politika ayrımı, kaynak-tarih-geçerlilik-sürüm, geri alma, PII'siz markalar arası özet paylaşımı (hedefte "yeniden denenmeli" hipotez) | `src/core/knowledge.ts` |
| Görev ve yetki | İdempotent görevler, ≤6 model çağrısı, ≤3 tekrar, üstel bekleme, hata kuyruğu, döngü algılama; kodda sabit yetki tablosu (ücretli reklam `forbidden`) | `src/core/tasks.ts`, `authority.ts` |
| Bütçe | Atomik rezervasyon, hedef 5.000 TL, kesin üst sınır 10.000 TL, %70/%90 uyarı, günlük pilot sınırı, bilinmeyen fiyat/kur engeli, uzlaştırma | `src/core/budget.ts`, `pricing.ts` |
| Durdurma | Global/marka/kanal/kampanya; kuyruktaki ve çalışan iş; yeniden başlatma yalnız kurucu | `src/core/halts.ts` |
| Beş rol | Sürümlü talimat, bilgi kapsamı, araç izni, JSON şeması, hata davranışı, model kademesi | `src/agents/roles.ts` |
| Koruma katmanı | Kanıtsız başarı/referans/fiyat/teslim, hazır olmayan hizmet, eski kurum, marka karışması, talimat girişimi, genel mesaj, kanıtsız strateji önceliği | `src/agents/guards.ts` |
| CRM | 11 aşama, mükerrer aday/ilk temas engeli, iletişim istemeyenler (hash), ilk temas kontrolü, nitelikli fırsat, kurucu doğrulamalı gelir | `src/crm/crm.ts` |
| Öğrenme | Gerekçeli eşikli deney, yetersiz veride hüküm yok, format karıştırıcı kontrolü, kurala yükseltme/geri alma | `src/learning/experiments.ts` |
| Denetim | 10 kontrol grubu + darboğaz analizi, ikinci bağımsız doğrulama, teyitli bulguda durdurma, model ikinci görüşü | `src/auditor/auditor.ts` |
| Entegrasyon | Egress koruması, LinkedIn (mock / Posts API / n8n köprüsü), WhatsApp Cloud (imza, tekrar önleme, butonlu karar, durumlar, 24 saat penceresi, şablon), e-posta yedeği (n8n) | `src/integrations/`, `src/notify/` |
| Rapor ve panel | Günlük/haftalık rapor (mock ve canlı ayrı, eksik ölçüm ≠ 0, belirsiz gelir ayrı), mobil panel, kurucu API'si, erişim günlüğü | `src/reports/`, `src/api/`, `panel/` |
| n8n | Zamanlayıcı, LinkedIn adaptör sözleşmesi, durum sorgusu, e-posta yedeği + doğrulayıcı | `n8n/`, `tools/` |
| Gizlilik ve yedek | Kişi silme, DB dışı silme kaydı, yedek/geri yükleme, saklama politikası | `src/core/privacy.ts`, `backup.ts` |
| Simülasyon | 16 günlük senaryo 1 + aday→görüşme senaryo 2 | `src/sim/`, çıktı `reports/` |

## 2. Ne test edildi

`npm run test:report` → **49/49 geçti** (14.10.2026, yerel PostgreSQL 16.15, Node 22.22.0). Şartname §11'deki 14 zorunlu testin tamamı `tests/e_acceptance.test.ts` içinde (KT-01…KT-14). Ayrıntı ve çıktı: `docs/test_raporu.md`. Ek olarak: ajan değerlendirme seti 13/13, n8n JSON doğrulaması 23 düğüm / 0 hata, `tsc --noEmit` temiz.

## 3. Ne yalnız mock ile doğrulandı

- Tüm ajan çıktıları (deterministik mock sağlayıcı). Gerçek model davranışı **sınanmadı**; koruma katmanı modelden bağımsız çalıştığı için gerçek modelde de geçerlidir, ama model kalitesi ayrıca değerlendirilmelidir.
- LinkedIn yayını, WhatsApp gönderimi ve e-posta: mock adaptörler; gerçek HTTP isteği kod gereği engelli.
- Ölçümler: simülasyonda üretilen ÖRNEK değerler. Deneyin "desteklendi" sonucu örnek veridir.
- Simülasyondaki tüm araştırma, aday, kişi ve yanıtlar ÖRNEK; alan adları `.invalid`.

## 4. Henüz çalıştırılamayan kontroller

- `docker compose up` (bu ortamda Docker Hub erişimi 403; compose dosyası sözdizimsel doğrulandı)
- n8n'e import edip çalıştırma (n8n sunucusu yok)
- Gerçek hesaplarla bağlantı, imza ve izin doğrulaması
- Sağlayıcı faturasıyla maliyet uzlaştırması

## 5. Bağımsız inceleme ve düzeltmeler

Ayrı bir ajan oturumu kodu şartnameye karşı inceledi ve çalışma zamanında denedi. Bulunanlar ve durum:

| Önem | Bulgu | Durum |
| --- | --- | --- |
| Kritik | `/%61pi/...` gibi URL kodlamasıyla kurucu girişinin atlanması | **Düzeltildi**: yetki eşleşen rota şablonuna göre, varsayılan "giriş gerekli"; test eklendi |
| Kritik | Eşzamanlı yazımda olay zinciri sırasının bozulup yanlış global durdurmaya yol açması | **Düzeltildi**: sıra numarası kilit sonrası tetikleyicide; doğrulama her özeti yeniden hesaplıyor; 40 eşzamanlı yazım testi |
| Yüksek | Geç gelen n8n "yayınlandı" geri çağrısının düşmesi | Düzeltildi |
| Yüksek | "Reddet" dışındaki her seçeneğin onay sayılması | Düzeltildi: yalnız "approve" onaydır |
| Yüksek | Mock'un yeniden gönderimi gizlemesi (testlerin zayıflığı) | Düzeltildi: gerçek çağrı sayacı |
| Orta | Engellenen istekte rezervasyon serbest kalmaması, webhook tekrar kaydının işlemden önce yazılması, şablon yolu eksikliği, 24 saat penceresinde yabancı numara, formalite ikinci denetim, raporda örnek/gerçek fırsatın karışması, bazı zayıf testler | Düzeltildi |
| Düşük | Marka raporunda diğer markanın durdurma gerekçesi; yönlendirme takibi; CLI'da çıkış koruması; zamanlayıcıda tekrar oynatma; ay anahtarı | Düzeltildi |

İnceleme ajanı düzeltmeleri aynı denemelerle yeniden doğruladı: kritik ve yüksek bulgular kapandı, gerileme yok.

## 6. Kalan bilinen sınırlar (bilinçli)

1. **Canlı araştırma adaptörü yok.** Araştırma kaydı şu an kurucu/manuel kanıt girişi veya simülasyon örneğiyle; bir arama API'si seçilince adaptör eklenmeli.
2. **RLS ikinci katmandır.** Uygulama kodu oturum ayarını belirler; kod hatasına karşı korur, kötü niyetli koda karşı değil.
3. **Arka plan işçisi yok.** Geçici hatayla kuyruğa dönen görev, aynı zamanlanmış iş bir sonraki tetiklendiğinde yeniden denenir.
4. **Mock uzak durum süreç belleğinde.** Uzlaştırma senaryosu aynı süreçte sınanır.
5. **LinkedIn ölçümü otomatik değil** (`r_member_social` kısıtlı): n8n geri bildirimi veya manuel giriş.
6. **Müşteriye canlı e-posta ile ilk temas V1'de kapalı**; taslaklar kurucuya bırakılır (ticari ileti mevzuatı değerlendirmesi kurucuda).
7. Aynı WhatsApp mesajı aynı anda iki kez gelirse olay günlüğüne iki kez yazılabilir; karar yine tek kez uygulanır.
8. Bağlantıyı "verified" yapmak için serbest metin doğrulama kaynağı yeterli; kanıt dosyası zorunlu değil.
9. n8n Code düğümleri için `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` gerekiyor; n8n konteynerine yalnız gerekli sırlar verilmeli.
10. Google/Gemini, xAI ve video sağlayıcıları (Kling vb.) hesap/API sözleşmesi doğrulanmadığı için eklenmedi; Instagram ve X adaptörleri yalnız yetenek kaydı düzeyinde.

## 7. Kurucunun ekleyeceği

`docs/eksik_baglantilar.md` (17 madde) ve `docs/canliya_gecis_kontrol_listesi.md`.

## 8. Bağımsız incelemeye hazır çıktı

`bays-growth-os-v1.zip` (kaynak, göçler, Docker, n8n JSON, testler, belgeler, simülasyon çıktıları). İçinde gerçek anahtar veya kişi bilgisi yoktur; test sırları `_not_real` sonekli yer tutuculardır.
