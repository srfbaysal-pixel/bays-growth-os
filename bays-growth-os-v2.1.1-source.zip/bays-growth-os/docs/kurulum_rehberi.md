# Kurulum rehberi

> V2 notu: V1'den güncelleme, geri dönüş, worker ve kip bazlı komutlar için önce `docs/kurulum_guncelleme_geri_donus.md`'yi okuyun. Bu dosya hesapların sonradan bağlanması için geçerliliğini korur.

## 1. Gereksinimler

- Docker Engine + Docker Compose v2 **veya** Node.js 22 + PostgreSQL 16
- Sunucuda en az 2 GB RAM önerilir (PostgreSQL + Node + n8n). Hostinger planınızın uygunluğu kontrol edilmedi.

## 2. Simülasyonda çalıştırma

```bash
cp .env.example .env
```
`.env` içinde doldurun:
- `POSTGRES_OWNER_PASSWORD`, `APP_DB_PASSWORD`, `AUDITOR_DB_PASSWORD` — üç ayrı, güçlü parola
- `N8N_SHARED_SECRET` — uzun rastgele değer (`openssl rand -hex 32`)
- `FOUNDER_TOKEN_SHA256` — panel anahtarınızın özeti:
  ```bash
  node -e "console.log(require('crypto').createHash('sha256').update('PANEL_ANAHTARINIZ').digest('hex'))"
  ```
  Panel girişinde `PANEL_ANAHTARINIZ` değerini kullanırsınız; sunucuda yalnız özeti durur.

```bash
docker compose up --build -d
docker compose logs -f app          # "dinlemede: :8080 (kip: simulation)" görünmeli
docker compose exec app npx tsx src/cli.ts simulate
```
Panel: `http://localhost:8080/panel`. Üstte mor "SİMÜLASYON KİPİ" bandı görünür.

n8n: `http://localhost:5678` → hesap oluşturun → `n8n/` klasöründeki 4 JSON'u import edin. Zamanlayıcı akışını etkinleştirdiğinizde 08:00/20:00/Pazar 20:00'de servisi çağırır (simülasyon kipinde dış işlem yine yapılmaz).

## 3. Testler

```bash
npm ci
npm test               # yerel PostgreSQL 16 gerekir; test veritabanı bays_test sıfırdan kurulur
npm run test:report    # docs/test_raporu.md
```
Testler `postgres://postgres:postgres_local_dev@localhost:5432` sahibine bağlanır (yalnız yerel geliştirme). Farklıysa `vitest.config.ts` ve `tests/globalSetup.ts` içindeki bağlantıları değiştirin.

## 4. Hesapların sonradan bağlanması (sıra önemli)

Her bağlantı için akış: **anahtarı `.env`'e ekle → panelde `configured` → test et → doğrulama kaydıyla `verified` → kurucu olarak `live`**. `RUN_MODE=live` ve `EGRESS_ENABLED=true` yapılmadan hiçbir bağlantı dışarı çıkmaz.

### 4.1 Fiyatlar (önce bu)
`config/pricing.json`: kullanacağınız her model/servis için fiyat, **kaynak URL'si ve tarih**; USD/EUR kuru için kaynak ve tarih. Fiyatı boş kalan kalem canlıda engellenir. `npm run cost:estimate` ile aylık tahmini görün; `config/usage_profile.json` gerçek hacme göre düzenlenmeli.

### 4.2 Model sağlayıcısı
`.env`: `MODEL_ECONOMY=anthropic:<model-kimliği>`, `MODEL_STRONG=...`, `ANTHROPIC_API_KEY=...` (veya OpenAI). `MODEL_PROVIDER_STATUS={"anthropic":"live"}` yalnız sağlayıcı hesabında harcama limiti tanımladıktan sonra. Sağlayıcı panelinde aylık harcama sınırını 5.000 TL karşılığının altında tutun — sistemin bütçe kontrolü sağlayıcı faturasını tek başına garanti etmez.

### 4.3 WhatsApp (kurucu raporu ve karar)
Meta Business hesabı + WhatsApp Business numarası (bot numarası) + Cloud API uygulaması.
- `.env`: `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_ACCESS_TOKEN`, `WHATSAPP_APP_SECRET`, `WHATSAPP_VERIFY_TOKEN`, `WHATSAPP_GRAPH_VERSION` (Meta'nın güncel sürümü), `FOUNDER_WHATSAPP_NUMBER`
- Webhook URL: `https://<alan-adınız>/webhooks/whatsapp` (HTTPS, geçerli sertifika; Meta kendinden imzalı sertifikayı kabul etmez), doğrulama belirteci = `WHATSAPP_VERIFY_TOKEN`, `messages` alanına abone olun.
- 24 saat dışı raporlar için Meta'da onaylı bir **utility** şablonu oluşturun (tek gövde parametresi), adını `WHATSAPP_REPORT_TEMPLATE`'e, fiyatını `pricing.json` → `whatsapp:utility_template_TR`'ye girin.
- Test: kendi numaranızdan bota "merhaba" yazın (pencere açılır) → `npm run report:daily` → panelde bildirim durumu.

### 4.4 LinkedIn
İki seçenek (birini kullanın):
- **Mevcut n8n akışınız:** `docs/n8n_adaptor_sozlesmesi.md`'ye göre bağlayın; panelde `linkedin/n8n-linkedin` bağlantısını ilerletin.
- **Doğrudan API:** LinkedIn Developer Portal'da uygulama → "Share on LinkedIn" ürünü → OAuth ile `w_member_social` (şirket sayfası için `w_organization_social` + sayfa yöneticisi rolü). `.env`: `BRAND_BAYSSYSTEMS_LINKEDIN_TOKEN`, `BRAND_BAYSSYSTEMS_LINKEDIN_AUTHOR_URN`, `LINKEDIN_API_VERSION` (YYYYMM, güncel).
Mesaj ve bağlantı daveti API'leri onaylı iş ortaklarına kısıtlı olduğundan sistem bunları **taslak + manuel görev** olarak bırakır.

### 4.5 E-posta yedeği
n8n'de SMTP kimliği oluşturun, `bays-email-fallback.json` akışında seçin, `FOUNDER_EMAIL` ve `BAYS_REPORT_FROM_EMAIL` girin.

## 5. Yedekleme

```bash
npm run backup                                    # backups/bays-<zaman>.dump
npm run restore -- backups/<dosya>.dump bays_geri  # ayrı veritabanına geri yükler
# uygulamayı bays_geri'ye yönlendirdikten sonra:
npm run restore:reapply-erasures                   # yedekten sonra silinen kişileri yeniden siler
```
`data/erasure-ledger.jsonl` (yalnız özetler içerir) veritabanı yedeğinden **ayrı** saklanmalıdır; geri yüklemede silme taleplerinin kaybolmaması buna bağlıdır.

## 6. Bütçe sınırını değiştirmek

- Hedefi (5.000 TL) en fazla 10.000 TL'ye çıkarmak: sistem `budget.change_limit` karar talebi üretir; WhatsApp/panelden onaylarsınız.
- 10.000 TL kesin üst sınırı: yalnız sunucuda `.env` → `BUDGET_HARD_CAP_TRY` değiştirilip servis yeniden başlatılarak. Ajanlar ve panel bunu değiştiremez.
