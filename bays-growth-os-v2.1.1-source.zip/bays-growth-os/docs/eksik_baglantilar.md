# Eksik bağlantılar ve girdiler (V2.1, 14.10.2026)

Teslimde **hiçbir gerçek hesaba bağlanılmadı**; hiçbir gerçek yayın, mesaj, arama veya harcama yapılmadı. Eksikler geliştirmeyi durdurmadı: her biri için kod, kapalı anahtar ve dışarıya çıkmayan test yolu hazır.

## A. Sizden gerekenler

| # | Gereken | Nereye | Açtığı iş | Yokken sistem ne yapar |
|---|---|---|---|---|
| 1 | Mevcut LinkedIn n8n workflow JSON'u ve n8n sunucu sürümü | `docs/n8n_adaptor_sozlesmesi.md` §1–3 | LinkedIn canlı yayını (n8n yolu) | Akışınız **incelenmedi, entegre değil**. Yayın mock; kanal `disconnected`. |
| 2 | Sunucu (Hostinger planı, RAM/disk) ve `docker compose up` denemesi | — | Üretim kurulumu | Bu ortamda Docker imajı çekilemedi; yerel kurulum doğrulandı. |
| 3 | Model sağlayıcı anahtarı, model kimlikleri, fiyatı, hesap harcama limiti | `.env`, `config/pricing.json` | Gerçek ajan çıktısı, gerçek kalite değerlendirmesi | Mock model; kalite değerlendirmesi BEKLEMEDE. Fiyatsız model canlıda çağrılmaz. |
| 4 | USD → TL kuru, kaynağı, tarihi | `config/pricing.json → fx` | Döviz bazlı her ücretli iş (Brave, model) | Kur bilinmiyorsa iş başlamaz; toplam "hesaplanamadı" gösterilir (sıfır yazılmaz). |
| 5 | Brave Search API anahtarı (ve kullanılabilir kredi teyidi) | `.env BRAVE_SEARCH_API_KEY`, panelde research bağlantısı `live` | Canlı pazar araştırması ve müşteri keşfi | `RESEARCH_PROVIDER=none` → raporda "Araştırma yapılmadı" yazar; aday üretilmez. Anahtar bulunması kredi bulunduğunu kanıtlamaz. |
| 6 | WhatsApp Cloud API: telefon no. kimliği, erişim anahtarı, App Secret, doğrulama belirteci, Graph sürümü, onaylı utility rapor şablonu ve Türkiye fiyatı | `.env`, `pricing.json` | Kurucuya WhatsApp raporu ve karar düğmeleri | Rapor ve kararlar panelde; e-posta yedeği n8n bağlanınca. |
| 7 | Kurucu WhatsApp numarası, yedek e-posta | `.env` | Karar yetkisi doğrulaması | Karar yalnız panel girişiyle. |
| 8 | SMTP (giden) ve IMAP (gelen) kimlikleri — n8n içinde | n8n Credentials; `bays-email-fallback.json`, `bays-email-inbound.json` | Müşteriye e-posta ve gelen yanıtın otomatik kaydı | Gönderim kurucuya manuel görev; yanıt panelden elle girilir. |
| 9 | Müşteriye otomatik e-posta kararı + 6563 sayılı Kanun / ticari elektronik ileti değerlendirmesi | `.env CUSTOMER_EMAIL_LIVE=true` (yalnız sizin kararınızla) | Otomatik ilk temas ve takip | Kapalı: her ilk temas ve takip manuel görevdir; taslak gönderilmiş sayılmaz. |
| 10 | Doğrulanmış demo(lar): ekran kaydı/URL + test notu | Panel → Hizmetler → Demo bağla | Güven kanıtı, "demo hazır" içerik | Denetçi her gün "güven kanıtı yok" darboğazını ve düzeltme işini raporlar. |
| 11 | Fiyat listesi ve teslim süreleri | Kurucu kararı | Teklif aşaması | Ajanlar fiyat/teslim yazamaz. |
| 12 | Haftalık görüşme kapasitesi | `settings: founder.meeting_capacity_per_week` | Görüşme saati önerisi | Görüşmeler kurucu kararına bırakılır, saat önerilmez. |
| 13 | Marka dili örnekleri (gerçek gönderileriniz) | `brand_profiles` yeni sürüm | İçerik kalitesi | Genel Türkçe kurallarıyla yazılır. |
| 14 | Pilot hacmi ve ilk temas sınırları onayı | `brand_profiles.contact_rules`, `.env RESEARCH_MAX_*` | Pilot ölçeği | Varsayılanlar: günde 8 arama, 20 sayfa; profil sınırları. |
| 15a | LinkedIn gönderi ölçümlerinin kaynağı: mevcut akışınızın analiz çıktısı, LinkedIn analiz API erişimi veya elle giriş | Panel → Ölçüm (elle) veya `n8n/bays-metrics-push.json` "Ölçüm kaynağı" düğümü | Gerçek ölçümle deney/strateji | Ölçüm yoksa "canlı ölçüm yok (sıfır değil)" raporlanır, deney hüküm vermez. |
| 15b | Belirsiz giderlerin uzlaştırılması (sağlayıcı paneli/faturası) | Panel → Manuel işler → "Uzlaştır" | Bütçenin gerçek tutarla güncellenmesi | Belirsiz çağrının tahmini tutarı bütçede sayılmaya devam eder. |
| 15 | Web analitik aracı seçimi | ileride adaptör | Site ziyareti ölçümü | "Canlı ölçüm yok (sıfır sonuç anlamına gelmez)". |
| 16 | Mevcut repo (varsa) | — | Uyarlama | Paylaşılmadı; bağımsız proje. |

## B. Geliştirmeyle çözülenler (V1'de eksikti, V2'de kodlandı ve test ortamında doğrulandı)

| Konu | V2'de | Doğrulama |
|---|---|---|
| Araştırma adaptörü | Brave sağlayıcısı + güvenli sayfa okuyucu (SSRF, IPv6, DNS rebinding, yönlendirme, boyut, zaman aşımı, robots.txt, 401/403/429 aşılmaz) + önbellek + kaynaklı bulgular | V2-01…03, V2-15, R-06…R-10 (fixture) |
| Sürekli yürütücü | Kalıcı kuyruk worker'ı, kira, kurtarma, üstel bekleme, hata kuyruğu, fencing, Docker servisi | V2-11, V2-12, R-12, temiz klasör worker çalıştırması |
| Günlük müşteri zinciri | Araştırma → aday → değerlendirme → taslak → gönderim/manuel → yanıt → takip → fırsat → kurucu kararı | V2-04…06, V2-17 |
| Gelen yanıt yolu | İmzalı `/webhooks/email/inbound` + n8n IMAP akışı + panel manuel girişi | V2-05, R-13, R-14 |
| Çift gönderim koruması | `sending` işareti, belirsiz sonuçta doğrulama görevi | R-01…R-03 |
| Gerçek zamanlama | `scheduled_at` dış çağrı koşulu; kaçırılan yayın politikası | V2-10, V2-13 |
| Strateji geri bildirimi ve uygulanan öğrenme | Bağlam + yapısal kural + geri alma | V2-07…09, V2-16 |
| Kalite değerlendirmesi | 20 senaryo, önceden kayıtlı rubrik, mock/canlı kip, `eval_runs` | V2-18 |
| Gerçek ölçüm girişi (V2.1) | Kurucu API/panel + imzalı n8n webhook; doğrulama, tekrar teslim koruması, kümülatif güncelleme politikası | M-01…M-07 |
| Kip ayrımı (V2.1) | Örnek, değerlendirme ve canlı veri/görev/önbellek ayrımı; kipi bilinmeyen eski kayıt koruması | K-01…K-07 |
| Açık ret modelden önce (V2.1) | Yanıt kaydıyla aynı işlemde yasak, kayıp ve bekleyen işlerin iptali | O-01…O-04 |
| Belirsiz gider (V2.1) | Çağrı yapılmadı / ücretlenmedi / belirsiz ayrımı; kurucu uzlaştırması | B-01…B-06 |
| Hizmet kartı + demo bağlama | Kapsam, hazır oluş, kanıt, gerekli bağlantılar, kurucu doğrulaması | API `/offers/:code/demo` |

## C. Dış sağlayıcı kısıtları (geliştirmeyle çözülemez)

| Kısıt | Etki | Sistemdeki karşılık |
|---|---|---|
| LinkedIn mesaj ve bağlantı daveti API'si genel geliştiricilere kapalı | Otomatik LinkedIn mesajı yok | Manuel görev; tarayıcı otomasyonu yapılmaz |
| n8n "Send Email" düğümü özel Message-ID başlığı ayarlamıyor (n8n-nodes-base 2.43.2 tanımı) | Gelen yanıtın In-Reply-To ile eşleşmesi zayıf | Gönderen adresiyle eşleşme; eşleşmezse `match_reply` manuel görevi |
| n8n "Send Email" varsayılan olarak imza ekler | Müşteri e-postasında "n8n ile gönderildi" satırı | `appendAttribution: false` ayarlandı |
| Brave: `country=TR` ve `search_lang=tr` desteği belgede liste olarak görülmedi | Türkiye sonuçlarının kalitesi bilinmiyor | İlk canlı çalıştırmada doğrulanacak; sorgular zaten Türkçe ve şehir adlı |
| Brave fiyatı USD (1.000 istek 5 USD; aylık 5 USD kredi — üçüncü taraf fiyat sayfası Ağustos 2026 doğrulaması ile tutarlı) | TL maliyet kura bağlı | Kur girilmeden canlı arama başlamaz |
| WhatsApp 24 saat penceresi dışı mesaj yalnız onaylı şablonla, ücretli | Rapor gönderimi şablon ister | Şablon/fiyat yoksa panel + e-posta yedeği |
| Web siteleri robots.txt, 401/403/429 ile erişimi kısıtlayabilir | Bazı işletmeler okunamaz | Kısıt aşılmaz; kaynak "erişilemedi/yasak" işaretlenir |
| LinkedIn analiz verisine programatik erişim ürün/izin onayına bağlı (doğrulanmadı) | Ölçüm otomatik gelmeyebilir | Elle giriş ve n8n köprüsü; ölçüm yoksa sonuç uydurulmaz |
| Sağlayıcılar zaman aşımı/5xx'te isteğin ücretlenip ücretlenmediğini bildirmeyebilir | Gider belirsiz kalabilir | Tahmini tutar bütçede sayılır, kurucu faturadan uzlaştırır |
| Docker Hub erişimi bu geliştirme ortamında 403 | Konteyner sınaması yapılamadı | Sizin sunucunuzda `docker compose up` ilk kontrol |
