# Sınırlı pilot, örnek raporlar, durdurma ve yeniden başlatma

## 1. Sınırlı pilot listesi

Pilot, bağlantıları **tek tek** açar; her adım bir önceki adımın gerçek sonucu görülmeden açılmaz. Her adımı açmak kurucu kararıdır; hiçbir ajan bu adımları kendisi açamaz. Ücretli reklam pilotun hiçbir aşamasında yoktur.

| Adım | Açılan | Ön koşul (sizden) | Sınır | Başarı ölçüsü (sonuç garantisi değil) | Durdurma koşulu |
|---|---|---|---|---|---|
| P0 | Kurulum, panel, worker; `RUN_MODE=simulation` | Sunucu, `.env` | — | Worker 1 hafta kesintisiz; günlük rapor panelde | Görev hata kuyruğunda birikme |
| P1 | Gerçek model, yalnız değerlendirme (`RUN_MODE=eval`) | Model anahtarı, fiyat, kur | Tek çalıştırma; maliyet `eval_runs`'ta | Kalite seti eşiği (≥%80, rol başına ≥3/4) | Eşik altı → rehber/talimat düzeltmesi, canlıya geçilmez |
| P2 | Canlı araştırma (Brave), müşteri teması **kapalı** | Brave anahtarı, kur, research bağlantısı `live` | Günde ≤ 8 arama, ≤ 20 sayfa; 1 hafta | Kaynaklı aday sayısı ve kaynak kalitesi (kurucu 10 adayı elle kontrol eder) | Yanlış/uydurma bilgi gören tek aday → durdur |
| P3 | LinkedIn yayını (mevcut n8n akışınız veya doğrudan API) + gerçek ölçüm girişi (Panel → Ölçüm veya `bays-metrics-push`) | Akış JSON'u veya token + URN; sözleşmeye uygun bağlama | Günde 1 yayın; ilk 5 yayın kurucu önizlemeli | Planlanan saatte tek yayın; gerçek ölçüm girilir (bilinmeyen değer boş bırakılır, sıfır yazılmaz) | Çift yayın veya saat dışı yayın → durdur |
| P4 | WhatsApp raporu ve karar düğmeleri | Cloud API bilgileri, şablon, fiyat | Günde 1 rapor + kararlar | Kararın panelle aynı sonuca ulaşması | Yetkisiz numaradan kabul edilen karar → durdur |
| P5 | Gelen e-posta yanıtlarının otomatik kaydı (IMAP) | IMAP kimliği (n8n) | — | Yanıtların doğru adaya eşleşmesi | Yanlış eşleşme |
| P6 | Müşteriye otomatik e-posta (`CUSTOMER_EMAIL_LIVE=true`) | 6563/KVKK değerlendirmesi, SMTP, doğrulanmış demo | Haftada ≤ 10 ilk temas; profil takip sınırı; sessiz saat 20:00–09:00 | Gerçekten gönderilmiş temas, yanıt, nitelikli fırsat, gerçekleşen görüşme (ayrı ayrı) | "İstemiyorum" yanıtına rağmen temas, belirsiz gönderimde tekrar → durdur |

P6 açılmadan önce tüm temaslar manuel görevdir; bu da bir pilot biçimidir: kurucu taslağı kendi e-postasından gönderip panelde "gönderildi" işaretler, zincir (takip, yanıt, fırsat) aynen çalışır.

## 2. Örnek raporlar

Aşağıdakiler `npm run simulate` çıktısıdır (`reports/simulasyon_son_rapor.txt`). **Tüm sayılar ÖRNEK veridir**: gerçek müşteri, gerçek yayın veya gelir göstermez. Raporda "0 (ÖRNEK 3)" biçimi, gerçek sayı ile örnek sayının ayrı tutulduğunu gösterir.

### Günlük kısa rapor (örnek)
```
Günlük kısa rapor · 2026-10-14 · SİMÜLASYON KİPİ: dış işlem yapılmadı

— Yayın —
Canlı yayın: yok
ÖRNEK/simülasyon yayın (gerçek paylaşım değil): published: 16

— Ölçüm —
Canlı ölçüm yok (sıfır sonuç anlamına gelmez)

— Araştırma —
fixture (ÖRNEK) · done · sorgu 8 · belge 8 · bulgu 6 · yeni aday 0

— Müşteri hunisi —
Kaynaklı aday: 0 (ÖRNEK 3)
Uygun aday (puan ≥60): 0 (ÖRNEK 3)
Taslak (temas sayılmaz): 0 (ÖRNEK 7)
Gerçekten gönderilmiş temas: 0 (ÖRNEK 6)
Yanıt: 0 (ÖRNEK 1)
Nitelikli fırsat: 0 (ÖRNEK 1)
Gerçekleşen görüşme: 0
Teklif: 0
Kurucunun doğruladığı satış: 0
Kampanyaya bağlı doğrulanmış gelir: yok

— Günün darboğazı —
Günün darboğazı: Güven kanıtı yok: hiçbir hizmette çalışan demo/test kaydı yok
Düzeltme: İlk LinkedIn hizmeti için ekran kaydı + test notu ekleyin (Panel → Hizmetler → Demo bağla). İçerik bu eksiği kapatamaz.

— Açık manuel işler —
add_contact: 1 · linkedin_message: 1 · record_demo: 1

— Maliyet (2026-10) —
Canlı: 0 / 5000 TL (kesin üst sınır 10000 TL)
Simülasyon (gerçek gider değil): 0 TL

— Denetim —
[medium] Günün darboğazı: Güven kanıtı yok … (×7)
[medium] 2 dış içerikte talimat girişimi tespit edildi ve bağlamdan çıkarıldı (örnek veri)
```

### Haftalık değerlendirme (örnekten ek bölümler)
```
— Deneyler —
supported (örnek): Aynı içerik türünde 09:00 paylaşımı 12:30 paylaşımına göre daha fazla etkileşim alır

— Uluslararası açılım kapısı —
Henüz önerilmez.
✗ Türkiye pilotunda kurucunun doğruladığı satış
✗ Gerçekleşen görüşme
✗ Teslim ve destek kapasitesi tanımlı
✗ Hedef ülke için kaynaklı araştırma ve ayrı bütçe kararı

— Bilgi değişiklikleri —
rule:linkedin:publish_time v1 (verified_rule, current, örnek)
```
Rapor WhatsApp bağlanınca 4.000 karakterle sınırlı gönderilir; bağlantı yoksa panelde durur ve (n8n SMTP bağlanınca) e-posta yedeğine gider.

## 3. Durdurma ve yeniden başlatma

Durdurma kapsamları: `global` (her şey), `brand` (tek marka), `channel` (ör. `linkedin`, `email`, `research`), `campaign`.

### Durdurma
- **Panel → Durdurma**: kapsam seç, kanal adı (gerekirse) ve gerekçe yaz → "Durdur".
- **API**: `POST /api/halts` gövde `{"scope":"channel","brandId":"<id>","scopeValue":"email","reason":"..."}` (kurucu oturumu gerekir).
- Etki: kuyruktaki ilgili işler `halted` olur; **çalışmakta olan** araştırma bir sonraki aramadan/sayfadan önce, e-posta gönderimi dış çağrıdan önce durur (R-10, R-15). Durdurma varken önceki sonuç bile yeniden raporlanmaz.
- **Acil tam durdurma**: `docker compose stop worker` (veya worker sürecine SIGTERM). Worker elindeki işi bitirip çıkar; yarım kalan iş kirası dolunca kurtarılır, belirsiz dış sonuç tekrar gönderilmez, doğrulama görevi olur.

### Yeniden başlatma
- **Panel → Durdurma → Yeniden başlat** (onay sorulur; durdurulan işler yeniden kuyruğa alınır).
- **API**: `POST /api/halts/<id>/resume` gövde `{"requeue": true}`.
- Worker'ı yeniden başlatma: `docker compose start worker` veya `npm run worker`. Başlangıçta süresi dolmuş kiralar kurtarılır; zamanlayıcı aynı günün işini ikinci kez açmaz.
- Yeniden başlatmadan önce: panelde **Manuel işler** sekmesindeki `verify_publication` (belirsiz yayın/gönderim) görevlerini kapatın; sistem bunları kendi kendine yeniden göndermez.

### Kip değişimi (simülasyondan canlıya)
Aynı gün simülasyondan canlıya geçmek güvenlidir. Canlı kök görev ayrı açılır, bekleyen ÖRNEK görevler canlı worker tarafından yürütülmez ve raporda "Kip ayrımı" satırında görünür. Örnek araştırma önbelleği canlıda kullanılmaz.

### Belirsiz gider
Zaman aşımı veya 5xx nedeniyle ücretlenip ücretlenmediği bilinmeyen çağrılar rapordaki "Uzlaştırma bekleyen" satırında listelenir. Bunlar için Panel → Manuel işler → "Uzlaştır" ile sağlayıcı paneline göre "0.005 USD" gibi tutarı ya da "hayır" girin. Uzlaştırılana kadar tahmini tutar bütçede sayılır.

### Hata kuyruğu
`dead_letter` durumundaki görevler panelde **Görevler** sekmesinde neden (`dead_reason`) ile görünür. Kalıcı hata (fiyat bilinmiyor, bütçe engeli) düzeltilmeden yeniden denenmez.
