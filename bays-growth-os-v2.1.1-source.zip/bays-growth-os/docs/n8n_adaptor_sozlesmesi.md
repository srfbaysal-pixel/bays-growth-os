# n8n adaptör sözleşmesi

Mevcut LinkedIn n8n akışınız **paylaşılmadı ve incelenmedi**. Bu belge, akışınızın servise nasıl bağlanacağını tanımlar. `n8n/` klasöründeki JSON'lar bu sözleşmenin örnek uygulamasıdır; bağlantı noktaları `NoOp` düğümüyle işaretlidir.

## Ortak kurallar

- İmza: her istekte `X-Bays-Signature: sha256=<HMAC-SHA256(N8N_SHARED_SECRET, gövde)>`. Servis ve n8n aynı sırrı kullanır (`N8N_SHARED_SECRET` ↔ n8n'de `BAYS_N8N_SHARED_SECRET`).
- n8n Code düğümünde imza için `NODE_FUNCTION_ALLOW_BUILTIN=crypto` ve `$env` erişimi için `N8N_BLOCK_ENV_ACCESS_IN_NODE=false` gerekir (n8n 2.0'da ikisi de varsayılan kapalı). Not: ikincisi n8n Code düğümlerinin tüm ortam değişkenlerini görmesine izin verir; n8n konteynerine yalnız gereken sırları verin.
- İdempotency: aynı `idempotency_key` ikinci kez gelirse yeniden yayınlamayın; önceki sonucu döndürün.

## 1. Yayın isteği — servis → n8n

`POST {N8N_BASE_URL}/webhook/bays-linkedin-publish` (marka bazlı yol: `BRAND_<SLUG>_N8N_LINKEDIN_WEBHOOK_PATH`)

```json
{ "contract": "bays.publish.v1", "brand": "bayssystems", "idempotency_key": "2026-10-14:linkedin:<asset>",
  "text": "...", "hashtags": ["#..."], "image_brief": "...", "scheduled_at": "2026-10-14T09:00:00+03:00" }
```

**Zaman sözleşmesi (V2):** servis bu isteği yalnız `scheduled_at` geldiğinde gönderir (doğrudan LinkedIn yolu ile aynı kural). `scheduled_at` alanı bilgi amaçlıdır; n8n tarafında **ikinci bir bekletme/zamanlama yapmayın**, istek geldiğinde yayımlayın. Planlanan saatten `PUBLISH_MISSED_GRACE_MINUTES` (varsayılan 180 dk) sonra hâlâ gönderilmemiş yayın servis tarafından `missed` yapılır, n8n'e hiç gönderilmez ve bir kez yeniden planlanır.

Yanıt (hemen): `{"status":"accepted","idempotency_key":"..."}` — servis kaydı "sonuç bekleniyor" olarak tutar, **tekrar göndermez**.
İsterseniz senkron: `{"status":"published","external_id":"urn:li:share:..."}`.

Not: Mevcut akışınız görseli ve hashtag'i kendisi üretiyorsa, servisin gönderdiği `image_brief`/`hashtags` alanlarını yok sayabilir veya girdi olarak kullanabilirsiniz; hangisinin geçerli olduğunu bağlarken netleştirin.

## 2. Sonuç geri çağrısı — n8n → servis

`POST {BAYS_API_URL}/webhooks/n8n/publication-result` (imzalı)

```json
{ "idempotency_key": "...", "status": "published", "external_id": "urn:li:share:...", "error": null }
```
`status`: `published` | `failed`. Aynı sonuç ikinci kez gelirse yok sayılır. Geç gelen sonuç, manuel uzlaştırmaya düşmüş kaydı da kapatır.

## 3. Durum sorgusu (uzlaştırma) — servis → n8n

`POST {N8N_BASE_URL}/webhook/bays-linkedin-status` · gövde: `{"contract":"bays.publish_status.v1","brand":"...","idempotency_key":"..."}`

Yanıt: `{"status":"published","external_id":"..."}` | `{"status":"never_received"}` | `{"status":"unknown"}`. Emin değilseniz `unknown` döndürün: servis kurucuya manuel kontrol görevi açar, otomatik yeniden göndermez.

## 4. Zamanlayıcı — n8n → servis

`POST {BAYS_API_URL}/internal/cycle/{daily-plan|daily-report|weekly-review}` · gövde `{"trigger":"n8n","job":"...","at":"<ISO zaman>"}` · imzalı. Zaman 5 dakikadan eskiyse veya aynı gövde ikinci kez gelirse reddedilir. Varsayılan takvim Europe/Istanbul: 08:00, 20:00, Pazar 20:00.

## 5. E-posta yedeği — servis → n8n

`POST {N8N_BASE_URL}/webhook/bays-email-send` · gövde `{"contract":"bays.email.v1","to":"...","subject":"...","text":"..."}`. n8n'de "SMTP" kimliği kurulumda seçilir. E-posta yalnız rapordur; karar yürütmez.

## 6. Müşteriye e-posta (ilk temas/takip) — servis → n8n

Aynı uç: `POST {N8N_BASE_URL}/webhook/bays-email-send` · gövde `{"contract":"bays.outreach.v1","to":"...","subject":"...","text":"...","message_id":"<bays-...@bayssystems.local>"}` (imzalı).

- Yalnız `CUSTOMER_EMAIL_LIVE=true`, `RUN_MODE=live`, e-posta bağlantısı `live` ve alıcı kaynakta doğrulanmışken gönderilir; aksi hâlde kurucuya manuel görev açılır.
- Yanıt kodu anlamı: **2xx** = gönderildi; **4xx** = kesin gönderilmedi (servis yeniden deneyebilir); **5xx / zaman aşımı** = sonuç belirsiz → servis **yeniden göndermez**, kurucuya "gönderilenler kutusunu kontrol et" görevi açar. n8n akışı SMTP hatasında 5xx değil 4xx dönerse çift gönderim riski azalır; kesin olmayan durumda 5xx dönün.
- Teslimdeki `bays-email-fallback.json` "Send Email" düğümü `appendAttribution: false` ile gelir. Düğüm özel `Message-ID` başlığı ayarlayamadığından `message_id` şu an yalnız kayıt içindir; gelen yanıtlar gönderen adresiyle eşleşir.

## 7. Gelen e-posta — n8n → servis

`bays-email-inbound.json`: IMAP tetikleyici (emailReadImap v2.1) → imzalı `POST {BAYS_API_URL}/webhooks/email/inbound`

```json
{ "brand": "bayssystems", "message_id": "<...>", "in_reply_to": "<...>", "from": "kisi@ornek.com", "text": "...", "received_at": "2026-10-14T10:00:00Z" }
```
Eşleştirme: `in_reply_to` → bizim gönderdiğimiz kimlik; yoksa `from` → kayıtlı kişi; yoksa kurucuya `match_reply` görevi. Aynı `message_id` ikinci kez gelirse yeni işlem açılmaz (eksik sınıflandırma görevi varsa tamamlanır). Yanıt kaydı ve sınıflandırma görevi aynı veritabanı işleminde yazılır. Servis tarafı sınandı (V2-05, R-14); **n8n'de IMAP ile çalıştırma sınanmadı**.

## 8. Ölçüm aktarımı (V2.1) — n8n → servis

`POST {BAYS_API_URL}/webhooks/n8n/metrics` (imzalı, `X-Bays-Signature`)

```json
{ "contract": "bays.metrics.v1", "brand": "bayssystems",
  "publication": { "idempotency_key": "2026-10-14:linkedin:<asset>" },
  "delivery_id": "<bu ölçüm gönderiminin tekil kimliği>",
  "measured_at": "2026-10-14T19:00:00+03:00",
  "values": { "impressions": 410, "reactions": 12, "comments": null, "engagement_rate": 0.031 },
  "evidence_url": "https://..." }
```
- `publication` için `idempotency_key` (servisin yayın isteğinde gönderdiği) **veya** `external_id` (LinkedIn `urn:li:share:…`) verilir. Başka markanın yayını 404 döner.
- İzinli ölçüm türleri: `impressions`, `reactions`, `comments`, `shares`, `clicks` (tam sayı, ≥0) ve `engagement_rate` (0–1, yüzde değil). Bilinmeyen tür 400 döner.
- **Bilinmeyen değeri `null` gönderin, 0 yazmayın.** `null` atlanır ve yanıtta `skipped` olarak listelenir.
- Aynı `delivery_id` ikinci kez gelirse `{"status":"duplicate"}` döner. Aynı zaman ve aynı değer farklı kimlikle gelse de tekrar sayılır.
- Sayılar kümülatiftir: daha yeni `measured_at` güncel değeri değiştirir, eski değer tarihçede kalır ve ayrı deney örneği sayılmaz.
- Örnek akış: `n8n/bays-metrics-push.json`. Kaynak düğüm ("Ölçüm kaynağı (bağlanacak)") NoOp olarak bırakıldı. Teslim kimliği yayın + zaman + değerlerden türetilir. İmzalama kodunun servisle uyumu testle doğrulandı (M-07); **n8n'de içe aktarılıp çalıştırılmadı**.

## Bağlama adımları

1. `n8n/*.json` dosyalarını n8n'e import edin (Workflows → Import from file).
2. `bays-linkedin-adapter.json` içindeki "Mevcut LinkedIn akışı (bağlanacak)" düğümünü kendi akışınızla değiştirin (Execute Workflow düğümüyle mevcut akışı çağırabilirsiniz). Çıkışta `{ idempotency_key, status, external_id, error }` üretin.
3. Mevcut akışınızın kendi zamanlayıcısı varsa, çift yayın olmaması için ya onu ya bu adaptörü kullanın — ikisini birlikte değil.
4. Test: `npm run n8n:validate` (node tanımları — bu yalnız yapı kontrolüdür, n8n'de çalıştırma kanıtı değildir) → n8n'de "Test workflow" ile örnek istek → servis panelinde yayın durumunu kontrol edin.
5. Panelden bağlantıyı `configured` → doğrulama kaydıyla `verified` → kurucu kararıyla `live` yapın.
