# A Aşaması — Keşif, bağımlılık ve uygulama planı

Tarih: 14 Ekim 2026 · Hazırlayan: Claude (Opus 5.5) · Şartname: BaysSystems Claude geliştirme görevi V1

## 1. Mevcut proje ve akış keşfi

| Girdi | Durum | Sonuç |
| --- | --- | --- |
| Mevcut repo | **Paylaşılmadı** (kurucu kararı, 14.10.2026) | Yeni bağımsız proje kuruldu. Göç/uyarlama raporu üretilemedi. |
| Mevcut LinkedIn n8n workflow JSON'u | **Paylaşılmadı** | İncelenmedi, test edilmedi. "İçerik + görsel + hashtag üretip belirlenmiş saatte onaysız yayımlıyor" ifadesi yalnız **kullanıcı beyanı** olarak kaydedildi. Bağlantı için `n8n-linkedin` adaptör sözleşmesi hazırlandı. |
| n8n sunucu sürümü | **Bilinmiyor** | Teslim JSON'ları npm'deki güncel kararlı **n8n 2.43.4** (n8n-nodes-base 2.43.2) node tanımlarına göre doğrulandı. Sunucunuz farklı sürümdeyse yeniden doğrulayın (`npm run n8n:validate`). |
| Sunucu kapasitesi / Hostinger planı | **Bilinmiyor** | Docker Compose yerel simülasyon için hazırlandı; üretim uygunluğu kontrol edilmedi. |
| Sağlayıcı kredileri / fiyatları | **Bilinmiyor** | Fiyat tablosu boş yer tutucularla geldi; fiyatı bilinmeyen ücretli iş engellenir. |
| WhatsApp bot numarası, şablonlar | **Yok** | Adaptör `disconnected`; karar paneli + e-posta yedeği devrede. |
| Doğrulanmış demo / fiyat listesi | **Yok** | Hizmet kayıtları "kullanıcı beyanı" durumunda; hiçbiri "testle doğrulandı" değil. |

Bu oturumda gördüklerim: yalnız şartname dosyası. Hiçbir hesap, sunucu veya workflow'a erişim olmadı ve öyle iddia edilmiyor.

## 2. Geliştirme ortamı (gerçek değerler)

| Bileşen | Sürüm | Not |
| --- | --- | --- |
| Node.js | 22.22.0 | Docker imajı: `node:22-alpine` |
| PostgreSQL | 16.15 (yerel) | Docker imajı: `postgres:16-alpine` |
| n8n (hedef) | 2.43.4 | Docker imajı: `n8nio/n8n:2.43.4` |
| TypeScript | 5.x (package.json'da kilitli) | — |
| Docker Engine / Compose | 29.8.2 / v5.5.1 | Bu ortamda Docker Hub erişimi **engelli (403)**; imajlar çekilemedi. Compose dosyası `docker compose config` ile sözdizimsel doğrulandı; konteynerle çalıştırma sizin makinenizde yapılmalı. Testler yerel PostgreSQL 16 üzerinde gerçekten çalıştırıldı. |

## 3. Kanal ve sağlayıcı doğrulama matrisi

Ayrıntı: `docs/kanal_yetenek_matrisi.md`. Özet: LinkedIn'de yalnız **üye adına yayın** self-servis görünüyor; mesaj ve bağlantı daveti onaylı iş ortaklarına kısıtlı → sistemde **taslak/manuel görev**. WhatsApp Cloud API karar akışı için teknik olarak uygun (imzalı webhook, etkileşimli butonlar), ancak numara/şablon/hesap yok.

## 4. Uygulama planı (şartnameye göre)

Yığın şartnamedeki varsayımla aynı: **n8n + TypeScript servis + PostgreSQL + vanilla mobil panel**. Panel derleme adımı olmadan vanilla HTML/CSS/JS (sizin alıştığınız yaklaşım).

- **B — Çekirdek:** 23 asgari tablo + yardımcı tablolar; PostgreSQL **satır düzeyi güvenlik (RLS)** ile marka izolasyonu; ayrı veritabanı rolleri (`bays_app`, `bays_auditor`); sürümlü bilgi merkezi (ham araştırma / hipotez / doğrulanmış kural / politika ayrı); görev kuyruğu (idempotency, model çağrısı ≤6, tekrar ≤3, döngü algılama); yetki politikası; atomik bütçe rezervasyonu (hedef 5.000 TL, kesin üst sınır 10.000 TL); global/marka/kanal/kampanya durdurma.
- **C — Ajanlar:** 5 rol, her biri sürümlü talimat + bilgi kapsamı + araç izni + JSON şeması + değerlendirme örneği + hata davranışı; mock sağlayıcı (deterministik); deterministik koruma katmanı (kanıtsız vaat, sahte referans, prompt injection, marka karışması); CRM aşamaları, mükerrer temas ve iletişim istemeyenler listesi; deney motoru (yetersiz veride hüküm yok); denetçi (yalnız bulgu yazar + durdurabilir, ikinci değerlendirme).
- **D — Entegrasyon:** adaptör durum makinesi; anahtar/durum yokken HTTP çıkışı engelli; LinkedIn doğrudan API adaptörü + mevcut n8n akışına bağlanacak adaptör; WhatsApp Cloud API (imza doğrulama, durumlar, karar butonları); e-posta yedeği; mobil panel; n8n import JSON'ları.
- **E — Güvenlik/test:** 14 zorunlu kabul testi gerçek PostgreSQL'de; yedekleme/geri yükleme; kişisel veri silme; iki uçtan uca simülasyon.
- **F — Teslim:** kurulum rehberi, raporlar, eksik bağlantı listesi, canlıya geçiş kontrol listesi, ZIP; ayrı ajanla bağımsız kod incelemesi.

## 5. Kesin karar olarak uygulananlar

Ücretli reklam **kapalı** (yetki motorunda `forbidden`, yapılandırmayla açılamaz). Başlangıç markası BaysSystems, pazar Türkiye, dil Türkçe. Aylık hedef bütçe 5.000 TL; kurucu kararıyla en fazla 10.000 TL'ye çıkarılabilir; 10.000 TL'yi aşmak kod/ajan/panel üzerinden mümkün değil, yalnız sunucu yapılandırmasını kurucu değiştirerek.
