# V2.1 düzeltme matrisi

Tarih: 14.10.2026 · Sürüm: 2.1.1 (2.1.0 + açık ret kelime sınırı düzeltmesi) · Ortam: Node 22, PostgreSQL 16 (yerel), Docker yok.
Yöntem: Her bulgu önce koda bakılarak doğrulandı. Ardından bulguyu gösteren regresyon testi yazıldı (`tests/h_v21.test.ts`) ve **düzeltmeden önce çalıştırıldı: 22 testten 21'i kırmızıydı**. Sonra düzeltildi. Son durum: **107/107 test geçti**: 49 V1, 18 V2, 15 V2 inceleme ve 25 V2.1 testi.

Düzeltme öncesi çalıştırmadan örnek hata çıktıları:
- K-01: canlı strateji bağlamında etkileşim ortalaması 0,455 çıktı; beklenen 0,01'di. Örnek veri (0,9) ile gerçek veri (0,01) karışmıştı.
- K-04: ÖRNEK aday, e-posta bağlantısı canlıyken `sent` döndü; yani gerçek kanaldan gönderilecekti.
- O-02: model hata verdiğinde "Bir daha yazmayın" yanıtı sonrası aday `contacted` kaldı.
- B-05: model 5xx ve 4xx hatalarında iki rezervasyon da `active` kaldı.
- M-06: aynı gönderinin 3 ölçümü vardı ama deney değerlendirmesi kol başına 0 örnek gördü; gerçek ölçüm yolu yoktu.

## 1. Gerçek performans ölçümlerinin sisteme alınması

| | |
|---|---|
| **Belirti** | Ölçüm yazan tek yol `ingestMockMetrics` idi ve yalnız simülasyonda çalışıyordu. Kurucu veya n8n gerçek ölçüm giremiyordu. Deney değerlendirmesi her ölçüm satırını ayrı örnek sayıyordu. |
| **Kök neden** | Ölçüm girişi için API/webhook/panel yoktu. `metrics` tablosunda "güncel anlık görüntü" kavramı ve tekrar teslim anahtarı yoktu. `evaluateExperiment` satır sayıyordu, yayın saymıyordu. |
| **Değişen dosyalar** | `src/metrics/ingest.ts` (yeni). `src/api/server.ts`: `POST/GET /api/brands/:id/metrics`, `GET /api/brands/:id/publications/live`, imzalı `POST /webhooks/n8n/metrics`. `panel/index.html` (Ölçüm sekmesi). `migrations/004_v21.sql` (metrics: `is_current`, `external_key`, `received_at`, `recorded_by`; tek güncel satır ve teslim kimliği için tekil indeksler). `src/learning/experiments.ts` (yalnız güncel satır; örnek ve canlı ayrı). `src/agents/strategyContext.ts`, `src/reports/reports.ts` (yalnız güncel satır). `tools/build-n8n.mjs` → `n8n/bays-metrics-push.json`. |
| **Davranış** | Yayın markaya ait, canlı ve yayımlanmış olmalı; ÖRNEK yayına gerçek ölçüm 422 ile reddedilir. İzinli ölçüm türleri: impressions, reactions, comments, shares, clicks (tam sayı, ≥0) ve engagement_rate (0–1). Ölçüm zamanı gelecekte ya da yayından önce olamaz. Kanıt zorunlu: https URL veya not; n8n'de teslim kimliği. Boş değer atlanır ve "sıfır sayılmadı" diye bildirilir. Deney ve kol istemciden alınmaz, yayının içerik kaydından türetilir. **Güncelleme politikası:** daha yeni ölçüm güncel değeri değiştirir, eskisi tarihçeye geçer; geç gelen eski ölçüm yalnız tarihçeye yazılır; aynı zaman ve aynı değer tekrar sayılır; aynı zamanda farklı değer düzeltme sayılır; aynı teslim kimliği tekrar sayılır. Deney değerlendirmesinde yayın başına tek örnek kullanılır. |
| **Doğrulayan testler** | M-01 yetkisiz giriş ve imzasız webhook · M-02 başka markanın yayını (API ve webhook) · M-03 geçersiz değer, eksik kanıt, gelecek zaman, yayından önce, ÖRNEK yayın, boş değer · M-04 tekrar teslim (aynı teslim kimliği; farklı kimlik ama aynı içerik) · M-05 kümülatif güncelleme ve geç gelen ölçüm · M-06 doğru deney kolu, 3 ölçüm = 1 örnek, strateji bağlamına ulaşma · M-07 n8n akışındaki imzalama kodu Node ile çalıştırıldı, servis kabul etti, ikinci gönderim tekrar sayıldı |
| **Kalan sınır** | LinkedIn analiz verisine API erişiminiz doğrulanmadı. n8n akışındaki "Ölçüm kaynağı" düğümü bağlanacak bir NoOp düğümü; ölçüm şimdilik panelden elle ya da kendi akışınızdan gelir. **n8n'de içe aktarılıp çalıştırılmadı**, yalnız yapı ve imza uyumu sınandı. Görsel panel ekranı tarayıcıda açılıp elle denenmedi; API'si testli. |

## 2. Simülasyon, değerlendirme ve canlı veri ayrımı

| | |
|---|---|
| **Belirti** | Strateji bağlamında müşteri, araştırma ve ölçüm toplamlarında kip filtresi yoktu; ortalamalar örnek ve gerçek veriyi birleştiriyordu. Ayrıca şu sorunlar bulundu: (a) Aynı gün simülasyondan canlıya geçişte `2026-10-13:daily_plan` gibi görev anahtarı örnek görevle çakışıyor, canlı iş açılmıyordu. (b) Bekleyen örnek görev canlı e-posta bağlantısıyla çalıştırılabiliyordu. Bu en ciddisiydi: gerçek gönderim olurdu. (c) Örnek araştırma önbelleği canlı süreçte kullanılıyordu. (d) Canlı görev örnek kampanyaya bağlanabiliyor, model bağlamına ÖRNEK kanıt girebiliyordu. (e) Kalite değerlendirmesi görevleri operasyon kuyruğunda duruyordu. (f) Kip belirtmeden yazılan kayıt varsayılan olarak "canlı" sayılıyordu. (g) Denetçi simülasyon bulgularını canlı işaretliyordu. |
| **Kök neden** | Tekillik kısıtları kipi içermiyordu: `tasks`, `manual_tasks`, `leads`, `source_documents`, `research_queries`, `research_runs`. Sorgularda `is_simulated`/`is_sample` filtresi eksikti. Worker kip ayırt etmeden görev alıyordu. Birçok tabloda `DEFAULT false` vardı. |
| **Değişen dosyalar** | `migrations/004_v21.sql`: kip bazlı tekillik; `tasks.purpose` ve `agent_runs.purpose`; `mode_unknown` sütunları; DEFAULT kaldırıldı. `src/core/tasks.ts`, `src/worker/worker.ts` (worker yalnız kendi kipindeki operasyon görevini alır; eval kipinde hiç almaz). `src/crm/outreach.ts` (örnek görev canlı kanala, örnek aday canlı temasa gidemez). `src/research/research.ts` (önbellek ve tekilleştirme kip bazlı; örnek görev canlı sağlayıcıyı çağıramaz). `src/crm/crm.ts`, `src/crm/manual.ts`, `src/orchestrator/chain.ts` (kampanya, aday, manuel iş ve uzlaştırma sorguları). `src/agents/strategyContext.ts`. `src/agents/runner.ts` (kanıt ve bilgi bağlamı). `src/evals/quality.ts`. `src/auditor/auditor.ts`. `src/reports/reports.ts`. |
| **Geçiş koruması** | Göç hiçbir veriyi silmez. Veritabanında canlı işlem kanıtı yoksa (canlı gider, yayın, temas veya ölçüm) `false` işaretli eski satırlar `mode_unknown=true` olur. Bunlar canlı karara girmez, raporda "kipi bilinmeyen eski kayıt" olarak ayrı görünür. Canlı kanıt varsa işaretleme yapılmaz; kurucu gözden geçirir (`settings: migration.004.live_proof`). Bundan sonra kip belirtmeyen kayıt veritabanı tarafından reddedilir. |
| **Doğrulayan testler** | K-01 aynı markada örnek ve gerçek veri: canlı bağlam yalnız gerçeği görür, ortalama karışmaz · K-02 kipi bilinmeyen kayıt canlı sayılmaz, kipsiz kayıt reddedilir · K-03 aynı gün kip değişimi: canlı kök görev ayrı açılır, canlı worker örnek görevi almaz · K-04 bekleyen örnek gönderim canlı bağlantıyla çalışmaz, n8n'e istek gitmez · K-05 örnek sorgu ve sayfa önbelleği canlı süreçte kullanılmaz · K-06 canlı görev örnek kampanyaya ve örnek kanıta bağlanmaz · K-07 kalite değerlendirmesi operasyon görevlerini, adayları, ölçümleri ve fırsatları değiştirmez; worker değerlendirme görevini almaz |
| **Kalan sınır** | Canlı kanıt bulunan veritabanında eski satırlar otomatik işaretlenmez; kurucu gözden geçirmesi gerekir. Diğer kipe ait bekleyen görevler silinmez veya iptal edilmez, yalnız yürütülmez ve raporda görünür. Gerçek model değerlendirmesinin maliyeti gerçek para olduğu için canlı bütçeye yazılır; bu bilinçli bir tercih. |

## 3. Açık iletişim reddinin modelden önce işlenmesi

| | |
|---|---|
| **Belirti** | `reply_classify` içinde kesin ret kontrolü model çağrısından sonra yapılıyordu. Model anahtarı, fiyat ya da bütçe hatasında görev başarısız oluyor ve iletişim yasağı kaydedilmiyordu. |
| **Kök neden** | Deterministik tespit `runAgent`'tan sonra yer alıyordu ve yanıt kaydıyla aynı işlemde değildi. |
| **Değişen dosyalar** | `src/crm/optout.ts` (yeni). `src/crm/outreach.ts`: `ingestReply` açık reddi yanıt kaydıyla aynı veritabanı işleminde uygular. `src/crm/manual.ts`: elle girilen yanıt da aynı şekilde işlenir. `src/orchestrator/chain.ts`: `reply_classify` modelden önce kontrol eder ve açık retse modeli çağırmaz. |
| **Davranış** | Kesin ifadeler her zaman ret sayılır: listeden çıkarın, bir daha yazmayın, iletişime geçmeyin, rahatsız etmeyin, abonelikten çık. Tek başına "istemiyorum" ise yalnız kısa ve çekincesiz olduğunda ya da bizim iletilerimizi hedeflediğinde ret sayılır. Çekinceli ifadeler model yoluna gider; örneğin "şimdilik istemiyoruz, belki ileride" veya "fiyat istemiyorum, önce demo". Alıntılanan önceki ileti değerlendirmeye girmez; bizim altbilgimizdeki "İSTEMİYORUM" alıntıda geçebilir. Türkçe büyük/küçük harf `tr-TR` ile dönüştürülür. Ret uygulanınca: iletişim yasağı kaydedilir (işletme ve e-posta), aday `lost` olur, bekleyen `contact_send`/`follow_up_check` görevleri `cancelled`, açık gönderim işleri `skipped` olur. Model anahtarı veya bütçe gerekmez. İşlem idempotent: tekrar teslimde yeni olay, fırsat veya karar oluşmaz. |
| **Doğrulayan testler** | O-01 "LÜTFEN BENİ LİSTEDEN ÇIKARIN, İSTEMİYORUM": worker çalışmadan önce yasak, kayıp ve iptal; model çağrısı 0 · O-02 model anahtarı yok (enjekte hata) ve bütçe dolu: ret yine kaydedilir, model çağrısı 0 · O-03 belirsiz ifade ret sayılmaz, model yoluna gider · O-04 üç kez tekrar teslim: tek olay; fırsat, karar ve çelişkili durum yok · R-04 (V2) korunuyor |
| **Kalan sınır** | İfade listesi kural tabanlıdır; listede olmayan bir ret ifadesi model yoluna düşer. Model yokken bu tür yanıtlar sınıflandırılamaz, görev yeniden denenir ve yasak otomatik oluşmaz. Gerçek yanıt örnekleriyle liste gözden geçirilmeli. |

## 4. Belirsiz araştırma giderlerinin uzlaştırılması

| | |
|---|---|
| **Belirti** | `research.ts` arama hatasında rezervasyonu her durumda serbest bırakıyordu. İstek sağlayıcıya ulaşıp ücretlenmiş olsa bile gider kayboluyordu. Model çağrısında ise başarısız rezervasyon `active` kalıyor, kimse uzlaştırmıyordu. WhatsApp şablon gönderiminde de her hata "gönderilemedi" sayılıp rezervasyon bırakılıyordu. |
| **Kök neden** | "Çağrı yapılmadı", "kesin ücretlenmedi" ve "belirsiz" ayrımı yoktu. Sağlayıcı hataları HTTP durumunu taşımıyordu. |
| **Değişen dosyalar** | `src/core/callOutcome.ts` (yeni sınıflandırıcı). `src/core/budget.ts`: `settleFailedCall`, `markUncertain`, `resolveUncertainCost`; `uncertain` toplamda sayılır; her rezervasyonda `call_ref` var. `src/research/research.ts` (arama ve sayfa okuma). `src/agents/runner.ts` (model). `src/notify/notifier.ts` ve `src/integrations/whatsapp.ts` (şablon). `src/research/providers.ts` ve `src/agents/providers.ts` (hatalar `httpStatus` taşır). `src/crm/manual.ts` (`reconcile_cost` işi). `panel/index.html` ("Uzlaştır" düğmesi). `src/auditor/auditor.ts` (`uncertain_cost` bulgusu). `src/reports/reports.ts` ("Uzlaştırma bekleyen" satırı). `migrations/004_v21.sql`. |
| **Davranış** | Egress, bütçe, fiyat ya da anahtar engeli → çağrı yapılmadı, rezervasyon bırakılır. HTTP 4xx (401, 402, 403, 429…) → sağlayıcı reddetti, ücretlenmedi, bırakılır. Zaman aşımı, bağlantı kopması, 5xx veya bilinmeyen hata → **belirsiz**: rezervasyon `uncertain` kalır, tahmini tutar bütçede sayılır, kurucuya tek bir "reconcile_cost" işi açılır, raporda ve denetimde görünür. Kurucu "ücretlendi (tutar)" derse deftere bir kez yazılır; ikinci kayıt yazılmaz. "Ücretlenmedi" derse rezervasyon bırakılır. Her deneme ayrı rezervasyon ve ayrı `call_ref` taşır. |
| **Doğrulayan testler** | B-01 dış çağrı öncesi engel: fiyat bilinmiyorsa rezervasyon açılmaz, egress engelinde bırakılır · B-02 sağlayıcı isteği aldıktan sonra zaman aşımı: belirsiz, toplamda 400 TL, uzlaştırma işi var, raporda görünür · B-03 5xx belirsiz, 401 bırakıldı · B-04 tekrar deneme ayrı izleniyor; uzlaştırma üç kez (iki "ücretlendi", bir "ücretlenmedi") ve manuel iş yoluyla yapılsa da defterde tek kayıt · B-05 model çağrısında aynı desen · B-06 Brave, Anthropic, OpenAI ve WhatsApp hata biçimlerinin sınıflandırması |
| **Kalan sınır** | Sağlayıcının gerçek faturasıyla otomatik eşleştirme yok; uzlaştırmayı kurucu yapar. Sınıflandırma sağlayıcının HTTP durumuna güvenir; 2xx dönüp gövdesi okunamayan yanıt temkinli olarak belirsiz sayılır. WhatsApp şablon yolu canlı WhatsApp gerektirdiği için uçtan uca değil, yalnız sınıflandırma düzeyinde test edildi (B-06). |

## 2.1.1 düzeltmesi: açık ret tespitinde Türkçe kelime sınırı

| | |
|---|---|
| **Belirti** | `detectExplicitOptOut('Fiyat istemiyorum, önce demo')` ve `'Fiyat istemiyorum önce demo'` **true** dönüyordu. Bu yanıtlar ret değil, çekinceli ilgi ifadesi; yanlışlıkla iletişim yasağına alınıp aday kaybedildi sayılacaktı. |
| **Kök neden** | `src/crm/optout.ts` içinde çekince listesi `\bönce\b` gibi JavaScript `\b` sınırı kullanıyordu. `\b`, `u` bayrağıyla bile yalnız ASCII harfleri kelime karakteri sayar. "ö" harf sayılmadığı için ` önce` başındaki sınır bulunamadı, çekince görülmedi; kısa yanıt (≤6 kelime) kuralı da onu ret saydı. Aynı risk `şimdilik`, `ışık` gibi Türkçe karakterle başlayan/biten bütün sözcüklerde vardı. |
| **Düzeltme** | Tüm `\b` kullanımları kaldırıldı. Yerine Unicode harf/rakam bakışlarıyla (`(?<![\p{L}\p{N}])…(?![\p{L}\p{N}])`) kelime sınırı kuran `word()` ve ek alabilen kökler için `wordPrefix()` yardımcıları kondu. Böylece "önce" tanınıyor, ama "öncelikle" ve "tamam" içindeki "önce" ve "ama" çekince sayılmıyor. Değişen dosya: `src/crm/optout.ts`. |
| **Doğrulayan test** | O-05: iki cümle (ve büyük harfli hali) `false` döner; `ingestReply` üzerinden iletişim yasağı yok, aday `lost` değil, `contact.opted_out` olayı yok, `reply_classify` görevi kuyrukta, worker modeli çağırıp sınıflandırmayı tamamlıyor. Açık retler korunuyor: "İSTEMİYORUM", "Bir daha yazmayın", "Hayır, istemiyorum.", "lütfen listeden çıkarın" `true` döner; O-01, O-02, O-04 ve R-04 değişmeden geçiyor. Düzeltmeden önce O-05 kırmızıydı ("Fiyat istemiyorum, önce demo: expected true to be false"). |
| **Kalan sınır** | İfade listesi hâlâ kural tabanlı. Çekince listesine tek başına "sonra" eklendi; bu, belirsiz yanıtların daha çok model yoluna gitmesi yönünde temkinli bir değişiklik. |

## Testlerde yapılan değişiklikler (beklenti gevşetilmedi)

| Dosya | Değişiklik | Neden |
|---|---|---|
| `tests/g_review.test.ts` | R-01–R-03 canlı gönderim testleri ÖRNEK olmayan aday kullanıyor | V2.1 kuralı örnek adayın canlı kanaldan temasını engelliyor. Bu kural K-04 ile ayrıca test ediliyor. Testlerin çift gönderim beklentileri değişmedi. |
| `tests/g_review.test.ts` | R-04 yasak kaydı gerekçe metni `%istemedi%` yerine `%açık ret%` | Gerekçe metni değişti. Yasak kaydının e-posta anahtarıyla oluşması beklentisi aynı. |
| `vitest.config.ts` | Test dosyası sırası sabitlendi: V2 dosyaları V2'deki sırayla (f, e, g, d, b, c), V2.1 dosyası en sonda | Vitest'in varsayılan sırası önbellekteki sürelere göre değişiyordu. KT-10, `c_agents`'ın elle eklediği yayından önce koşmaya bağlıydı; sıra değişince yanlış yayını seçiyordu (V2'de de var olan kırılganlık). Sabit sırayla iki ardışık çalıştırma 104/104, 2.1.0 son çalıştırması 106/106, 2.1.1 çalıştırması 107/107 geçti. |

## Ek bulgu (düzeltildi)

`npm run eval:quality` aynı saat içinde art arda çalıştırılınca döngü algılayıcı aynı parmak izli görevleri engelliyordu: üçüncü-dördüncü çalıştırmada çıktı boş kalıyordu. Bu V2'de de vardı. Her değerlendirme çalıştırmasına ayrı anahtar eklendi; dört ardışık çalıştırma sorunsuz geçti.
