// Vitest JSON çıktısından Türkçe test raporu üretir: docs/test_raporu.md
import fs from 'node:fs';
import { execSync } from 'node:child_process';

const j = JSON.parse(fs.readFileSync('reports/vitest.json', 'utf8'));
const now = new Date();
const tz = now.toLocaleString('tr-TR', { timeZone: 'Europe/Istanbul' });
const node = process.version;
let pgv = 'bilinmiyor';
try { pgv = execSync('psql --version').toString().trim(); } catch {}

const rows = [];
for (const f of j.testResults) {
  for (const t of f.assertionResults) {
    rows.push({ file: f.name.split('/tests/')[1], title: [...t.ancestorTitles.slice(1), t.title].join(' › '), status: t.status, ms: Math.round(t.duration ?? 0) });
  }
}
const pass = rows.filter((r) => r.status === 'passed').length;
const fail = rows.filter((r) => r.status !== 'passed').length;
const kt = rows.filter((r) => /^KT-\d\d/.test(r.title.split(' › ').pop()));

let evalOut = '', n8nOut = '', qMock = '', qLive = '';
try { qMock = execSync('npx tsx src/cli.ts eval-quality', { env: process.env }).toString(); } catch (e) { qMock = String(e.stdout ?? e); }
try { qLive = execSync('npx tsx src/cli.ts eval-quality --live', { env: { ...process.env, RUN_MODE: 'eval' } }).toString(); } catch (e) { qLive = String(e.stdout ?? e); }
const v2 = rows.filter((r) => /^V2-\d\d/.test(r.title.split(' › ').pop()));
const rv = rows.filter((r) => /^R-\d\d/.test(r.title.split(' › ').pop()));
const v21 = rows.filter((r) => r.file === 'h_v21.test.ts');
const tbl = (xs) => xs.map((r) => `| ${r.title.split(' › ').pop().split(' ')[0]} | ${r.title.split(' › ').pop().split(' ').slice(1).join(' ').replace(/\|/g, '/')} | ${r.status === 'passed' ? '✓ geçti' : '✗ ' + r.status} | ${r.ms} |`).join('\n');
try { evalOut = execSync('npx tsx src/cli.ts eval', { env: process.env }).toString(); } catch (e) { evalOut = String(e.stdout ?? e); }
try { n8nOut = execSync('node tools/validate-n8n.mjs').toString(); } catch (e) { n8nOut = String(e.stdout ?? e); }

const md = `# Test raporu

Oluşturulma: **${tz}** (Europe/Istanbul) · Node ${node} · ${pgv}

Sürüm: **${JSON.parse(fs.readFileSync('package.json','utf8')).version}** · Komut: \`npm run test:report\` (içinde \`vitest run\`, \`tsx src/cli.ts eval\`, \`eval-quality\`, \`node tools/validate-n8n.mjs\`) · Test dosyası sırası sabit (vitest.config.ts)

Sonuç: **${pass} geçti, ${fail} başarısız** (toplam ${rows.length}).

## Test türleri

| Tür | Kapsam | Durum |
| --- | --- | --- |
| Mock / simülasyon testi | Aşağıdaki tüm testler. Gerçek PostgreSQL 16 üzerinde, RLS ve veritabanı rolleri dahil; dış sağlayıcılar mock/fixture; e-posta çift gönderim testleri yerel sahte HTTP sunucusuyla (127.0.0.1). | Çalıştırıldı |
| Canlı entegrasyon testi | LinkedIn yayını, WhatsApp gönderimi, n8n akışı, model sağlayıcısı, e-posta, Brave araştırma, gerçek web sayfası okuma | **Çalıştırılmadı** — hesap/anahtar yok, kod gereği engelli |
| Henüz çalıştırılamayan kontroller | Docker imajlarıyla \`docker compose up\` (bu ortamda Docker Hub erişimi 403), n8n'e import edip çalıştırma, gerçek model çıktısıyla değerlendirme seti, sağlayıcı faturasıyla maliyet uzlaştırması | Canlıya geçiş listesinde |

## Şartname §11 zorunlu kabul testleri

| # | Test | Sonuç | Süre (ms) |
| --- | --- | --- | --- |
${kt.map((r) => `| ${r.title.split(' › ').pop().slice(0, 5)} | ${r.title.split(' › ').pop().slice(6)} | ${r.status === 'passed' ? '✓ geçti' : '✗ ' + r.status} | ${r.ms} |`).join('\n')}

## V2 görev dosyası §9 — 18 yeni kabul testi

| # | Test | Sonuç | Süre (ms) |
| --- | --- | --- | --- |
${tbl(v2)}

## Bağımsız V2 incelemesi düzeltme testleri

| # | Test | Sonuç | Süre (ms) |
| --- | --- | --- | --- |
${tbl(rv)}

## V2.1 düzeltme testleri (önce kırmızı yazıldı, sonra düzeltildi)

| # | Test | Sonuç | Süre (ms) |
| --- | --- | --- | --- |
${tbl(v21)}

## Kalite değerlendirmesi (20 senaryo, rol başına 4)

Mock sözleşme kipi — **model kalitesi değildir**; yalnız çıktı sözleşmesi, korumalar ve puanlama kodunun çalıştığını gösterir:

\`\`\`
${qMock.trim()}
\`\`\`

Gerçek model kipi (\`npm run eval:quality:live\`) — anahtar/canlı model yokken beklenen sonuç BEKLEMEDE'dir:

\`\`\`
${qLive.trim()}
\`\`\`

## Tüm testler

| Dosya | Test | Sonuç |
| --- | --- | --- |
${rows.map((r) => `| ${r.file} | ${r.title.replace(/\|/g, '/')} | ${r.status === 'passed' ? '✓' : '✗ ' + r.status} |`).join('\n')}

## Ajan değerlendirme seti (deterministik koruma katmanı, mock)

\`\`\`
${evalOut.trim()}
\`\`\`

## n8n JSON doğrulaması

\`\`\`
${n8nOut.trim()}
\`\`\`
`;
fs.writeFileSync('docs/test_raporu.md', md);
console.log(`docs/test_raporu.md yazıldı: ${pass}/${rows.length}`);
