-- V2.1 → V2 şema geri dönüşü. ÖNCE YEDEK ALIN (pg_dump). Tercih edilen yol: 004 öncesi yedeğin geri yüklenmesi.
-- Bu betik yedek yoksa V2 kodunun V2.1 ile büyümüş veritabanında çalışabilmesi içindir. Veri silmez; V2'nin
-- kısıtlarına sığmayan kayıtları dönüştürür:
--  * Kip bazlı tekillikte çakışan ÖRNEK kayıtların anahtarına ":ornek" eklenir (canlı kayıt anahtarını korur).
--  * "uncertain" rezervasyonlar "expired" olur: V2'de de bütçe toplamında sayılır (temkinli), denetçi uzlaştırma ister.
--  * "reconcile_cost" manuel işleri "fix_bottleneck" olarak kalır (yük/payload korunur).
BEGIN;
-- Tekillik çakışmalarını çöz (aynı anahtar hem örnek hem canlı kayıtta varsa örneğinkini yeniden adlandır)
UPDATE tasks t SET idempotency_key = t.idempotency_key || ':ornek'
 WHERE t.is_simulated AND EXISTS (SELECT 1 FROM tasks x WHERE x.brand_id=t.brand_id AND x.idempotency_key=t.idempotency_key AND NOT x.is_simulated);
UPDATE manual_tasks m SET dedupe_key = m.dedupe_key || ':ornek'
 WHERE m.is_simulated AND EXISTS (SELECT 1 FROM manual_tasks x WHERE x.brand_id=m.brand_id AND x.dedupe_key=m.dedupe_key AND NOT x.is_simulated);
UPDATE leads l SET business_key = l.business_key || ':ornek'
 WHERE l.is_sample AND EXISTS (SELECT 1 FROM leads x WHERE x.brand_id=l.brand_id AND x.business_key=l.business_key AND NOT x.is_sample);
UPDATE source_documents d SET url_hash = d.url_hash || ':ornek'
 WHERE d.is_simulated AND EXISTS (SELECT 1 FROM source_documents x WHERE x.brand_id=d.brand_id AND x.url_hash=d.url_hash AND NOT x.is_simulated);
UPDATE research_queries q SET query_hash = q.query_hash || ':ornek'
 WHERE q.is_simulated AND EXISTS (SELECT 1 FROM research_queries x WHERE x.brand_id=q.brand_id AND x.provider=q.provider AND x.query_hash=q.query_hash AND NOT x.is_simulated);
UPDATE research_runs r SET provider = r.provider || ':ornek'
 WHERE r.is_simulated AND EXISTS (SELECT 1 FROM research_runs x WHERE x.brand_id=r.brand_id AND x.day=r.day AND x.provider=r.provider AND NOT x.is_simulated);

ALTER TABLE tasks DROP CONSTRAINT tasks_brand_key_mode_key;
ALTER TABLE tasks ADD CONSTRAINT tasks_brand_id_idempotency_key_key UNIQUE (brand_id, idempotency_key);
ALTER TABLE manual_tasks DROP CONSTRAINT manual_tasks_brand_key_mode_key;
ALTER TABLE manual_tasks ADD CONSTRAINT manual_tasks_brand_id_dedupe_key_key UNIQUE (brand_id, dedupe_key);
ALTER TABLE leads DROP CONSTRAINT leads_brand_key_mode_key;
ALTER TABLE leads ADD CONSTRAINT leads_brand_id_business_key_key UNIQUE (brand_id, business_key);
ALTER TABLE source_documents DROP CONSTRAINT source_documents_brand_url_mode_key;
ALTER TABLE source_documents ADD CONSTRAINT source_documents_brand_id_url_hash_key UNIQUE (brand_id, url_hash);
ALTER TABLE research_queries DROP CONSTRAINT research_queries_brand_q_mode_key;
ALTER TABLE research_queries ADD CONSTRAINT research_queries_brand_id_provider_query_hash_key UNIQUE (brand_id, provider, query_hash);
ALTER TABLE research_runs DROP CONSTRAINT research_runs_brand_day_mode_key;
ALTER TABLE research_runs ADD CONSTRAINT research_runs_brand_id_day_provider_key UNIQUE (brand_id, day, provider);

-- Belirsiz gider
UPDATE budget_reservations SET status='expired' WHERE status='uncertain';
ALTER TABLE budget_reservations DROP CONSTRAINT budget_reservations_status_check;
ALTER TABLE budget_reservations ADD CONSTRAINT budget_reservations_status_check CHECK (status IN ('active','reconciled','released','expired'));
ALTER TABLE budget_reservations DROP COLUMN call_ref, DROP COLUMN outcome_note, DROP COLUMN resolved_at, DROP COLUMN resolved_by;
UPDATE manual_tasks SET kind='fix_bottleneck', payload = payload || '{"v21_kind":"reconcile_cost"}'::jsonb WHERE kind='reconcile_cost';
ALTER TABLE manual_tasks DROP CONSTRAINT manual_tasks_kind_check;
ALTER TABLE manual_tasks ADD CONSTRAINT manual_tasks_kind_check CHECK (kind IN ('send_first_contact','send_follow_up','linkedin_message','linkedin_connection','verify_publication','match_reply','add_contact','record_demo','fix_bottleneck'));

-- Kip bilinmiyor işaretleri ve varsayılanlar (V2'deki gibi DEFAULT false)
DO $$
DECLARE t text; f text;
BEGIN
  FOR t, f IN SELECT * FROM (VALUES ('leads','is_sample'),('contacts','is_sample'),('assets','is_sample'),('campaigns','is_sample'),('evidence','is_sample'),
      ('opportunities','is_simulated'),('meetings','is_simulated'),('experiments','is_simulated'),('manual_tasks','is_simulated'),
      ('approval_requests','is_simulated'),('audit_findings','is_simulated')) v(t, f)
  LOOP
    EXECUTE format('ALTER TABLE %I DROP COLUMN mode_unknown', t);
    EXECUTE format('ALTER TABLE %I ALTER COLUMN %I SET DEFAULT false', t, f);
  END LOOP;
END $$;

ALTER TABLE agent_runs DROP COLUMN purpose;
ALTER TABLE tasks DROP COLUMN purpose;

-- Ölçümler: tarihçe satırları korunur; V2 tüm satırları sayar (V2 davranışı)
DROP INDEX IF EXISTS metrics_one_current_idx;
DROP INDEX IF EXISTS metrics_external_key_idx;
ALTER TABLE metrics DROP COLUMN is_current, DROP COLUMN external_key, DROP COLUMN received_at, DROP COLUMN recorded_by;

DELETE FROM settings WHERE key IN ('schema.version','migration.004.live_proof');
DELETE FROM schema_migrations WHERE name = '004_v21.sql';
COMMIT;
