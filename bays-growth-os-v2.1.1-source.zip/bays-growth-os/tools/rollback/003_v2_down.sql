-- V2 → V1 şema geri dönüşü (YALNIZ acil durumda; önce mutlaka yedek alın: npm run backup veya pg_dump).
-- Tercih edilen geri dönüş yolu, 003 öncesi alınan yedeğin geri yüklenmesidir. Bu betik, yedek yoksa
-- V1 kodunun V2 ile büyümüş veritabanında çalışabilmesi içindir. V2'ye özgü veriler (araştırma, manuel işler,
-- değerlendirme kayıtları) SİLİNİR; çekirdek V1 verisi (aday, temas, yayın, görev, bütçe, olay) korunur.
BEGIN;
DROP TABLE IF EXISTS eval_runs, manual_tasks, research_findings, source_documents, research_queries, research_runs CASCADE;

-- V1'de olmayan yayın durumu: "missed" → "cancelled"
UPDATE publications SET status = 'cancelled' WHERE status = 'missed';
ALTER TABLE publications DROP CONSTRAINT IF EXISTS publications_status_check;
ALTER TABLE publications ADD CONSTRAINT publications_status_check CHECK (status IN ('queued','sending','outcome_unknown','published','failed','cancelled','manual_required','halted'));
ALTER TABLE publications DROP COLUMN IF EXISTS replan_of;

-- Gönderim sonucu belirsiz kayıtlar V1'de "recorded" olarak görünür (V1 bunları yeniden göndermez: ilk temas engeli)
ALTER TABLE interactions DROP CONSTRAINT IF EXISTS interactions_status_check;

ALTER TABLE offers DROP COLUMN IF EXISTS demo_evidence_id, DROP COLUMN IF EXISTS founder_verified, DROP COLUMN IF EXISTS required_connections, DROP COLUMN IF EXISTS scope;

-- Kirada kalmış işler V1 yürütücüsü için kuyruğa döner
UPDATE tasks SET status = 'queued' WHERE status = 'running';
DROP INDEX IF EXISTS tasks_due_idx, tasks_lease_idx;
ALTER TABLE tasks DROP COLUMN IF EXISTS started_at, DROP COLUMN IF EXISTS dead_reason, DROP COLUMN IF EXISTS locked_by;

DELETE FROM channel_connections WHERE channel = 'research';
DELETE FROM schema_migrations WHERE name = '003_v2.sql';
COMMIT;
