// n8n import JSON'larını üretir. Hedef: n8n 2.43.4 (n8n-nodes-base 2.43.2). Doğrulama: npm run n8n:validate
// Bu akışlar ÖRNEK ADAPTÖRDÜR: mevcut LinkedIn akışınız paylaşılmadığı için yerine bağlanacak noktalar NoOp ile işaretlidir.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const OUT = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../n8n');
fs.mkdirSync(OUT, { recursive: true });
const id = (s) => crypto.createHash('sha256').update(s).digest('hex').slice(0, 8) + '-' + crypto.createHash('md5').update(s).digest('hex').slice(0, 4) + '-4000-8000-' + crypto.createHash('sha1').update(s).digest('hex').slice(0, 12);

function wf(name, nodes, chain, extraConnections = {}) {
  const connections = { ...extraConnections };
  for (const [a, b] of chain) {
    connections[a] ??= { main: [[]] };
    connections[a].main[0].push({ node: b, type: 'main', index: 0 });
  }
  return { name, nodes: nodes.map((n, i) => ({ id: id(name + n.name), position: n.position ?? [i * 260, 0], ...n })), connections, active: false, settings: { executionOrder: 'v1', timezone: 'Europe/Istanbul' }, pinData: {}, meta: { templateCredsSetupCompleted: false }, tags: [] };
}

// İmza: X-Bays-Signature = sha256=HMAC(BAYS_N8N_SHARED_SECRET, gövde). Code node'da crypto için NODE_FUNCTION_ALLOW_BUILTIN=crypto gerekir.
const signCode = (bodyExpr) => `const crypto = require('crypto');\nconst body = JSON.stringify(${bodyExpr});\nconst sig = 'sha256=' + crypto.createHmac('sha256', $env.BAYS_N8N_SHARED_SECRET).update(body).digest('hex');\nreturn [{ json: { body, sig } }];`;
const verifyCode = `const crypto = require('crypto');\n// Gelen istek BaysSystems servisinden mi? (imza kontrolü)\nconst item = $input.first().json;\nconst body = JSON.stringify(item.body);\nconst expected = 'sha256=' + crypto.createHmac('sha256', $env.BAYS_N8N_SHARED_SECRET).update(body).digest('hex');\nconst got = item.headers['x-bays-signature'] || '';\nif (got.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(got), Buffer.from(expected))) {\n  throw new Error('Geçersiz imza');\n}\nreturn [{ json: item.body }];`;

const httpPost = (name, url, position) => ({
  name, type: 'n8n-nodes-base.httpRequest', typeVersion: 4.2, position,
  parameters: {
    method: 'POST', url,
    sendHeaders: true, headerParameters: { parameters: [{ name: 'X-Bays-Signature', value: '={{ $json.sig }}' }, { name: 'Content-Type', value: 'application/json' }] },
    sendBody: true, contentType: 'raw', rawContentType: 'application/json', body: '={{ $json.body }}',
    options: { timeout: 60000 },
  },
});

// 1) Zamanlayıcı: 08:00 plan, 20:00 günlük rapor, Pazar 20:00 haftalık değerlendirme (Europe/Istanbul)
const sched = (name, cron, x, y) => ({ name, type: 'n8n-nodes-base.scheduleTrigger', typeVersion: 1.2, position: [x, y], parameters: { rule: { interval: [{ field: 'cronExpression', expression: cron }] } } });
const scheduler = wf('BaysSystems — Zamanlayıcı (08:00 / 20:00 / Pazar 20:00)', [
  sched('08:00 Günlük plan', '0 8 * * *', 0, 0),
  sched('20:00 Günlük rapor', '0 20 * * *', 0, 200),
  sched('Pazar 20:00 Haftalık', '0 20 * * 0', 0, 400),
  { name: 'İmzala: daily-plan', type: 'n8n-nodes-base.code', typeVersion: 2, position: [260, 0], parameters: { mode: 'runOnceForAllItems', language: 'javaScript', jsCode: signCode(`{ trigger: 'n8n', job: 'daily-plan', at: new Date().toISOString() }`) } },
  { name: 'İmzala: daily-report', type: 'n8n-nodes-base.code', typeVersion: 2, position: [260, 200], parameters: { mode: 'runOnceForAllItems', language: 'javaScript', jsCode: signCode(`{ trigger: 'n8n', job: 'daily-report', at: new Date().toISOString() }`) } },
  { name: 'İmzala: weekly-review', type: 'n8n-nodes-base.code', typeVersion: 2, position: [260, 400], parameters: { mode: 'runOnceForAllItems', language: 'javaScript', jsCode: signCode(`{ trigger: 'n8n', job: 'weekly-review', at: new Date().toISOString() }`) } },
  httpPost('Servis: daily-plan', '={{ $env.BAYS_API_URL }}/internal/cycle/daily-plan', [520, 0]),
  httpPost('Servis: daily-report', '={{ $env.BAYS_API_URL }}/internal/cycle/daily-report', [520, 200]),
  httpPost('Servis: weekly-review', '={{ $env.BAYS_API_URL }}/internal/cycle/weekly-review', [520, 400]),
], [
  ['08:00 Günlük plan', 'İmzala: daily-plan'], ['İmzala: daily-plan', 'Servis: daily-plan'],
  ['20:00 Günlük rapor', 'İmzala: daily-report'], ['İmzala: daily-report', 'Servis: daily-report'],
  ['Pazar 20:00 Haftalık', 'İmzala: weekly-review'], ['İmzala: weekly-review', 'Servis: weekly-review'],
]);

// 2) LinkedIn yayın adaptörü sözleşmesi (mevcut akışa bağlanacak)
const webhook = (name, p) => ({ name, type: 'n8n-nodes-base.webhook', typeVersion: 2, position: [0, 0], webhookId: id(p), parameters: { httpMethod: 'POST', path: p, responseMode: 'responseNode', options: {} } });
const respond = (name, bodyJs, x) => ({ name, type: 'n8n-nodes-base.respondToWebhook', typeVersion: 1.1, position: [x, 0], parameters: { respondWith: 'json', responseBody: bodyJs, options: {} } });
const code = (name, js, x) => ({ name, type: 'n8n-nodes-base.code', typeVersion: 2, position: [x, 0], parameters: { mode: 'runOnceForAllItems', language: 'javaScript', jsCode: js } });
const noop = (name, x) => ({ name, type: 'n8n-nodes-base.noOp', typeVersion: 1, position: [x, 0], parameters: {}, notes: 'BURAYA mevcut LinkedIn yayın akışınızı bağlayın. Çıkışta { idempotency_key, status: "published"|"failed", external_id, error } üretin. Aynı idempotency_key ikinci kez gelirse yeniden yayınlamayın.' });

const linkedin = wf('BaysSystems — LinkedIn yayın adaptörü (ÖRNEK SÖZLEŞME)', [
  webhook('Servisten yayın isteği', 'bays-linkedin-publish'),
  code('İmza ve sözleşme kontrolü', verifyCode, 260),
  respond('Kabul edildi (202 benzeri)', `={{ JSON.stringify({ status: 'accepted', idempotency_key: $json.idempotency_key }) }}`, 520),
  noop('Mevcut LinkedIn akışı (bağlanacak)', 780),
  code('Sonucu imzala', signCode(`{ idempotency_key: $input.first().json.idempotency_key, status: $input.first().json.status || 'failed', external_id: $input.first().json.external_id || null, error: $input.first().json.error || 'mevcut akış bağlanmadı' }`), 1040),
  httpPost('Servise sonucu bildir', '={{ $env.BAYS_API_URL }}/webhooks/n8n/publication-result', [1300, 0]),
], [
  ['Servisten yayın isteği', 'İmza ve sözleşme kontrolü'], ['İmza ve sözleşme kontrolü', 'Kabul edildi (202 benzeri)'],
  ['Kabul edildi (202 benzeri)', 'Mevcut LinkedIn akışı (bağlanacak)'], ['Mevcut LinkedIn akışı (bağlanacak)', 'Sonucu imzala'], ['Sonucu imzala', 'Servise sonucu bildir'],
]);

// 3) Yayın durumu sorgusu (uzlaştırma): varsayılan yanıt "unknown" → servis manuel uzlaştırmaya düşer, tekrar göndermez
const status = wf('BaysSystems — LinkedIn yayın durumu (ÖRNEK SÖZLEŞME)', [
  webhook('Servisten durum sorusu', 'bays-linkedin-status'),
  code('İmza kontrolü', verifyCode, 260),
  { ...noop('Kendi yayın kaydınızda ara (bağlanacak)', 520), notes: 'idempotency_key ile kendi kaydınızda arayın. Bulursanız status "published" + external_id; isteği hiç almadıysanız "never_received"; emin değilseniz "unknown" döndürün.' },
  respond('Durum yanıtı', `={{ JSON.stringify({ status: $json.status || 'unknown', external_id: $json.external_id || null }) }}`, 780),
], [['Servisten durum sorusu', 'İmza kontrolü'], ['İmza kontrolü', 'Kendi yayın kaydınızda ara (bağlanacak)'], ['Kendi yayın kaydınızda ara (bağlanacak)', 'Durum yanıtı']]);

// 4) E-posta yedek rapor (SMTP kimliği n8n'de "SMTP" credential olarak tanımlanır)
const email = wf('BaysSystems — Kurucu e-posta yedeği', [
  webhook('Servisten e-posta', 'bays-email-send'),
  code('İmza kontrolü', verifyCode, 260),
  { name: 'E-posta gönder', type: 'n8n-nodes-base.emailSend', typeVersion: 2.1, position: [520, 0], parameters: { fromEmail: '={{ $env.BAYS_REPORT_FROM_EMAIL }}', toEmail: '={{ $json.to }}', subject: '={{ $json.subject }}', emailFormat: 'text', text: '={{ $json.text }}', options: { appendAttribution: false } }, credentials: { smtp: { id: 'SMTP_KIMLIGINIZ', name: 'SMTP (kurulumda seçilecek)' } } },
  respond('Gönderildi', `={{ JSON.stringify({ ok: true }) }}`, 780),
], [['Servisten e-posta', 'İmza kontrolü'], ['İmza kontrolü', 'E-posta gönder'], ['E-posta gönder', 'Gönderildi']]);

// 5) Gelen e-posta yanıtı (V2): IMAP tetikleyici → imzalı servis çağrısı. Message-ID/In-Reply-To eşleştirme serviste.
const inbound = wf('BaysSystems — Gelen e-posta yanıtı (IMAP → servis)', [
  { name: 'Gelen kutusu (IMAP)', type: 'n8n-nodes-base.emailReadImap', typeVersion: 2.1, position: [0, 0], parameters: { mailbox: 'INBOX', postProcessAction: 'nothing', format: 'resolved', options: {} }, credentials: { imap: { id: 'IMAP_KIMLIGINIZ', name: 'IMAP (kurulumda seçilecek)' } } },
  code('Yanıtı sözleşmeye çevir ve imzala', signCode(`{ brand: $env.BAYS_BRAND_SLUG || 'bayssystems', message_id: $input.first().json.messageId, in_reply_to: $input.first().json.inReplyTo || null, from: ($input.first().json.from?.value?.[0]?.address) || null, text: ($input.first().json.text || '').slice(0, 20000), received_at: $input.first().json.date || new Date().toISOString() }`), 260),
  httpPost('Servise yanıtı bildir', '={{ $env.BAYS_API_URL }}/webhooks/email/inbound', [520, 0]),
], [['Gelen kutusu (IMAP)', 'Yanıtı sözleşmeye çevir ve imzala'], ['Yanıtı sözleşmeye çevir ve imzala', 'Servise yanıtı bildir']]);

// 6) Ölçüm aktarımı (V2.1): kaynak (mevcut LinkedIn akışınız / analiz dışa aktarımı) → sözleşmeye çevir + imzala → servis.
//    Kaynak düğüm NoOp ile işaretlidir: LinkedIn analiz verisine erişiminiz doğrulanmadığı için uydurulmuş veri çekilmez.
const metricsNoop = { name: 'Ölçüm kaynağı (bağlanacak)', type: 'n8n-nodes-base.noOp', typeVersion: 1, position: [260, 0], parameters: {},
  notes: 'BURAYA ölçüm kaynağınızı bağlayın (mevcut LinkedIn akışınızın analiz çıktısı vb.). Her öğe: { idempotency_key | external_id, measured_at (ISO), values: { impressions, reactions, comments, shares, clicks, engagement_rate(0–1) }, evidence_url? }. Bilinmeyen değeri null bırakın; 0 yazmayın.' };
const metricsPush = wf('BaysSystems — Ölçüm aktarımı (n8n → servis, V2.1)', [
  sched('Günde iki kez (10:00 ve 19:00)', '0 10,19 * * *', 0, 0),
  metricsNoop,
  code('Sözleşmeye çevir ve imzala', `const crypto = require('crypto');
const out = [];
for (const it of $input.all()) {
  const j = it.json;
  // Teslim kimliği: aynı ölçüm yeniden gönderilirse servis tekrar sayar ve yazmaz
  const delivery = crypto.createHash('sha256').update([j.idempotency_key || '', j.external_id || '', j.measured_at || '', JSON.stringify(j.values || {})].join('|')).digest('hex').slice(0, 32);
  const body = JSON.stringify({ contract: 'bays.metrics.v1', brand: $env.BAYS_BRAND_SLUG || 'bayssystems', publication: { idempotency_key: j.idempotency_key || null, external_id: j.external_id || null }, delivery_id: delivery, measured_at: j.measured_at, values: j.values || {}, evidence_url: j.evidence_url || null });
  out.push({ json: { body, sig: 'sha256=' + crypto.createHmac('sha256', $env.BAYS_N8N_SHARED_SECRET).update(body).digest('hex') } });
}
return out;`, 520),
  httpPost('Servise ölçümü gönder', '={{ $env.BAYS_API_URL }}/webhooks/n8n/metrics', [780, 0]),
], [['Günde iki kez (10:00 ve 19:00)', 'Ölçüm kaynağı (bağlanacak)'], ['Ölçüm kaynağı (bağlanacak)', 'Sözleşmeye çevir ve imzala'], ['Sözleşmeye çevir ve imzala', 'Servise ölçümü gönder']]);

for (const [file, w] of [['bays-metrics-push.json', metricsPush], ['bays-email-inbound.json', inbound], ['bays-scheduler.json', scheduler], ['bays-linkedin-adapter.json', linkedin], ['bays-linkedin-status.json', status], ['bays-email-fallback.json', email]]) {
  fs.writeFileSync(path.join(OUT, file), JSON.stringify(w, null, 2) + '\n');
  console.log('yazıldı:', file);
}
