// n8n JSON doğrulayıcı: her node tipinin, typeVersion'ın ve üst düzey parametre adlarının
// seçilen n8n-nodes-base sürümünde gerçekten bulunduğunu kontrol eder.
// Kullanım: node tools/validate-n8n.mjs [n8n klasörü]   (N8N_NODES_BASE_DIR ile paket klasörü verilebilir)
import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';

const NODES_BASE_VERSION = '2.43.2'; // n8n 2.43.4'ün bağımlılığı (npm view n8n@2.43.4 dependencies)
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const wfDir = path.resolve(process.argv[2] ?? path.join(root, 'n8n'));

function nodesBaseDir() {
  if (process.env.N8N_NODES_BASE_DIR) return process.env.N8N_NODES_BASE_DIR;
  const cache = path.join(root, '.cache', `n8n-nodes-base-${NODES_BASE_VERSION}`);
  if (!fs.existsSync(path.join(cache, 'package', 'package.json'))) {
    fs.mkdirSync(cache, { recursive: true });
    const tgz = execFileSync('npm', ['pack', `n8n-nodes-base@${NODES_BASE_VERSION}`, '--silent'], { cwd: cache }).toString().trim().split('\n').pop();
    execFileSync('tar', ['xzf', path.join(cache, tgz), '-C', cache]);
  }
  return path.join(cache, 'package');
}

const base = nodesBaseDir();
const pkg = JSON.parse(fs.readFileSync(path.join(base, 'package.json'), 'utf8'));
const nodeFiles = pkg.n8n.nodes; // dist/nodes/.../X.node.js
const index = new Map();
for (const rel of nodeFiles) {
  const file = path.join(base, rel);
  const stem = path.basename(rel).replace('.node.js', '');
  const type = stem.charAt(0).toLowerCase() + stem.slice(1);
  index.set(type, path.dirname(file));
}
function readAllJs(dir) {
  let out = '';
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out += readAllJs(p);
    else if (e.name.endsWith('.js')) out += fs.readFileSync(p, 'utf8') + '\n';
  }
  return out;
}

let errors = 0, checked = 0;
for (const f of fs.readdirSync(wfDir).filter((x) => x.endsWith('.json'))) {
  const wf = JSON.parse(fs.readFileSync(path.join(wfDir, f), 'utf8'));
  const names = new Set(wf.nodes.map((n) => n.name));
  for (const [from, c] of Object.entries(wf.connections)) {
    if (!names.has(from)) { console.error(`✗ ${f}: bağlantı kaynağı yok: ${from}`); errors++; }
    for (const out of c.main) for (const t of out) if (!names.has(t.node)) { console.error(`✗ ${f}: bağlantı hedefi yok: ${t.node}`); errors++; }
  }
  for (const n of wf.nodes) {
    checked++;
    const [pfx, type] = n.type.split('.');
    if (pfx !== 'n8n-nodes-base' || !index.has(type)) { console.error(`✗ ${f}: node tipi bulunamadı: ${n.type}`); errors++; continue; }
    const src = readAllJs(index.get(type));
    if (!src.includes(`name: '${type}'`)) { console.error(`✗ ${f}: ${n.type} tanımı doğrulanamadı`); errors++; continue; }
    const versions = new Set();
    for (const m of src.matchAll(/\b(?:version|defaultVersion):\s*(\[[^\]]*\]|[0-9.]+)/g)) {
      for (const v of m[1].replace(/[\[\]\s]/g, '').split(',')) if (v) versions.add(Number(v));
    }
    if (!versions.has(Number(n.typeVersion))) { console.error(`✗ ${f}: ${n.name}: typeVersion ${n.typeVersion} yok (mevcut: ${[...versions].sort().join(', ')})`); errors++; }
    const params = new Set([...src.matchAll(/name:\s*'([A-Za-z0-9_]+)'/g)].map((m) => m[1]));
    for (const k of Object.keys(n.parameters ?? {})) {
      if (!params.has(k)) { console.error(`✗ ${f}: ${n.name}: parametre "${k}" ${n.type} tanımında yok`); errors++; }
    }
    // İç içe kontrol: schedule kuralı ve http başlık parametreleri
    if (type === 'scheduleTrigger') for (const it of n.parameters.rule?.interval ?? []) for (const k of Object.keys(it)) if (!params.has(k)) { console.error(`✗ ${f}: ${n.name}: interval alanı "${k}" yok`); errors++; }
    for (const [credType] of Object.entries(n.credentials ?? {})) if (!src.includes(`name: '${credType}'`)) { console.error(`✗ ${f}: ${n.name}: kimlik tipi "${credType}" yok`); errors++; }
  }
  console.log(`✓ ${f}: ${wf.nodes.length} node kontrol edildi`);
}
console.log(`\nn8n-nodes-base ${pkg.version} ile ${checked} node doğrulandı; hata: ${errors}`);
process.exit(errors ? 1 : 0);
