# BaysSystems Growth OS (V2.1)

Beş uzman ajanlı marka, pazarlama ve müşteri geliştirme sistemi. İlk marka **BaysSystems**, pazar **Türkiye**, dil **Türkçe**. Aynı çekirdek Almakİstiyorum.net, Maple Market ve Mentora için marka yapılandırmasıyla kullanılır (teslimde taslak/kapalı).

> **Durum (V2.1 · sürüm 2.1.1, 14.10.2026):** Kod tamam ve test ortamında doğrulandı (107/107 test, temiz klasör kurulumu, V2→V2.1 göçü ve geri dönüş). **Canlı bağlantıda doğrulanmadı**: hiçbir gerçek hesaba bağlanılmadı; gerçek yayın, mesaj, arama, ölçüm veya harcama yapılmadı. Simülasyon sonuçları müşteri veya gelir göstermez. Bkz. `docs/teslim_raporu_v21.md`.
>
> V2.1: gerçek ölçüm girişi (panel/API/imzalı n8n), simülasyon–değerlendirme–canlı veri ayrımı, açık iletişim reddinin modelden önce işlenmesi, belirsiz ücretli çağrıların uzlaştırılması.

V2 ile gelen döngü: **kaynaklı araştırma → aday → değerlendirme → taslak → izinli gönderim veya manuel görev → yanıt → takip → nitelikli fırsat → kurucu kararı**, ve **ölçüm → denetim → deney → kural → değişen yayın saati**. Hepsi kalıcı kuyrukta, sürekli çalışan worker ile.

## Hızlı başlangıç

**Docker ile (tek komut, simülasyon):**
```bash
cp .env.example .env        # yer tutucuları doldurun (en az üç DB parolası, N8N_SHARED_SECRET, FOUNDER_TOKEN_SHA256)
docker compose up --build   # postgres:16-alpine + uygulama (Node 22) + worker + n8n 2.43.4
docker compose exec app npx tsx src/cli.ts simulate   # iki senaryolu uçtan uca simülasyon
```
Panel: http://localhost:8080/panel · n8n: http://localhost:5678

**Docker olmadan (yerel PostgreSQL 16 + Node 22):**
```bash
npm ci
# .env değişkenlerini ortama verin (DATABASE_URL_OWNER/APP/AUDITOR, parolalar)
npm run sim:fresh     # veritabanını sıfırdan kurar + 16 günlük simülasyon
npm run worker        # sürekli worker (SCHEDULER=on → 08:00/20:00/Pazar takvimi)
npm test              # 107 test: 49 V1 (14 zorunlu kabul dahil) + 18 V2 + 15 V2 inceleme + 25 V2.1
npm run test:report   # docs/test_raporu.md üretir
```

## Komutlar

| Komut | İş |
| --- | --- |
| `npm run migrate` / `npm run seed` | Şema + roller / marka profilleri (idempotent) |
| `npm start` | API + panel + webhook uçları |
| `npm run simulate` / `npm run sim:fresh` | Uçtan uca simülasyon (çıktı: `reports/`) |
| `npm run worker` | Sürekli worker: atomik sahiplenme, kira, kurtarma, yeniden deneme, hata kuyruğu |
| `npm run drain` | Zamanı gelmiş işleri bir kez yürütüp çıkar |
| `npm run cycle:daily [-- --drain]` | 08:00 kök görevini elle açar (normalde worker zamanlayıcısı veya n8n) |
| `npm run report:daily` / `report:weekly` | Raporu konsola yazar |
| `npm run backup` / `npm run restore -- <dosya> <db>` / `npm run restore:reapply-erasures` | Yedek, geri yükleme, silmeleri yeniden uygulama |
| `npm run cost:estimate` | Aylık maliyet tahmini (bilinmeyen fiyat sıfır sayılmaz) |
| `npm run eval` | 13 deterministik **koruma** testi (model kalitesi değildir) |
| `npm run eval:quality` | 20 senaryoluk kalite seti, mock sözleşme kipi |
| `npm run eval:quality:live` | Gerçek model kalite değerlendirmesi (`RUN_MODE=eval`; anahtar yoksa BEKLEMEDE) |
| `npm run n8n:build` / `npm run n8n:validate` | n8n JSON üretimi / n8n 2.43.4 node tanımlarına karşı doğrulama |

## Klasörler

```
src/            servis kodu (ajanlar, çekirdek, CRM, araştırma, worker, öğrenme, denetim, entegrasyonlar, rapor, API)
migrations/     PostgreSQL şeması, RLS, roller
seed/           marka profilleri (yalnız BaysSystems aktif)
config/         fiyat tablosu (boş, kaynak/tarih zorunlu) ve kullanım varsayımı
n8n/            import JSON'ları (zamanlayıcı, LinkedIn adaptör sözleşmesi, durum, e-posta)
panel/          mobil yönetim paneli (vanilla HTML/JS)
evals/          koruma vakaları + quality/ (20 senaryo, önceden kayıtlı rubrik)
tests/          107 test; e_acceptance = V1 §11, f_v2 = V2 §9, g_review = V2 inceleme, h_v21 = V2.1 düzeltmeleri; dosya sırası sabit (vitest.config.ts)
tools/          n8n üretimi/doğrulaması, test raporu, rollback/003_v2_down.sql ve rollback/004_v21_down.sql
docs/           raporlar ve rehberler
reports/        simülasyon çıktıları (ÖRNEK veri)
```

## Belgeler

- `docs/teslim_raporu_v21.md` — **V2.1 final hükmü** (kod tamam / test ortamında doğrulandı / canlıda doğrulandı)
- `docs/v21_duzeltme_matrisi.md` — V2.1'in dört bulgusu: belirti, kök neden, dosyalar, testler, kalan sınır
- `docs/teslim_raporu_v2.md` — V2 final hükmü (kod tamam / test ortamında doğrulandı / canlıda doğrulandı)
- `docs/v2_duzeltme_matrisi.md` — V1 bulguları ve inceleme düzeltmeleri: dosya, test, kanıt, kalan sınır
- `docs/kurulum_guncelleme_geri_donus.md` — temiz kurulum, V1→V2 güncelleme, geri dönüş; kip bazlı komutlar
- `docs/ajanlar_uzmanlik_degerlendirme.md` — beş ajanın iş akışı, uzmanlık kaynakları, kalite değerlendirmesi
- `docs/pilot_raporlar_durdurma.md` — sınırlı pilot adımları, örnek günlük/haftalık rapor, durdurma/yeniden başlatma
- `docs/maliyet_formulu.md` — maliyet formülü ve gereken girdiler
- `docs/teslim_raporu.md` — V1 teslim raporu (tarihsel)
- `docs/kurulum_rehberi.md` — kurulum ve hesapların sonradan bağlanması
- `docs/eksik_baglantilar.md` — eksik bağlantılar: sizden gerekenler / geliştirmeyle çözülenler / sağlayıcı kısıtları
- `docs/canliya_gecis_kontrol_listesi.md` — sınırlı pilot öncesi kontrol listesi
- `docs/mimari_ve_veri_modeli.md` — mimari, güvenlik, bütçe, veri modeli, roller
- `docs/kanal_yetenek_matrisi.md` — resmî belgelerle kanal yetenekleri (14.10.2026)
- `docs/n8n_adaptor_sozlesmesi.md` — mevcut LinkedIn akışınızı bağlama sözleşmesi
- `docs/kampanya_plani_pilot.md` — pilot öncesi Türkçe kampanya planı ve değerlendirme örnekleri
- `docs/test_raporu.md` — çalıştırılan testlerin çıktısı
- `docs/A_kesif_ve_plan.md` — A aşaması keşif ve plan

## Sürümler (gerçek seçilen değerler)

Node.js 22 · TypeScript 7.0.2 · tsx 4.23.15 · Fastify 5.12.7 · pg 8.23.1 · Zod 4.6.7 · undici 8.11.2 · Vitest 5.0.4 · PostgreSQL 16 · n8n 2.43.4 (n8n-nodes-base 2.43.2).
