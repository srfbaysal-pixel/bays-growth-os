-- İlk açılışta: n8n için ayrı veritabanı (uygulama veritabanından bağımsız)
CREATE DATABASE n8n;
