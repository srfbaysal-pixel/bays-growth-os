import { withBrand } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { clock } from '../core/clock.js';

/**
 * Gerçek performans ölçümü girişi (V2.1). İki giriş yolu: kurucu paneli/API (source='manual') ve imzalı n8n webhook'u (source='n8n').
 *
 * Doğrulama: yayın bu markaya ait, canlı (ÖRNEK değil) ve yayımlanmış olmalı; ölçüm türü izinli listede; değer sayısal,
 * negatif değil (sayımlar tam sayı, oranlar 0–1); ölçüm zamanı yayından önce veya gelecekte olamaz; kanıt (URL veya not) zorunlu
 * (n8n teslim kimliği kanıt sayılır). Boş/eksik değer SIFIR SAYILMAZ, atlanır ve yanıt içinde bildirilir.
 *
 * Kümülatif güncelleme politikası (LinkedIn sayıları zamanla büyüyen anlık görüntülerdir):
 * - Her (yayın, ölçüm) için yalnız bir "güncel" satır vardır; deney değerlendirmesi ve strateji yalnız güncel satırı kullanır.
 *   Böylece aynı gönderinin farklı zamanlardaki ölçümleri ayrı deney örnekleri sayılmaz.
 * - Daha yeni ölçüm zamanı → yeni satır güncel olur, eskisi tarihçeye düşer.
 * - Daha eski (geç gelen) ölçüm → tarihçe olarak saklanır, güncel değişmez.
 * - Aynı zaman + aynı değer → tekrar; hiçbir şey yazılmaz. Aynı zaman + farklı değer → düzeltme: yeni satır güncel olur.
 * - Aynı n8n teslim kimliği (external_key) ikinci kez gelirse → tekrar.
 * Deney ve kol istemciden alınmaz; yayının içerik kaydındaki deney/kol bilgisinden türetilir.
 */
export const METRIC_RULES: Record<string, { kind: 'count' | 'rate'; label: string }> = {
  impressions: { kind: 'count', label: 'gösterim' },
  reactions: { kind: 'count', label: 'tepki' },
  comments: { kind: 'count', label: 'yorum' },
  shares: { kind: 'count', label: 'paylaşım' },
  clicks: { kind: 'count', label: 'tıklama' },
  engagement_rate: { kind: 'rate', label: 'etkileşim oranı (0–1)' },
};

export class MetricInputError extends Error {
  constructor(message: string, public readonly statusCode: number) { super(message); this.name = 'MetricInputError'; }
}

export interface MetricInput {
  brandId: string;
  publicationId?: string | null;
  publicationRef?: { idempotencyKey?: string | null; externalId?: string | null } | null;
  measuredAt: unknown;
  values: unknown;
  source: 'manual' | 'n8n';
  externalKey?: string | null;
  evidence?: { url?: string | null; note?: string | null } | null;
  actor: string;
  now?: Date;
}

export interface MetricResult {
  status: 'recorded' | 'duplicate';
  publicationId: string; experimentId: string | null; arm: string | null;
  recorded: { metric: string; value: number; current: boolean; note?: string }[];
  duplicates: string[];
  skipped: { metric: string; reason: string }[];
}

function parseValues(raw: unknown): { ok: Map<string, number>; skipped: { metric: string; reason: string }[] } {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new MetricInputError('values bir nesne olmalı: {"impressions": 120, ...}', 400);
  const ok = new Map<string, number>();
  const skipped: { metric: string; reason: string }[] = [];
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    const rule = METRIC_RULES[k];
    if (!rule) throw new MetricInputError(`Bilinmeyen ölçüm türü: ${k}. İzinli: ${Object.keys(METRIC_RULES).join(', ')}`, 400);
    if (v === null || v === undefined || (typeof v === 'string' && v.trim() === '')) { skipped.push({ metric: k, reason: 'değer yok — sıfır sayılmadı' }); continue; }
    const n = typeof v === 'number' ? v : typeof v === 'string' && /^-?\d+(\.\d+)?$/.test(v.trim()) ? Number(v) : NaN;
    if (!Number.isFinite(n)) throw new MetricInputError(`${k}: sayısal değer değil (${JSON.stringify(v)})`, 400);
    if (n < 0) throw new MetricInputError(`${k}: negatif olamaz`, 400);
    if (rule.kind === 'count' && !Number.isInteger(n)) throw new MetricInputError(`${k}: tam sayı olmalı`, 400);
    if (rule.kind === 'rate' && n > 1) throw new MetricInputError(`${k}: oran 0 ile 1 arasında olmalı (yüzde değil)`, 400);
    ok.set(k, n);
  }
  if (ok.size === 0 && skipped.length === 0) throw new MetricInputError('En az bir ölçüm değeri gerekli', 400);
  return { ok, skipped };
}

export async function ingestMetrics(input: MetricInput): Promise<MetricResult> {
  const now = input.now ?? clock.now();
  const at = new Date(String(input.measuredAt ?? ''));
  if (!input.measuredAt || Number.isNaN(at.getTime())) throw new MetricInputError('measuredAt geçerli bir ISO zaman olmalı', 400);
  if (at.getTime() > Date.now() + 5 * 60_000 && at.getTime() > now.getTime() + 5 * 60_000) throw new MetricInputError('Ölçüm zamanı gelecekte olamaz', 400);
  const { ok, skipped } = parseValues(input.values);
  const ev = input.evidence ?? {};
  const url = ev.url ? String(ev.url) : null;
  if (url && !/^https:\/\/[^\s]+$/i.test(url)) throw new MetricInputError('Kanıt URL https ile başlamalı', 400);
  const note = ev.note ? String(ev.note).trim() : null;
  if (input.source === 'manual' && !url && !(note && note.length >= 5)) throw new MetricInputError('Kanıt gerekli: ekran/rapor URL\'si veya en az 5 karakterlik not (ör. "LinkedIn analiz ekranı")', 400);
  if (input.source === 'n8n' && !input.externalKey) throw new MetricInputError('n8n teslim kimliği (delivery_id) gerekli', 400);

  return withBrand(input.brandId, async (c) => {
    // Yayın: RLS + açık marka koşulu. Başka markanın yayını bulunamaz (404).
    const p = (await c.query(
      `SELECT p.id, p.brand_id, p.status, p.is_simulated, p.sent_at, p.scheduled_at, a.content
         FROM publications p LEFT JOIN assets a ON a.id=p.asset_id
        WHERE p.brand_id=$1 AND (${input.publicationId ? 'p.id::text=$2' : '(p.idempotency_key=$2 OR p.external_id=$3)'}) LIMIT 1`,
      input.publicationId ? [input.brandId, String(input.publicationId)] : [input.brandId, input.publicationRef?.idempotencyKey ?? '', input.publicationRef?.externalId ?? ''])).rows[0];
    if (!p) throw new MetricInputError('Yayın bu markada bulunamadı', 404);
    if (p.is_simulated) throw new MetricInputError('ÖRNEK (simülasyon) yayına gerçek ölçüm girilemez', 422);
    if (p.status !== 'published') throw new MetricInputError(`Yalnız yayımlanmış gönderiye ölçüm girilir (durum: ${p.status})`, 409);
    const start = p.sent_at ?? p.scheduled_at;
    if (start && at.getTime() < new Date(start).getTime()) throw new MetricInputError('Ölçüm zamanı yayından önce olamaz', 400);
    const experimentId: string | null = p.content?.experiment_id ?? null;
    const arm: string | null = experimentId ? (p.content?.arm ?? null) : null;

    // Teslim kimliği tekrarı (n8n yeniden denemesi)
    if (input.externalKey) {
      const seen = (await c.query(`SELECT 1 FROM metrics WHERE brand_id=$1 AND source=$2 AND external_key=$3 LIMIT 1`, [input.brandId, input.source, input.externalKey])).rowCount;
      if (seen) return { status: 'duplicate', publicationId: p.id, experimentId, arm, recorded: [], duplicates: [...ok.keys()], skipped };
    }
    // Aynı yayın için eşzamanlı girişler sıralanır
    await c.query(`SELECT pg_advisory_xact_lock(hashtext($1))`, [`metrics:${p.id}`]);
    let evidenceId: string | null = null;
    const recorded: MetricResult['recorded'] = [];
    const duplicates: string[] = [];
    for (const [metric, value] of ok) {
      const cur = (await c.query(`SELECT id, value::float8 v, measured_at FROM metrics WHERE publication_id=$1 AND metric=$2 AND NOT is_simulated AND is_current FOR UPDATE`, [p.id, metric])).rows[0];
      let current = true; let noteTxt: string | undefined;
      if (cur) {
        const curAt = new Date(cur.measured_at).getTime();
        if (curAt === at.getTime() && Number(cur.v) === value) { duplicates.push(metric); continue; }
        if (at.getTime() < curAt) { current = false; noteTxt = 'geç gelen eski ölçüm: tarihçeye yazıldı, güncel değer değişmedi'; }
        else noteTxt = curAt === at.getTime() ? 'aynı zaman için düzeltme: güncel değer değişti' : 'yeni anlık görüntü: önceki değer tarihçeye alındı';
        if (current) await c.query(`UPDATE metrics SET is_current=false WHERE id=$1`, [cur.id]);
      }
      if (!evidenceId) {
        evidenceId = (await c.query(`INSERT INTO evidence (brand_id, kind, title, uri, payload, is_sample) VALUES ($1,'metric',$2,$3,$4,false) RETURNING id`,
          [input.brandId, `Gerçek ölçüm (${input.source === 'n8n' ? 'n8n' : 'kurucu girişi'})`, url, { note, source: input.source, externalKey: input.externalKey ?? null, measuredAt: at.toISOString(), recordedBy: input.actor }])).rows[0].id;
      }
      await c.query(
        `INSERT INTO metrics (brand_id, publication_id, experiment_id, arm, metric, value, source, is_simulated, evidence_id, measured_at, is_current, external_key, recorded_by)
         VALUES ($1,$2,$3,$4,$5,$6,$7,false,$8,$9,$10,$11,$12)`,
        [input.brandId, p.id, experimentId, arm, metric, value, input.source, evidenceId, at, current, input.externalKey ?? null, input.actor]);
      recorded.push({ metric, value, current, note: noteTxt });
    }
    const status: MetricResult['status'] = recorded.length ? 'recorded' : 'duplicate';
    await logEvent(c, { brandId: input.brandId, type: recorded.length ? 'metric.ingested' : 'metric.duplicate', actor: input.actor, subjectType: 'publication', subjectId: p.id,
      payload: { source: input.source, recorded, duplicates, skipped, externalKey: input.externalKey ?? null, measuredAt: at.toISOString() }, simulated: false });
    return { status, publicationId: p.id, experimentId, arm, recorded, duplicates, skipped };
  });
}
