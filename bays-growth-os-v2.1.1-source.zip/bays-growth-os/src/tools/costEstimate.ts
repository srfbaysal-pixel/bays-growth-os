import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { estimateCost, loadPricing, PriceUnknownError, round2 } from '../core/pricing.js';

/**
 * Aylık maliyet tahmini: kullanım varsayımı × yapılandırılmış fiyat. Fiyatı bilinmeyen kalem
 * sıfır sayılmaz; "hesaplanamadı" olarak listelenir ve toplam "eksik" diye işaretlenir.
 */
export function costEstimate(profileFile = 'config/usage_profile.json'): string {
  const prof = JSON.parse(fs.readFileSync(path.resolve(profileFile), 'utf8'));
  const p = loadPricing();
  const cfg = config() as any;
  const lines: string[] = [];
  let total = 0, unknown = 0;
  for (const it of prof.items) {
    const key = it.pricing_key ?? cfg[it.pricing_key_env];
    try {
      const perMonthUnits = it.units_per_month ?? (it.units_per_day ?? 0) * prof.days_per_month;
      const est = it.calls_per_day
        ? estimateCost(key, { inputTokens: it.input_tokens * it.calls_per_day * prof.days_per_month, maxOutputTokens: it.output_tokens * it.calls_per_day * prof.days_per_month, units: it.calls_per_day * prof.days_per_month }, p)
        : estimateCost(key, { units: perMonthUnits }, p);
      const sim = est.simulatedOnly ? ' (SİMÜLASYON kalemi — gerçek gider değil)' : '';
      total += est.simulatedOnly ? 0 : est.tryAmount;
      lines.push(`${it.role.padEnd(32)} ${key.padEnd(34)} ${est.tryAmount.toFixed(2).padStart(10)} TL${sim}`);
    } catch (e) {
      if (!(e instanceof PriceUnknownError)) throw e;
      unknown++;
      lines.push(`${it.role.padEnd(32)} ${String(key).padEnd(34)} ${'?'.padStart(10)}    — ${e.message}`);
    }
  }
  const lim = Math.min(cfg.BUDGET_TARGET_TRY, cfg.BUDGET_HARD_CAP_TRY);
  lines.push('');
  lines.push(unknown ? `Toplam: hesaplanamadı (${unknown} kalemin fiyatı/kuru bilinmiyor). Bilinen kalemler: ${round2(total)} TL` : `Tahmini aylık toplam: ${round2(total)} TL / hedef ${lim} TL (kesin üst sınır ${cfg.BUDGET_HARD_CAP_TRY} TL)`);
  lines.push('Not: Tahmin üst sınır yaklaşımıdır; gerçek gider sağlayıcı faturasıyla uzlaştırılmalıdır.');
  return lines.join('\n');
}
