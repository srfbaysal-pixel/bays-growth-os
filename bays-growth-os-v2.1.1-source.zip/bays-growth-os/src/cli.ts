import fs from 'node:fs';
import { config } from './config.js';
import { migrate } from './db/migrate.js';
import { seed } from './db/seed.js';
import { closePools } from './db/pool.js';

/** Komut satırı: migrate | seed | simulate | cycle <ad> | report <daily|weekly> | backup | restore <dosya> <hedef-db> | cost-estimate | eval */
const [cmd, ...args] = process.argv.slice(2);

async function main() {
  const { installGlobalEgressGuard } = await import('./integrations/egress.js');
  installGlobalEgressGuard();
  switch (cmd) {
    case 'migrate': console.log('Uygulanan göçler:', await migrate()); break;
    case 'seed': console.log(await seed()); break;
    case 'fresh': {
      // Yalnız simülasyon kipinde: veritabanını sıfırdan kurar
      if (config().RUN_MODE !== 'simulation') throw new Error('fresh yalnız RUN_MODE=simulation iken çalışır');
      const { recreateDatabase } = await import('./db/migrate.js');
      const u = new URL(config().DATABASE_URL_OWNER); const db = u.pathname.slice(1); u.pathname = '/postgres';
      await recreateDatabase(db, u.toString());
      console.log('Göçler:', await migrate()); console.log(await seed());
      try { fs.unlinkSync(process.env.ERASURE_LEDGER_FILE ?? 'data/erasure-ledger.jsonl'); } catch {}
      break;
    }
    case 'simulate': {
      const { simulate } = await import('./sim/simulate.js');
      const r = await simulate({ days: Number(args[0] ?? 16) });
      fs.mkdirSync('reports', { recursive: true });
      fs.writeFileSync('reports/simulasyon_ciktisi.json', JSON.stringify(r, null, 2));
      fs.writeFileSync('reports/simulasyon_son_rapor.txt', `${r.lastReport ?? ''}\n\n==========\n\n${r.weeklyReport ?? ''}\n`);
      console.log('\nÇıktı: reports/simulasyon_ciktisi.json, reports/simulasyon_son_rapor.txt');
      break;
    }
    case 'cycle': {
      // Kök görevi kuyruğa ekler; "--drain" ile zamanı gelen işleri hemen yürütür (worker çalışmıyorsa)
      const { runScheduled } = await import('./orchestrator/schedule.js');
      const name = args[0] === 'daily' ? 'daily-plan' : args[0];
      console.log(JSON.stringify(await runScheduled(name, new Date()), null, 2));
      if (args.includes('--drain')) { const { drain } = await import('./worker/worker.js'); console.log(JSON.stringify(await drain())); }
      break;
    }
    case 'worker': {
      // Sürekli worker: zamanı gelen işleri sahiplenir; SCHEDULER=on ise 08:00/20:00/Pazar takvimini kendisi de tetikler
      await import('./orchestrator/chain.js');
      const { runWorker } = await import('./worker/worker.js');
      let timer: NodeJS.Timeout | null = null;
      if (process.env.SCHEDULER === 'on') {
        const { scheduleTick } = await import('./orchestrator/schedule.js');
        // Başlangıçta hemen bir kez (gün anahtarı sayesinde aynı gün ikinci kez iş açılmaz), sonra dakikada bir
        const tick = () => scheduleTick().then((f) => { if (f.length) console.log(`[zamanlayıcı] tetiklendi: ${f.join(', ')}`); }).catch((e) => console.error('zamanlayıcı:', e.message));
        await tick();
        timer = setInterval(tick, 60_000);
      }
      await runWorker({ pollMs: Number(process.env.WORKER_POLL_MS ?? 2000) });
      if (timer) clearInterval(timer);
      break;
    }
    case 'drain': {
      await import('./orchestrator/chain.js');
      const { drain } = await import('./worker/worker.js');
      console.log(JSON.stringify(await drain()));
      break;
    }
    case 'report': {
      const { buildReport } = await import('./reports/reports.js');
      console.log((await buildReport(args[0] === 'weekly' ? 'weekly' : 'daily')).text);
      break;
    }
    case 'backup': {
      const { backupDatabase } = await import('./core/backup.js');
      console.log('Yedek:', backupDatabase(args[0]));
      break;
    }
    case 'restore': {
      const { restoreDatabase } = await import('./core/backup.js');
      if (!args[0] || !args[1]) throw new Error('Kullanım: restore <dosya> <hedef-veritabanı>');
      await restoreDatabase(args[0], args[1]);
      console.log(`Geri yüklendi: ${args[1]}. Uygulamayı bu veritabanına yönlendirdikten sonra "npm run restore:reapply-erasures" çalıştırın.`);
      break;
    }
    case 'reapply-erasures': {
      const { reapplyErasures } = await import('./core/privacy.js');
      console.log('Yeniden silinen kişi:', await reapplyErasures());
      break;
    }
    case 'cost-estimate': {
      const { costEstimate } = await import('./tools/costEstimate.js');
      console.log(costEstimate());
      break;
    }
    case 'eval-quality': {
      const { runQuality } = await import('./evals/quality.js');
      const r = await runQuality({ live: args.includes('--live') });
      console.log(`Kip: ${r.mode} · durum: ${r.status}${r.model ? ' · model: ' + r.model : ''}`);
      for (const x of r.results ?? []) console.log(`${x.pass ? '✓' : '✗'} ${x.id} [${x.role}] ${x.error ? 'HATA: ' + x.error : Object.entries(x.scores).filter(([, v]: any) => !v.pass).map(([k, v]: any) => `${k}: ${v.note}`).join('; ')}`);
      if (r.passRate != null) console.log(`Geçme oranı: ${(r.passRate * 100).toFixed(0)}% · rol bazında: ${JSON.stringify(r.perRole)} · eşik sağlandı: ${r.meetsThreshold ? 'evet' : 'hayır'}`);
      console.log(r.note);
      break;
    }
    case 'eval': {
      const { runEvals } = await import('./agents/evals.js');
      const r = runEvals();
      for (const x of r.results) console.log(`${x.passed ? '✓' : '✗'} ${x.id} → ${x.got.join(', ') || 'ok'}`);
      console.log(`\n${r.passed}/${r.total} · ${r.note}`);
      if (r.passed !== r.total) process.exitCode = 1;
      break;
    }
    default:
      console.log('Komutlar: migrate | seed | simulate [gün] | cycle <daily|daily-report|weekly-review> | report <daily|weekly> | backup [dosya] | restore <dosya> <db> | reapply-erasures | cost-estimate | eval');
  }
}

main().catch((e) => { console.error('Hata:', e.message); process.exitCode = 1; }).finally(() => closePools());
void config;
