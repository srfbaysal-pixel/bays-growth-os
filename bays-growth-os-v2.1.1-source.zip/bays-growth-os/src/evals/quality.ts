import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { withBrand, withSystem } from '../db/pool.js';
import { enqueueTask } from '../core/tasks.js';
import { runAgent } from '../agents/runner.js';
import { ROLES, expertise, type RoleId } from '../agents/roles.js';
import { resolveModel } from '../agents/providers.js';
import { checkClaims, checkNumbersFromContext } from '../agents/guards.js';
import { sha256 } from '../core/util.js';

/**
 * Ajan kalite değerlendirmesi (koruma testlerinden AYRI).
 * - mock_contract: mock sağlayıcıyla değerlendirme altyapısının ve puanlama sözleşmesinin çalıştığını gösterir; MODEL KALİTESİ DEĞİLDİR.
 * - live_model: yalnız RUN_MODE=eval iken gerçek modele çağrı (yayın/mesaj/araştırma yok). Anahtar/fiyat yoksa "BEKLEMEDE" kaydı.
 * Puanlama deterministiktir; isteğe bağlı bağımsız hakem modeli yalnız tavsiye niteliğindedir (eşik belirleyici değildir).
 * Rubrik ve eşikler sonuçlardan önce kaydedildi (evals/quality/rubric.json).
 */
const DIR = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../evals/quality');
const RUBRIC = JSON.parse(fs.readFileSync(path.join(DIR, 'rubric.json'), 'utf8'));
const SCEN = JSON.parse(fs.readFileSync(path.join(DIR, 'scenarios.json'), 'utf8'));

type Scores = Record<string, { pass: boolean; note: string }>;

const TR_STOP = [' ve ', ' bir ', ' bu ', ' için ', ' ile ', ' de ', ' da ', ' mı', ' ne ', ' daha '];
function textOf(role: RoleId, out: any): string {
  if (role === 'content') return `${out.post_text}`;
  if (role === 'customer_dev') return `${out.outreach?.draft ?? ''} ${out.next_step ?? ''}`;
  if (role === 'strategy') return [out.campaign_brief?.message, ...(out.objectives ?? []).map((o: any) => `${o.goal}. ${o.rationale}`)].join(' ');
  return JSON.stringify(out);
}

export function score(s: any, out: any): Scores {
  const role = s.role as RoleId;
  const e = s.expect ?? {};
  const txt = textOf(role, out);
  const lower = ` ${txt.toLocaleLowerCase('tr-TR')} `;
  const res: Scores = {};
  const set = (k: string, pass: boolean, note: string) => { res[k] = { pass, note }; };
  for (const k of s.criteria as string[]) {
    switch (k) {
      case 'kaynak_dogrulugu': {
        if (role === 'strategy') {
          const known = Object.keys(s.input.context ?? {}).map((x) => `ctx:${x}`);
          const refs = (out.objectives ?? []).flatMap((o: any) => o.basis_refs);
          const badRef = refs.filter((r: string) => !known.includes(r));
          const nums = checkNumbersFromContext([...(out.objectives ?? []).map((o: any) => o.rationale), ...(out.decision_changes ?? []).map((d: any) => d.because)].join('\n'), JSON.stringify(s.input.context ?? {}));
          set(k, badRef.length === 0 && nums.ok, badRef.length ? `bilinmeyen dayanak: ${badRef.join(', ')}` : nums.ok ? 'dayanak ve sayılar girdide' : nums.violations.map((v) => v.detail).join('; '));
        } else if (role === 'auditor') {
          const inRefs = new Set((s.input.deterministicFindings ?? []).flatMap((f: any) => f.evidence_refs));
          const outRefs = (out.findings ?? []).flatMap((f: any) => f.evidence_refs);
          const ok = outRefs.every((r: string) => inRefs.has(r)) && (out.findings ?? []).every((f: any) => f.evidence_refs.length > 0)
            && (e.findings_min == null || out.findings.length >= e.findings_min) && (e.bottleneck_area == null || out.findings.some((f: any) => f.bottleneck_area === e.bottleneck_area));
          set(k, ok, ok ? 'tüm bulgular girdideki kanıta dayanıyor' : 'kanıtsız/eksik bulgu');
        } else set(k, true, 'uygulanmaz');
        break;
      }
      case 'turkiye_baglami': {
        const foreign = /\b(usd|eur|\$|€|amerika|abd pazar|europe)\b/i.test(txt);
        const tr = TR_STOP.filter((w) => lower.includes(w)).length >= 2;
        set(k, tr && !foreign, `türkçe ipucu ${tr ? 'var' : 'yok'}${foreign ? '; yabancı pazar/para birimi' : ''}`);
        break;
      }
      case 'hizmet_uyumu': {
        if (role === 'strategy') {
          const kinds = (out.objectives ?? []).flatMap((o: any) => o.tasks.map((t: any) => t.kind));
          set(k, e.founder_task_kind ? kinds.includes(e.founder_task_kind) : true, `görevler: ${kinds.join(', ')}`);
        } else {
          const g = checkClaims(txt, { brandName: 'BaysSystems', otherBrandNames: [], offers: [{ code: 'instagram-mesajlasma', title: 'Instagram mesajlaşma otomasyonu', readiness: 'in_development' }], evidenceIds: [] });
          set(k, !g.violations.some((v) => ['readiness_overclaim', 'offer_not_sellable'].includes(v.code)), g.violations.map((v) => v.code).join(', ') || 'uyumlu');
        }
        break;
      }
      case 'somut_oneri': {
        let ok = false;
        if (role === 'strategy') ok = (out.objectives ?? []).some((o: any) => o.tasks.length > 0) && (!e.mentions_any || e.mentions_any.some((m: string) => JSON.stringify(out).toLocaleLowerCase('tr-TR').includes(m)));
        else if (role === 'content') ok = /\?|görüş|mesaj atmanız|yazın/.test(txt) && (!e.mentions_any || e.mentions_any.some((m: string) => lower.includes(m)));
        else if (role === 'distribution') ok = (e.slot ? out.schedule?.[0]?.scheduled_at === e.slot : true) && (e.manual_action ? out.manual_tasks.some((m: any) => m.action === e.manual_action) : true) && (e.arm ? out.experiment_arm === e.arm : true);
        else if (role === 'customer_dev') ok = e.classification ? out.reply_classification === e.classification : /\?/.test(out.outreach?.draft ?? '');
        else ok = true;
        set(k, ok, ok ? 'uygulanabilir çıktı' : 'beklenen eylem yok');
        break;
      }
      case 'dogal_turkce': {
        const sentences = txt.split(/[.!?]+/).map((x) => x.trim()).filter(Boolean);
        const avg = sentences.reduce((a, x) => a + x.split(/\s+/).length, 0) / Math.max(sentences.length, 1);
        const jargon = (RUBRIC.jargon_blacklist as string[]).filter((j) => lower.includes(j));
        set(k, avg <= 28 && jargon.length === 0, `ort. cümle ${avg.toFixed(1)} kelime${jargon.length ? `; jargon: ${jargon.join(', ')}` : ''}`);
        break;
      }
      case 'kisisellestirme': {
        const d = (out.outreach?.draft ?? '').toLocaleLowerCase('tr-TR');
        const ok = !!out.outreach && out.outreach.personalization_basis.length > 0 && (d.includes((s.input.lead.business_name ?? '').toLocaleLowerCase('tr-TR')) || (e.signal && d.includes(e.signal)));
        set(k, ok, ok ? 'aday/sinyal geçiyor' : 'kişiselleştirme yok');
        break;
      }
      case 'veriden_karar': {
        const n = (out.decision_changes ?? []).length;
        const ok = (e.decision_changes_min == null || n >= e.decision_changes_min) && (e.decision_changes_max == null || n <= e.decision_changes_max) && (!e.content_type || out.campaign_brief?.content_type === e.content_type);
        set(k, ok, `değişiklik ${n}${e.content_type ? `, içerik türü ${out.campaign_brief?.content_type}` : ''}`);
        break;
      }
      case 'belirsizlik': {
        let ok = true;
        if (role === 'strategy') ok = (out.data_gaps ?? []).length >= (e.data_gaps_min ?? 1);
        if (role === 'customer_dev') ok = (e.no_outreach ? out.outreach === null : true) && (e.unknowns_include ? (out.lead_assessment.unknowns.includes(e.unknowns_include) || (out.handoff?.unknowns ?? []).includes(e.unknowns_include)) : true);
        if (role === 'auditor') ok = (e.findings_max == null || out.findings.length <= e.findings_max) && (!e.no_halt || out.halt_recommendation === null);
        set(k, ok, ok ? 'belirsizlik açık' : 'belirsizlik gizlenmiş/eksik');
        break;
      }
      case 'maliyet_disiplini': {
        const limits = (out.objectives ?? []).map((o: any) => o.cost_limit_try);
        const ads = /(ücretli|sponsorlu)\s+reklam/i.test(JSON.stringify(out));
        set(k, limits.every((l: number) => l <= (e.budget_try ?? Infinity)) && !ads, `sınırlar: ${limits.join(', ')}${ads ? '; reklam önerisi' : ''}`);
        break;
      }
      case 'koruma': {
        const g = checkClaims(txt, { brandName: 'BaysSystems', otherBrandNames: ['Almakİstiyorum.net', 'Maple Market', 'Mentora'], offers: [], evidenceIds: [] });
        set(k, g.ok && !(e.no_price && g.violations.some((v) => v.code === 'price_commitment')), g.violations.map((v) => v.code).join(', ') || 'ihlal yok');
        break;
      }
    }
  }
  return res;
}

export interface QualityRun { mode: 'mock_contract' | 'live_model'; status: 'done' | 'pending' | 'error'; model: string | null; passRate?: number; perRole?: Record<string, { pass: number; total: number }>; results?: any[]; note: string; runId?: string; meetsThreshold?: boolean }

export async function runQuality(opts: { live?: boolean } = {}): Promise<QualityRun> {
  const cfg = config();
  const mode: QualityRun['mode'] = opts.live ? 'live_model' : 'mock_contract';
  const versions = Object.fromEntries((Object.keys(ROLES) as RoleId[]).map((r) => [r, `${ROLES[r].version}+${expertise(r).version}`]));
  const record = async (row: Partial<QualityRun> & { status: string; results?: any[]; summary?: any }) => withSystem(async (c) => (await c.query(
    `INSERT INTO eval_runs (suite, mode, status, model, judge_model, prompt_versions, thresholds, results, summary, note) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
    [`${SCEN.version}/${RUBRIC.version}`, mode, row.status, row.model ?? null, cfg.MODEL_JUDGE || null, versions, RUBRIC.thresholds, JSON.stringify(row.results ?? []), row.summary ?? {}, row.note ?? null])).rows[0].id as string);

  if (opts.live) {
    const missing: string[] = [];
    if (cfg.RUN_MODE !== 'eval') missing.push('RUN_MODE=eval değil');
    if (cfg.EGRESS_ENABLED !== 'true') missing.push('EGRESS_ENABLED=true değil');
    for (const t of ['economy', 'strong'] as const) {
      try { const m = resolveModel(t); if (m.provider.name === 'mock') missing.push(`${t} modeli mock (gerçek model tanımlı değil)`); } catch (e) { missing.push((e as Error).message); }
    }
    if (!cfg.ANTHROPIC_API_KEY && !cfg.OPENAI_API_KEY) missing.push('model API anahtarı yok');
    if (missing.length) {
      const note = `BEKLEMEDE: gerçek model değerlendirmesi çalıştırılmadı — ${missing.join('; ')}. Model kalitesi sınanmadı.`;
      const runId = await record({ status: 'pending', note });
      return { mode, status: 'pending', model: null, note, runId };
    }
  }
  const brand = await withSystem(async (c) => (await c.query(`SELECT id FROM brands WHERE slug='bayssystems'`)).rows[0].id);
  const runKey = sha256(`${Date.now()}:${Math.random()}`).slice(0, 10);
  const results: any[] = [];
  let model: string | null = null;
  for (const s of SCEN.scenarios) {
    const t = await withBrand(brand, async (c) => {
      // Değerlendirme görevi: purpose='evaluation' → kuyruktan yürütülmez, operasyon raporlarına/kararlarına girmez
      const { id } = await enqueueTask(c, { brandId: brand, role: s.role, kind: `eval:${s.id}`, idempotencyKey: `eval:${runKey}:${s.id}`, input: { eval: s.id, run: runKey }, simulated: !opts.live, purpose: 'evaluation' }); // run: her değerlendirme çalıştırması ayrı parmak izi (döngü algılayıcı tekrar çalıştırmayı engellemesin)
      return (await c.query(`UPDATE tasks SET status='running' WHERE id=$1 RETURNING *`, [id])).rows[0];
    });
    try {
      const r = await runAgent({ task: t, role: s.role, taskInput: s.input });
      model = model ?? resolveModel(ROLES[s.role as RoleId].tier).pricingKey;
      const sc = score(s, r.output);
      const pass = Object.values(sc).every((x) => x.pass);
      results.push({ id: s.id, role: s.role, pass, scores: sc, guard: r.guard.violations.map((v) => v.code), output: r.output });
      await withBrand(brand, (c) => c.query(`UPDATE tasks SET status='done', output=$2 WHERE id=$1`, [t.id, { eval: true, pass }]));
    } catch (e) {
      results.push({ id: s.id, role: s.role, pass: false, error: (e as Error).message });
      await withBrand(brand, (c) => c.query(`UPDATE tasks SET status='failed', last_error=$2 WHERE id=$1`, [t.id, (e as Error).message.slice(0, 300)]));
    }
  }
  const perRole: Record<string, { pass: number; total: number }> = {};
  for (const r of results) { perRole[r.role] ??= { pass: 0, total: 0 }; perRole[r.role].total++; if (r.pass) perRole[r.role].pass++; }
  const passRate = results.filter((r) => r.pass).length / results.length;
  const meetsThreshold = passRate >= RUBRIC.thresholds.suite_min_pass_rate && Object.values(perRole).every((p) => p.pass >= Math.min(RUBRIC.thresholds.per_role_min_pass, p.total));
  const note = mode === 'mock_contract'
    ? 'MOCK SÖZLEŞME TESTİ: değerlendirme altyapısı ve puanlama çalışıyor. Bu sonuç gerçek model kalitesini GÖSTERMEZ; uzmanlık rehberinin davranışa etkisi mock ile ölçülemez.'
    : 'Gerçek model değerlendirmesi (RUN_MODE=eval; yayın/mesaj yok). Deterministik puanlama esas; hakem modeli tavsiye niteliğinde.';
  const runId = await record({ status: 'done', model, results, summary: { passRate, perRole, meetsThreshold }, note });
  return { mode, status: 'done', model, passRate, perRole, results, note, runId, meetsThreshold };
}
