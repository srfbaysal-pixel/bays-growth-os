import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import Fastify, { type FastifyInstance, type FastifyRequest } from 'fastify';
import { config, maskSecrets } from '../config.js';
import { withSystem, withBrand } from '../db/pool.js';
import { sha256 } from '../core/util.js';
import { handleDecisionReply } from '../core/approvals.js';
import { createHalt, applyHaltToQueue, resumeHalt } from '../core/halts.js';
import { logEvent } from '../core/events.js';
import { committed, getLimits } from '../core/budget.js';
import { monthKey } from '../core/util.js';
import { verifyChallenge, handleWhatsAppWebhook } from '../integrations/whatsapp.js';
import { signBody } from '../integrations/linkedin.js';
import { buildReport } from '../reports/reports.js';
import { recordRevenue } from '../crm/crm.js';
import { installGlobalEgressGuard } from '../integrations/egress.js';
import { completeManualTask } from '../crm/manual.js';
import { ingestReply } from '../crm/outreach.js';
import { ingestMetrics } from '../metrics/ingest.js';
import { enqueueTask } from '../core/tasks.js';
import { clock } from '../core/clock.js';

const APP_VERSION: string = JSON.parse(fs.readFileSync(path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../package.json'), 'utf8')).version;
const PANEL = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../panel/index.html');

function founderAuth(req: FastifyRequest): boolean {
  const expected = config().FOUNDER_TOKEN_SHA256;
  const h = req.headers.authorization;
  if (!expected || !h?.startsWith('Bearer ')) return false;
  const got = Buffer.from(sha256(h.slice(7)));
  const exp = Buffer.from(expected);
  return got.length === exp.length && crypto.timingSafeEqual(got, exp);
}

function n8nAuth(raw: Buffer, header: string | undefined): boolean {
  const secret = config().N8N_SHARED_SECRET;
  if (!secret || !header) return false;
  const exp = Buffer.from(signBody(raw.toString(), secret));
  const got = Buffer.from(header);
  return exp.length === got.length && crypto.timingSafeEqual(exp, got);
}

export async function buildServer(): Promise<FastifyInstance> {
  installGlobalEgressGuard();
  const app = Fastify({ logger: false, bodyLimit: 512 * 1024 });
  // Ham gövde: webhook imzaları yeniden serileştirilmiş JSON üzerinden değil, gelen baytlar üzerinden doğrulanır
  app.addContentTypeParser('application/json', { parseAs: 'buffer' }, (_req, body, done) => done(null, body));
  const json = (req: FastifyRequest) => { const b = req.body as Buffer | undefined; return b && b.length ? JSON.parse(b.toString()) : {}; };

  // Yetki kararı ham URL'ye göre değil, eşleşen rota şablonuna göre verilir (URL kodlamasıyla atlatmayı önler).
  // Varsayılan: giriş gerekir. Yalnız kendi imza denetimi olan webhook/internal uçları ve sağlık/panel kabuğu açıktır.
  const PUBLIC = (route: string) => route === '/health' || route === '/panel' || route.startsWith('/webhooks/') || route.startsWith('/internal/');
  const routeOf = (req: FastifyRequest) => req.routeOptions?.url ?? '';
  app.addHook('onResponse', async (req, reply) => {
    const route = routeOf(req);
    if (route === '/health' || route === '/panel') return;
    const actor = !route ? 'unmatched' : PUBLIC(route) ? route.split('/')[1] : (founderAuth(req) ? 'founder' : 'anonymous');
    await withSystem((c) => c.query(`INSERT INTO access_log (actor, method, path, status, ip_hash) VALUES ($1,$2,$3,$4,$5)`, [actor, req.method, (route || req.url.split('?')[0]).slice(0, 200), reply.statusCode, sha256(req.ip ?? '')])).catch(() => undefined);
  });
  app.addHook('preHandler', async (req, reply) => {
    const route = routeOf(req);
    if (!route || PUBLIC(route)) return;
    if (!founderAuth(req)) return reply.code(401).send({ error: 'Kurucu girişi gerekli' });
  });
  app.setErrorHandler((err: any, _req, reply) => { reply.code(err?.statusCode ?? 400).send({ error: maskSecrets(String(err?.message ?? err)) }); });

  app.get('/health', async () => ({ ok: true, mode: config().RUN_MODE, version: APP_VERSION }));
  app.get('/panel', async (_req, reply) => reply.type('text/html; charset=utf-8').send(fs.readFileSync(PANEL, 'utf8')));

  // ---- Kurucu API ----
  app.get('/api/overview', async () => withSystem(async (c) => {
    const lim = await getLimits(c);
    return {
      mode: config().RUN_MODE,
      brands: (await c.query(`SELECT id, slug, name, status FROM brands ORDER BY created_at`)).rows,
      halts: (await c.query(`SELECT * FROM halts WHERE active ORDER BY created_at DESC`)).rows,
      decisions: (await c.query(`SELECT a.code, a.action, a.rationale, a.cost_try, a.options, a.expires_at, a.is_simulated, b.name brand FROM approval_requests a JOIN brands b ON b.id=a.brand_id WHERE a.status='pending' ORDER BY a.created_at`)).rows,
      budget: { limits: lim, live: await committed(c, 'live', monthKey(new Date())), simulation: await committed(c, 'simulation', monthKey(new Date())) },
      connections: (await c.query(`SELECT cc.id, b.slug, cc.channel, cc.adapter, cc.status, cc.last_error, cc.verified_at FROM channel_connections cc JOIN brands b ON b.id=cc.brand_id ORDER BY b.slug, cc.channel`)).rows,
      findings: (await c.query(`SELECT id, brand_id, severity, title, status, is_simulated, created_at FROM audit_findings WHERE status='open' ORDER BY created_at DESC LIMIT 50`)).rows,
    };
  }));
  app.get('/api/brands/:id/tasks', async (req) => withBrand((req.params as any).id, async (c) => (await c.query(`SELECT id, role, kind, status, attempts, model_calls, last_error, dead_reason, next_run_at, is_simulated, updated_at FROM tasks ORDER BY updated_at DESC LIMIT 100`)).rows));
  app.get('/api/brands/:id/opportunities', async (req) => withBrand((req.params as any).id, async (c) => (await c.query(
    `SELECT o.id, o.status, o.need_summary, o.unknowns, o.next_step, o.evidence, o.is_simulated, l.business_name, l.stage FROM opportunities o JOIN leads l ON l.id=o.lead_id ORDER BY o.created_at DESC LIMIT 100`)).rows));
  app.get('/api/brands/:id/leads', async (req) => withBrand((req.params as any).id, async (c) => (await c.query(`SELECT id, business_name, stage, fit_score, need_signals, is_sample FROM leads ORDER BY updated_at DESC LIMIT 200`)).rows));
  app.get('/api/reports/:kind', async (req) => buildReport((req.params as any).kind === 'weekly' ? 'weekly' : 'daily', { brandId: (req.query as any).brand ?? null }));

  app.post('/api/decisions/:code', async (req) => {
    const b = json(req);
    return handleDecisionReply({ via: 'panel', founderAuthenticated: true, text: `${(req.params as any).code} ${String(b.option ?? '').toUpperCase()}` });
  });
  app.post('/api/halts', async (req) => {
    const b = json(req);
    return withSystem(async (c) => { const id = await createHalt(c, { scope: b.scope, brandId: b.brandId ?? null, scopeValue: b.scopeValue ?? null, reason: String(b.reason ?? 'kurucu durdurması'), by: 'founder' }); const n = await applyHaltToQueue(c, id); return { id, ...n }; });
  });
  app.post('/api/halts/:id/resume', async (req) => {
    const b = json(req);
    await withSystem((c) => resumeHalt(c, (req.params as any).id, { authenticated: true, actor: 'founder' }, b.requeue === true));
    return { ok: true };
  });
  /** Bağlantı durumu: "live" yalnız doğrulanmış (verified_at dolu) bağlantıya ve yalnız kurucu tarafından verilebilir. */
  app.post('/api/connections/:id/status', async (req, reply) => {
    const b = json(req);
    const allowed = ['disconnected', 'mock', 'configured', 'verified', 'live', 'degraded'];
    if (!allowed.includes(b.status)) return reply.code(400).send({ error: 'Geçersiz durum' });
    return withSystem(async (c) => {
      const cur = (await c.query(`SELECT * FROM channel_connections WHERE id=$1`, [(req.params as any).id])).rows[0];
      if (!cur) return reply.code(404).send({ error: 'Bağlantı yok' });
      if (b.status === 'verified' && !b.verificationSource) return reply.code(400).send({ error: 'Doğrulama kaynağı (test kaydı/belge) gerekli' });
      if (b.status === 'live' && !cur.verified_at) return reply.code(400).send({ error: 'Canlıya almak için önce doğrulanmış (verified) olmalı' });
      await c.query(`UPDATE channel_connections SET status=$2, verified_at = CASE WHEN $2='verified' THEN now() ELSE verified_at END, verification_source = COALESCE($3, verification_source), updated_at=now() WHERE id=$1`, [cur.id, b.status, b.verificationSource ?? null]);
      await logEvent(c, { brandId: cur.brand_id, type: 'connection.status_changed', actor: 'founder', subjectType: 'channel_connection', subjectId: cur.id, payload: { from: cur.status, to: b.status } });
      return { ok: true };
    });
  });
  /** Gelir girişi: kurucu doğrulamalı manuel kayıt (entegrasyon yokken). */
  app.post('/api/opportunities/:id/revenue', async (req) => {
    const b = json(req);
    const brandId = await withSystem(async (c) => (await c.query(`SELECT brand_id FROM opportunities WHERE id=$1`, [(req.params as any).id])).rows[0]?.brand_id);
    await withBrand(brandId, (c) => recordRevenue(c, (req.params as any).id, { valueTry: Number(b.valueTry), verifiedByFounder: true, attribution: b.attribution === 'campaign_confirmed' ? 'campaign_confirmed' : 'unattributed' }));
    return { ok: true };
  });

  // ---- V2: manuel görevler, yanıt girişi, hizmet kartları, araştırma ----
  app.get('/api/brands/:id/manual-tasks', async (req) => withBrand((req.params as any).id, async (c) => (await c.query(
    `SELECT m.id, m.kind, m.channel, m.status, m.payload, m.is_simulated, m.created_at, l.business_name FROM manual_tasks m LEFT JOIN leads l ON l.id=m.lead_id ORDER BY (m.status='open') DESC, m.created_at DESC LIMIT 100`)).rows));
  /** Manuel işin sonucu: "sent" temas kaydı + takip görevi; "reply_received" yanıt sınıflandırma; taslak tek başına temas sayılmaz */
  app.post('/api/brands/:id/manual-tasks/:mid/complete', async (req) => {
    const b = json(req);
    const allowed = ['sent', 'not_sent', 'reply_received', 'done', 'skipped'];
    if (!allowed.includes(b.outcome)) throw Object.assign(new Error('Geçersiz sonuç'), { statusCode: 400 });
    return completeManualTask((req.params as any).id, (req.params as any).mid, { outcome: b.outcome, sentAt: b.sentAt, replyText: b.replyText, messageRef: b.messageRef, email: b.email, note: b.note }, 'founder', clock.now());
  });
  /** Kurucunun manuel yanıt girişi (e-posta entegrasyonu yoksa yedek yol) */
  app.post('/api/brands/:id/leads/:lid/replies', async (req) => {
    const b = json(req);
    const brandId = (req.params as any).id;
    if (!b.text || String(b.text).length < 1) throw Object.assign(new Error('Yanıt metni gerekli'), { statusCode: 400 });
    const msgId = b.messageRef ?? `manual-reply:${sha256(`${(req.params as any).lid}:${b.text}`).slice(0, 16)}`;
    const lid = String((req.params as any).lid);
    if (!/^[0-9a-f-]{36}$/i.test(lid)) throw Object.assign(new Error('Geçersiz aday kimliği'), { statusCode: 400 });
    return ingestReply({ brandId, leadId: lid, messageId: msgId, text: String(b.text), receivedAt: b.receivedAt ? new Date(b.receivedAt) : clock.now(), via: 'manual', simulated: config().RUN_MODE !== 'live', enqueueClassify: true });
  });
  // ── V2.1: gerçek performans ölçümü (kurucu girişi) ──
  app.get('/api/brands/:id/publications/live', async (req) => withBrand((req.params as any).id, async (c) => (await c.query(
    `SELECT p.id, p.channel, p.external_id, p.sent_at, p.scheduled_at, left(a.content->>'post_text', 120) excerpt, a.content->>'experiment_id' experiment_id, a.content->>'arm' arm,
            (SELECT json_object_agg(m.metric, m.value) FROM metrics m WHERE m.publication_id=p.id AND m.is_current AND NOT m.is_simulated) current
       FROM publications p LEFT JOIN assets a ON a.id=p.asset_id WHERE p.status='published' AND NOT p.is_simulated ORDER BY coalesce(p.sent_at, p.scheduled_at) DESC LIMIT 50`)).rows));
  app.get('/api/brands/:id/metrics', async (req) => withBrand((req.params as any).id, async (c) => (await c.query(
    `SELECT id, publication_id, metric, value, source, is_simulated, is_current, measured_at, received_at, experiment_id, arm, recorded_by FROM metrics
      WHERE ($1::text IS NULL OR publication_id::text=$1) ORDER BY measured_at DESC LIMIT 200`, [((req.query as any).publicationId as string) ?? null])).rows));
  app.post('/api/brands/:id/metrics', async (req) => {
    const b = json(req);
    return ingestMetrics({ brandId: (req.params as any).id, publicationId: b.publicationId, measuredAt: b.measuredAt, values: b.values, source: 'manual', evidence: b.evidence ?? null, actor: 'founder:panel' });
  });
  app.get('/api/brands/:id/offers', async (req) => withBrand((req.params as any).id, async (c) => (await c.query(
    `SELECT code, title, description, scope, readiness, delivery_note, required_connections, founder_verified, demo_evidence_id, evidence_ids FROM offers ORDER BY code`)).rows));
  /** Demo bağlama: kurucu kanıt (URL + test notu) ekler; hizmet "demo" olur. Fiyat/teslim yazılmaz. */
  app.post('/api/brands/:id/offers/:code/demo', async (req) => {
    const b = json(req);
    if (!b.uri || !b.testNote) throw Object.assign(new Error('Demo URL ve test notu gerekli'), { statusCode: 400 });
    return withBrand((req.params as any).id, async (c) => {
      const ev = (await c.query(`INSERT INTO evidence (brand_id, kind, title, uri, payload, is_sample) VALUES ($1,'test_result',$2,$3,$4,false) RETURNING id`, [(req.params as any).id, `Demo: ${(req.params as any).code}`, b.uri, { testNote: b.testNote, recordedBy: 'founder', recordedAt: clock.now().toISOString() }])).rows[0].id;
      const r = await c.query(`UPDATE offers SET demo_evidence_id=$3, readiness=CASE WHEN readiness IN ('user_declared','in_development') THEN 'demo' ELSE readiness END, founder_verified=true, evidence_ids=array_append(evidence_ids, $3::uuid), updated_at=now() WHERE brand_id=$1 AND code=$2 RETURNING code, readiness`, [(req.params as any).id, (req.params as any).code, ev]);
      if (!r.rows[0]) throw Object.assign(new Error('Hizmet yok'), { statusCode: 404 });
      await logEvent(c, { brandId: (req.params as any).id, type: 'offer.demo_attached', actor: 'founder', subjectType: 'offer', subjectId: (req.params as any).code, payload: { evidence: ev } });
      return r.rows[0];
    });
  });
  app.get('/api/brands/:id/research', async (req) => withBrand((req.params as any).id, async (c) => ({
    runs: (await c.query(`SELECT day, provider, status, queries, documents, findings, candidates, notes FROM research_runs ORDER BY created_at DESC LIMIT 14`)).rows,
    findings: (await c.query(`SELECT kind, source_url, accessed_at, excerpt, observed_fact, inference, confidence, freshness, is_simulated FROM research_findings ORDER BY created_at DESC LIMIT 50`)).rows,
  })));

  // ---- Webhook'lar ----
  /** Gelen e-posta yanıtı (n8n IMAP akışı → imzalı). Aynı Message-ID ikinci kez işlenmez. */
  app.post('/webhooks/email/inbound', async (req, reply) => {
    const raw = req.body as Buffer;
    if (!n8nAuth(raw, req.headers['x-bays-signature'] as string | undefined)) return reply.code(401).send({ error: 'imza' });
    const b = JSON.parse(raw.toString());
    if (!b.brand || !b.message_id || typeof b.text !== 'string') return reply.code(400).send({ error: 'sözleşme: brand, message_id, text' });
    const brandId = await withSystem(async (c) => (await c.query(`SELECT id FROM brands WHERE slug=$1`, [b.brand])).rows[0]?.id);
    if (!brandId) return reply.code(404).send({ error: 'marka yok' });
    // Yanıt kaydı ve sınıflandırma görevi aynı veritabanı işleminde (çökmede yanıt işlenmeden kalmaz)
    const r = await ingestReply({ brandId, messageId: String(b.message_id), inReplyTo: b.in_reply_to ?? null, from: b.from ?? null, text: b.text.slice(0, 20000), receivedAt: b.received_at ? new Date(b.received_at) : clock.now(), via: 'webhook', simulated: config().RUN_MODE !== 'live', enqueueClassify: true });
    return { ok: true, status: r.status };
  });
  app.get('/webhooks/whatsapp', async (req, reply) => {
    const ch = verifyChallenge(req.query as Record<string, string>);
    return ch ? reply.type('text/plain').send(ch) : reply.code(403).send('forbidden');
  });
  app.post('/webhooks/whatsapp', async (req, reply) => {
    const r = await handleWhatsAppWebhook(req.body as Buffer, req.headers['x-hub-signature-256'] as string | undefined);
    return reply.code(r.status).send({ ok: r.ok });
  });
  /** n8n yayın sonucu geri çağrısı (imzalı, tekrar korumalı). */
  /** V2.1: n8n'den ölçüm aktarımı (imzalı). Sözleşme: docs/n8n_adaptor_sozlesmesi.md §8 */
  app.post('/webhooks/n8n/metrics', async (req, reply) => {
    const raw = req.body as Buffer;
    if (!n8nAuth(raw, req.headers['x-bays-signature'] as string | undefined)) return reply.code(401).send({ error: 'imza' });
    let b: any; try { b = JSON.parse(raw.toString()); } catch { return reply.code(400).send({ error: 'geçersiz JSON' }); }
    if (b.contract !== 'bays.metrics.v1' || !b.brand || !b.publication || !b.delivery_id) return reply.code(400).send({ error: 'sözleşme: contract=bays.metrics.v1, brand, publication{idempotency_key|external_id}, delivery_id, measured_at, values' });
    const brandId = await withSystem(async (c) => (await c.query(`SELECT id FROM brands WHERE slug=$1`, [String(b.brand)])).rows[0]?.id);
    if (!brandId) return reply.code(404).send({ error: 'marka yok' });
    return ingestMetrics({ brandId, publicationRef: { idempotencyKey: b.publication.idempotency_key ?? null, externalId: b.publication.external_id ?? null }, measuredAt: b.measured_at, values: b.values,
      source: 'n8n', externalKey: String(b.delivery_id), evidence: { url: b.evidence_url ?? null, note: `n8n teslimi ${String(b.delivery_id).slice(0, 80)}` }, actor: 'n8n' });
  });
  app.post('/webhooks/n8n/publication-result', async (req, reply) => {
    const raw = req.body as Buffer;
    if (!n8nAuth(raw, req.headers['x-bays-signature'] as string | undefined)) return reply.code(401).send({ error: 'imza' });
    const b = JSON.parse(raw.toString());
    return withSystem(async (c) => {
      const first = (await c.query(`INSERT INTO inbound_webhooks (provider, event_key, payload_hash) VALUES ('n8n', $1, $2) ON CONFLICT DO NOTHING RETURNING id`, [`pub:${b.idempotency_key}:${b.status}`, sha256(raw.toString())])).rowCount === 1;
      if (!first) return { ok: true, duplicate: true };
      const p = (await c.query(`SELECT id, brand_id, asset_id, status FROM publications WHERE idempotency_key=$1 AND adapter='n8n-linkedin'`, [b.idempotency_key])).rows[0];
      if (!p) return reply.code(404).send({ error: 'yayın yok' });
      if (b.status === 'published' && b.external_id && ['sending', 'outcome_unknown', 'manual_required'].includes(p.status)) {
        await c.query(`UPDATE publications SET status='published', external_id=$2 WHERE id=$1`, [p.id, String(b.external_id)]);
        await c.query(`UPDATE assets SET status='published' WHERE id=$1`, [p.asset_id]);
      } else if (b.status === 'failed' && ['sending', 'outcome_unknown', 'manual_required'].includes(p.status)) {
        await c.query(`UPDATE publications SET status='failed', error=$2 WHERE id=$1`, [p.id, String(b.error ?? 'n8n hata')]);
      }
      await logEvent(c, { brandId: p.brand_id, type: 'publication.n8n_callback', actor: 'n8n', subjectType: 'publication', subjectId: p.id, payload: { status: b.status } });
      return { ok: true };
    });
  });
  /** n8n zamanlayıcısı bu uçları çağırır (imzalı). İş mantığı servistedir. */
  app.post('/internal/cycle/:name', async (req, reply) => {
    const raw = (req.body as Buffer) ?? Buffer.from('');
    if (!n8nAuth(raw, req.headers['x-bays-signature'] as string | undefined)) return reply.code(401).send({ error: 'imza' });
    // Tekrar oynatma koruması: imzalı gövdedeki zaman 5 dakikadan eski olamaz ve aynı gövde bir kez işlenir
    const b = JSON.parse(raw.toString() || '{}');
    const at = Date.parse(b.at ?? '');
    if (!Number.isFinite(at) || Math.abs(Date.now() - at) > 5 * 60_000) return reply.code(401).send({ error: 'zaman damgası geçersiz' });
    const first = await withSystem(async (c) => (await c.query(`INSERT INTO inbound_webhooks (provider, event_key, payload_hash) VALUES ('n8n-cycle', $1, $1) ON CONFLICT DO NOTHING RETURNING id`, [sha256(raw.toString())])).rowCount === 1);
    if (!first) return reply.code(409).send({ error: 'tekrar' });
    const { runScheduled } = await import('../orchestrator/schedule.js');
    return runScheduled((req.params as any).name, new Date());
  });
  return app;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const app = await buildServer();
  await app.listen({ port: config().PORT, host: '0.0.0.0' });
  console.log(`BaysSystems Growth OS dinlemede: :${config().PORT} (kip: ${config().RUN_MODE})`);
}
