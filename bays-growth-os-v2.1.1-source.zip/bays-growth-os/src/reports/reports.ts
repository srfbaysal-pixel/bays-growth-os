import { config } from '../config.js';
import { withSystem, type Db } from '../db/pool.js';
import { committed, getLimits } from '../core/budget.js';
import { monthKey, dayKey } from '../core/util.js';

/**
 * Raporlar ham kayıtlardan üretilir. Kurallar:
 * - Simülasyon/mock sonuç canlı başarı olarak yazılmaz; ayrı satırda "ÖRNEK" etiketiyle gösterilir.
 * - Eksik ölçüm sıfır değildir: "ölçüm yok" yazılır.
 * - Kaynağı belirsiz veya kurucu doğrulaması olmayan gelir kampanya sonucu sayılmaz.
 * Her bölüm, kanıt izi için ilgili kayıt kimliklerini data içinde taşır.
 */
export interface Report { kind: 'daily' | 'weekly'; text: string; data: Record<string, any> }

async function section(c: Db, brandFilter: string | null, since: Date) {
  const bf = brandFilter ? 'AND brand_id = $2' : '';
  const params = brandFilter ? [since, brandFilter] : [since];
  const pubs = (await c.query(`SELECT status, is_simulated, count(*)::int n, array_agg(id::text) ids FROM publications WHERE created_at >= $1 ${bf} GROUP BY status, is_simulated`, params)).rows;
  // V2.1: yalnız güncel anlık görüntüler (aynı gönderinin tekrar ölçümleri toplamı şişirmez); örnek/gerçek ayrı
  const metrics = (await c.query(`SELECT metric, is_simulated, source, count(*)::int n, sum(value)::float8 s FROM metrics WHERE measured_at >= $1 AND is_current ${bf} GROUP BY metric, is_simulated, source`, params)).rows;
  const funnel = (await c.query(`SELECT stage, is_sample, count(*)::int n FROM leads WHERE 1=1 ${brandFilter ? 'AND brand_id = $1' : ''} GROUP BY stage, is_sample`, brandFilter ? [brandFilter] : [])).rows;
  const opps = (await c.query(`SELECT status, is_simulated, attribution, revenue_verified_by_founder v, count(*)::int n, coalesce(sum(value_try),0)::float8 val, array_agg(id::text) ids FROM opportunities WHERE 1=1 ${brandFilter ? 'AND brand_id = $1' : ''} GROUP BY status, is_simulated, attribution, revenue_verified_by_founder`, brandFilter ? [brandFilter] : [])).rows;
  const decisions = (await c.query(`SELECT code, action, expires_at FROM approval_requests WHERE status='pending' ${brandFilter ? 'AND brand_id = $1' : ''} ORDER BY created_at`, brandFilter ? [brandFilter] : [])).rows;
  const findings = (await c.query(`SELECT id::text id, severity, title, is_simulated, mode_unknown FROM audit_findings WHERE status='open' AND severity IN ('high','critical','medium') ${brandFilter ? 'AND (brand_id = $1 OR brand_id IS NULL)' : ''} ORDER BY created_at DESC LIMIT 8`, brandFilter ? [brandFilter] : [])).rows;
  const conns = (await c.query(`SELECT b.slug, cc.channel, cc.adapter, cc.status FROM channel_connections cc JOIN brands b ON b.id=cc.brand_id WHERE b.status='active' ${brandFilter ? 'AND b.id = $1' : ''} ORDER BY b.slug, cc.channel`, brandFilter ? [brandFilter] : [])).rows;
  const halts = (await c.query(`SELECT scope, scope_value, reason FROM halts WHERE active ${brandFilter ? 'AND (scope = \'global\' OR brand_id = $1)' : ''}`, brandFilter ? [brandFilter] : [])).rows;
  // V2: huni aşamaları ayrı sayılır; taslak ≠ gönderilmiş temas; örnek/canlı ayrı
  const bf2 = brandFilter ? 'AND brand_id = $1' : '';
  const p2 = brandFilter ? [brandFilter] : [];
  // V2.1: kipi bilinmeyen eski kayıtlar (mode_unknown) gerçek sayıya katılmaz, ayrı gösterilir
  const cnt = async (sql: string) => (await c.query(sql, p2)).rows.reduce((a: any, r: any) => { const k = r.unk ? 'unknown' : r.sim ? 'sample' : 'real'; return { ...a, [k]: (a[k] ?? 0) + Number(r.n) }; }, { real: 0, sample: 0, unknown: 0 });
  const funnelV2 = {
    sourced: await cnt(`SELECT is_sample sim, mode_unknown unk, count(*)::int n FROM leads WHERE source_uri IS NOT NULL ${bf2} GROUP BY 1,2`),
    fit: await cnt(`SELECT is_sample sim, mode_unknown unk, count(*)::int n FROM leads WHERE fit_score >= 60 ${bf2} GROUP BY 1,2`),
    drafts: await cnt(`SELECT is_sample sim, mode_unknown unk, count(*)::int n FROM assets WHERE kind='outreach_draft' ${bf2} GROUP BY 1,2`),
    sent: await cnt(`SELECT is_simulated sim, count(*)::int n FROM interactions WHERE direction='outbound' AND status IN ('sent','manual_sent') ${bf2} GROUP BY 1`),
    replies: await cnt(`SELECT is_simulated sim, count(*)::int n FROM interactions WHERE direction='inbound' ${bf2} GROUP BY 1`),
    qualified: await cnt(`SELECT is_simulated sim, mode_unknown unk, count(*)::int n FROM opportunities WHERE 1=1 ${bf2} GROUP BY 1,2`),
    meetingsHeld: await cnt(`SELECT is_simulated sim, mode_unknown unk, count(*)::int n FROM meetings WHERE status='held' ${bf2} GROUP BY 1,2`),
    proposals: await cnt(`SELECT is_simulated sim, mode_unknown unk, count(*)::int n FROM opportunities WHERE status='proposal' ${bf2} GROUP BY 1,2`),
    verifiedSales: await cnt(`SELECT is_simulated sim, mode_unknown unk, count(*)::int n FROM opportunities WHERE status='won' AND revenue_verified_by_founder ${bf2} GROUP BY 1,2`),
  };
  const research = (await c.query(`SELECT provider, status, queries, documents, findings, candidates, notes, is_simulated FROM research_runs WHERE 1=1 ${bf2} ORDER BY created_at DESC LIMIT 1`, p2)).rows[0] ?? null;
  const manualOpen = (await c.query(`SELECT kind, count(*)::int n FROM manual_tasks WHERE status='open' ${bf2} GROUP BY 1`, p2)).rows;
  const topBottleneck = (await c.query(`SELECT title, detail->>'fix' fix FROM audit_findings WHERE check_id='top_bottleneck' ${brandFilter ? 'AND brand_id=$1' : ''} ORDER BY created_at DESC LIMIT 1`, p2)).rows[0] ?? null;
  const uncertain = (await c.query(`SELECT mode, count(*)::int n, coalesce(sum(est_try),0)::float8 s FROM budget_reservations WHERE status='uncertain' ${bf2} GROUP BY mode`, p2)).rows;
  const otherMode = (await c.query(`SELECT is_simulated sim, count(*)::int n FROM tasks WHERE status='queued' AND purpose='operation' ${bf2} GROUP BY 1`, p2)).rows;
  return { pubs, metrics, funnel, opps, decisions, findings, conns, halts, funnelV2, research, manualOpen, topBottleneck, uncertain, otherMode };
}

function fmtFunnelV2(f: any) {
  const row = (label: string, x: { real: number; sample: number; unknown?: number }) => `${label}: ${x.real}${x.sample ? ` (ÖRNEK ${x.sample})` : ''}${x.unknown ? ` (kipi bilinmeyen eski kayıt ${x.unknown}, gerçek sayılmadı)` : ''}`;
  return [row('Kaynaklı aday', f.sourced), row('Uygun aday (puan ≥60)', f.fit), row('Taslak (temas sayılmaz)', f.drafts), row('Gerçekten gönderilmiş temas', f.sent), row('Yanıt', f.replies), row('Nitelikli fırsat', f.qualified), row('Gerçekleşen görüşme', f.meetingsHeld), row('Teklif', f.proposals), row('Kurucunun doğruladığı satış', f.verifiedSales)].join('\n');
}
function fmtResearch(r: any) {
  if (!r) return 'Araştırma çalıştırması yok';
  if (r.status === 'disabled') return `Araştırma yapılmadı: ${r.notes?.[0] ?? 'sağlayıcı bağlı değil'}`;
  return `${r.provider}${r.is_simulated ? ' (ÖRNEK)' : ''} · ${r.status} · sorgu ${r.queries} · belge ${r.documents} · bulgu ${r.findings} · yeni aday ${r.candidates}${r.notes?.length ? ` · not: ${r.notes.slice(0, 2).join('; ')}` : ''}`;
}

/** Uluslararası açılım kapısı: Türkiye'de doğrulanmış sonuç olmadan önerilmez. */
function internationalGate(f: any): string {
  const conds = [
    ['Türkiye pilotunda kurucunun doğruladığı satış', f.verifiedSales.real > 0],
    ['Gerçekleşen görüşme', f.meetingsHeld.real > 0],
    ['Teslim ve destek kapasitesi tanımlı', false],
    ['Hedef ülke için kaynaklı araştırma ve ayrı bütçe kararı', false],
  ] as const;
  const ok = conds.every(([, v]) => v);
  return `${ok ? 'Koşullar sağlandı; kurucu kararına sunulabilir.' : 'Henüz önerilmez.'}\n${conds.map(([k, v]) => `${v ? '✓' : '✗'} ${k}`).join('\n')}\nHedef dilde içerik ve destek yeterliliği, destek saatleri ve maliyet kapıdan önce ayrıca planlanmalı; çeviri tek başına açılım değildir.`;
}

function fmtPubs(pubs: any[]) {
  const live = pubs.filter((p) => !p.is_simulated), sim = pubs.filter((p) => p.is_simulated);
  const line = (rows: any[]) => rows.length ? rows.map((p) => `${p.status}: ${p.n}`).join(', ') : 'yok';
  return `Canlı yayın: ${line(live)}\nÖRNEK/simülasyon yayın (gerçek paylaşım değil): ${line(sim)}`;
}
function fmtMetrics(ms: any[]) {
  const live = ms.filter((m) => !m.is_simulated);
  const sim = ms.filter((m) => m.is_simulated);
  const val = (m: any) => (/rate|oran/.test(m.metric) ? `ort. ${round(m.s / m.n)}` : `${round(m.s)}`);
  const l = live.length ? live.map((m) => `${m.metric}=${val(m)} (${m.n} ölçüm, ${m.source})`).join('; ') : 'Canlı ölçüm yok (sıfır sonuç anlamına gelmez)';
  const s = sim.length ? `\nÖRNEK ölçümler (mock, canlı sonuç değil): ${sim.map((m) => `${m.metric}=${val(m)} (${m.n} ölçüm)`).join('; ')}` : '';
  return l + s;
}
function fmtFunnel(f: any[]) {
  const real = f.filter((x) => !x.is_sample), sample = f.filter((x) => x.is_sample);
  return `Gerçek adaylar: ${real.length ? real.map((x) => `${x.stage} ${x.n}`).join(', ') : 'yok'}${sample.length ? `\nÖRNEK adaylar: ${sample.map((x) => `${x.stage} ${x.n}`).join(', ')}` : ''}`;
}
function fmtRevenue(o: any[]) {
  const won = o.filter((x) => x.status === 'won');
  const confirmed = won.filter((x) => !x.is_simulated && x.v && x.attribution === 'campaign_confirmed');
  const other = won.filter((x) => !confirmed.includes(x));
  const q = o.filter((x) => x.status === 'qualified' || x.status === 'meeting');
  const qReal = q.filter((x) => !x.is_simulated).reduce((a, b) => a + b.n, 0), qSample = q.filter((x) => x.is_simulated).reduce((a, b) => a + b.n, 0);
  return `Nitelikli fırsat/görüşme: ${qReal}${qSample ? ` · ÖRNEK: ${qSample}` : ''}\nKampanyaya bağlı doğrulanmış gelir: ${confirmed.length ? round(confirmed.reduce((a, b) => a + b.val, 0)) + ' TL' : 'yok'}${other.length ? `\nKaynağı belirsiz / doğrulanmamış / örnek gelir (kampanya sonucu sayılmadı): ${round(other.reduce((a, b) => a + b.val, 0))} TL` : ''}`;
}
const round = (n: number) => Math.round(n * 1000) / 1000;

export async function buildReport(kind: 'daily' | 'weekly', opts: { brandId?: string | null; now?: Date } = {}): Promise<Report> {
  const now = opts.now ?? new Date();
  const since = new Date(now.getTime() - (kind === 'daily' ? 1 : 7) * 86400_000);
  return withSystem(async (c) => {
    const s = await section(c, opts.brandId ?? null, since);
    const lim = await getLimits(c);
    const live = await committed(c, 'live', monthKey(now));
    const sim = await committed(c, 'simulation', monthKey(now));
    const simMode = config().RUN_MODE === 'simulation';
    let experiments: any[] = [], knowledge: any[] = [];
    if (kind === 'weekly') {
      experiments = (await c.query(`SELECT id::text id, hypothesis, status, is_simulated, result->'notes' notes FROM experiments WHERE created_at >= $1 OR status='running' ORDER BY created_at DESC LIMIT 10`, [since])).rows;
      knowledge = (await c.query(`SELECT item_key, version, kind, validity, is_sample FROM knowledge_versions WHERE created_at >= $1 AND kind IN ('verified_rule','hypothesis') ORDER BY created_at DESC LIMIT 10`, [since])).rows;
    }
    const lines = [
      `${kind === 'daily' ? 'Günlük kısa rapor' : 'Haftalık değerlendirme'} · ${dayKey(now)}${simMode ? ' · SİMÜLASYON KİPİ: dış işlem yapılmadı' : ''}`,
      `— Yayın —\n${fmtPubs(s.pubs)}`,
      `— Ölçüm —\n${fmtMetrics(s.metrics)}`,
      `— Araştırma —\n${fmtResearch(s.research)}`,
      `— Müşteri hunisi —\n${fmtFunnelV2(s.funnelV2)}\n${fmtRevenue(s.opps)}`,
      s.topBottleneck ? `— Günün darboğazı —\n${s.topBottleneck.title}\nDüzeltme: ${s.topBottleneck.fix}` : '',
      s.manualOpen.length ? `— Açık manuel işler —\n${s.manualOpen.map((m: any) => `${m.kind}: ${m.n}`).join('\n')}` : '',
      `— Bekleyen kararlar —\n${s.decisions.length ? s.decisions.map((d) => `${d.code} ${d.action}`).join('\n') : 'yok'}`,
      `— Maliyet (${monthKey(now)}) —\nCanlı: ${live.total} / ${lim.activeLimitTry} TL (kesin üst sınır ${lim.hardCapTry} TL)\nSimülasyon (gerçek gider değil): ${sim.total} TL${fmtUncertain(s.uncertain)}`,
      fmtOtherMode(s.otherMode, simMode),
      `— Denetim —\n${s.findings.length ? groupFindings(s.findings).join('\n') : 'Açık önemli bulgu yok'}`,
      `— Bağlantılar —\n${s.conns.map((x) => `${x.channel}/${x.adapter}: ${x.status}${x.status === 'mock' ? ' (SİMÜLASYON)' : ''}`).join('\n')}`,
      s.halts.length ? `— AKTİF DURDURMA —\n${s.halts.map((h) => `${h.scope}${h.scope_value ? ':' + h.scope_value : ''} — ${h.reason}`).join('\n')}` : '',
    ];
    if (kind === 'weekly') {
      lines.push(`— Deneyler —\n${experiments.length ? experiments.map((e) => `${e.status}${e.is_simulated ? ' (örnek)' : ''}: ${e.hypothesis}`).join('\n') : 'yok'}`);
      lines.push(`— Uluslararası açılım kapısı —\n${internationalGate(s.funnelV2)}`);
      lines.push(`— Bilgi değişiklikleri —\n${knowledge.length ? knowledge.map((k) => `${k.item_key} v${k.version} (${k.kind}, ${k.validity}${k.is_sample ? ', örnek' : ''})`).join('\n') : 'yok'}`);
    }
    const text = lines.filter(Boolean).join('\n\n').slice(0, 4000);
    return { kind, text, data: { ...s, budget: { live, sim, limits: lim }, experiments, knowledge, simulationMode: simMode, generatedAt: now.toISOString() } };
  });
}

/** Aynı başlıklı bulgular tek satırda, tekrar sayısıyla gösterilir (her gün aynı bulgu rapora yığılmasın). */
function groupFindings(fs: { severity: string; title: string; is_simulated: boolean; mode_unknown?: boolean }[]): string[] {
  const m = new Map<string, { f: (typeof fs)[number]; n: number }>();
  for (const f of fs) { const k = `${f.severity}|${f.title}|${f.is_simulated}|${!!f.mode_unknown}`; const e = m.get(k); if (e) e.n++; else m.set(k, { f, n: 1 }); }
  return [...m.values()].map(({ f, n }) => `[${f.severity}] ${f.title}${f.is_simulated ? ' (örnek veri)' : f.mode_unknown ? ' (kipi bilinmeyen eski kayıt)' : ''}${n > 1 ? ` (×${n})` : ''}`);
}

/** Belirsiz gider: bilinmiyor; sıfır sayılmaz, tahmini tutar bütçede sayılır, kurucu uzlaştırır. */
function fmtUncertain(rows: { mode: string; n: number; s: number }[]): string {
  if (!rows?.length) return '';
  return rows.map((r) => `\nUzlaştırma bekleyen (gideri belirsiz) ${r.mode === 'live' ? 'canlı' : 'simülasyon'} çağrı: ${r.n} · tahmini ${round(r.s)} TL bütçede sayılıyor (gerçek tutar bilinmiyor) → Panel → Manuel işler → "Uzlaştır"`).join('');
}
/** Kip ayrımı: çalışma kipine ait olmayan bekleyen görevler yürütülmez; raporda görünür. */
function fmtOtherMode(rows: { sim: boolean; n: number }[], simMode: boolean): string {
  const other = rows?.find((r) => r.sim === !simMode && config().RUN_MODE !== 'eval');
  if (!other || !other.n) return '';
  return `— Kip ayrımı —\n${other.n} bekleyen ${simMode ? 'canlı' : 'ÖRNEK'} görev bu kipte yürütülmez${simMode ? '' : ' (örnek görevler canlı bağlantıyla çalıştırılmaz)'}`;
}
