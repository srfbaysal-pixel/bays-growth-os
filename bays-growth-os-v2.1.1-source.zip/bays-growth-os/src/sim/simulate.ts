import crypto from 'node:crypto';
import { withBrand, withSystem } from '../db/pool.js';
import { config, reloadConfig } from '../config.js';
import { installGlobalEgressGuard } from '../integrations/egress.js';
import { clock, istanbulTime } from '../core/clock.js';
import { dayKey } from '../core/util.js';
import { simulateDay, ingestMockMetrics, advanceTo, nextDay } from '../orchestrator/cycle.js';
import { ingestReply } from '../crm/outreach.js';
import { handleWhatsAppWebhook } from '../integrations/whatsapp.js';
import { buttonId } from '../core/approvals.js';
import { buildReport } from '../reports/reports.js';
import { SAMPLE_REPLY_POSITIVE } from './sampleData.js';

/**
 * V2 uçtan uca simülasyon (tüm veriler ÖRNEK; dış işlem yok). Sahte saat geçmişten başlar ki
 * veritabanı kayıt zamanları (gerçek saat) ile işletim saati (sahte saat) tutarlı kalsın.
 * Senaryo 1 (16 gün): fixture araştırma → strateji (bağlamla) → içerik → planlanan saatte sahte yayın → ölçüm → denetim
 *   → deney → kural → SONRAKİ yayın saatinin kurala göre değişmesi.
 * Senaryo 2: araştırmadan gelen aday → değerlendirme → (mock) ilk temas → gelen yanıt (imzalı webhook yolu yerine
 *   ingestReply) → nitelikli fırsat → WhatsApp karar düğmesiyle kurucu kararı.
 */
export async function simulate(opts: { days?: number; log?: (s: string) => void; brandSlug?: string } = {}) {
  if (config().RUN_MODE !== 'simulation') throw new Error('Simülasyon yalnız RUN_MODE=simulation iken çalışır');
  if (config().RESEARCH_PROVIDER !== 'fixture') { process.env.RESEARCH_PROVIDER = 'fixture'; reloadConfig(); }
  installGlobalEgressGuard();
  const log = opts.log ?? ((s: string) => console.log(s));
  const brand = await withSystem(async (c) => (await c.query(`SELECT id, slug FROM brands WHERE slug=$1`, [opts.brandSlug ?? 'bayssystems'])).rows[0]);
  const days = opts.days ?? 16;
  let day = dayKey(new Date(Date.now() - (days + 2) * 86400_000));
  const out: any = { scenario1: [], scenario2: null };
  log(`ÖRNEK SİMÜLASYON (V2) · marka: ${brand.slug} · ${days} gün · başlangıç ${day} · dış işlem yok · araştırma: ÖRNEK fixture`);

  for (let d = 0; d < days; d++) {
    const r = await simulateDay(brand.id, day, {
      onPublished: async (p) => {
        // ÖRNEK ölçüm: 09:00 kolu 12:30'dan %25 yüksek (yapay); kural sonrası yayın da ölçülür
        const er = p.arm === '09:00' ? 0.05 : p.arm === '12:30' ? 0.04 : 0.05;
        await ingestMockMetrics({ brandId: brand.id, simulated: true }, p.id, p.experimentId, p.arm, { impressions: 300, engagement_rate: er });
      },
    });
    const pub = await withBrand(brand.id, async (c) => (await c.query(
      `SELECT p.status, to_char(p.scheduled_at AT TIME ZONE 'Europe/Istanbul','HH24:MI') t, a.content->>'publish_time_basis' basis FROM publications p JOIN assets a ON a.id=p.asset_id
       WHERE p.brand_id=$1 AND (p.scheduled_at AT TIME ZONE 'Europe/Istanbul')::date=$2::date ORDER BY p.created_at LIMIT 1`, [brand.id, day])).rows[0]);
    const exp = await withBrand(brand.id, async (c) => (await c.query(`SELECT status FROM experiments WHERE brand_id=$1 ORDER BY created_at LIMIT 1`, [brand.id])).rows[0]?.status ?? '-');
    const row = { day, publication: pub?.status ?? 'yok', time: pub?.t ?? null, basis: pub?.basis ?? null, experiment: exp, tasks: r.tasks.length };
    out.scenario1.push(row);
    log(`Gün ${d + 1} (${day}): yayın=${row.publication} saat=${row.time} dayanak=${row.basis} deney=${row.experiment}`);
    day = nextDay(day);
  }
  out.learning = await withBrand(brand.id, async (c) => (await c.query(`SELECT item_key, version, kind, validity, content->>'value' value, is_sample FROM knowledge_versions WHERE kind='verified_rule' ORDER BY created_at`)).rows);

  // Senaryo 2: araştırmadan gelmiş ve mock ilk temas almış adaylardan birine yanıt
  const contacted = await withBrand(brand.id, async (c) => (await c.query(
    `SELECT i.lead_id, i.external_id, l.business_name FROM interactions i JOIN leads l ON l.id=i.lead_id WHERE i.brand_id=$1 AND i.direction='outbound' AND i.kind='first_contact' ORDER BY i.occurred_at LIMIT 1`, [brand.id])).rows[0]);
  let decision: any = null, reply: any = null;
  if (contacted) {
    clock.set(istanbulTime(day, '10:00'));
    await ingestReply({ brandId: brand.id, messageId: `<sim-reply-${contacted.lead_id}@ornek.invalid>`, inReplyTo: contacted.external_id, text: SAMPLE_REPLY_POSITIVE, receivedAt: clock.now(), via: 'webhook', simulated: true, enqueueClassify: true });
    await advanceTo(clock.now(), brand.id);
    reply = await withBrand(brand.id, async (c) => (await c.query(`SELECT output FROM tasks WHERE brand_id=$1 AND kind='reply_classify' ORDER BY created_at DESC LIMIT 1`, [brand.id])).rows[0]?.output);
    if (reply?.decisionCode && config().WHATSAPP_APP_SECRET && config().FOUNDER_WHATSAPP_NUMBER) {
      const a = await withSystem(async (c) => (await c.query(`SELECT code, nonce FROM approval_requests WHERE code=$1`, [reply.decisionCode])).rows[0]);
      const raw = JSON.stringify({ object: 'whatsapp_business_account', entry: [{ changes: [{ value: { messages: [{ id: `wamid.sim.${a.code}`, from: config().FOUNDER_WHATSAPP_NUMBER, timestamp: String(Math.floor(Date.now() / 1000)), type: 'interactive', interactive: { type: 'button_reply', button_reply: { id: buttonId(a.code, 'approve', a.nonce), title: 'Görüşmeyi kabul' } } }] } }] }] });
      decision = (await handleWhatsAppWebhook(raw, 'sha256=' + crypto.createHmac('sha256', config().WHATSAPP_APP_SECRET).update(raw).digest('hex'))).decisions;
    }
  }
  out.scenario2 = { lead: contacted?.business_name ?? null, reply, decision: decision ?? 'WhatsApp test sırrı yapılandırılmadığı için kurucu kararı simüle edilmedi' };
  out.funnel = await withBrand(brand.id, async (c) => ({
    research_runs: (await c.query(`SELECT status, count(*)::int n FROM research_runs GROUP BY 1`)).rows,
    leads: (await c.query(`SELECT stage, count(*)::int n FROM leads GROUP BY 1`)).rows,
    manual_tasks: (await c.query(`SELECT kind, status, count(*)::int n FROM manual_tasks GROUP BY 1,2`)).rows,
  }));
  clock.reset();
  out.lastReport = (await buildReport('daily', { brandId: brand.id })).text;
  out.weeklyReport = (await buildReport('weekly', { brandId: brand.id })).text;
  log(`Senaryo 2: aday=${out.scenario2.lead} yanıt=${reply?.classification} karar=${JSON.stringify(out.scenario2.decision)}`);
  return out;
}
