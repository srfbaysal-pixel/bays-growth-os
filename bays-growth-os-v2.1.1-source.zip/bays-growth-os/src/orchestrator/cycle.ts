import './chain.js';
import { clock, istanbulTime } from '../core/clock.js';
import { dayKey } from '../core/util.js';
import { withBrand } from '../db/pool.js';
import { drain } from '../worker/worker.js';
import { runScheduled } from './schedule.js';

/**
 * Simülasyon ve testler için yardımcı: sahte saatle bir günü kalıcı kuyruk üzerinden yürütür.
 * Gerçek işletimde aynı iş n8n/worker zamanlayıcısıyla ve sürekli worker ile yapılır; bu dosya iş mantığı içermez.
 */
export interface DayResult { day: string; tasks: { kind: string; status: string; output: any }[]; drained: number }

/** Sahte saati ilerletip zamanı gelen işleri yürütür (yayınlar planlanan saatte çalışır). */
export async function advanceTo(at: Date, brandId?: string): Promise<number> {
  clock.set(at);
  let total = 0;
  for (let i = 0; i < 10; i++) {
    const r = await drain({ now: () => clock.now(), brandId });
    total += r.executed;
    if (r.executed === 0) break;
  }
  return total;
}

/** 08:00 tetik → zamanı gelen işler gün boyunca saat saat → 20:00 tetik (rapor). */
export async function simulateDay(brandId: string, day: string, opts: { onPublished?: (pub: { id: string; arm: string | null; experimentId: string | null }) => Promise<void> } = {}): Promise<DayResult> {
  let drained = 0;
  clock.set(istanbulTime(day, '08:00'));
  await runScheduled('daily-plan', clock.now(), brandId);
  drained += await advanceTo(istanbulTime(day, '08:00'), brandId);
  for (const hh of ['09:00', '10:00', '11:00', '12:00', '12:30', '13:00', '15:00', '18:00']) drained += await advanceTo(istanbulTime(day, hh), brandId);
  if (opts.onPublished) {
    const pubs = await withBrand(brandId, async (c) => (await c.query(
      `SELECT p.id, a.content->>'arm' arm, a.content->>'experiment_id' exp FROM publications p JOIN assets a ON a.id=p.asset_id
       WHERE p.brand_id=$1 AND p.status='published' AND (p.scheduled_at AT TIME ZONE 'Europe/Istanbul')::date = $2::date
       AND NOT EXISTS (SELECT 1 FROM metrics m WHERE m.publication_id=p.id)`, [brandId, day])).rows);
    for (const p of pubs) await opts.onPublished({ id: p.id, arm: p.arm, experimentId: p.exp });
  }
  clock.set(istanbulTime(day, '20:00'));
  await runScheduled('daily-report', clock.now(), brandId);
  drained += await advanceTo(istanbulTime(day, '20:00'), brandId);
  const tasks = await withBrand(brandId, async (c) => (await c.query(`SELECT kind, status, output FROM tasks WHERE brand_id=$1 AND (input->>'day' = $2 OR (created_at > now() - interval '1 minute' AND input->>'day' IS NULL)) ORDER BY created_at`, [brandId, day])).rows);
  return { day, tasks, drained };
}

export const nextDay = (day: string) => dayKey(new Date(new Date(`${day}T12:00:00+03:00`).getTime() + 86400_000));

/** Ölçüm: mock bağlantıda ÖRNEK ölçüm üretir (açıkça simülasyon); canlıda n8n/manuel girişten gelir. */
export async function ingestMockMetrics(ctx: { brandId: string; simulated: boolean }, pubId: string, experimentId: string | null, arm: string | null, values: Record<string, number>) {
  if (!ctx.simulated) throw new Error('Mock ölçüm yalnız simülasyonda üretilebilir');
  const { logEvent } = await import('../core/events.js');
  await withBrand(ctx.brandId, async (c) => {
    const ev = (await c.query(`INSERT INTO evidence (brand_id, kind, title, payload, is_sample) VALUES ($1,'metric','ÖRNEK ölçüm (mock)', $2, true) RETURNING id`, [ctx.brandId, values])).rows[0].id;
    for (const [metric, value] of Object.entries(values)) {
      await c.query(`INSERT INTO metrics (brand_id, publication_id, experiment_id, arm, metric, value, source, is_simulated, evidence_id, measured_at) VALUES ($1,$2,$3,$4,$5,$6,'mock',true,$7,$8)`, [ctx.brandId, pubId, experimentId, arm, metric, value, ev, clock.now()]);
    }
    await logEvent(c, { brandId: ctx.brandId, type: 'metric.ingested', actor: 'distribution', subjectType: 'publication', subjectId: pubId, payload: { values, source: 'mock' }, simulated: true });
  });
}
