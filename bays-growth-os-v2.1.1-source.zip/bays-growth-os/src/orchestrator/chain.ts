import { config } from '../config.js';
import { withBrand, withSystem, type Db } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { enqueueTask, TransientError } from '../core/tasks.js';
import { createDecisionRequest } from '../core/approvals.js';
import { dayKey } from '../core/util.js';
import { istanbulTime } from '../core/clock.js';
import { runAgent } from '../agents/runner.js';
import { buildStrategyContext } from '../agents/strategyContext.js';
import { queuePublication, executePublication, reconcilePublication } from '../integrations/publisher.js';
import { advanceStage, addSuppression, createQualifiedOpportunity } from '../crm/crm.js';
import { contactLead } from '../crm/outreach.js';
import { createManualTask } from '../crm/manual.js';
import { applyExplicitOptOut, detectExplicitOptOut } from '../crm/optout.js';
import { createExperiment, evaluateExperiment, promoteSupportedMethod } from '../learning/experiments.js';
import { resolveRule } from '../learning/rules.js';
import { runAudit } from '../auditor/auditor.js';
import { buildReport } from '../reports/reports.js';
import { notifyFounder } from '../notify/notifier.js';
import { runResearch } from '../research/research.js';
import { registerHandler, RescheduleError } from '../worker/worker.js';

/**
 * V2 kalıcı görev zinciri. Her adım bir görevdir; bir sonraki adımı idempotent anahtarla kuyruğa ekler.
 * Zincir: daily_plan → research_discover → (lead_assess → contact_send → follow_up_check …) + strategy_plan → campaign_plan
 *         → content_create → distribution_schedule → publish_due(planlanan saatte) → [reconcile_publication]
 *         evening (20:00) · weekly (Pazar 20:00) · reply_classify (yanıt gelince)
 * Tüm dış çağrılar (araştırma, model, yayın, e-posta, bildirim) kendi içinde bütçe + durdurma + egress kontrolünden geçer.
 */
const DEFAULT_PUBLISH_TIME = '10:00';

async function brandOf(c: Db, brandId: string) { return (await c.query(`SELECT id, slug, name, status FROM brands WHERE id=$1`, [brandId])).rows[0]; }

export async function campaignFor(c: Db, brandId: string, objective: 'awareness' | 'acquisition', simulated: boolean): Promise<string> {
  // Kip ayrımı: canlı iş örnek kampanyaya (ve tersi) bağlanmaz; kipi bilinmeyen eski kampanya kullanılmaz
  const ex = (await c.query(`SELECT id FROM campaigns WHERE brand_id=$1 AND objective=$2 AND status='active' AND is_sample=$3 AND NOT mode_unknown ORDER BY created_at LIMIT 1`, [brandId, objective, simulated])).rows[0];
  if (ex) return ex.id;
  const name = objective === 'awareness' ? 'Pilot — marka bilinirliği (LinkedIn)' : 'Pilot — müşteri kazanımı';
  return (await c.query(`INSERT INTO campaigns (brand_id, name, objective, status, is_sample) VALUES ($1,$2,$3,'active',$4) RETURNING id`, [brandId, name, objective, simulated])).rows[0].id;
}

const enq = (c: Db, t: Parameters<typeof enqueueTask>[1]) => enqueueTask(c, t);

// ---------------------------------------------------------------- günlük kök
registerHandler('daily_plan', async (task) => {
  const day = task.input.day as string;
  return withBrand(task.brand_id, async (c) => {
    const r = await enq(c, { brandId: task.brand_id, role: 'strategy', kind: 'research_discover', idempotencyKey: `${day}:research_discover`, parentTaskId: task.id, input: { day }, simulated: task.is_simulated });
    return { next: [r.id] };
  });
});

// ---------------------------------------------------------------- araştırma ve keşif
registerHandler('research_discover', async (task, { now }) => {
  const day = task.input.day as string;
  const focus = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT plan->'research_focus' f FROM campaigns WHERE brand_id=$1 AND objective='awareness' AND status='active' AND is_sample=$2 AND NOT mode_unknown LIMIT 1`, [task.brand_id, task.is_simulated])).rows[0]?.f ?? null);
  const res = await runResearch({ brandId: task.brand_id, day, now, simulated: task.is_simulated, focus });
  return withBrand(task.brand_id, async (c) => {
    const next: string[] = [];
    for (const leadId of res.newLeadIds) next.push((await enq(c, { brandId: task.brand_id, role: 'customer_dev', kind: 'lead_assess', idempotencyKey: `lead_assess:${leadId}`, parentTaskId: task.id, input: { leadId }, simulated: task.is_simulated })).id);
    next.push((await enq(c, { brandId: task.brand_id, role: 'strategy', kind: 'strategy_plan', idempotencyKey: `${day}:strategy_plan`, parentTaskId: task.id, input: { day }, simulated: task.is_simulated })).id);
    return { research: { status: res.status, runId: res.runId, queries: res.queries, documents: res.documents, findings: res.findings, newLeads: res.newLeadIds.length, rediscovered: res.existingLeadIds.length, notes: res.notes }, next };
  });
});

// ---------------------------------------------------------------- strateji (veriyle beslenir)
registerHandler('strategy_plan', async (task, { now }) => {
  const day = task.input.day as string;
  const context = await withBrand(task.brand_id, (c) => buildStrategyContext(c, task.brand_id, now, 14, task.is_simulated));
  const r = await runAgent({ task, role: 'strategy', taskInput: { objective: 'awareness', context } });
  return withBrand(task.brand_id, async (c) => {
    const campaignId = await campaignFor(c, task.brand_id, 'awareness', task.is_simulated);
    let experimentId: string | null = null;
    if (r.output.experiment) {
      const ex = (await c.query(`SELECT id FROM experiments WHERE brand_id=$1 AND primary_variable=$2 AND is_simulated=$3 AND (status IN ('running','insufficient_data') OR created_at > now() - interval '30 days') ORDER BY created_at DESC LIMIT 1`, [task.brand_id, r.output.experiment.primary_variable, task.is_simulated])).rows[0];
      experimentId = ex?.id ?? await createExperiment(c, { brandId: task.brand_id, campaignId, ...r.output.experiment, simulated: task.is_simulated });
    }
    const guardBlocked = r.guard.violations.some((v) => v.severity === 'high' || v.severity === 'critical');
    await c.query(`UPDATE campaigns SET plan=$2, hypothesis=$3 WHERE id=$1`, [campaignId, { ...r.output, guardBlocked, guardViolations: r.guard.violations, context_period: context.period, context_missing: context.missing }, r.output.experiment?.hypothesis ?? null]);
    const next = (await enq(c, { brandId: task.brand_id, role: 'distribution', kind: 'campaign_plan', idempotencyKey: `${day}:campaign_plan`, parentTaskId: task.id, campaignId, input: { day, experimentId }, simulated: task.is_simulated })).id;
    return { guardOk: r.guard.ok, violations: r.guard.violations.map((v) => v.code), objectives: r.output.objectives.map((o: any) => o.goal), decisionChanges: r.output.decision_changes, dataGaps: r.output.data_gaps, contentType: r.output.campaign_brief.content_type, cta: r.output.campaign_brief.cta, experimentId, next: [next] };
  });
});

// ---------------------------------------------------------------- kampanya: planı içerik ve müşteri geliştirme işlerine bağlar
registerHandler('campaign_plan', async (task) => {
  const day = task.input.day as string;
  return withBrand(task.brand_id, async (c) => {
    const plan = (await c.query(`SELECT plan FROM campaigns WHERE id=$1`, [task.campaign_id])).rows[0].plan;
    const next: string[] = [];
    const tasks = (plan.objectives ?? []).flatMap((o: any) => o.tasks ?? []);
    for (const t of tasks) {
      if (t.role === 'founder') {
        const mk = t.kind === 'record_demo' ? 'record_demo' : 'fix_bottleneck';
        const existing = (await c.query(`SELECT id FROM manual_tasks WHERE brand_id=$1 AND kind=$2 AND status='open' AND is_simulated=$3 ORDER BY created_at LIMIT 1`, [task.brand_id, mk, task.is_simulated])).rows[0]?.id;
        next.push(existing ?? await createManualTask(c, { brandId: task.brand_id, kind: mk, payload: { brief: t.brief, from: 'strategy' }, dedupeKey: `founder:${t.kind}:${task.input.day ?? ''}`, simulated: task.is_simulated }));
      }
    }
    if (plan.guardBlocked) return { skipped: 'strateji kontrolden geçmedi' };
    // İçerik: günde bir LinkedIn gönderisi (strateji içerik görevi verdiyse)
    if (tasks.some((t: any) => t.role === 'content') || (plan.daily_tasks ?? []).some((t: any) => t.role === 'content')) {
      next.push((await enq(c, { brandId: task.brand_id, role: 'content', kind: 'content_create', channel: 'linkedin', idempotencyKey: `${day}:content_create:linkedin`, parentTaskId: task.id, campaignId: task.campaign_id, input: { day, experimentId: task.input.experimentId ?? null }, simulated: task.is_simulated })).id);
    }
    // Müşteri geliştirme: değerlendirilmemiş kaynaklı adaylar
    if (tasks.some((t: any) => t.role === 'customer_dev') || (plan.daily_tasks ?? []).some((t: any) => t.role === 'customer_dev')) {
      const leads = (await c.query(`SELECT id FROM leads WHERE brand_id=$1 AND stage='found' AND is_sample=$2 AND NOT mode_unknown ORDER BY created_at LIMIT 20`, [task.brand_id, task.is_simulated])).rows;
      for (const l of leads) next.push((await enq(c, { brandId: task.brand_id, role: 'customer_dev', kind: 'lead_assess', idempotencyKey: `lead_assess:${l.id}`, parentTaskId: task.id, input: { leadId: l.id }, simulated: task.is_simulated })).id);
    }
    return { linked: next.length, next };
  });
});

// ---------------------------------------------------------------- içerik
registerHandler('content_create', async (task) => {
  const plan = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT plan FROM campaigns WHERE id=$1`, [task.campaign_id])).rows[0].plan);
  let r = await runAgent({ task, role: 'content', taskInput: { channel: 'linkedin', brief: plan.campaign_brief } });
  if (!r.guard.ok) r = await runAgent({ task, role: 'content', taskInput: { channel: 'linkedin', brief: plan.campaign_brief, fix: r.guard.violations } });
  return withBrand(task.brand_id, async (c) => {
    const assetId = (await c.query(`INSERT INTO assets (brand_id, campaign_id, task_id, kind, content, guard_result, status, is_sample) VALUES ($1,$2,$3,'post_text',$4,$5,$6,$7) RETURNING id`,
      [task.brand_id, task.campaign_id, task.id, r.output, r.guard, r.guard.ok ? 'passed_checks' : 'blocked', task.is_simulated])).rows[0].id;
    const next = r.guard.ok ? [(await enq(c, { brandId: task.brand_id, role: 'distribution', kind: 'distribution_schedule', channel: 'linkedin', idempotencyKey: `distribution_schedule:${assetId}`, parentTaskId: task.id, campaignId: task.campaign_id, input: { day: task.input.day, assetId, experimentId: task.input.experimentId ?? null }, simulated: task.is_simulated })).id] : [];
    return { assetId, guardOk: r.guard.ok, violations: r.guard.violations.map((v) => v.code), contentType: r.output.content_type, next };
  });
});

/**
 * Yayın saati seçimi (uygulanan öğrenme):
 * 1) Deney sürüyorsa: dengeli atama (daha az yayın almış kola) — keşif.
 * 2) Deney yoksa: geçerli kural (resolveRule) — sömürü. Geri alınırsa kural düşer, varsayılana dönülür.
 * 3) Hiçbiri yoksa: varsayılan saat.
 */
export async function choosePublishTime(c: Db, brandId: string, experimentId: string | null, simulated: boolean, now: Date): Promise<{ time: string; arm: string | null; basis: string }> {
  if (experimentId) {
    const e = (await c.query(`SELECT comparison, status FROM experiments WHERE id=$1 AND is_simulated=$2`, [experimentId, simulated])).rows[0];
    if (e && ['running', 'insufficient_data'].includes(e.status)) {
      const arms = [e.comparison.control, e.comparison.variant];
      const pend = (await c.query(`SELECT a.content->>'arm' arm, count(*)::int n FROM publications p JOIN assets a ON a.id=p.asset_id WHERE p.brand_id=$1 AND p.status IN ('queued','sending','published','outcome_unknown') AND a.content->>'experiment_id'=$2 GROUP BY 1`, [brandId, experimentId])).rows;
      const n = (arm: string) => pend.find((x) => x.arm === arm)?.n ?? 0;
      const arm = n(arms[0]) <= n(arms[1]) ? arms[0] : arms[1];
      return { time: arm, arm, basis: `deney kolu (dengeli atama: ${arms[0]}=${n(arms[0])}, ${arms[1]}=${n(arms[1])})` };
    }
  }
  const rule = await resolveRule<string>(c, brandId, 'publish_time', { channel: 'linkedin' }, DEFAULT_PUBLISH_TIME, now, { simulated });
  return { time: rule.value ?? DEFAULT_PUBLISH_TIME, arm: null, basis: rule.reason };
}

registerHandler('distribution_schedule', async (task, { now }) => {
  const { assetId, experimentId, replanOf } = task.input;
  const choice = await withBrand(task.brand_id, (c) => choosePublishTime(c, task.brand_id, experimentId ?? null, task.is_simulated, now));
  // Yayın günü: içerik günü; saati geçmişse ertesi gün (kaçırılmış yeniden planlamada da ertesi gün)
  let day = task.input.day as string;
  let at = istanbulTime(day, choice.time);
  if (at <= now) { day = dayKey(new Date(now.getTime() + 86400_000)); at = istanbulTime(day, choice.time); }
  const r = await runAgent({ task, role: 'distribution', taskInput: { assets: [{ ref: assetId, channel: 'linkedin', slot: at.toISOString() }], arm: choice.arm, requestedOps: [] } });
  return withBrand(task.brand_id, async (c) => {
    await c.query(`UPDATE assets SET content = content || $2::jsonb WHERE id=$1`, [assetId, JSON.stringify({ arm: choice.arm, experiment_id: choice.arm ? experimentId : null, publish_time_basis: choice.basis })]);
    const key = replanOf ? `replan:${replanOf}` : `${task.input.day}:linkedin:${assetId}`;
    const q = await queuePublication(c, { brandId: task.brand_id, campaignId: task.campaign_id, taskId: task.id, assetId, channel: 'linkedin', idempotencyKey: key, scheduledAt: at });
    if (replanOf) await c.query(`UPDATE publications SET replan_of=$2 WHERE id=$1`, [q.id, replanOf]);
    for (const m of r.output.manual_tasks) await createManualTask(c, { brandId: task.brand_id, kind: m.action === 'linkedin_connection' ? 'linkedin_connection' : 'linkedin_message', channel: m.channel, payload: m, dedupeKey: `dist:${assetId}:${m.action}`, simulated: task.is_simulated });
    const due = await enq(c, { brandId: task.brand_id, role: 'distribution', kind: 'publish_due', channel: 'linkedin', idempotencyKey: `publish_due:${q.id}`, parentTaskId: task.id, campaignId: task.campaign_id, input: { publicationId: q.id }, runAt: at, simulated: task.is_simulated });
    return { publicationId: q.id, scheduledAt: at.toISOString(), time: choice.time, arm: choice.arm, basis: choice.basis, next: [due.id] };
  });
});

registerHandler('publish_due', async (task, { now }) => {
  const b = await withBrand(task.brand_id, (c) => brandOf(c, task.brand_id));
  const pub = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT status, scheduled_at FROM publications WHERE id=$1`, [task.input.publicationId])).rows[0]);
  // Süreç çökmesinden sonra yeniden çalışma: "gönderiliyor/belirsiz" yayın tekrar gönderilmez, uzlaştırılır
  if (pub.status === 'sending' || pub.status === 'outcome_unknown') {
    const rr = await reconcilePublication(task.brand_id, task.input.publicationId, b.slug);
    return { reconciled: rr.status };
  }
  const r = await executePublication(task.brand_id, task.input.publicationId, b.slug, now);
  if (r.reason === 'not_due') throw new RescheduleError(new Date(r.dueAt!), 'planlanan saat gelmedi');
  return withBrand(task.brand_id, async (c) => {
    const next: string[] = [];
    if (r.status === 'outcome_unknown') next.push((await enq(c, { brandId: task.brand_id, role: 'distribution', kind: 'reconcile_publication', idempotencyKey: `reconcile:${task.input.publicationId}`, input: { publicationId: task.input.publicationId }, runAt: new Date(now.getTime() + 15 * 60_000), simulated: task.is_simulated })).id);
    if (r.status === 'missed') {
      const p = (await c.query(`SELECT asset_id, replan_of, campaign_id FROM publications WHERE id=$1`, [task.input.publicationId])).rows[0];
      if (!p.replan_of) next.push((await enq(c, { brandId: task.brand_id, role: 'distribution', kind: 'distribution_schedule', channel: 'linkedin', idempotencyKey: `distribution_schedule:replan:${task.input.publicationId}`, campaignId: p.campaign_id, input: { day: dayKey(now), assetId: p.asset_id, replanOf: task.input.publicationId }, simulated: task.is_simulated })).id);
      else await logEvent(c, { brandId: task.brand_id, type: 'alert.raised', actor: 'distribution', subjectType: 'publication', subjectId: task.input.publicationId, payload: { reason: 'Yeniden planlanan yayın da kaçırıldı; tekrar planlanmadı' }, simulated: task.is_simulated });
    }
    if (r.status === 'queued' && r.reason) throw new TransientError(`yayın yeniden denenecek: ${r.reason}`);
    return { status: r.status, externalId: r.externalId ?? null, reason: r.reason ?? null, next };
  });
});

registerHandler('reconcile_publication', async (task) => {
  const b = await withBrand(task.brand_id, (c) => brandOf(c, task.brand_id));
  const r = await reconcilePublication(task.brand_id, task.input.publicationId, b.slug);
  if (r.status === 'manual_required') {
    await withBrand(task.brand_id, (c) => createManualTask(c, { brandId: task.brand_id, kind: 'verify_publication', publicationId: task.input.publicationId, channel: 'linkedin', payload: { note: 'Yayının gerçekleşip gerçekleşmediğini profilden kontrol edin; tekrar göndermeyin.', reason: r.reason }, dedupeKey: `verify:${task.input.publicationId}`, simulated: task.is_simulated }));
  }
  return { status: r.status };
});

// ---------------------------------------------------------------- müşteri geliştirme
registerHandler('lead_assess', async (task, { now }) => {
  const lead = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT * FROM leads WHERE id=$1`, [task.input.leadId])).rows[0]);
  if (!lead || lead.stage !== 'found') return { skipped: `aşama ${lead?.stage}` };
  const r = await runAgent({ task, role: 'customer_dev', taskInput: { lead: { business_name: lead.business_name, need_signals: lead.need_signals, source_note: lead.source_note, source_uri: lead.source_uri }, channel: 'email' }, external: [{ ref: lead.source_uri ?? 'kaynak', text: lead.source_note }] });
  return withBrand(task.brand_id, async (c) => {
    const campaignId = await campaignFor(c, task.brand_id, 'acquisition', task.is_simulated);
    // Model ihtiyaç uyduramaz: yalnız kaynakta kayıtlı sinyaller tutulur
    const sourced: string[] = lead.need_signals ?? [];
    const signals = (r.output.lead_assessment.need_signals as string[]).filter((s) => sourced.includes(s));
    await c.query(`UPDATE leads SET fit_score=$2, fit_reasons=$3, campaign_id=COALESCE(campaign_id,$4), updated_at=now() WHERE id=$1`, [lead.id, r.output.lead_assessment.fit_score, JSON.stringify(r.output.lead_assessment.reasons), campaignId]);
    await advanceStage(c, lead.id, 'fit_verified', 'kaynak ve sinyal kaydı var');
    await advanceStage(c, lead.id, 'evaluated', `uygunluk puanı ${r.output.lead_assessment.fit_score}`);
    if (!r.output.outreach || !signals.length || Number(r.output.lead_assessment.fit_score) < 60) return { fit: r.output.lead_assessment.fit_score, contact: false, reason: 'uygunluk/ihtiyaç kanıtı yetersiz' };
    const assetId = (await c.query(`INSERT INTO assets (brand_id, campaign_id, task_id, kind, content, guard_result, status, is_sample) VALUES ($1,$2,$3,'outreach_draft',$4,$5,$6,$7) RETURNING id`,
      [task.brand_id, campaignId, task.id, r.output.outreach, r.guard, r.guard.ok ? 'passed_checks' : 'blocked', task.is_simulated])).rows[0].id;
    if (!r.guard.ok) return { fit: r.output.lead_assessment.fit_score, contact: false, reason: 'taslak kontrolden geçmedi', violations: r.guard.violations.map((v) => v.code) };
    const next = (await enq(c, { brandId: task.brand_id, role: 'customer_dev', kind: 'contact_send', channel: 'email', idempotencyKey: `contact_send:${lead.id}:first`, parentTaskId: task.id, campaignId, input: { leadId: lead.id, kind: 'first_contact', draftAssetId: assetId }, runAt: now, simulated: task.is_simulated })).id;
    return { fit: r.output.lead_assessment.fit_score, contact: true, draftAssetId: assetId, next: [next] };
  });
});

registerHandler('contact_send', async (task, ctx) => {
  const { now } = ctx;
  let draftAssetId = task.input.draftAssetId;
  if (!draftAssetId) draftAssetId = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT id FROM assets WHERE brand_id=$1 AND kind='outreach_draft' AND task_id IN (SELECT id FROM tasks WHERE kind='lead_assess' AND input->>'leadId'=$2) ORDER BY created_at DESC LIMIT 1`, [task.brand_id, task.input.leadId])).rows[0]?.id);
  if (!draftAssetId) return { skipped: 'taslak yok' };
  const o = await contactLead({ brandId: task.brand_id, leadId: task.input.leadId, kind: task.input.kind, followUpNo: task.input.followUpNo, draftAssetId, now, simulated: task.is_simulated, taskId: task.id, signal: ctx.signal });
  if (o.result === 'deferred') throw new RescheduleError(o.until, o.reason);
  return withBrand(task.brand_id, async (c) => {
    const next: string[] = [];
    if (o.result === 'sent') {
      const gap = (await c.query(`SELECT profile FROM brand_profiles WHERE brand_id=$1 AND validity='current' ORDER BY version DESC LIMIT 1`, [task.brand_id])).rows[0]?.profile?.contact_rules?.follow_up_gap_days ?? 5;
      const n = task.input.kind === 'first_contact' ? 1 : (task.input.followUpNo ?? 1) + 1;
      next.push((await enq(c, { brandId: task.brand_id, role: 'customer_dev', kind: 'follow_up_check', idempotencyKey: `follow_up_check:${task.input.leadId}:${n}`, input: { leadId: task.input.leadId, followUpNo: n }, runAt: new Date(now.getTime() + gap * 86400_000), simulated: task.is_simulated })).id);
    }
    return { ...o, until: undefined, next };
  });
});

registerHandler('follow_up_check', async (task) => {
  const lead = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT * FROM leads WHERE id=$1`, [task.input.leadId])).rows[0]);
  const replied = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT 1 FROM interactions WHERE lead_id=$1 AND direction='inbound' LIMIT 1`, [lead.id])).rowCount);
  if (replied || ['lost', 'on_hold', 'replied', 'meeting', 'proposal', 'won'].includes(lead.stage)) return { skipped: 'yanıt var veya aşama uygun değil' };
  const max = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT profile FROM brand_profiles WHERE brand_id=$1 AND validity='current' ORDER BY version DESC LIMIT 1`, [task.brand_id])).rows[0]?.profile?.contact_rules?.follow_up_max ?? 0);
  if (task.input.followUpNo > max) {
    await withBrand(task.brand_id, (c) => advanceStage(c, lead.id, 'on_hold', 'takip sınırı doldu, yanıt yok'));
    return { onHold: true };
  }
  const r = await runAgent({ task, role: 'customer_dev', taskInput: { mode: 'follow_up', followUpNo: task.input.followUpNo, lead: { business_name: lead.business_name, need_signals: lead.need_signals, fit_score: Number(lead.fit_score) } } });
  return withBrand(task.brand_id, async (c) => {
    const assetId = (await c.query(`INSERT INTO assets (brand_id, campaign_id, task_id, kind, content, guard_result, status, is_sample) VALUES ($1,$2,$3,'outreach_draft',$4,$5,$6,$7) RETURNING id`,
      [task.brand_id, lead.campaign_id, task.id, r.output.outreach, r.guard, r.guard.ok ? 'passed_checks' : 'blocked', task.is_simulated])).rows[0].id;
    if (!r.guard.ok) return { blocked: r.guard.violations.map((v) => v.code) };
    const next = (await enq(c, { brandId: task.brand_id, role: 'customer_dev', kind: 'contact_send', channel: 'email', idempotencyKey: `contact_send:${lead.id}:follow_up:${task.input.followUpNo}`, input: { leadId: lead.id, kind: 'follow_up', followUpNo: task.input.followUpNo, draftAssetId: assetId }, simulated: task.is_simulated })).id;
    return { draftAssetId: assetId, next: [next] };
  });
});

registerHandler('reply_classify', async (task) => {
  const { leadId, interactionId } = task.input;
  // İdempotency: bu yanıt için fırsat/sınıflandırma zaten yapıldıysa ajan yeniden çağrılmaz, ikinci fırsat açılmaz
  const already = await withBrand(task.brand_id, async (c) => (await c.query(`SELECT id FROM opportunities WHERE brand_id=$1 AND evidence ? $2 LIMIT 1`, [task.brand_id, `interaction:${interactionId}`])).rows[0]);
  if (already) return { classification: 'already_processed', opportunityId: already.id, next: [] };
  const { lead, text, flagged } = await withBrand(task.brand_id, async (c) => {
    const i = (await c.query(`SELECT content FROM interactions WHERE id=$1`, [interactionId])).rows[0];
    return { lead: (await c.query(`SELECT * FROM leads WHERE id=$1`, [leadId])).rows[0], text: (i?.content?.text as string) ?? '', flagged: i?.content?.opt_out === true };
  });
  // Açık ret MODELDEN ÖNCE: yanıt kaydında işlendiyse ya da (eski kayıt) burada tespit edilirse model çağrılmaz;
  // model anahtarı, fiyat veya bütçe olmadan da iletişim yasağı geçerli olur.
  if (flagged || detectExplicitOptOut(text)) {
    const res = await withBrand(task.brand_id, (c) => applyExplicitOptOut(c, { brandId: task.brand_id, leadId, interactionId, simulated: task.is_simulated }));
    return { classification: 'do_not_contact', explicit: true, modelCalled: false, applied: res.applied };
  }
  const r = await runAgent({ task, role: 'customer_dev', taskInput: { mode: 'classify_reply', replyText: text, interactionRef: interactionId, lead: { business_name: lead.business_name, need_signals: lead.need_signals, fit_score: Number(lead.fit_score), source_uri: lead.source_uri } }, external: [{ ref: `interaction:${interactionId}`, text }] });
  const cls = r.output.reply_classification;
  const out = await withBrand(task.brand_id, async (c) => {
    for (const st of ['contact_planned', 'contacted', 'replied'] as const) {
      const cur = (await c.query(`SELECT stage FROM leads WHERE id=$1`, [leadId])).rows[0].stage;
      if (cur === st) continue;
      if ((st === 'contact_planned' && cur === 'evaluated') || (st === 'contacted' && cur === 'contact_planned') || (st === 'replied' && cur === 'contacted')) await advanceStage(c, leadId, st, `yanıt: ${cls}`);
    }
    if (cls === 'do_not_contact') {
      const ct = (await c.query(`SELECT email FROM contacts WHERE lead_id=$1`, [leadId])).rows;
      await addSuppression(c, task.brand_id, [{ type: 'business_key', value: lead.business_key }, ...ct.filter((x) => x.email).map((x) => ({ type: 'email' as const, value: x.email }))], 'yanıtta iletişim istemedi');
      await advanceStage(c, leadId, 'lost', 'iletişim istemiyor');
      return { classification: cls };
    }
    if (cls !== 'positive_meeting' || !r.output.handoff) return { classification: cls };
    const opp = await createQualifiedOpportunity(c, { brandId: task.brand_id, leadId, campaignId: lead.campaign_id, offerCode: 'musteri-iletisim-takip', need: r.output.handoff.need, openToMeeting: true, evidence: [`interaction:${interactionId}`, ...(lead.source_uri ? [lead.source_uri] : [])], unknowns: r.output.handoff.unknowns, nextStep: r.output.handoff.suggested_next, simulated: task.is_simulated });
    await advanceStage(c, leadId, 'meeting', 'görüşmeye açık');
    const mtg = (await c.query(`INSERT INTO meetings (brand_id, lead_id, opportunity_id, status, notes, is_simulated) VALUES ($1,$2,$3,'awaiting_founder',$4,$5) RETURNING id`, [task.brand_id, leadId, opp, 'Kurucu görüşme kapasitesi bilinmiyor; saat önerilmedi', task.is_simulated])).rows[0].id;
    const dec = await createDecisionRequest(c, { brandId: task.brand_id, action: 'meeting.schedule', params: { meetingId: mtg, opportunityId: opp }, rationale: `${lead.business_name}: ${r.output.handoff.need}. Bilinmeyenler: ${r.output.handoff.unknowns.join(', ')}`, options: [{ id: 'approve', label: 'Görüşmeyi kabul' }, { id: 'reject', label: 'Şimdilik hayır' }], simulated: task.is_simulated });
    return { classification: cls, opportunityId: opp, meetingId: mtg, decisionCode: dec.code, handoff: r.output.handoff };
  });
  if ((out as any).decisionCode) {
    const n = await notifyFounder({ kind: 'decision', brandId: task.brand_id, dedupeKey: `decision:${(out as any).decisionCode}`, text: `Görüşme fırsatı: ${(out as any).handoff.need}`, approvalCode: (out as any).decisionCode });
    return { ...out, notified: n };
  }
  return out;
});

// ---------------------------------------------------------------- akşam ve hafta
registerHandler('evening', async (task, { now }) => {
  const day = task.input.day as string;
  const b = await withBrand(task.brand_id, (c) => brandOf(c, task.brand_id));
  await withBrand(task.brand_id, async (c) => {
    for (const p of (await c.query(`SELECT id FROM publications WHERE brand_id=$1 AND status='outcome_unknown' AND is_simulated=$2`, [task.brand_id, task.is_simulated])).rows) await reconcilePublication(task.brand_id, p.id, b.slug);
  });
  const audit = await runAudit({ brandId: task.brand_id, now });
  const important = audit.findings.filter((f) => f.severity === 'high' || f.severity === 'critical');
  let secondOpinion: number | null = null;
  if (important.length) {
    const r = await runAgent({ task, role: 'auditor', taskInput: { deterministicFindings: important.map((f) => ({ check_id: f.check_id, severity: f.severity, title: f.title, evidence_refs: f.evidence_refs, bottleneck_area: f.bottleneck_area })) } });
    secondOpinion = r.output.findings.length;
  }
  const evaluations = await withBrand(task.brand_id, async (c) => {
    const out: any[] = [];
    for (const e of (await c.query(`SELECT id, primary_variable FROM experiments WHERE brand_id=$1 AND is_simulated=$2 AND status IN ('running','insufficient_data')`, [task.brand_id, task.is_simulated])).rows) {
      const ev = await evaluateExperiment(c, e.id, now);
      let rule: any = null;
      if (ev.status === 'supported' && /saat/i.test(e.primary_variable)) rule = await promoteSupportedMethod(c, e.id, 'rule:linkedin:publish_time', { rule_type: 'publish_time', scope: { channel: 'linkedin' } });
      out.push({ id: e.id, status: ev.status, rule });
    }
    return out;
  });
  // En önemli darboğaz: somut düzeltme işi kurucuya
  const top = audit.findings.filter((f) => f.check_id === 'top_bottleneck')[0];
  // Aynı darboğaz için açık bir manuel iş varsa yenisi açılmaz (her gün tekrar eden görev yığılmasın)
  if (top) await withBrand(task.brand_id, async (c) => {
    const kind = top.bottleneck_area === 'trust_proof' ? 'record_demo' : 'fix_bottleneck';
    const open = (await c.query(`SELECT 1 FROM manual_tasks WHERE brand_id=$1 AND kind=$2 AND status='open' AND is_simulated=$4 AND (kind='record_demo' OR payload->>'title'=$3) LIMIT 1`, [task.brand_id, kind, top.title, task.is_simulated])).rowCount;
    if (!open) await createManualTask(c, { brandId: task.brand_id, kind, payload: { title: top.title, fix: top.detail.fix }, dedupeKey: `bottleneck:${day}`, simulated: task.is_simulated });
  });
  const report = await buildReport('daily', { brandId: task.brand_id, now });
  const sent = await notifyFounder({ kind: 'daily_report', brandId: task.brand_id, dedupeKey: `daily:${task.brand_id}:${day}`, text: report.text });
  return { findingsWritten: audit.written, halts: audit.halts.length, secondOpinion, evaluations, notify: sent };
});

registerHandler('weekly', async (task, { now }) => {
  const report = await buildReport('weekly', { brandId: task.brand_id, now });
  const sent = await notifyFounder({ kind: 'weekly_report', brandId: task.brand_id, dedupeKey: `weekly:${task.brand_id}:${task.input.day}`, text: report.text });
  return { notify: sent };
});

/** Zamanlanmış kök görevleri oluşturur (n8n veya worker içi zamanlayıcı çağırır). Aynı gün ikinci tetik yeni iş başlatmaz. */
export async function enqueueScheduled(name: 'daily-plan' | 'daily-report' | 'weekly-review', now: Date, onlyBrandId?: string): Promise<{ brand: string; taskId: string; created: boolean }[]> {
  const brands = await withSystem(async (c) => (await c.query(`SELECT id, slug FROM brands WHERE status='active' ${onlyBrandId ? 'AND id = $1' : ''}`, onlyBrandId ? [onlyBrandId] : [])).rows);
  const day = dayKey(now);
  const kind = name === 'daily-plan' ? 'daily_plan' : name === 'daily-report' ? 'evening' : 'weekly';
  const simulated = config().RUN_MODE !== 'live';
  const out: { brand: string; taskId: string; created: boolean }[] = [];
  for (const b of brands) {
    const r = await withBrand(b.id, (c) => enqueueTask(c, { brandId: b.id, role: 'system', kind, idempotencyKey: `${day}:${kind}`, input: { day }, simulated }));
    out.push({ brand: b.slug, taskId: r.id, created: r.created });
  }
  return out;
}
