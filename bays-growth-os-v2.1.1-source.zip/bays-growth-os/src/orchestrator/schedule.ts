import { config } from '../config.js';
import { expireDecisions } from '../core/approvals.js';
import { markExpiredReservations } from '../core/budget.js';
import { clock, istanbulHour } from '../core/clock.js';
import { enqueueScheduled } from './chain.js';

/**
 * Zamanlanmış işler artık yalnız KÖK GÖREV oluşturur; yürütmeyi worker yapar (kalıcı kuyruk).
 * Tetik kaynağı n8n (imzalı /internal/cycle) veya worker içi zamanlayıcı olabilir; ikisi birlikte çalışsa da
 * gün anahtarlı idempotency nedeniyle aynı iş ikinci kez başlamaz.
 * İşletim saatleri Europe/Istanbul; saklama UTC.
 */
export async function runScheduled(name: string, now: Date = clock.now(), onlyBrandId?: string) {
  if (!['daily-plan', 'daily-report', 'weekly-review'].includes(name)) throw Object.assign(new Error(`Bilinmeyen iş: ${name}`), { statusCode: 404 });
  await expireDecisions(now);
  await markExpiredReservations(now);
  const enqueued = await enqueueScheduled(name as any, now, onlyBrandId);
  return { ok: true, name, mode: config().RUN_MODE, enqueued };
}

/** Worker içi zamanlayıcı adımı: varsayılan takvim 08:00 plan, 20:00 rapor, Pazar 20:00 haftalık. */
export async function scheduleTick(now: Date = clock.now()): Promise<string[]> {
  const h = istanbulHour(now);
  const dow = new Intl.DateTimeFormat('en-US', { timeZone: 'Europe/Istanbul', weekday: 'short' }).format(now);
  const fired: string[] = [];
  if (h >= 8) { await runScheduled('daily-plan', now); fired.push('daily-plan'); }
  if (h >= 20) { await runScheduled('daily-report', now); fired.push('daily-report'); }
  if (h >= 20 && dow === 'Sun') { await runScheduled('weekly-review', now); fired.push('weekly-review'); }
  return fired;
}
