import { config } from '../config.js';
import { withSystem } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { egressFetch, type AdapterStatus } from '../integrations/egress.js';
import { signBody } from '../integrations/linkedin.js';
import { buildDecisionMessage, buildReportTemplate, sendWhatsApp } from '../integrations/whatsapp.js';
import { estimateCost } from '../core/pricing.js';
import { reserveBudget, reconcileReservation, settleFailedCall } from '../core/budget.js';

async function anyActiveBrand(): Promise<string> {
  return withSystem(async (c) => (await c.query(`SELECT id FROM brands WHERE status='active' ORDER BY created_at LIMIT 1`)).rows[0].id);
}

/**
 * Kurucu bildirimleri. Birincil kanal WhatsApp, yedek e-posta, her zaman panel.
 * Aynı bildirim (dedupe anahtarı) bir kanalda yalnız bir kez gönderilir; e-posta yalnız WhatsApp başarısızsa devreye girer.
 * E-posta karar yürütmez; kararlar yalnız WhatsApp butonu/kod yanıtı veya panelden alınır.
 */
export type NotifyKind = 'daily_report' | 'weekly_report' | 'decision' | 'alert';
export interface NotifyResult { whatsapp: string; email: string; duplicate: boolean }

async function founderChannelStatus(channel: 'whatsapp' | 'email'): Promise<AdapterStatus> {
  return withSystem(async (c) => (await c.query(`SELECT cc.status FROM channel_connections cc JOIN brands b ON b.id=cc.brand_id WHERE b.status='active' AND cc.channel=$1 ORDER BY b.created_at LIMIT 1`, [channel])).rows[0]?.status ?? 'disconnected');
}

export async function notifyFounder(n: { kind: NotifyKind; brandId: string | null; dedupeKey: string; text: string; approvalCode?: string }): Promise<NotifyResult> {
  const simulated = config().RUN_MODE === 'simulation';
  const claim = await withSystem(async (c) => (await c.query(
    `INSERT INTO outbound_notifications (brand_id, kind, dedupe_key, channel, payload, is_simulated) VALUES ($1,$2,$3,'whatsapp',$4,$5)
     ON CONFLICT (dedupe_key, channel) DO NOTHING RETURNING id`, [n.brandId, n.kind, n.dedupeKey, { text: n.text, approvalCode: n.approvalCode ?? null }, simulated])).rows[0]);
  if (!claim) return { whatsapp: 'duplicate', email: 'skipped', duplicate: true };

  const waStatus = await founderChannelStatus('whatsapp');
  const to = config().FOUNDER_WHATSAPP_NUMBER;
  let payload: any = { messaging_product: 'whatsapp', recipient_type: 'individual', to, type: 'text', text: { body: n.text.slice(0, 4096) } };
  if (n.kind === 'decision' && n.approvalCode) {
    const a = await withSystem(async (c) => (await c.query(`SELECT a.*, b.name brand_name FROM approval_requests a JOIN brands b ON b.id=a.brand_id WHERE a.code=$1`, [n.approvalCode])).rows[0]);
    payload = buildDecisionMessage(a, a.brand_name, to);
  }
  let wa = to ? await sendWhatsApp(payload, waStatus) : { ok: false as const, reason: 'Kurucu WhatsApp numarası yapılandırılmamış', fallback: true };
  // 24 saat penceresi kapalıysa rapor için onaylı utility şablonu denenir (ücretli olabilir → bütçe rezervasyonu; fiyat bilinmiyorsa gönderilmez)
  if (!wa.ok && /pencere/.test(wa.reason) && n.kind !== 'decision' && waStatus === 'live') {
    const tpl = buildReportTemplate(to, n.text);
    if (!tpl) wa = { ok: false, reason: `${wa.reason}; WHATSAPP_REPORT_TEMPLATE tanımlı değil`, fallback: true };
    else {
      try {
        const est = estimateCost('whatsapp:utility_template_TR', { units: 1 });
        const rsv = await reserveBudget({ brandId: n.brandId ?? (await anyActiveBrand()), mode: 'live', provider: 'whatsapp', estimate: est });
        wa = await sendWhatsApp(tpl, waStatus, { template: true });
        if (wa.ok) await reconcileReservation(rsv.reservationId, { amountOriginal: est.original, currency: est.currency, item: 'whatsapp:utility_template_TR', succeeded: true, externalRef: wa.externalId });
        else await settleFailedCall(rsv.reservationId, Object.assign(new Error(wa.reason), { callState: wa.callState ?? 'not_sent' }), 'WhatsApp şablonu');
      } catch (e) {
        wa = { ok: false, reason: `${wa.ok ? '' : wa.reason}; şablon gönderilmedi: ${(e as Error).message}`, fallback: true };
      }
    }
  }
  await withSystem(async (c) => {
    await c.query(`UPDATE outbound_notifications SET status=$2, external_id=$3, payload = payload || $4::jsonb, updated_at=now() WHERE id=$1`,
      [claim.id, wa.ok ? 'sent' : 'failed', wa.ok ? wa.externalId : null, JSON.stringify(wa.ok ? { simulated: wa.simulated } : { error: wa.reason })]);
    await logEvent(c, { brandId: n.brandId, type: `notify.whatsapp.${wa.ok ? 'sent' : 'failed'}`, actor: 'notifier', subjectType: 'notification', subjectId: claim.id, payload: { kind: n.kind, reason: wa.ok ? undefined : wa.reason }, simulated });
  });
  if (wa.ok) return { whatsapp: wa.simulated ? 'sent(mock)' : 'sent', email: 'not_needed', duplicate: false };

  // Yedek: e-posta (aynı anahtar → en fazla bir e-posta)
  const em = await withSystem(async (c) => (await c.query(
    `INSERT INTO outbound_notifications (brand_id, kind, dedupe_key, channel, payload, is_simulated) VALUES ($1,$2,$3,'email',$4,$5)
     ON CONFLICT (dedupe_key, channel) DO NOTHING RETURNING id`, [n.brandId, n.kind, n.dedupeKey, { text: n.kind === 'decision' ? `${n.text}\n\nKarar e-postayla verilemez; paneli veya WhatsApp'ı kullanın.` : n.text }, simulated])).rows[0]);
  if (!em) return { whatsapp: 'failed', email: 'duplicate', duplicate: false };
  const emStatus = await founderChannelStatus('email');
  const r = await sendEmail(n.kind, n.text, emStatus);
  await withSystem((c) => c.query(`UPDATE outbound_notifications SET status=$2, external_id=$3, updated_at=now() WHERE id=$1`, [em.id, r.ok ? 'sent' : 'failed', r.ok ? r.id : null]));
  return { whatsapp: 'failed', email: r.ok ? (emStatus === 'mock' ? 'sent(mock)' : 'sent') : `failed: ${r.reason}`, duplicate: false };
}

async function sendEmail(kind: string, text: string, status: AdapterStatus): Promise<{ ok: true; id: string } | { ok: false; reason: string }> {
  if (status === 'mock') return { ok: true, id: `mock:email:${Date.now()}` };
  if (status !== 'live') return { ok: false, reason: `e-posta bağlantısı ${status}` };
  const cfg = config();
  const body = JSON.stringify({ contract: 'bays.email.v1', to: cfg.FOUNDER_EMAIL, subject: kind === 'decision' ? 'Karar bekleniyor' : 'BaysSystems raporu', text });
  try {
    const host = new URL(cfg.N8N_BASE_URL).host;
    const res = await egressFetch({ adapter: 'n8n-email', status, purpose: 'live', allowedHosts: [host], credentialPresent: !!cfg.N8N_SHARED_SECRET && !!cfg.FOUNDER_EMAIL,
      url: `${cfg.N8N_BASE_URL.replace(/\/$/, '')}/webhook/${cfg.N8N_EMAIL_WEBHOOK_PATH}`,
      init: { method: 'POST', headers: { 'content-type': 'application/json', 'X-Bays-Signature': signBody(body, cfg.N8N_SHARED_SECRET) }, body } });
    return res.ok ? { ok: true, id: `n8n:${Date.now()}` } : { ok: false, reason: `n8n ${res.status}` };
  } catch (e) {
    return { ok: false, reason: (e as Error).message };
  }
}
