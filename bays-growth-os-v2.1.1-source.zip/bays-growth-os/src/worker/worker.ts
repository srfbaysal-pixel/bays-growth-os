import crypto from 'node:crypto';
import os from 'node:os';
import { withBrand, withSystem } from '../db/pool.js';
import { config } from '../config.js';
import { clock } from '../core/clock.js';
import { logEvent } from '../core/events.js';
import { activeHaltFor } from '../core/halts.js';
import { HaltedError, TransientError } from '../core/tasks.js';
import { BudgetBlockedError } from '../core/budget.js';
import { PriceUnknownError } from '../core/pricing.js';

/**
 * Kalıcı görev yürütücüsü (worker).
 * - Sahiplenme atomiktir: FOR UPDATE SKIP LOCKED + locked_by/locked_until (kira). İki worker aynı işi alamaz.
 * - Kira süresi dolan "running" iş (süreç çöktü) kurtarılır: deneme hakkı varsa geri çekilmeyle kuyruğa, yoksa hata kuyruğuna.
 * - Tamamlama/başarısızlık yalnız işi hâlâ sahiplenen worker tarafından yazılabilir (fencing); geç kalan eski worker'ın sonucu yok sayılır.
 * - Geçici hata: üstel geri çekilmeyle yeniden dener. Kalıcı hata veya deneme sınırı: hata kuyruğu (dead_letter) + neden.
 * - İş mantığı handler'larda; her dış çağrı kendi içinde bütçe ve durdurma kontrolünden geçer.
 */
/** İş zamanı gelmeden çalıştıysa (veya sessiz saat) ceza puanı olmadan yeniden zamanlanır. */
export class RescheduleError extends Error {
  constructor(public readonly until: Date, reason: string) { super(`yeniden zamanlandı: ${reason}`); this.name = 'RescheduleError'; }
}

export type Handler = (task: any, ctx: { workerId: string; now: Date; signal: AbortSignal }) => Promise<Record<string, unknown>>;
const handlers = new Map<string, Handler>();
export function registerHandler(kind: string, h: Handler): void { handlers.set(kind, h); }
export function hasHandler(kind: string): boolean { return handlers.has(kind); }

export const newWorkerId = () => `${os.hostname()}:${process.pid}:${crypto.randomBytes(3).toString('hex')}`;

/** Kira süresi dolmuş işleri kurtarır. Dönüş: kuyruğa dönen ve hata kuyruğuna giden sayısı. */
export async function recoverExpiredLeases(now = clock.now()): Promise<{ requeued: number; dead: number }> {
  return withSystem(async (c) => {
    const rows = (await c.query(`SELECT id, brand_id, attempts, max_attempts, locked_by, is_simulated FROM tasks WHERE status='running' AND locked_until < $1 FOR UPDATE SKIP LOCKED`, [now])).rows;
    let requeued = 0, dead = 0;
    for (const t of rows) {
      if (t.attempts >= t.max_attempts) {
        await c.query(`UPDATE tasks SET status='dead_letter', dead_reason=$2, locked_by=NULL, locked_until=NULL, updated_at=now() WHERE id=$1`, [t.id, `kira süresi doldu (sahip: ${t.locked_by}); deneme sınırı aşıldı`]);
        dead++;
      } else {
        await c.query(`UPDATE tasks SET status='queued', last_error=$2, next_run_at=$3, locked_by=NULL, locked_until=NULL, updated_at=now() WHERE id=$1`, [t.id, `kira süresi doldu (sahip: ${t.locked_by}); kurtarıldı`, new Date(now.getTime() + backoffMs(t.attempts))]);
        requeued++;
      }
      await logEvent(c, { brandId: t.brand_id, type: 'task.lease_recovered', actor: 'worker', subjectType: 'task', subjectId: t.id, payload: { previousOwner: t.locked_by, attempts: t.attempts }, simulated: t.is_simulated });
    }
    return { requeued, dead };
  });
}

export const backoffMs = (attempts: number) => Math.min(2 ** Math.max(attempts, 1) * 30_000, 3_600_000);

/** Zamanı gelmiş bir işi atomik olarak sahiplenir. */
export async function claimDue(workerId: string, now = clock.now(), leaseMs = config().TASK_TIMEOUT_MS, filter: { brandId?: string } = {}): Promise<any | null> {
  return withSystem(async (c) => {
    for (let i = 0; i < 25; i++) {
      // Kip ayrımı: canlı worker yalnız canlı görevi, simülasyon worker'ı yalnız örnek görevi alır; değerlendirme kipinde
      // operasyon görevi yürütülmez. Değerlendirme (eval) görevleri hiçbir zaman kuyruktan yürütülmez.
      const mode = workerMode();
      if (mode === 'none') return null;
      const t = (await c.query(
        `SELECT * FROM tasks WHERE status='queued' AND next_run_at <= $1 AND purpose='operation' AND is_simulated = ${mode === 'simulation' ? 'true' : 'false'}
         ${filter.brandId ? 'AND brand_id = $2' : ''}
         ORDER BY next_run_at, created_at FOR UPDATE SKIP LOCKED LIMIT 1`, filter.brandId ? [now, filter.brandId] : [now])).rows[0];
      if (!t) return null;
      if (!handlers.has(t.kind)) {
        await c.query(`UPDATE tasks SET status='dead_letter', dead_reason=$2, updated_at=now() WHERE id=$1`, [t.id, `işleyici yok: ${t.kind}`]);
        continue;
      }
      const h = await activeHaltFor(c, { brandId: t.brand_id, channel: t.channel, campaignId: t.campaign_id });
      if (h) { await c.query(`UPDATE tasks SET status='halted', last_error=$2, updated_at=now() WHERE id=$1`, [t.id, `durduruldu: ${h.reason}`]); continue; }
      return (await c.query(`UPDATE tasks SET status='running', locked_by=$2, locked_until=$3, attempts=attempts+1, started_at=$4, updated_at=now() WHERE id=$1 RETURNING *`,
        [t.id, workerId, new Date(now.getTime() + leaseMs), now])).rows[0];
    }
    return null;
  });
}

/** Worker kipi: simulation → örnek görevler; live → canlı görevler; eval → operasyon görevi yürütülmez. */
export function workerMode(): 'simulation' | 'live' | 'none' {
  const m = config().RUN_MODE;
  return m === 'live' ? 'live' : m === 'eval' ? 'none' : 'simulation';
}

/** Canlı kipe geçerken bekleyen örnek görev sayısı (yürütülmez; raporda gösterilir). */
export async function pendingOtherModeTasks(): Promise<number> {
  const mode = workerMode();
  if (mode === 'none') return 0;
  return withSystem(async (c) => (await c.query(`SELECT count(*)::int n FROM tasks WHERE status='queued' AND purpose='operation' AND is_simulated = $1`, [mode === 'live'])).rows[0].n);
}

const PERMANENT = (e: unknown) => e instanceof PriceUnknownError || (e instanceof BudgetBlockedError);

/** Sahiplenilmiş işi yürütür ve sonucu yalnız sahiplik hâlâ geçerliyse yazar. */
export async function executeClaimed(task: any, workerId: string, now = clock.now()): Promise<'done' | 'retry' | 'dead_letter' | 'halted' | 'lost_lease' | 'waiting' | 'rescheduled'> {
  const h = handlers.get(task.kind)!;
  // Kira yenileme: uzun süren işte sahiplik sürerken kira uzatılır (yalnız sahibi uzatabilir)
  const leaseMs = config().TASK_TIMEOUT_MS;
  // Kira kaybı (başka worker devraldı / iş durduruldu) fark edilirse handler'a iptal sinyali verilir;
  // dış yan etkisi olan adımlar (ör. e-posta gönderimi) çağrıdan hemen önce bu sinyali denetler.
  const lease = new AbortController();
  const hb = setInterval(() => {
    withSystem((c) => c.query(`UPDATE tasks SET locked_until=$3 WHERE id=$1 AND locked_by=$2 AND status='running' RETURNING id`, [task.id, workerId, new Date(clock.now().getTime() + leaseMs)]))
      .then((r) => { if (!r.rows[0]) lease.abort(new Error('kira kaybedildi')); }).catch(() => undefined);
  }, Math.max(1000, Math.floor(leaseMs / 3)));
  try {
    const out = await h(task, { workerId, now, signal: lease.signal });
    return withBrand(task.brand_id, async (c) => {
      const status = out.__status === 'waiting_decision' ? 'waiting_decision' : 'done';
      const { __status, ...rest } = out as any;
      const r = await c.query(`UPDATE tasks SET status=$3, output=$4, locked_by=NULL, locked_until=NULL, updated_at=now() WHERE id=$1 AND locked_by=$2 AND status='running' RETURNING id`, [task.id, workerId, status, rest]);
      if (!r.rows[0]) return 'lost_lease';
      await logEvent(c, { brandId: task.brand_id, type: `task.${status}`, actor: `worker:${task.kind}`, subjectType: 'task', subjectId: task.id, simulated: task.is_simulated });
      return status === 'waiting_decision' ? 'waiting' : 'done';
    });
  } catch (err) {
    const e = err as Error;
    return withBrand(task.brand_id, async (c) => {
      const cur = (await c.query(`SELECT status, locked_by, attempts, max_attempts FROM tasks WHERE id=$1 FOR UPDATE`, [task.id])).rows[0];
      // Önce sahiplik: işi artık sahiplenmeyen (eski) worker hiçbir durum yazamaz
      if (cur.locked_by !== workerId || cur.status !== 'running') return cur.status === 'halted' ? 'halted' : 'lost_lease';
      if (e instanceof HaltedError) {
        await c.query(`UPDATE tasks SET status='halted', locked_by=NULL, locked_until=NULL, last_error=$3, updated_at=now() WHERE id=$1 AND locked_by=$2`, [task.id, workerId, e.message.slice(0, 500)]);
        return 'halted';
      }
      if (e instanceof RescheduleError) {
        await c.query(`UPDATE tasks SET status='queued', attempts=GREATEST(attempts-1,0), next_run_at=$2, last_error=$3, locked_by=NULL, locked_until=NULL, updated_at=now() WHERE id=$1 AND locked_by=$4`, [task.id, e.until, e.message, workerId]);
        return 'rescheduled';
      }
      const transient = e instanceof TransientError || (e as any).transient === true;
      let status: 'queued' | 'dead_letter';
      let reason: string | null = null;
      if (transient && cur.attempts < cur.max_attempts) status = 'queued';
      else { status = 'dead_letter'; reason = transient ? `deneme sınırı aşıldı (${cur.attempts}/${cur.max_attempts}): ${e.message}` : `kalıcı hata${PERMANENT(e) ? ' (bütçe/fiyat)' : ''}: ${e.message}`; }
      await c.query(`UPDATE tasks SET status=$2, last_error=$3, dead_reason=$4, next_run_at=$5, locked_by=NULL, locked_until=NULL, updated_at=now() WHERE id=$1 AND locked_by=$6`,
        [task.id, status, e.message.slice(0, 500), reason?.slice(0, 500) ?? null, new Date(now.getTime() + backoffMs(cur.attempts)), workerId]);
      await logEvent(c, { brandId: task.brand_id, type: status === 'queued' ? 'task.retry_scheduled' : 'task.dead_letter', actor: `worker:${task.kind}`, subjectType: 'task', subjectId: task.id, payload: { error: e.message.slice(0, 300), attempts: cur.attempts, reason }, simulated: task.is_simulated });
      return status === 'queued' ? 'retry' : 'dead_letter';
    });
  } finally {
    clearInterval(hb);
  }
}

/** Zamanı gelen tüm işleri bitirene kadar yürütür (test, simülasyon ve tek seferlik çalıştırma için). */
export async function drain(opts: { workerId?: string; now?: () => Date; max?: number; brandId?: string } = {}): Promise<{ executed: number; results: Record<string, number> }> {
  const id = opts.workerId ?? newWorkerId();
  const nowFn = opts.now ?? (() => clock.now());
  const results: Record<string, number> = {};
  let executed = 0;
  await recoverExpiredLeases(nowFn());
  for (; executed < (opts.max ?? 500);) {
    const t = await claimDue(id, nowFn(), undefined, { brandId: opts.brandId });
    if (!t) break;
    const r = await executeClaimed(t, id, nowFn());
    results[r] = (results[r] ?? 0) + 1;
    executed++;
  }
  return { executed, results };
}

/** Sürekli çalışan worker döngüsü. SIGTERM/SIGINT ile güvenli durur (elindeki işi bitirir). */
export async function runWorker(opts: { pollMs?: number; signal?: AbortSignal; log?: (s: string) => void } = {}): Promise<void> {
  const id = newWorkerId();
  const log = opts.log ?? ((s: string) => console.log(`[worker ${id}] ${s}`));
  let stop = false;
  const onStop = () => { stop = true; log('durdurma sinyali alındı; elindeki iş bitince çıkacak'); };
  process.once('SIGTERM', onStop); process.once('SIGINT', onStop);
  opts.signal?.addEventListener('abort', onStop);
  log(`başladı (kip: ${config().RUN_MODE})`);
  const other = await pendingOtherModeTasks().catch(() => 0);
  if (other) log(`${other} bekleyen görev başka kipe ait (${workerMode() === 'live' ? 'ÖRNEK' : 'canlı'}); bu worker tarafından yürütülmez`);
  let lastRecover = 0;
  while (!stop) {
    if (Date.now() - lastRecover > 30_000) { const r = await recoverExpiredLeases(); if (r.requeued || r.dead) log(`kurtarma: ${JSON.stringify(r)}`); lastRecover = Date.now(); }
    const t = await claimDue(id).catch((e) => { log(`sahiplenme hatası: ${e.message}`); return null; });
    if (!t) { await new Promise((r) => setTimeout(r, opts.pollMs ?? 2000)); continue; }
    const r = await executeClaimed(t, id).catch((e) => { log(`yürütme hatası: ${e.message}`); return 'error'; });
    log(`${t.kind} ${t.id} → ${r}`);
  }
  log('çıktı');
}
