import { withBrand, type Db } from '../db/pool.js';
import { assertNotHalted, countModelCall, ModelCallLimitError, TransientError } from '../core/tasks.js';
import { estimateCost } from '../core/pricing.js';
import { reserveBudget, reconcileReservation, settleFailedCall } from '../core/budget.js';
import { currentKnowledge } from '../core/knowledge.js';
import { logEvent } from '../core/events.js';
import { sha256, stableStringify } from '../core/util.js';
import { ROLES, roleHash, systemPrompt, expertise, type RoleId } from './roles.js';
import { resolveModel, type AgentInput } from './providers.js';
import { checkClaims, checkOutreachQuality, checkStrategyEvidence, checkObjectiveBasis, checkNumbersFromContext, wrapExternal, merge, type GuardResult, type ClaimContext } from './guards.js';

export interface RunAgentInput {
  task: { id: string; brand_id: string; channel?: string | null; campaign_id?: string | null; is_simulated: boolean; kind: string };
  role: RoleId;
  taskInput: Record<string, unknown>;
  external?: { ref: string; text: string }[];
  maxOutputTokens?: number;
}
export interface RunAgentResult { output: any; guard: GuardResult; runId: string; modelCalls: number; simulated: boolean; claimContext: ClaimContext }

export class SchemaInvalidError extends Error {}

export async function buildContext(c: Db, brandId: string, role: RoleId, simulated = true) {
  const brand = (await c.query(`SELECT b.id, b.name, b.slug, p.profile FROM brands b JOIN brand_profiles p ON p.brand_id=b.id AND p.validity='current' WHERE b.id=$1 ORDER BY p.version DESC LIMIT 1`, [brandId])).rows[0];
  const offers = (await c.query(`SELECT code, title, readiness, delivery_note FROM offers WHERE brand_id=$1 ORDER BY code`, [brandId])).rows;
  // Kip ayrımı: canlı görev yalnız gerçek kanıtı görür (ÖRNEK kanıt canlı içerikte başarı kanıtı olamaz; kipi bilinmeyen eski kanıt da);
  // örnek görev örnek kanıtla birlikte gerçek kanıtı da görebilir (simülasyon gerçek hizmet bilgisini kullanır).
  const evidence = (await c.query(`SELECT 'ev:' || id AS ref, title, kind FROM evidence WHERE brand_id=$1 AND (valid_until IS NULL OR valid_until > now())
     ${simulated ? '' : 'AND NOT is_sample AND NOT mode_unknown'} ORDER BY captured_at DESC LIMIT 30`, [brandId])).rows;
  const kinds = ROLES[role].knowledgeScope.kinds as any[];
  const knowledge = (await currentKnowledge(c, brandId, kinds)).filter((k) => simulated || !k.is_sample).map((k) => ({ key: k.item_key, kind: k.kind, content: k.content, version: k.version }));
  // Diğer marka adları yalnız marka karışması kontrolü için (içerik değil)
  const others = (await c.query(`SELECT name FROM brands WHERE id <> $1`, [brandId])).rows.map((r) => r.name);
  return { brand, offers, evidence, knowledge, others };
}

export async function runAgent(a: RunAgentInput): Promise<RunAgentResult> {
  const role = ROLES[a.role];
  const brandId = a.task.brand_id;
  const mode = a.task.is_simulated ? 'simulation' : 'live';
  const ctx = await withBrand(brandId, async (c) => {
    await assertNotHalted(c, a.task);
    const b = await buildContext(c, brandId, a.role, a.task.is_simulated);
    const ext = wrapExternal(a.external ?? []);
    for (const f of ext.flagged) {
      await logEvent(c, { brandId, type: 'security.injection_detected', actor: a.role, subjectType: 'task', subjectId: a.task.id, payload: { ref: f.ref, violations: f.violations }, simulated: a.task.is_simulated });
    }
    return { ...b, externalBlock: ext.block, flagged: ext.flagged };
  });

  const input: AgentInput = {
    brand: { id: ctx.brand.id, name: ctx.brand.name, profile: ctx.brand.profile },
    offers: ctx.offers, evidence: ctx.evidence, knowledge: ctx.knowledge,
    external: ctx.externalBlock, task: { kind: a.task.kind, input: a.taskInput },
  };
  const { provider, model, pricingKey } = resolveModel(role.tier);
  const maxOut = a.maxOutputTokens ?? 2000;
  let lastErr: Error | null = null;
  let output: any = null;
  let calls = 0;
  let simulated = true;

  while (true) {
    // Fiyat bilinmiyorsa çağrı sayılmaz ve yapılmaz (PriceUnknownError)
    const sys = systemPrompt(role);
    const inputTokens = Math.ceil((sys.length + JSON.stringify(input).length) / 3);
    const est = estimateCost(pricingKey, { inputTokens, maxOutputTokens: maxOut, units: 1 });
    try {
      await withBrand(brandId, async (c) => { await assertNotHalted(c, a.task); calls = await countModelCall(c, a.task.id); });
    } catch (e) {
      if (e instanceof ModelCallLimitError) throw new SchemaInvalidError(`Model çağrı sınırı doldu; son hata: ${lastErr?.message ?? 'yok'}`);
      throw e;
    }
    const rsv = await reserveBudget({ brandId, mode, provider: provider.name, estimate: est, taskId: a.task.id, callRef: `task:${a.task.id}:model:${calls}` });
    let resp;
    try {
      resp = await provider.call(model, { role: a.role, system: sys, input, maxOutputTokens: maxOut });
    } catch (e) {
      // V2.1: yalnız çağrı yapılmadıysa veya sağlayıcı kesin reddettiyse (4xx) rezervasyon bırakılır; zaman aşımı/bağlantı
      // kopması/5xx'te "belirsiz" kalır, bütçede sayılır ve kurucuya uzlaştırma işi açılır. Her deneme ayrı rezervasyondur.
      await settleFailedCall(rsv.reservationId, e, `model ${pricingKey}`);
      if ((e as any).transient) throw new TransientError((e as Error).message);
      throw e;
    }
    simulated = resp.simulated;
    const actual = estimateCost(pricingKey, { inputTokens: resp.usage.inputTokens, maxOutputTokens: resp.usage.outputTokens, units: 1 });
    await reconcileReservation(rsv.reservationId, { amountOriginal: actual.original, currency: actual.currency, item: `${pricingKey}:${a.role}`, succeeded: true, isRetry: calls > 1 });
    try {
      const parsed = JSON.parse(extractJson(resp.raw));
      output = role.output.parse(parsed);
      break;
    } catch (e) {
      lastErr = e as Error;
      await withBrand(brandId, (c) => logEvent(c, { brandId, type: 'agent.schema_invalid', actor: a.role, subjectType: 'task', subjectId: a.task.id, payload: { error: String(e).slice(0, 300), call: calls }, simulated }));
      continue; // sınır kontrolü döngü başında
    }
  }

  const claimContext: ClaimContext = { brandName: ctx.brand.name, otherBrandNames: ctx.others, offers: ctx.offers, evidenceIds: ctx.evidence.map((e: any) => e.ref) };
  let guard: GuardResult = { ok: true, violations: [] };
  if (a.role === 'content') guard = checkClaims(`${output.post_text}\n${output.image_brief}\n${output.video_script ?? ''}`, claimContext, output.claims_used);
  if (a.role === 'strategy') {
    const ctxObj = (a.taskInput as any).context;
    const ctxRefs = ctxObj ? Object.keys(ctxObj).map((k) => `ctx:${k}`) : [];
    const known = [...claimContext.evidenceIds, ...ctxRefs];
    guard = merge(
      checkStrategyEvidence(output, known),
      checkClaims(output.campaign_brief.message, claimContext),
      checkObjectiveBasis(output.objectives, known),
      ctxObj ? checkNumbersFromContext([...output.objectives.map((o: any) => o.rationale), ...output.decision_changes.map((d: any) => d.because)].join('\n'), JSON.stringify(ctxObj)) : { ok: true, violations: [] },
    );
  }
  if (a.role === 'customer_dev' && output.outreach) guard = merge(checkClaims(output.outreach.draft, claimContext), checkOutreachQuality(output.outreach.draft, output.outreach.personalization_basis, output.lead_assessment.need_signals));

  const runId = await withBrand(brandId, async (c) => {
    const r = await c.query(
      `INSERT INTO agent_runs (brand_id, task_id, role, role_version, prompt_hash, provider, model, input_hash, output, schema_valid, guard_result, is_simulated, purpose)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,true,$10,$11,$12) RETURNING id`,
      [brandId, a.task.id, a.role, `${role.version}+${expertise(a.role).version}`, roleHash(role), provider.name, model, sha256(stableStringify(input)), output, guard, simulated, (a.task as any).purpose ?? (a.task.kind.startsWith('eval:') ? 'evaluation' : 'operation')]);
    await logEvent(c, { brandId, type: 'agent.run', actor: a.role, subjectType: 'agent_run', subjectId: r.rows[0].id, payload: { task: a.task.id, version: role.version, guardOk: guard.ok, violations: guard.violations.map((v) => v.code) }, simulated });
    return r.rows[0].id as string;
  });
  return { output, guard, runId, modelCalls: calls, simulated, claimContext };
}

function extractJson(raw: string): string {
  const s = raw.trim();
  if (s.startsWith('{')) return s;
  const m = /```(?:json)?\s*([\s\S]*?)```/.exec(s);
  return m ? m[1] : s;
}
