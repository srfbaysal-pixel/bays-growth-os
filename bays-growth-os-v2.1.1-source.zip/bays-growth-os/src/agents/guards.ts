/**
 * Deterministik koruma katmanı. Model çıktısı kendi doğruluğunun kanıtı değildir;
 * bu kontroller modelden bağımsız çalışır ve denetçi tarafından ayrıca yeniden çalıştırılır.
 */
export interface Violation { code: string; severity: 'low' | 'medium' | 'high' | 'critical'; detail: string }
export interface GuardResult { ok: boolean; violations: Violation[] }

export interface ClaimContext {
  brandName: string;
  otherBrandNames: string[];
  offers: { code: string; title: string; readiness: string }[];
  /** Kanıt kimlikleri: içerikteki iddiaların dayanabileceği kayıtlar */
  evidenceIds: string[];
}

const SUCCESS_CLAIM = [
  /%\s?\d+|\d+\s?%/, // yüzde
  /\b\d+\s?(kat|x)\b/i,
  /\b(garanti|garantili|kesin sonuç|kanıtlanmış|lider|bir numara|1 numara|en iyi)\b/i,
  /\b(binlerce|yüzlerce|onlarca)\s+(müşteri|işletme|firma)/i,
];
const REFERENCE_CLAIM = /\b(müşterimiz|müşterilerimiz|referans(larımız)?|birlikte çalıştığımız|çalıştığımız firmalar|başarı hikaye|başarı hikâye)/i;
const DELIVERY_COMMIT = /\b(\d+\s?(gün|saat)(de|da|te|ta|içinde)?\s?(teslim|kurulum|hazır)|kesin teslim|aynı gün teslim)\b/i;
const PRICE_MENTION = /(\d[\d.]*\s?(tl|₺|try|usd|\$|euro|€))|((tl|₺|\$|€)\s?\d)|\b(indirim|kampanyalı fiyat|ücretsiz deneme)\b/i;
const READY_WORDS = /\b(hazır|çalışan|kullanımda|canlıda|aktif olarak)\b/i;
const LEGACY = /nazilli/i;

/** İçerik/iletişim taslağı için iddia kontrolleri */
export function checkClaims(text: string, ctx: ClaimContext, claimsUsed: { claim: string; evidence_ref: string | null }[] = []): GuardResult {
  const v: Violation[] = [];
  const t = text ?? '';
  for (const re of SUCCESS_CLAIM) {
    const m = re.exec(t);
    if (m) {
      const backed = claimsUsed.some((c) => c.evidence_ref && ctx.evidenceIds.includes(c.evidence_ref) && t.includes(c.claim));
      if (!backed) v.push({ code: 'unverified_success_claim', severity: 'high', detail: `Kanıtsız başarı/üstünlük ifadesi: "${m[0]}"` });
    }
  }
  if (REFERENCE_CLAIM.test(t)) v.push({ code: 'fake_reference', severity: 'critical', detail: 'Müşteri referansı/başarı hikâyesi ifadesi; kayıtlı doğrulanmış referans yok' });
  if (DELIVERY_COMMIT.test(t)) v.push({ code: 'delivery_commitment', severity: 'high', detail: 'Kesin teslim süresi taahhüdü yalnız kurucu kararıyla verilebilir' });
  if (PRICE_MENTION.test(t)) v.push({ code: 'price_commitment', severity: 'high', detail: 'Fiyat/indirim ifadesi yalnız kurucu kararıyla kullanılabilir' });
  if (LEGACY.test(t)) v.push({ code: 'legacy_institution', severity: 'high', detail: 'Geçmiş Nazilli kurumu güncel faaliyet gibi sunulamaz' });
  for (const o of ctx.offers) {
    const mentioned = t.toLocaleLowerCase('tr-TR').includes(o.title.toLocaleLowerCase('tr-TR').slice(0, 24));
    if (mentioned && o.readiness !== 'test_verified' && READY_WORDS.test(t)) {
      v.push({ code: 'readiness_overclaim', severity: 'high', detail: `"${o.title}" durumu ${o.readiness}; hazır/çalışan diye sunulamaz` });
    }
    if (mentioned && (o.readiness === 'in_development' || o.readiness === 'not_for_sale')) {
      v.push({ code: 'offer_not_sellable', severity: 'high', detail: `"${o.title}" ${o.readiness} durumunda; satış iletisinde kullanılamaz` });
    }
  }
  for (const other of ctx.otherBrandNames) {
    if (other && t.toLocaleLowerCase('tr-TR').includes(other.toLocaleLowerCase('tr-TR'))) v.push({ code: 'brand_mixing', severity: 'high', detail: `Başka markanın adı geçiyor: ${other}` });
  }
  return { ok: v.length === 0, violations: v };
}

const INJECTION = [
  /(ignore|disregard)\s+(all\s+)?(previous|prior|above)\s+(instructions|prompts?)/i,
  /önceki\s+(tüm\s+)?(talimat|komut|yönerge)(ları|leri)?\s*(yok\s*say|unut|görmezden gel)/i,
  /\b(system\s*prompt|sistem\s*talimat)/i,
  /\byou\s+are\s+now\b|\bartık\s+sen\b/i,
  /\b(api[\s_-]?key|anahtar(ı|ını)?\s+(gönder|paylaş|yaz)|token(ı|ını)?\s+(gönder|paylaş))/i,
  /\b(bütçe(yi)?\s+(artır|yükselt|sınırsız)|kredi\s+yükle|reklam\s+(aç|başlat|ver))/i,
  /\b(tüm\s+(müşteri|kişi|lead)(leri|lerin)?\s+(listesini|bilgilerini)\s+(gönder|paylaş))/i,
  /\bonay(sız|a gerek yok)\b.*\b(gönder|yayınla|yayımla)/i,
];

/** Dış sayfa/müşteri mesajındaki talimat girişimlerini tespit eder. Tespit edilen içerik yetkiyi değiştiremez. */
export function detectInjection(text: string): GuardResult {
  const v: Violation[] = [];
  for (const re of INJECTION) {
    const m = re.exec(text ?? '');
    if (m) v.push({ code: 'prompt_injection', severity: 'high', detail: `Dış içerikte talimat girişimi: "${m[0].slice(0, 60)}"` });
  }
  return { ok: v.length === 0, violations: v };
}

/** Dış veriyi modele yalnız veri olarak verir; talimat girişimi varsa ilgili parça çıkarılır. */
export function wrapExternal(items: { ref: string; text: string }[]): { block: string; flagged: { ref: string; violations: Violation[] }[] } {
  const flagged: { ref: string; violations: Violation[] }[] = [];
  const parts: string[] = [];
  for (const it of items) {
    const g = detectInjection(it.text);
    if (!g.ok) { flagged.push({ ref: it.ref, violations: g.violations }); parts.push(`<dis_veri ref="${it.ref}">[KALDIRILDI: talimat girişimi tespit edildi]</dis_veri>`); continue; }
    parts.push(`<dis_veri ref="${it.ref}">${it.text.replace(/<\/?dis_veri[^>]*>/g, '')}</dis_veri>`);
  }
  return { block: parts.join('\n'), flagged };
}

/** Strateji çıktısı: her öncelik kanıt referansı taşımalı ya da açıkça hipotez olarak işaretlenmeli. */
export function checkStrategyEvidence(out: { weekly_plan: { priorities: { item: string; evidence_refs: string[]; is_hypothesis: boolean }[] }; findings?: { claim: string; source_ref: string | null; is_hypothesis: boolean }[] }, knownRefs: string[]): GuardResult {
  const v: Violation[] = [];
  for (const p of out.weekly_plan.priorities) {
    const valid = p.evidence_refs.filter((r) => knownRefs.includes(r));
    if (!p.is_hypothesis && valid.length === 0) v.push({ code: 'unsupported_priority', severity: 'medium', detail: `Kanıtsız öncelik hipotez olarak işaretlenmemiş: ${p.item}` });
    if (p.evidence_refs.some((r) => !knownRefs.includes(r))) v.push({ code: 'unknown_evidence_ref', severity: 'medium', detail: `Var olmayan kanıt referansı: ${p.item}` });
  }
  for (const f of out.findings ?? []) {
    if (!f.is_hypothesis && (!f.source_ref || !knownRefs.includes(f.source_ref))) v.push({ code: 'unsourced_finding', severity: 'medium', detail: `Kaynaksız bulgu: ${f.claim}` });
  }
  return { ok: v.length === 0, violations: v };
}

/** Genel/tekrarlı mesaj tespiti: kişiselleştirme dayanağı olmayan veya şablon ifadeli taslaklar */
export function checkOutreachQuality(draft: string, basis: string[], needSignals: string[]): GuardResult {
  const v: Violation[] = [];
  if (basis.length === 0) v.push({ code: 'generic_message', severity: 'medium', detail: 'Kişiselleştirme dayanağı yok' });
  const lower = draft.toLocaleLowerCase('tr-TR');
  if (needSignals.length > 0 && !needSignals.some((s) => s.split(/\s+/).filter((w) => w.length > 4).some((w) => lower.includes(w.toLocaleLowerCase('tr-TR'))))) {
    v.push({ code: 'need_not_addressed', severity: 'medium', detail: 'Taslak tespit edilen ihtiyaca değinmiyor' });
  }
  if (/sayın yetkili|değerli iş ortağımız|kaçırılmayacak fırsat/i.test(draft)) v.push({ code: 'template_phrasing', severity: 'low', detail: 'Toplu mesaj kalıbı' });
  return { ok: v.length === 0, violations: v };
}

export function merge(...rs: GuardResult[]): GuardResult {
  const violations = rs.flatMap((r) => r.violations);
  return { ok: violations.length === 0, violations };
}

/** V2: her hedef bağlamdaki bir alana dayanmalı veya hipotez olarak işaretlenmeli; maliyet sınırı ve durdurma koşulu zorunlu. */
export function checkObjectiveBasis(objs: { goal: string; basis_refs: string[]; is_hypothesis: boolean; stop_condition: string; cost_limit_try: number }[], knownRefs: string[]): GuardResult {
  const v: Violation[] = [];
  for (const o of objs ?? []) {
    const valid = o.basis_refs.filter((r) => knownRefs.includes(r));
    if (!o.is_hypothesis && valid.length === 0) v.push({ code: 'objective_without_basis', severity: 'medium', detail: `Dayanaksız hedef hipotez olarak işaretlenmemiş: ${o.goal}` });
    if (o.basis_refs.some((r) => !knownRefs.includes(r))) v.push({ code: 'unknown_basis_ref', severity: 'medium', detail: `Bağlamda olmayan dayanak: ${o.goal}` });
  }
  return { ok: v.length === 0, violations: v };
}

/** V2: gerekçede geçen her sayı bağlamda aynen bulunmalı (bilinmeyen veriden sonuç uydurulmaz). */
export function checkNumbersFromContext(text: string, contextJson: string): GuardResult {
  const v: Violation[] = [];
  const nums = new Set((text.match(/\d+(?:[.,]\d+)?/g) ?? []).map((n) => n.replace(',', '.')));
  for (const n of nums) {
    const variants = [n, String(Number(n))];
    if (!variants.some((x) => contextJson.includes(x))) v.push({ code: 'invented_number', severity: 'high', detail: `Gerekçedeki "${n}" sayısı bağlam verisinde yok` });
  }
  return { ok: v.length === 0, violations: v };
}
