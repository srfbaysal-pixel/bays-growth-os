import type { Db } from '../db/pool.js';
import { config } from '../config.js';
import { committed, getLimits } from '../core/budget.js';
import { monthKey } from '../core/util.js';
import { resolveRule } from '../learning/rules.js';
import { estimateCost } from '../core/pricing.js';

function unknownPrices(): boolean {
  const cfg = config();
  for (const k of [cfg.MODEL_ECONOMY, cfg.MODEL_STRONG]) {
    try { const e = estimateCost(k, { inputTokens: 1, maxOutputTokens: 1, units: 1 }); if (e.simulatedOnly && cfg.RUN_MODE === 'live') return true; } catch { return true; }
  }
  return false;
}

/**
 * Strateji bağlamı: yalnız ilgili markanın (RLS + açık brand_id filtresi) son dönem verisi.
 * Her bölüm dönemi ve eksikliği gösterir: "missing" listesi, verinin yokluğunu sıfır sonuçtan ayırır.
 * Kişisel veri içermez (adaylar yalnız sayı ve aşama olarak).
 */
export interface StrategyContext {
  brand: string; period: { from: string; to: string; days: number };
  publications: { status: string; simulated: boolean; n: number }[];
  metricsByContentType: { content_type: string; metric: string; n: number; mean: number; simulated: boolean }[];
  research: { runs: { status: string; n: number }[]; findings: { kind: string; n: number }[]; topSignals: { signal: string; count: number; offer: string }[]; disabledReason: string | null };
  crm: { stages: { stage: string; n: number }[]; sentContacts: number; draftedNotSent: number; replies: { classification: string; n: number }[]; qualified: number; meetingsHeld: number };
  costs: { live: number; simulation: number; limit: number; unknownPrices: boolean };
  offers: { code: string; readiness: string; demo: boolean; founderVerified: boolean }[];
  meetingCapacityPerWeek: number | null;
  experiments: { hypothesis: string; status: string; simulated: boolean }[];
  rules: { publishTime: { value: string | null; source: string; reason: string } };
  audit: { severity: string; title: string }[];
  missing: string[];
}

export async function buildStrategyContext(c: Db, brandId: string, now: Date, days = 14, simulated = true): Promise<StrategyContext> {
  // Kip ayrımı (V2.1): canlı bağlam yalnız canlı veriyi (kipi bilinmeyen eski kayıtlar hariç), örnek bağlam yalnız örnek veriyi görür.
  // Karma ortalama hesaplanmaz; ölçümlerde yayın başına yalnız güncel anlık görüntü sayılır.
  const from = new Date(now.getTime() - days * 86400_000);
  const P = [brandId, from, simulated];
  const q = async (sql: string, p: unknown[] = P) => (await c.query(sql, p)).rows;
  const brand = (await q(`SELECT name FROM brands WHERE id=$1`, [brandId]))[0].name;
  const publications = (await q(`SELECT status, is_simulated simulated, count(*)::int n FROM publications WHERE brand_id=$1 AND created_at >= $2 AND is_simulated=$3 GROUP BY 1,2`)).map((r) => ({ status: r.status, simulated: r.simulated, n: r.n }));
  const metricsByContentType = (await q(`SELECT coalesce(a.content->>'content_type','bilinmiyor') content_type, m.metric, count(*)::int n, avg(m.value)::float8 mean, bool_or(m.is_simulated) simulated
     FROM metrics m LEFT JOIN publications p ON p.id=m.publication_id LEFT JOIN assets a ON a.id=p.asset_id
     WHERE m.brand_id=$1 AND m.measured_at >= $2 AND m.is_simulated=$3 AND m.is_current GROUP BY 1,2`)).map((r) => ({ ...r, mean: Math.round(r.mean * 1000) / 1000 }));
  const runs = await q(`SELECT status, count(*)::int n FROM research_runs WHERE brand_id=$1 AND created_at >= $2 AND is_simulated=$3 GROUP BY 1`);
  const findings = await q(`SELECT kind, count(*)::int n FROM research_findings WHERE brand_id=$1 AND accessed_at >= $2 AND is_simulated=$3 GROUP BY 1`);
  const topSignals = (await q(`SELECT data->>'signal' signal, sum((data->>'count')::int)::int count, max(data->>'offer') offer FROM research_findings WHERE brand_id=$1 AND kind='market_need' AND accessed_at >= $2 AND is_simulated=$3 GROUP BY 1 ORDER BY 2 DESC LIMIT 5`));
  const lastRun = (await q(`SELECT status, notes FROM research_runs WHERE brand_id=$1 AND is_simulated=$2 ORDER BY created_at DESC LIMIT 1`, [brandId, simulated]))[0];
  const L = [brandId, simulated];
  const stages = await q(`SELECT stage, count(*)::int n FROM leads WHERE brand_id=$1 AND is_sample=$2 AND NOT mode_unknown GROUP BY 1`, L);
  const sentContacts = (await q(`SELECT count(*)::int n FROM interactions WHERE brand_id=$1 AND direction='outbound' AND status IN ('sent','manual_sent') AND occurred_at >= $2 AND is_simulated=$3`))[0].n;
  const draftedNotSent = (await q(`SELECT count(*)::int n FROM assets a WHERE a.brand_id=$1 AND a.kind='outreach_draft' AND a.created_at >= $2 AND a.is_sample=$3 AND NOT a.mode_unknown AND a.status IN ('passed_checks','manual_required','draft')`))[0].n;
  const replies = await q(`SELECT coalesce(t.output->>'classification','sınıflanmadı') classification, count(*)::int n FROM tasks t WHERE t.brand_id=$1 AND t.kind='reply_classify' AND t.status='done' AND t.updated_at >= $2 AND t.is_simulated=$3 AND t.purpose='operation' GROUP BY 1`);
  const qualified = (await q(`SELECT count(*)::int n FROM opportunities WHERE brand_id=$1 AND created_at >= $2 AND is_simulated=$3 AND NOT mode_unknown`))[0].n;
  const meetingsHeld = (await q(`SELECT count(*)::int n FROM meetings WHERE brand_id=$1 AND status='held' AND is_simulated=$2 AND NOT mode_unknown`, L))[0].n;
  const lim = await getLimits(c);
  // Maliyet: markanın bu aydaki gerçek ve simülasyon defteri ayrı; belirsiz (uzlaştırma bekleyen) rezervasyonlar ayrıca
  const live = (await c.query(`SELECT coalesce(sum(amount_try),0)::float8 s FROM cost_ledger WHERE brand_id=$1 AND mode='live' AND month=$2`, [brandId, monthKey(now)])).rows[0].s;
  const sim = (await c.query(`SELECT coalesce(sum(amount_try),0)::float8 s FROM cost_ledger WHERE brand_id=$1 AND mode='simulation' AND month=$2`, [brandId, monthKey(now)])).rows[0].s;
  const uncertain = (await c.query(`SELECT count(*)::int n, coalesce(sum(est_try),0)::float8 s FROM budget_reservations WHERE brand_id=$1 AND mode=$2 AND month=$3 AND status='uncertain'`, [brandId, simulated ? 'simulation' : 'live', monthKey(now)])).rows[0];
  void committed;
  const offers = (await q(`SELECT code, readiness, demo_evidence_id IS NOT NULL demo, founder_verified FROM offers WHERE brand_id=$1 ORDER BY code`, [brandId])).map((o) => ({ code: o.code, readiness: o.readiness, demo: o.demo, founderVerified: o.founder_verified }));
  const cap = (await q(`SELECT value FROM settings WHERE key='founder.meeting_capacity_per_week'`, []))[0]?.value?.amount ?? null;
  const experiments = (await q(`SELECT hypothesis, status, is_simulated simulated FROM experiments WHERE brand_id=$1 AND is_simulated=$2 AND NOT mode_unknown ORDER BY created_at DESC LIMIT 5`, L));
  const pt = await resolveRule<string>(c, brandId, 'publish_time', { channel: 'linkedin' }, null as any, now, { simulated });
  const audit = (await q(`SELECT severity, title FROM audit_findings WHERE brand_id=$1 AND status='open' AND severity IN ('medium','high','critical') AND is_simulated=$2 AND NOT mode_unknown ORDER BY created_at DESC LIMIT 6`, L));
  const unknownMode = simulated ? 0 : (await q(`SELECT (SELECT count(*) FROM leads WHERE brand_id=$1 AND mode_unknown) + (SELECT count(*) FROM opportunities WHERE brand_id=$1 AND mode_unknown) + (SELECT count(*) FROM experiments WHERE brand_id=$1 AND mode_unknown) + (SELECT count(*) FROM assets WHERE brand_id=$1 AND mode_unknown) AS n`, [brandId]))[0].n;

  const missing: string[] = [];
  if (!metricsByContentType.length) missing.push('yayın ölçümü yok (sıfır değil, bilinmiyor)');
  if (simulated || !metricsByContentType.length) missing.push('canlı ölçüm yok');
  if (!runs.length) missing.push('dönemde araştırma çalıştırması yok');
  if (lastRun?.status === 'disabled') missing.push('araştırma sağlayıcısı bağlı değil');
  if (sentContacts === 0) missing.push('gönderilmiş temas yok; yanıt oranı hesaplanamaz');
  if (cap == null) missing.push('kurucu görüşme kapasitesi tanımsız');
  if (!offers.some((o) => o.demo || o.readiness === 'test_verified')) missing.push('çalışan demo/test kanıtı yok');
  if (config().RUN_MODE !== 'live') missing.push('canlı maliyet verisi yok (simülasyon)');
  if (Number(uncertain.n) > 0) missing.push(`${uncertain.n} ücretli çağrının gideri belirsiz (uzlaştırma bekliyor, tahmini ${uncertain.s} TL sayıldı)`);
  if (Number(unknownMode) > 0) missing.push(`kipi bilinmeyen ${unknownMode} eski kayıt var; canlı karara katılmadı`);
  if (simulated) missing.push('ÖRNEK bağlam: bu veriler simülasyondur, canlı sonuç değildir');

  return {
    brand, period: { from: from.toISOString(), to: now.toISOString(), days },
    publications, metricsByContentType,
    research: { runs, findings, topSignals, disabledReason: lastRun?.status === 'disabled' ? (lastRun.notes?.[0] ?? 'bağlı değil') : null },
    crm: { stages, sentContacts, draftedNotSent, replies, qualified, meetingsHeld },
    costs: { live, simulation: sim, limit: lim.activeLimitTry, unknownPrices: unknownPrices() },
    offers, meetingCapacityPerWeek: cap, experiments,
    rules: { publishTime: { value: pt.value as any, source: pt.source, reason: pt.reason } },
    audit, missing,
  };
}
