import fs from 'node:fs';
import path from 'node:path';
import { checkClaims, checkOutreachQuality, checkStrategyEvidence, detectInjection, type GuardResult } from './guards.js';

const FILE = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../evals/cases.json');

/** BaysSystems seed hizmetleriyle aynı durum bilgileri (değerlendirme için sabit bağlam) */
const CTX = {
  brandName: 'BaysSystems',
  otherBrandNames: ['Almakİstiyorum.net', 'Maple Market', 'Mentora'],
  offers: [
    { code: 'sosyal-medya-otomasyon', title: 'Sosyal medya içerik ve paylaşım otomasyonu kurulumu', readiness: 'user_declared' },
    { code: 'instagram-mesajlasma', title: 'Instagram mesajlaşma otomasyonu', readiness: 'in_development' },
  ],
  evidenceIds: [],
};

export interface EvalResult { id: string; passed: boolean; got: string[]; expected: string[] | 'ok' }

export function runEvals(): { results: EvalResult[]; passed: number; total: number; note: string } {
  const cases = JSON.parse(fs.readFileSync(FILE, 'utf8')).cases as any[];
  const results: EvalResult[] = cases.map((k) => {
    let g: GuardResult;
    if (k.type === 'claims') g = checkClaims(k.text, CTX);
    else if (k.type === 'outreach') g = checkOutreachQuality(k.text, k.basis, k.needs);
    else if (k.type === 'strategy') g = checkStrategyEvidence(k.plan, k.known_refs);
    else g = detectInjection(k.text);
    const got = Array.from(new Set(g.violations.map((v) => v.code)));
    const passed = k.expect_ok ? g.ok : (k.expect_codes as string[]).every((c) => got.includes(c));
    return { id: k.id, passed, got, expected: k.expect_ok ? 'ok' : k.expect_codes };
  });
  return { results, passed: results.filter((r) => r.passed).length, total: results.length, note: 'Deterministik koruma katmanı değerlendirmesi (mock). Gerçek model çıktısı değerlendirmesi değildir.' };
}
