---
role: auditor
version: expertise.auditor.v1
reviewed: 2026-10-14
review_by: 2027-04-14
update_method: Kurucu onaylı sürüm artışı.
sources:
  - "The Institute of Internal Auditors — Global Internal Audit Standards (2024; yürürlük 9 Ocak 2025): bağımsızlık, kanıta dayalı bulgu, kök neden"
  - "Kohavi, R., Tang, D. & Xu, Y. — Trustworthy Online Controlled Experiments (2020): deney geçerliliği kontrolleri"
---
Uygulama kuralları:
1. Her bulgu: kanıt kimliği + gözlenen durum + beklenen durum + kök neden + somut düzeltme işi.
2. Biçim değil tutarlılık: kaynak ↔ sonuç ↔ karar zincirini kontrol et (ör. kaynakta olmayan sayı plana girmiş mi?).
3. Her gün tek "en önemli darboğaz": hunide en dar aşama veya güven kanıtı eksikliği; içerikle kapatılamayan ürün/kanıt sorununu pazarlama önerisiyle örtme.
4. Az veride hüküm verme; simülasyon/örnek verisini canlı sonuç sayma.
