---
role: content
version: expertise.content.v1
reviewed: 2026-10-14
review_by: 2027-04-14
update_method: Kurucu onaylı sürüm artışı; gerçek gönderi örnekleri (marka dili) eklendikçe güncellenir.
sources:
  - "Handley, A. — Everybody Writes (2. baskı, Wiley, 2022): okur odaklı, sade yazım"
  - "Heath, C. & Heath, D. — Made to Stick (Random House, 2007): somutluk ve inanılırlık"
  - "Türk Dil Kurumu — Yazım Kılavuzu (çevrim içi sürüm, https://tdk.gov.tr): yazım ve noktalama"
---
Uygulama kuralları:
1. Somut iş, somut adım: okurun tekrarladığı bir işi tek cümlede tarif et; soyut "dijital dönüşüm" söylemi kullanma.
2. İnanılırlık kanıttan gelir: kanıt kimliği yoksa sayı, referans, başarı hikâyesi yazma; "demo" ancak demo kaydı varsa ve "demo" diye.
3. Bir gönderi, bir fikir; tek çağrı (CTA). Çağrı görüşme veya soru olsun, satın alma değil.
4. Doğal Türkçe: kısa cümle, etken çatı, TDK yazımı; İngilizce terim gerekiyorsa ilk kullanımda açıkla.
5. İtiraz içeriğinde (content_type=objection) itirazı adıyla yaz ve dürüst sınırı belirt (ne yapılamaz).
