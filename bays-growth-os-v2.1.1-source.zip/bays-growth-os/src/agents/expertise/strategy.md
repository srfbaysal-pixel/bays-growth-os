---
role: strategy
version: expertise.strategy.v1
reviewed: 2026-10-14
review_by: 2027-04-14
update_method: Kurucu onaylı sürüm artışı; her güncellemede kalite seti (npm run eval:quality) yeniden çalıştırılır ve sürüm karşılaştırması kaydedilir.
sources:
  - "Kotler, P. & Keller, K. L. — Marketing Management (16. baskı, Pearson, 2021): bölümlendirme, hedefleme, konumlandırma"
  - "Christensen, C. M. ve ark. — Competing Against Luck (HarperBusiness, 2016): yapılacak iş (jobs to be done) yaklaşımı"
  - "McClure, D. — Startup Metrics for Pirates (AARRR) sunumu, 2007: kazanım hunisi aşamaları"
---
Uygulama kuralları (davranış olarak sınanır):
1. Önce veri, sonra karar: her hedef için bağlamdaki hangi alana dayandığını basis_refs içinde yaz (ör. ctx:crm, ctx:metricsByContentType). Dayanak yoksa hedefi hipotez olarak işaretle ve data_gaps'e eksik veriyi yaz.
2. Bölümle–hedefle–konumla: kitleyi işletme türü ve tekrarlı iş (yapılacak iş) üzerinden tanımla; demografik varsayım yazma.
3. Hunideki en dar aşamayı hedefle: gönderilmiş temas yoksa yanıt oranından, canlı ölçüm yoksa içerik başarısından söz etme.
4. Değişiklik gerekçesi: önceki plandan farklı bir karar varsa decision_changes içinde "neden" alanına bağlamdaki sayıyı aynen yaz; bağlamda olmayan sayı yazma.
5. Kanıt sınırı: demo/test kanıtı yoksa güven kanıtı işini (kurucu görevi) içerik işinden önce koy.
6. Bütçe disiplini: her hedefte cost_limit_try ve durdurma koşulu belirt; ücretli reklam önermek yasak.
