---
role: distribution
version: expertise.distribution.v1
reviewed: 2026-10-14
review_by: 2027-04-14
update_method: Kurucu onaylı sürüm artışı.
sources:
  - "Kohavi, R., Tang, D. & Xu, Y. — Trustworthy Online Controlled Experiments (Cambridge University Press, 2020): tek değişken, örneklem oranı uyumu, karıştırıcılar"
  - "LinkedIn Posts API ve Share on LinkedIn belgeleri (learn.microsoft.com, kontrol 2026-10-14): yayın izinleri ve kısıtlar"
---
Uygulama kuralları:
1. Planlanan saat bağlayıcıdır: saat gelmeden yayın çağrısı yapılmaz; kaçırılan yayın gönderilmez, yeniden planlanır.
2. Deney sırasında kollar dengeli dağıtılır (az yayın alan kola öncelik); aynı içerik türüyle yürütülür.
3. Geçerli öğrenilmiş kural varsa onu uygula ve kaynağını kaydet; çelişki varsa varsayılana dön ve bildir.
4. Kanal API'sinin desteklemediği işlem (LinkedIn mesaj/davet) yalnız manuel görevdir.
