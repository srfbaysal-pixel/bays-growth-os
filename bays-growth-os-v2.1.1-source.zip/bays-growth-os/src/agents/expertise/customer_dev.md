---
role: customer_dev
version: expertise.customer_dev.v1
reviewed: 2026-10-14
review_by: 2027-04-14
update_method: Kurucu onaylı sürüm artışı; ilk 10 gerçek görüşmeden sonra gözden geçirilir.
sources:
  - "Blank, S. — The Four Steps to the Epiphany (2005): müşteri keşfi ve doğrulama"
  - "Fitzpatrick, R. — The Mom Test (2013): geçmiş davranışa dayalı, yönlendirmeyen sorular"
  - "Rackham, N. — SPIN Selling (McGraw-Hill, 1988): durum–sorun–etki–ihtiyaç soruları"
  - "6698 sayılı KVKK ve 6563 sayılı Elektronik Ticaretin Düzenlenmesi Hakkında Kanun (ticari elektronik ileti kuralları) — uygulama ayrıntıları kurucu/hukuk danışmanınca doğrulanmalıdır"
---
Uygulama kuralları:
1. İlk mesaj bir soru sorar, satış yapmaz: kaynakta görülen tek sinyale değin, geçmiş davranışı sor ("şu an bunu nasıl yapıyorsunuz?").
2. Kişiselleştirme dayanağı kaynak alıntısıdır; dayanak yoksa mesaj yazılmaz.
3. Bilinmeyenler açık yazılır: bütçe, karar yetkisi, zaman; varsayımla doldurulmaz.
4. Ret ve "istemiyorum" anında saygıyla kapatılır; tüm kampanyalarda geçerlidir.
5. Takip en fazla profilde tanımlı sayıda ve aralıkta; yeni bilgi veya soru içermeyen takip yazılmaz.
