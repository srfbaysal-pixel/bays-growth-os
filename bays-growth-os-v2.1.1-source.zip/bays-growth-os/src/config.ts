import { z } from 'zod';

/**
 * Tüm ayarlar ortam değişkenlerinden gelir. Anahtarlar koda veya dosyaya yazılmaz.
 * Varsayılanlar şartnamedeki uygulama varsayımlarıdır ve değiştirilebilir.
 */
const schema = z.object({
  NODE_ENV: z.string().default('development'),
  // Çalışma kipi: simulation = hiçbir dış işlem yapılmaz. live = yalnız durumu "live" olan adaptörler dışarı çıkabilir.
  // eval = yalnız model değerlendirmesi için model sağlayıcısına çağrı; yayın/mesaj/araştırma dış işlemi yok
  RUN_MODE: z.enum(['simulation', 'eval', 'live']).default('simulation'),
  // Ek emniyet: live kipte bile bu açık değilse HTTP çıkışı yapılmaz.
  EGRESS_ENABLED: z.enum(['true', 'false']).default('false'),

  DATABASE_URL_APP: z.string().default('postgres://bays_app:bays_app_local_dev@localhost:5432/bays'),
  DATABASE_URL_AUDITOR: z.string().default('postgres://bays_auditor:bays_auditor_local_dev@localhost:5432/bays'),
  DATABASE_URL_OWNER: z.string().default('postgres://postgres:postgres_local_dev@localhost:5432/bays'),
  APP_DB_PASSWORD: z.string().default('bays_app_local_dev'),
  AUDITOR_DB_PASSWORD: z.string().default('bays_auditor_local_dev'),

  TIMEZONE: z.string().default('Europe/Istanbul'),
  PORT: z.coerce.number().default(8080),

  // Bütçe (TL). Hedef: 5.000. Kesin üst sınır: 10.000. Hedefi kurucu kararıyla en fazla üst sınıra kadar artırılabilir.
  // Üst sınırın kendisi yalnız bu ortam değişkeni değiştirilerek (kurucunun sunucu işlemi) değişir; ajan/panel değiştiremez.
  BUDGET_TARGET_TRY: z.coerce.number().default(5000),
  BUDGET_HARD_CAP_TRY: z.coerce.number().default(10000),
  BUDGET_DAILY_PILOT_LIMIT_TRY: z.coerce.number().default(250),
  BUDGET_WARN_PCTS: z.string().default('70,90'),

  // Yayın: planlanan saatten sonra bu süre içinde gönderilemeyen yayın "missed" olur ve gönderilmez
  PUBLISH_MISSED_GRACE_MINUTES: z.coerce.number().default(180),
  // Müşteriye canlı e-posta ile temas (V2): varsayılan kapalı; kanal canlı + bu bayrak açık + politika uygunsa gönderilir
  CUSTOMER_EMAIL_LIVE: z.enum(['true', 'false']).default('false'),
  // Araştırma sağlayıcısı: brave | fixture | none
  RESEARCH_PROVIDER: z.string().default('none'),
  BRAVE_SEARCH_API_KEY: z.string().default(''),
  RESEARCH_COUNTRY: z.string().default('TR'),
  RESEARCH_LANG: z.string().default('tr'),
  RESEARCH_MAX_QUERIES_PER_DAY: z.coerce.number().default(8),
  RESEARCH_MAX_PAGES_PER_DAY: z.coerce.number().default(20),
  RESEARCH_CACHE_DAYS: z.coerce.number().default(7),
  SOURCE_REFETCH_DAYS: z.coerce.number().default(14),
  RESEARCH_FIXTURE_DIR: z.string().default('tests/fixtures/research'),
  MODEL_JUDGE: z.string().default(''),

  // Görev sınırları
  TASK_MAX_MODEL_CALLS: z.coerce.number().default(6),
  TASK_MAX_RETRIES: z.coerce.number().default(3),
  TASK_TIMEOUT_MS: z.coerce.number().default(120000),
  LOOP_DETECT_WINDOW_HOURS: z.coerce.number().default(24),
  LOOP_DETECT_MAX_SAME_FINGERPRINT: z.coerce.number().default(3),

  // Kurucu girişi: token'ın kendisi değil SHA-256 özeti saklanır
  FOUNDER_TOKEN_SHA256: z.string().default(''),
  // WhatsApp karar yanıtı kabul edilecek kurucu numarası (E.164, + olmadan). Örn: 905xxxxxxxxx
  FOUNDER_WHATSAPP_NUMBER: z.string().default(''),
  FOUNDER_EMAIL: z.string().default(''),
  DECISION_TTL_HOURS: z.coerce.number().default(24),

  // WhatsApp Cloud API (son aşamada bağlanacak)
  WHATSAPP_PHONE_NUMBER_ID: z.string().default(''),
  WHATSAPP_ACCESS_TOKEN: z.string().default(''),
  WHATSAPP_APP_SECRET: z.string().default(''),
  WHATSAPP_VERIFY_TOKEN: z.string().default(''),
  WHATSAPP_GRAPH_VERSION: z.string().default(''),
  WHATSAPP_REPORT_TEMPLATE: z.string().default(''),

  // n8n köprüsü
  N8N_BASE_URL: z.string().default(''),
  N8N_SHARED_SECRET: z.string().default(''),

  // LinkedIn (marka bazlı token'lar BRAND_<SLUG>_LINKEDIN_TOKEN biçiminde)
  LINKEDIN_API_VERSION: z.string().default(''),

  // E-posta yedeği n8n üzerinden gönderilir (n8n Send Email node, SMTP kimliği n8n'de). Webhook yolu:
  N8N_EMAIL_WEBHOOK_PATH: z.string().default('bays-email-send'),

  // Fiyat ve kur yapılandırması (kaynak/tarih zorunlu)
  PRICING_FILE: z.string().default('config/pricing.json'),

  // Model seçimi "sağlayıcı:model" biçiminde. Ekonomik model rutin işlerde, güçlü model strateji/denetimde.
  MODEL_ECONOMY: z.string().default('mock:mock-economy'),
  MODEL_STRONG: z.string().default('mock:mock-strong'),
  // İkinci değerlendirme (denetim) için tercihen farklı sağlayıcı
  MODEL_SECOND_OPINION: z.string().default('mock:mock-strong'),
  ANTHROPIC_API_KEY: z.string().default(''),
  OPENAI_API_KEY: z.string().default(''),
  MODEL_PROVIDER_STATUS: z.string().default('{}'), // ör. {"anthropic":"live"} — doğrulama sonrası kurucu girer

  BACKUP_DIR: z.string().default('backups'),
});

export type Config = z.infer<typeof schema>;

let cached: Config | null = null;
export function config(): Config {
  if (!cached) cached = schema.parse(process.env);
  return cached;
}
/** Testler için: ortamı değiştirip yeniden okuma */
export function reloadConfig(overrides: Partial<Record<keyof Config, string>> = {}): Config {
  cached = schema.parse({ ...process.env, ...overrides });
  return cached;
}

/** Marka bazlı gizli değer erişimi: yalnız istenen markanın değişkenleri okunur. */
export function brandSecret(brandSlug: string, name: string): string | undefined {
  const key = `BRAND_${brandSlug.toUpperCase().replace(/-/g, '_')}_${name}`;
  const v = process.env[key];
  return v && v.length > 0 ? v : undefined;
}
export function brandSecretName(brandSlug: string, name: string): string {
  return `BRAND_${brandSlug.toUpperCase().replace(/-/g, '_')}_${name}`;
}

/** Gizli değerleri günlük/çıktıdan maskeler */
export function maskSecrets(text: string): string {
  const secrets = Object.entries(process.env)
    .filter(([k, v]) => v && v.length >= 8 && /(TOKEN|SECRET|PASSWORD|KEY|DATABASE_URL)/.test(k))
    .map(([, v]) => v as string);
  let out = text;
  for (const s of secrets) out = out.split(s).join('***');
  return out.replace(/(Bearer\s+)[A-Za-z0-9._\-]+/g, '$1***');
}
