import fs from 'node:fs';
import path from 'node:path';
import { withSystem } from './pool.js';
import { logEvent } from '../core/events.js';
import { CAPABILITIES } from '../integrations/capabilities.js';
import { brandSecretName } from '../config.js';

const SEED = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../seed/brands.json');

/** Bağlantılar başlangıçta: aktif markada mock, diğerlerinde disconnected. Gerçek bağlantı yoktur. */
const CONNECTIONS: { channel: string; adapter: string; secrets: string[] }[] = [
  { channel: 'linkedin', adapter: 'linkedin-api', secrets: ['LINKEDIN_TOKEN', 'LINKEDIN_AUTHOR_URN'] },
  { channel: 'linkedin', adapter: 'n8n-linkedin', secrets: ['N8N_LINKEDIN_WEBHOOK_PATH'] },
  { channel: 'whatsapp', adapter: 'whatsapp-cloud', secrets: [] },
  { channel: 'email', adapter: 'n8n-email', secrets: [] },
  { channel: 'instagram', adapter: 'instagram-graph', secrets: ['INSTAGRAM_TOKEN'] },
  { channel: 'x', adapter: 'x-api', secrets: ['X_TOKEN'] },
  { channel: 'web', adapter: 'web-analytics', secrets: [] },
  { channel: 'research', adapter: 'brave-search', secrets: [] },
];
const MOCK_FOR_ACTIVE = new Set(['linkedin-api', 'whatsapp-cloud', 'n8n-email']);

export async function seed(): Promise<{ brands: number }> {
  const data = JSON.parse(fs.readFileSync(SEED, 'utf8'));
  return withSystem(async (c) => {
    for (const b of data.brands) {
      const r = await c.query(
        `INSERT INTO brands (slug, name, status, market, language) VALUES ($1,$2,$3,$4,$5)
         ON CONFLICT (slug) DO UPDATE SET name=EXCLUDED.name RETURNING id`, [b.slug, b.name, b.status, b.market, b.language]);
      const brandId = r.rows[0].id;
      await c.query(`INSERT INTO brand_profiles (brand_id, version, profile, source) VALUES ($1, 1, $2, 'seed/brands.json') ON CONFLICT DO NOTHING`, [brandId, b.profile]);
      for (const o of b.offers) {
        await c.query(`INSERT INTO offers (brand_id, code, title, description, readiness, delivery_note, source, scope, required_connections) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (brand_id, code) DO NOTHING`,
          [brandId, o.code, o.title, o.description, o.readiness, o.delivery_note, o.source, o.scope ?? null, JSON.stringify(o.required_connections ?? [])]);
      }
      for (const cn of CONNECTIONS) {
        const status = b.status === 'active' && MOCK_FOR_ACTIVE.has(cn.adapter) ? 'mock' : 'disconnected';
        await c.query(`INSERT INTO channel_connections (brand_id, channel, adapter, status, capabilities, secret_refs) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT DO NOTHING`,
          [brandId, cn.channel, cn.adapter, status, CAPABILITIES[cn.channel] ?? {}, JSON.stringify(cn.secrets.map((s) => brandSecretName(b.slug, s)))]);
      }
      // Temel politika kayıtları (yalnız kurucu değiştirebilir)
      await c.query(`INSERT INTO knowledge_versions (brand_id, item_key, version, kind, content, source_kind, created_by)
        VALUES ($1, 'policy:core', 1, 'policy', $2, 'founder_statement', 'founder') ON CONFLICT DO NOTHING`, [brandId, {
        paid_ads: 'kapalı', market: b.market, language: b.language,
        claims: 'Kanıtsız özellik, referans, başarı oranı veya garanti kullanılmaz.',
        authority: 'Fiyat, indirim, kesin teslim ve sözleşme taahhüdünü yalnız kurucu verir.',
      }]);
    }
    await logEvent(c, { brandId: null, type: 'seed.applied', actor: 'system', payload: { brands: data.brands.map((b: any) => b.slug) } });
    return { brands: data.brands.length };
  });
}
