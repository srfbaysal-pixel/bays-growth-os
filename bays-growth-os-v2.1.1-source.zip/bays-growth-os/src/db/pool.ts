import pg from 'pg';
import { config } from '../config.js';

export type Db = pg.PoolClient;

let appPool: pg.Pool | null = null;
let auditorPool: pg.Pool | null = null;

export function getAppPool(): pg.Pool {
  if (!appPool) appPool = new pg.Pool({ connectionString: config().DATABASE_URL_APP, max: 10 });
  return appPool;
}
export function getAuditorPool(): pg.Pool {
  if (!auditorPool) auditorPool = new pg.Pool({ connectionString: config().DATABASE_URL_AUDITOR, max: 3 });
  return auditorPool;
}
export async function closePools(): Promise<void> {
  await appPool?.end();
  await auditorPool?.end();
  appPool = null;
  auditorPool = null;
}

async function tx<T>(pool: pg.Pool, setup: (c: Db) => Promise<void>, fn: (c: Db) => Promise<T>): Promise<T> {
  const c = await pool.connect();
  try {
    await c.query('BEGIN');
    await setup(c);
    const r = await fn(c);
    await c.query('COMMIT');
    return r;
  } catch (e) {
    await c.query('ROLLBACK').catch(() => undefined);
    throw e;
  } finally {
    c.release();
  }
}

/** Marka kapsamlı işlem: RLS yalnız bu markanın satırlarını gösterir. */
export function withBrand<T>(brandId: string, fn: (c: Db) => Promise<T>): Promise<T> {
  if (!/^[0-9a-f-]{36}$/.test(brandId)) throw new Error('Geçersiz brand_id');
  return tx(getAppPool(), async (c) => {
    await c.query(`SELECT set_config('app.brand_id', $1, true), set_config('app.scope', 'brand', true)`, [brandId]);
  }, fn);
}

/** Sistem kapsamı: yalnız toplam bütçe, global durdurma, global rapor gibi markalar arası işlerde kullanılır. */
export function withSystem<T>(fn: (c: Db) => Promise<T>): Promise<T> {
  return tx(getAppPool(), async (c) => {
    await c.query(`SELECT set_config('app.scope', 'system', true), set_config('app.brand_id', '', true)`);
  }, fn);
}

/** Denetçi bağlantısı: veritabanı düzeyinde yalnız okuma + bulgu/durdurma/olay ekleme izni vardır. */
export function withAuditor<T>(fn: (c: Db) => Promise<T>): Promise<T> {
  return tx(getAuditorPool(), async (c) => {
    await c.query(`SELECT set_config('app.scope', 'system', true)`);
  }, fn);
}
