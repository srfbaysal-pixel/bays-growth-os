import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';
import { config } from '../config.js';

const MIGRATIONS_DIR = path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../migrations');

/** Uygulama ve denetçi rollerini oluşturur (parolalar ortamdan), ardından sıralı SQL göçlerini uygular. */
export async function migrate(ownerUrl = config().DATABASE_URL_OWNER): Promise<string[]> {
  const client = new pg.Client({ connectionString: ownerUrl });
  await client.connect();
  const applied: string[] = [];
  try {
    for (const [role, pw] of [['bays_app', config().APP_DB_PASSWORD], ['bays_auditor', config().AUDITOR_DB_PASSWORD]] as const) {
      await client.query(`DO $$ BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${role}') THEN
          EXECUTE format('CREATE ROLE ${role} LOGIN NOSUPERUSER NOBYPASSRLS PASSWORD %L', ${pgLiteral(pw)});
        END IF; END $$`);
    }
    await client.query(`CREATE TABLE IF NOT EXISTS schema_migrations (name text PRIMARY KEY, applied_at timestamptz NOT NULL DEFAULT now())`);
    const done = new Set((await client.query('SELECT name FROM schema_migrations')).rows.map((r) => r.name));
    const files = fs.readdirSync(MIGRATIONS_DIR).filter((f) => f.endsWith('.sql')).sort();
    for (const f of files) {
      if (done.has(f)) continue;
      const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, f), 'utf8');
      await client.query('BEGIN');
      try {
        await client.query(sql);
        await client.query('INSERT INTO schema_migrations(name) VALUES ($1)', [f]);
        await client.query('COMMIT');
        applied.push(f);
      } catch (e) {
        await client.query('ROLLBACK');
        throw new Error(`Göç başarısız: ${f}: ${(e as Error).message}`);
      }
    }
  } finally {
    await client.end();
  }
  return applied;
}

function pgLiteral(s: string): string {
  return `'${s.replace(/'/g, "''")}'`;
}

/** Test/simülasyon için veritabanını sıfırdan oluşturur. */
export async function recreateDatabase(dbName: string, serverOwnerUrl: string): Promise<void> {
  if (!/^[a-z0-9_]+$/.test(dbName)) throw new Error('Geçersiz veritabanı adı');
  const c = new pg.Client({ connectionString: serverOwnerUrl });
  await c.connect();
  try {
    await c.query(`SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = $1 AND pid <> pg_backend_pid()`, [dbName]);
    await c.query(`DROP DATABASE IF EXISTS ${dbName}`);
    await c.query(`CREATE DATABASE ${dbName}`);
  } finally {
    await c.end();
  }
}
