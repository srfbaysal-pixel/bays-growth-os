import crypto from 'node:crypto';
import { config } from '../config.js';
import { withSystem } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { sha256, normalizePhone } from '../core/util.js';
import { buttonId, handleDecisionReply, type ReplyOutcome } from '../core/approvals.js';
import { EgressBlockedError, egressFetch, type AdapterStatus } from './egress.js';

/**
 * WhatsApp Cloud API: yalnız kurucuya rapor ve karar kanalı.
 * Belgeye göre: GET doğrulama (hub.mode/hub.verify_token/hub.challenge), POST imzası X-Hub-Signature-256 = sha256=HMAC(App Secret, gövde),
 * en fazla 3 yanıt butonu (başlık ≤20, id ≤256), yanıt webhook'ta interactive.button_reply.id.
 */

export function verifyChallenge(q: Record<string, string | undefined>): string | null {
  const token = config().WHATSAPP_VERIFY_TOKEN;
  if (!token) return null;
  if (q['hub.mode'] === 'subscribe' && q['hub.verify_token'] && timingSafeEq(q['hub.verify_token'], token)) return q['hub.challenge'] ?? null;
  return null;
}

/** İmza ham gövde üzerinden hesaplanır (JSON yeniden serileştirilmez). */
export function verifySignature(rawBody: Buffer | string, header: string | undefined): boolean {
  const secret = config().WHATSAPP_APP_SECRET;
  if (!secret || !header || !header.startsWith('sha256=')) return false;
  const expected = crypto.createHmac('sha256', secret).update(rawBody).digest('hex');
  return timingSafeEq(header.slice(7), expected);
}

function timingSafeEq(a: string, b: string): boolean {
  const x = Buffer.from(a), y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

export interface WebhookResult { ok: boolean; status: number; decisions: ReplyOutcome[]; statuses: number; duplicates: number }

/** Webhook işleme: imza → tekrar önleme → karar yanıtı / mesaj durumu. */
export async function handleWhatsAppWebhook(rawBody: Buffer | string, signatureHeader: string | undefined): Promise<WebhookResult> {
  if (!verifySignature(rawBody, signatureHeader)) return { ok: false, status: 401, decisions: [], statuses: 0, duplicates: 0 };
  const body = JSON.parse(rawBody.toString());
  const out: WebhookResult = { ok: true, status: 200, decisions: [], statuses: 0, duplicates: 0 };
  if (body.object !== 'whatsapp_business_account') return out;
  for (const entry of body.entry ?? []) for (const ch of entry.changes ?? []) {
    const v = ch.value ?? {};
    for (const m of v.messages ?? []) {
      // Tekrar kaydı işlemden SONRA yazılır: işlem hata verirse Meta'nın yeniden denemesi kaybolmaz.
      // Eşzamanlı tekrarlar karar katmanında zaten tek kez uygulanır (talep satırı kilitli, durum "pending" kontrolü).
      if (await alreadySeen('whatsapp', `msg:${m.id}`)) { out.duplicates++; continue; }
      await withSystem((c) => logEvent(c, { brandId: null, type: 'whatsapp.inbound', actor: 'whatsapp', payload: { from_hash: sha256(normalizePhone(m.from ?? '')), type: m.type, id: m.id } }));
      const reply = m.type === 'interactive' && m.interactive?.type === 'button_reply'
        ? { via: 'whatsapp' as const, from: m.from, buttonId: m.interactive.button_reply.id, receivedAt: tsDate(m.timestamp) }
        : m.type === 'text' ? { via: 'whatsapp' as const, from: m.from, text: m.text?.body ?? '', receivedAt: tsDate(m.timestamp) }
        : null; // sesli mesaj vb. V1 kapsamında karar olarak işlenmez
      if (reply) out.decisions.push(await handleDecisionReply(reply));
      await markSeen('whatsapp', `msg:${m.id}`, rawBody);
    }
    for (const s of v.statuses ?? []) {
      if (!(await firstSeen('whatsapp', `st:${s.id}:${s.status}`, rawBody))) { out.duplicates++; continue; }
      out.statuses++;
      const mapped = ['sent', 'delivered', 'read', 'failed'].includes(s.status) ? s.status : null;
      if (mapped) await withSystem(async (c) => {
        // Durum yalnız ileri gider: read > delivered > sent; "failed" ayrıca işlenir. Okundu bilgisi karar verildi demek değildir.
        const order = { queued: 0, sent: 1, delivered: 2, read: 3, failed: 9, skipped: 9 } as Record<string, number>;
        const cur = (await c.query(`SELECT id, status FROM outbound_notifications WHERE channel='whatsapp' AND external_id=$1`, [s.id])).rows[0];
        if (cur && (mapped === 'failed' || order[mapped] > order[cur.status])) await c.query(`UPDATE outbound_notifications SET status=$2, updated_at=now() WHERE id=$1`, [cur.id, mapped]);
      });
    }
  }
  return out;
}

async function firstSeen(provider: string, key: string, raw: Buffer | string): Promise<boolean> {
  return withSystem(async (c) => (await c.query(`INSERT INTO inbound_webhooks (provider, event_key, payload_hash) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING RETURNING id`, [provider, key, sha256(raw.toString())])).rowCount === 1);
}
async function alreadySeen(provider: string, key: string): Promise<boolean> {
  return withSystem(async (c) => (await c.query(`SELECT 1 FROM inbound_webhooks WHERE provider=$1 AND event_key=$2`, [provider, key])).rowCount === 1);
}
async function markSeen(provider: string, key: string, raw: Buffer | string): Promise<void> {
  await firstSeen(provider, key, raw);
}
const tsDate = (t?: string) => (t ? new Date(Number(t) * 1000) : new Date());

// ---------------------------------------------------------------------------
// Gönderim
// ---------------------------------------------------------------------------
/** callState: ücretli şablon gönderiminde rezervasyonun akıbeti (bkz. core/callOutcome.ts). Yoksa "not_sent" sayılır. */
export type SendResult = { ok: true; externalId: string; simulated: boolean } | { ok: false; reason: string; fallback: boolean; callState?: 'not_sent' | 'not_charged' | 'uncertain' };

/** Kurucu son 24 saatte yazmadıysa yalnız onaylı şablon gönderilebilir (ücretli olabilir). */
export async function insideServiceWindow(now = new Date()): Promise<boolean> {
  const founder = config().FOUNDER_WHATSAPP_NUMBER;
  if (!founder) return false;
  // Pencereyi yalnız kurucunun kendi mesajı açar (başka numaralar sayılmaz)
  return withSystem(async (c) => (await c.query(`SELECT 1 FROM operation_events WHERE event_type='whatsapp.inbound' AND payload->>'from_hash' = $2 AND created_at > $1::timestamptz - interval '24 hours' LIMIT 1`, [now, sha256(normalizePhone(founder))])).rowCount === 1);
}

/**
 * Pencere dışı rapor: yalnız onaylı utility şablonuyla. Şablon parametresinde satır sonu kullanılamadığı için özet tek satıra indirgenir.
 * Şablon adı/fiyatı yapılandırılmadan gönderilmez (fiyat bilinmiyorsa bütçe katmanı engeller).
 */
export function buildReportTemplate(to: string, summary: string) {
  const name = config().WHATSAPP_REPORT_TEMPLATE;
  if (!name) return null;
  const text = summary.replace(/\s*\n+\s*/g, ' · ').replace(/ {4,}/g, ' ').slice(0, 900);
  return { messaging_product: 'whatsapp', recipient_type: 'individual', to, type: 'template', template: { name, language: { code: 'tr' }, components: [{ type: 'body', parameters: [{ type: 'text', text }] }] } };
}

export function buildDecisionMessage(a: { code: string; nonce: string; action: string; rationale: string; cost_try: any; limit_note: string | null; expires_at: Date | string; options: { id: string; label: string }[] }, brandName: string, to: string) {
  const body = `Karar ${a.code} · ${brandName}\nİşlem: ${a.action}\nGerekçe: ${a.rationale}\nMaliyet/sınır: ${a.cost_try ?? 'yok'} TL${a.limit_note ? ' · ' + a.limit_note : ''}\nSon: ${new Date(a.expires_at).toLocaleString('tr-TR', { timeZone: 'Europe/Istanbul' })}`.slice(0, 1024);
  if (a.options.length <= 3) {
    return { messaging_product: 'whatsapp', recipient_type: 'individual', to, type: 'interactive',
      interactive: { type: 'button', body: { text: body }, action: { buttons: a.options.map((o) => ({ type: 'reply', reply: { id: buttonId(a.code, o.id, a.nonce), title: o.label.slice(0, 20) } })) } } };
  }
  return { messaging_product: 'whatsapp', recipient_type: 'individual', to, type: 'text', text: { body: `${body}\nYanıt: "${a.code} <seçenek>" veya paneli kullanın. Seçenekler: ${a.options.map((o) => o.id).join(', ')}` } };
}

export async function sendWhatsApp(payload: any, status: AdapterStatus, opts: { template?: boolean } = {}): Promise<SendResult> {
  if (status === 'mock') return { ok: true, externalId: `mock:wamid:${crypto.randomUUID()}`, simulated: true };
  if (status !== 'live') return { ok: false, reason: `WhatsApp bağlantısı ${status}`, fallback: true };
  if (!opts.template && !(await insideServiceWindow())) return { ok: false, reason: '24 saat hizmet penceresi kapalı; onaylı şablon gerekli', fallback: true };
  const cfg = config();
  if (!cfg.WHATSAPP_GRAPH_VERSION || !cfg.WHATSAPP_PHONE_NUMBER_ID) return { ok: false, reason: 'WhatsApp yapılandırması eksik', fallback: true };
  try {
    const res = await egressFetch({ adapter: 'whatsapp-cloud', status, purpose: 'live', allowedHosts: ['graph.facebook.com'], credentialPresent: !!cfg.WHATSAPP_ACCESS_TOKEN,
      url: `https://graph.facebook.com/${cfg.WHATSAPP_GRAPH_VERSION}/${cfg.WHATSAPP_PHONE_NUMBER_ID}/messages`,
      init: { method: 'POST', headers: { authorization: `Bearer ${cfg.WHATSAPP_ACCESS_TOKEN}`, 'content-type': 'application/json' }, body: JSON.stringify(payload) } });
    const j: any = await res.json().catch(() => ({}));
    if (res.ok && j.messages?.[0]?.id) return { ok: true, externalId: j.messages[0].id, simulated: false };
    // 2xx ama ileti kimliği yok veya 5xx: gönderilmiş olabilir → belirsiz; 4xx: kesin reddedildi
    return { ok: false, reason: `WhatsApp ${res.status}`, fallback: true, callState: res.status >= 400 && res.status < 500 ? 'not_charged' : 'uncertain' };
  } catch (e) {
    return { ok: false, reason: (e as Error).message, fallback: true, callState: e instanceof EgressBlockedError ? 'not_sent' : 'uncertain' };
  }
}
