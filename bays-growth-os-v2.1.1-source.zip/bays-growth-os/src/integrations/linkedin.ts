import crypto from 'node:crypto';
import { config, brandSecret } from '../config.js';
import { egressFetch, EgressBlockedError, type AdapterStatus } from './egress.js';

/**
 * Yayın adaptörü sözleşmesi. Sonuçlar dört türdür:
 * - published: dış kimlikle kesin yayın
 * - failed: kesin olarak yayınlanmadı (doğrulama/izin hatası)
 * - retryable: kota/geçici hata, yayınlanmadığı kesin (ör. 429)
 * - unknown: istek gitti ama sonuç bilinmiyor (zaman aşımı) → ASLA tekrar gönderilmez, uzlaştırılır
 */
export type PublishOutcome =
  | { kind: 'published'; externalId: string; simulated: boolean }
  | { kind: 'failed'; error: string; authRevoked?: boolean }
  | { kind: 'retryable'; error: string; quota?: boolean }
  | { kind: 'unknown'; error: string };

export type LookupOutcome = { kind: 'found'; externalId: string } | { kind: 'not_found_definitive' } | { kind: 'unverifiable'; reason: string };

export interface PublishRequest { brandSlug: string; idempotencyKey: string; text: string; hashtags: string[]; imageBrief?: string | null; scheduledAt?: string | null }
export interface PublishAdapter {
  name: string;
  simulated: boolean;
  publish(req: PublishRequest, status: AdapterStatus): Promise<PublishOutcome>;
  lookup(req: { brandSlug: string; idempotencyKey: string }, status: AdapterStatus): Promise<LookupOutcome>;
}

// ---------------------------------------------------------------------------
// Mock LinkedIn: gerçek paylaşım yapmaz. Hata senaryoları test için enjekte edilebilir.
// Uzak taraf durumu süreç belleğinde tutulur (simülasyon).
// ---------------------------------------------------------------------------
type Fault = 'timeout_after_send' | 'timeout_before_send' | 'quota' | 'revoked' | null;
const mockRemote = new Map<string, string>(); // idempotencyKey → externalId
const publishCalls = new Map<string, number>(); // idempotencyKey → publish() çağrı sayısı (yeniden gönderim tespiti)
let nextFault: Fault = null;
export const mockLinkedInControl = {
  injectFault(f: Fault) { nextFault = f; },
  remoteCount(key?: string) { return key ? (mockRemote.has(key) ? 1 : 0) : mockRemote.size; },
  publishCalls(key: string) { return publishCalls.get(key) ?? 0; },
  reset() { mockRemote.clear(); publishCalls.clear(); nextFault = null; },
};

export class MockLinkedInAdapter implements PublishAdapter {
  name = 'mock-linkedin';
  simulated = true;
  async publish(req: PublishRequest): Promise<PublishOutcome> {
    publishCalls.set(req.idempotencyKey, (publishCalls.get(req.idempotencyKey) ?? 0) + 1);
    const f = nextFault; nextFault = null;
    if (f === 'quota') return { kind: 'retryable', error: 'SİMÜLASYON: 429 kota', quota: true };
    if (f === 'revoked') return { kind: 'failed', error: 'SİMÜLASYON: 401 erişim iptal', authRevoked: true };
    if (f === 'timeout_before_send') return { kind: 'unknown', error: 'SİMÜLASYON: zaman aşımı (istek ulaşmadı)' };
    // Uzak taraf da idempotent davranır: aynı anahtar ikinci gönderide yeni gönderi oluşturmaz
    let ext = mockRemote.get(req.idempotencyKey);
    if (!ext) { ext = `mock:linkedin:${crypto.randomUUID()}`; mockRemote.set(req.idempotencyKey, ext); }
    if (f === 'timeout_after_send') return { kind: 'unknown', error: 'SİMÜLASYON: zaman aşımı (gönderi oluştu, yanıt gelmedi)' };
    return { kind: 'published', externalId: ext, simulated: true };
  }
  async lookup(req: { idempotencyKey: string }): Promise<LookupOutcome> {
    const ext = mockRemote.get(req.idempotencyKey);
    return ext ? { kind: 'found', externalId: ext } : { kind: 'not_found_definitive' };
  }
}

// ---------------------------------------------------------------------------
// LinkedIn Posts API (doğrudan). Belge: POST https://api.linkedin.com/rest/posts, x-restli-id yanıt başlığı.
// Not: Üye gönderilerini okumak (r_member_social) kısıtlı olduğundan sonuç sorgulanamaz → belirsiz sonuç manuel uzlaştırılır.
// ---------------------------------------------------------------------------
export class LinkedInApiAdapter implements PublishAdapter {
  name = 'linkedin-api';
  simulated = false;
  async publish(req: PublishRequest, status: AdapterStatus): Promise<PublishOutcome> {
    const token = brandSecret(req.brandSlug, 'LINKEDIN_TOKEN');
    const author = brandSecret(req.brandSlug, 'LINKEDIN_AUTHOR_URN');
    const version = config().LINKEDIN_API_VERSION;
    if (!version) return { kind: 'failed', error: 'LINKEDIN_API_VERSION yapılandırılmamış' };
    const body = {
      author, commentary: `${req.text}\n\n${req.hashtags.join(' ')}`.trim(), visibility: 'PUBLIC',
      distribution: { feedDistribution: 'MAIN_FEED', targetEntities: [], thirdPartyDistributionChannels: [] },
      lifecycleState: 'PUBLISHED', isReshareDisabledByAuthor: false,
    };
    let res: Response;
    try {
      res = await egressFetch({
        adapter: this.name, status, purpose: 'live', allowedHosts: ['api.linkedin.com'], credentialPresent: !!token && !!author,
        url: 'https://api.linkedin.com/rest/posts',
        init: { method: 'POST', headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json', 'Linkedin-Version': version, 'X-Restli-Protocol-Version': '2.0.0' }, body: JSON.stringify(body) },
      });
    } catch (e) {
      if (e instanceof EgressBlockedError) return { kind: 'failed', error: (e as Error).message };
      return { kind: 'unknown', error: (e as Error).message };
    }
    if (res.status === 201) {
      const id = res.headers.get('x-restli-id');
      return id ? { kind: 'published', externalId: id, simulated: false } : { kind: 'unknown', error: '201 ama x-restli-id yok' };
    }
    if (res.status === 429) return { kind: 'retryable', error: '429 kota', quota: true };
    if (res.status === 401 || res.status === 403) return { kind: 'failed', error: `${res.status} yetki`, authRevoked: true };
    if (res.status >= 500) return { kind: 'unknown', error: `${res.status} sunucu hatası (gönderi oluşmuş olabilir)` };
    return { kind: 'failed', error: `${res.status} ${(await res.text()).slice(0, 200)}` };
  }
  async lookup(): Promise<LookupOutcome> {
    return { kind: 'unverifiable', reason: 'Üye gönderisi okuma izni (r_member_social) kısıtlı; kurucu profilden kontrol etmeli' };
  }
}

// ---------------------------------------------------------------------------
// Mevcut n8n LinkedIn akışına köprü. Sözleşme: docs/n8n_adaptor_sozlesmesi.md
// İstek imzası: X-Bays-Signature: sha256=<HMAC-SHA256(N8N_SHARED_SECRET, gövde)>
// ---------------------------------------------------------------------------
export function signBody(body: string, secret: string): string {
  return 'sha256=' + crypto.createHmac('sha256', secret).update(body).digest('hex');
}

export class N8nLinkedInAdapter implements PublishAdapter {
  name = 'n8n-linkedin';
  simulated = false;
  private host(): string { try { return new URL(config().N8N_BASE_URL).host; } catch { return ''; } }
  async publish(req: PublishRequest, status: AdapterStatus): Promise<PublishOutcome> {
    const secret = config().N8N_SHARED_SECRET;
    const path = brandSecret(req.brandSlug, 'N8N_LINKEDIN_WEBHOOK_PATH') ?? 'bays-linkedin-publish';
    const body = JSON.stringify({ contract: 'bays.publish.v1', brand: req.brandSlug, idempotency_key: req.idempotencyKey, text: req.text, hashtags: req.hashtags, image_brief: req.imageBrief ?? null, scheduled_at: req.scheduledAt ?? null });
    let res: Response;
    try {
      res = await egressFetch({
        adapter: this.name, status, purpose: 'live', allowedHosts: [this.host()], credentialPresent: !!secret && !!config().N8N_BASE_URL,
        url: `${config().N8N_BASE_URL.replace(/\/$/, '')}/webhook/${path}`,
        init: { method: 'POST', headers: { 'content-type': 'application/json', 'X-Bays-Signature': signBody(body, secret) }, body },
      });
    } catch (e) {
      if (e instanceof EgressBlockedError) return { kind: 'failed', error: (e as Error).message };
      return { kind: 'unknown', error: (e as Error).message };
    }
    if (res.ok) {
      const j: any = await res.json().catch(() => ({}));
      if (j.status === 'published' && j.external_id) return { kind: 'published', externalId: String(j.external_id), simulated: false };
      if (j.status === 'accepted') return { kind: 'unknown', error: 'n8n kabul etti; sonuç geri çağrıyla gelecek' };
      return { kind: 'unknown', error: 'n8n yanıtı sözleşme dışı' };
    }
    if (res.status === 429) return { kind: 'retryable', error: '429', quota: true };
    if (res.status === 401 || res.status === 403) return { kind: 'failed', error: `${res.status}`, authRevoked: true };
    return { kind: 'unknown', error: `n8n ${res.status}` };
  }
  async lookup(req: { brandSlug: string; idempotencyKey: string }, status: AdapterStatus): Promise<LookupOutcome> {
    const secret = config().N8N_SHARED_SECRET;
    const body = JSON.stringify({ contract: 'bays.publish_status.v1', brand: req.brandSlug, idempotency_key: req.idempotencyKey });
    try {
      const res = await egressFetch({
        adapter: this.name, status, purpose: 'live', allowedHosts: [this.host()], credentialPresent: !!secret,
        url: `${config().N8N_BASE_URL.replace(/\/$/, '')}/webhook/bays-linkedin-status`,
        init: { method: 'POST', headers: { 'content-type': 'application/json', 'X-Bays-Signature': signBody(body, secret) }, body },
      });
      const j: any = await res.json();
      if (j.status === 'published' && j.external_id) return { kind: 'found', externalId: String(j.external_id) };
      if (j.status === 'never_received') return { kind: 'not_found_definitive' };
      return { kind: 'unverifiable', reason: 'n8n durum bilgisi belirsiz' };
    } catch (e) {
      return { kind: 'unverifiable', reason: (e as Error).message };
    }
  }
}

export function publishAdapterFor(adapter: string, status: AdapterStatus): PublishAdapter | null {
  if (status === 'mock') return new MockLinkedInAdapter();
  if (status !== 'live') return null; // disconnected/configured/verified/degraded: canlı yayın yok
  if (adapter === 'linkedin-api') return new LinkedInApiAdapter();
  if (adapter === 'n8n-linkedin') return new N8nLinkedInAdapter();
  return null;
}
