import { config, maskSecrets } from '../config.js';

export type AdapterStatus = 'disconnected' | 'mock' | 'configured' | 'verified' | 'live' | 'degraded';

export class EgressBlockedError extends Error {
  constructor(m: string) { super(m); this.name = 'EgressBlockedError'; }
}

/**
 * Tüm dış HTTP çağrıları buradan geçer. Şu koşulların hepsi sağlanmadan istek atılmaz:
 * RUN_MODE=live, EGRESS_ENABLED=true, adaptör durumu "live" (doğrulama için "verified"), gerekli anahtar mevcut, host izinli.
 */
export async function egressFetch(opts: {
  adapter: string;
  status: AdapterStatus;
  /** live: yayın/mesaj/araştırma gibi canlı dış işlem · verify: bağlantı doğrulama · model: yalnız model sağlayıcısı çağrısı */
  purpose: 'live' | 'verify' | 'model';
  /** İzinli host listesi; "public" yalnız güvenli kaynak okuyucu içindir (host doğrulaması DNS düzeyinde yapılır) */
  allowedHosts: string[] | 'public';
  credentialPresent: boolean;
  url: string;
  init?: RequestInit & { dispatcher?: unknown };
  timeoutMs?: number;
}): Promise<Response> {
  assertEgressAllowed(opts);
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), opts.timeoutMs ?? 30000);
  try {
    // Yönlendirme takip edilmez: izinli hosttan başka hosta kaçış olmasın
    return await realFetch(opts.url, { ...(opts.init as RequestInit), redirect: 'manual', signal: ctrl.signal });
  } catch (e) {
    throw new Error(maskSecrets(`Dış istek hatası (${opts.adapter}): ${(e as Error).message}`));
  } finally {
    clearTimeout(timer);
  }
}


/** Dış çağrı koşullarını denetler; uygun değilse EgressBlockedError fırlatır. Kaynak okuyucu da bunu kullanır. */
export function assertEgressAllowed(opts: { adapter: string; status: AdapterStatus; purpose: 'live' | 'verify' | 'model'; allowedHosts: string[] | 'public'; credentialPresent: boolean; url: string }): void {
  const cfg = config();
  const reasons: string[] = [];
  // Kip ayrımı: simulation → hiçbir dış çağrı; eval → yalnız model değerlendirme çağrısı; live → tümü (diğer koşullarla)
  if (cfg.RUN_MODE === 'simulation') reasons.push('RUN_MODE=simulation');
  if (cfg.RUN_MODE === 'eval' && opts.purpose !== 'model') reasons.push('RUN_MODE=eval: yalnız model değerlendirme çağrısı izinli');
  if (cfg.EGRESS_ENABLED !== 'true') reasons.push('EGRESS_ENABLED kapalı');
  if (!opts.credentialPresent) reasons.push('anahtar yok');
  const okStatus = opts.purpose === 'verify' ? ['configured', 'verified', 'live'] : ['live'];
  if (!okStatus.includes(opts.status)) reasons.push(`adaptör durumu ${opts.status}`);
  const host = safeHost(opts.url);
  if (!host) reasons.push('geçersiz URL');
  else if (opts.allowedHosts !== 'public' && !opts.allowedHosts.includes(host)) reasons.push(`izinsiz host ${host}`);
  if (reasons.length) throw new EgressBlockedError(`Dış istek engellendi (${opts.adapter}): ${reasons.join(', ')}`);
}

function safeHost(u: string): string | null {
  try { return new URL(u).host; } catch { return null; }
}

// Orijinal fetch saklanır; simülasyonda global fetch kapatılır ki adaptör dışı kod da dışarı çıkamasın.
const realFetch: typeof fetch = globalThis.fetch.bind(globalThis);
let guardInstalled = false;
export function installGlobalEgressGuard(): void {
  if (guardInstalled) return;
  guardInstalled = true;
  globalThis.fetch = (async (input: RequestInfo | URL) => {
    const url = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
    const host = safeHost(url);
    if (host && /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/.test(host)) return realFetch(input as any);
    throw new EgressBlockedError(`Global çıkış koruması: ${host} adresine doğrudan fetch yasak; egressFetch kullanılmalı`);
  }) as typeof fetch;
}
