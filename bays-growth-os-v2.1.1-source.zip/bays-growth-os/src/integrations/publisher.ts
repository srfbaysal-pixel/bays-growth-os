import { withBrand, type Db } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { evaluateAction } from '../core/authority.js';
import { publishAdapterFor } from './linkedin.js';
import type { AdapterStatus } from './egress.js';
import { clock } from '../core/clock.js';
import { config } from '../config.js';

/** Kanal için kullanılacak bağlantı: canlı olan tercih edilir; yoksa mock; ikisi de yoksa yok. */
export async function pickConnection(c: Db, brandId: string, channel: string): Promise<{ id: string; adapter: string; status: AdapterStatus } | null> {
  const rows = (await c.query(`SELECT id, adapter, status FROM channel_connections WHERE brand_id=$1 AND channel=$2`, [brandId, channel])).rows;
  return rows.find((r) => r.status === 'live') ?? rows.find((r) => r.status === 'mock') ?? rows[0] ?? null;
}

/** Yayın kuyruğuna alma idempotenttir: aynı anahtar ikinci kayıt oluşturmaz. Yalnız kontrolden geçmiş içerik kuyruğa girer. */
export async function queuePublication(c: Db, p: { brandId: string; campaignId?: string | null; taskId?: string | null; assetId: string; channel: string; idempotencyKey: string; scheduledAt?: Date | null }): Promise<{ id: string; created: boolean }> {
  const a = (await c.query(`SELECT status, brand_id FROM assets WHERE id=$1`, [p.assetId])).rows[0];
  if (!a || a.brand_id !== p.brandId) throw new Error('İçerik bu markaya ait değil');
  if (a.status !== 'passed_checks') throw new Error(`İçerik kontrolden geçmemiş (${a.status})`);
  const conn = await pickConnection(c, p.brandId, p.channel);
  const adapter = conn?.status === 'mock' ? 'mock-linkedin' : conn?.adapter ?? 'none';
  const simulated = conn?.status !== 'live';
  const r = await c.query(
    `INSERT INTO publications (brand_id, campaign_id, task_id, asset_id, channel, adapter, idempotency_key, is_simulated, scheduled_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT (brand_id, idempotency_key) DO NOTHING RETURNING id`,
    [p.brandId, p.campaignId ?? null, p.taskId ?? null, p.assetId, p.channel, adapter, p.idempotencyKey, simulated, p.scheduledAt ?? null]);
  if (!r.rows[0]) return { id: (await c.query(`SELECT id FROM publications WHERE brand_id=$1 AND idempotency_key=$2`, [p.brandId, p.idempotencyKey])).rows[0].id, created: false };
  await logEvent(c, { brandId: p.brandId, type: 'publication.queued', actor: 'distribution', subjectType: 'publication', subjectId: r.rows[0].id, payload: { channel: p.channel, adapter }, simulated });
  return { id: r.rows[0].id, created: true };
}

export type ExecResult = { status: string; skipped?: boolean; reason?: string; externalId?: string; dueAt?: string };

/**
 * Yayını yürütür. Dış çağrıdan önce kayıt "sending" olarak işlenir ve işlem kapanır;
 * böylece süreç çökse bile kayıt belirsiz olarak kalır ve tekrar gönderilmez.
 */
export async function executePublication(brandId: string, pubId: string, brandSlug: string, now: Date = clock.now()): Promise<ExecResult> {
  const prep = await withBrand(brandId, async (c) => {
    const p = (await c.query(`SELECT p.*, a.content FROM publications p JOIN assets a ON a.id=p.asset_id WHERE p.id=$1 FOR UPDATE OF p`, [pubId])).rows[0];
    if (!p) throw new Error('Yayın yok');
    if (p.status !== 'queued') return { skip: { status: p.status, skipped: true, reason: 'yalnız kuyruktaki yayın yürütülür' } as ExecResult };
    // Planlanan saat dış çağrının gerçek koşuludur: saat gelmeden hiçbir adaptör çağrılmaz
    if (p.scheduled_at && now < new Date(p.scheduled_at)) return { skip: { status: 'queued', skipped: true, reason: 'not_due', dueAt: new Date(p.scheduled_at).toISOString() } as ExecResult };
    // Kaçırılmış yayın: tolerans süresi geçtiyse gönderilmez; "missed" olur ve yeniden planlama dağıtım rolüne bırakılır
    const graceMs = config().PUBLISH_MISSED_GRACE_MINUTES * 60_000;
    if (p.scheduled_at && now.getTime() > new Date(p.scheduled_at).getTime() + graceMs) {
      await c.query(`UPDATE publications SET status='missed', error=$2 WHERE id=$1`, [pubId, `Planlanan saat (${new Date(p.scheduled_at).toISOString()}) ${config().PUBLISH_MISSED_GRACE_MINUTES} dk toleransla kaçırıldı; gönderilmedi`]);
      await logEvent(c, { brandId, type: 'publication.missed', actor: 'distribution', subjectType: 'publication', subjectId: pubId, payload: { scheduledAt: p.scheduled_at, now: now.toISOString() }, simulated: p.is_simulated });
      return { skip: { status: 'missed', skipped: true, reason: 'missed' } as ExecResult };
    }
    const d = await evaluateAction(c, { brandId, action: 'publish.routine', channel: p.channel, campaignId: p.campaign_id, external: true });
    if (d.decision !== 'allow') {
      const st = d.reasons.some((r) => r.startsWith('Durdurma')) ? 'halted' : 'cancelled';
      await c.query(`UPDATE publications SET status=$2, error=$3 WHERE id=$1`, [pubId, st, d.reasons.join('; ')]);
      return { skip: { status: st, skipped: true, reason: d.reasons.join('; ') } as ExecResult };
    }
    const conn = await pickConnection(c, brandId, p.channel);
    const adapter = conn ? publishAdapterFor(conn.adapter, conn.status) : null;
    if (!conn || !adapter) {
      await c.query(`UPDATE publications SET status='manual_required', error='Canlı/mock bağlantı yok; taslak kurucuya manuel görev olarak bırakıldı' WHERE id=$1`, [pubId]);
      await logEvent(c, { brandId, type: 'publication.manual_required', actor: 'distribution', subjectType: 'publication', subjectId: pubId, simulated: p.is_simulated });
      return { skip: { status: 'manual_required', skipped: true } as ExecResult };
    }
    if (adapter.simulated !== p.is_simulated) throw new Error('Yayın simülasyon işareti ile adaptör uyuşmuyor');
    await c.query(`UPDATE publications SET status='sending', attempts=attempts+1, sent_at=now() WHERE id=$1`, [pubId]);
    await logEvent(c, { brandId, type: 'publication.sending', actor: 'distribution', subjectType: 'publication', subjectId: pubId, payload: { adapter: adapter.name }, simulated: p.is_simulated });
    return { p, conn, adapter };
  });
  if ('skip' in prep) return prep.skip!;
  const { p, conn, adapter } = prep;
  const outcome = await adapter.publish({ brandSlug, idempotencyKey: p.idempotency_key, text: p.content.post_text, hashtags: p.content.hashtags ?? [], imageBrief: p.content.image_brief, scheduledAt: p.scheduled_at }, conn.status);

  return withBrand(brandId, async (c) => {
    const ev = (type: string, payload: any = {}) => logEvent(c, { brandId, type, actor: 'distribution', subjectType: 'publication', subjectId: pubId, payload, simulated: p.is_simulated });
    switch (outcome.kind) {
      case 'published':
        await c.query(`UPDATE publications SET status='published', external_id=$2, error=NULL WHERE id=$1`, [pubId, outcome.externalId]);
        await c.query(`UPDATE assets SET status='published' WHERE id=$1`, [p.asset_id]);
        await ev('publication.published', { externalId: outcome.externalId });
        return { status: 'published', externalId: outcome.externalId };
      case 'retryable': {
        const next = p.attempts + 1 >= 3 ? 'failed' : 'queued';
        await c.query(`UPDATE publications SET status=$2, error=$3 WHERE id=$1`, [pubId, next, outcome.error]);
        if (outcome.quota) await c.query(`UPDATE channel_connections SET status='degraded', last_error=$2, updated_at=now() WHERE id=$1 AND status IN ('live','mock')`, [conn.id, `kota: ${outcome.error}`]);
        await ev('publication.retryable', { error: outcome.error, next });
        return { status: next, reason: outcome.error };
      }
      case 'failed':
        await c.query(`UPDATE publications SET status='failed', error=$2 WHERE id=$1`, [pubId, outcome.error]);
        if (outcome.authRevoked) {
          await c.query(`UPDATE channel_connections SET status='degraded', last_error=$2, updated_at=now() WHERE id=$1`, [conn.id, `erişim iptal/yetki: ${outcome.error}`]);
          await logEvent(c, { brandId, type: 'alert.raised', actor: 'distribution', subjectType: 'channel_connection', subjectId: conn.id, payload: { reason: 'Bağlantı yetkisi iptal edilmiş olabilir', error: outcome.error }, simulated: p.is_simulated });
        }
        await ev('publication.failed', { error: outcome.error });
        return { status: 'failed', reason: outcome.error };
      case 'unknown':
        await c.query(`UPDATE publications SET status='outcome_unknown', error=$2 WHERE id=$1`, [pubId, outcome.error]);
        await ev('publication.outcome_unknown', { error: outcome.error });
        return { status: 'outcome_unknown', reason: outcome.error };
    }
  });
}

/** Belirsiz sonucu tekrar göndermeden uzlaştırır. */
export async function reconcilePublication(brandId: string, pubId: string, brandSlug: string): Promise<ExecResult> {
  const p = await withBrand(brandId, async (c) => (await c.query(`SELECT * FROM publications WHERE id=$1`, [pubId])).rows[0]);
  if (!['outcome_unknown', 'sending'].includes(p.status)) return { status: p.status, skipped: true };
  const conn = await withBrand(brandId, (c) => pickConnection(c, brandId, p.channel));
  const adapter = conn ? publishAdapterFor(conn.adapter, conn.status) : null;
  const look = adapter ? await adapter.lookup({ brandSlug, idempotencyKey: p.idempotency_key }, conn!.status) : { kind: 'unverifiable' as const, reason: 'Bağlantı yok' };
  return withBrand(brandId, async (c) => {
    await c.query(`UPDATE publications SET last_checked_at=now() WHERE id=$1`, [pubId]);
    const ev = (type: string, payload: any = {}) => logEvent(c, { brandId, type, actor: 'distribution', subjectType: 'publication', subjectId: pubId, payload, simulated: p.is_simulated });
    if (look.kind === 'found') {
      await c.query(`UPDATE publications SET status='published', external_id=$2, error=NULL WHERE id=$1`, [pubId, look.externalId]);
      await c.query(`UPDATE assets SET status='published' WHERE id=$1`, [p.asset_id]);
      await ev('publication.reconciled', { result: 'found', externalId: look.externalId });
      return { status: 'published', externalId: look.externalId };
    }
    if (look.kind === 'not_found_definitive') {
      await c.query(`UPDATE publications SET status='failed', error='Uzlaştırma: uzak tarafta yok. Otomatik yeniden gönderim yapılmadı; dağıtım rolü yeni kayıtla yeniden planlayabilir.' WHERE id=$1`, [pubId]);
      await ev('publication.reconciled', { result: 'not_found' });
      return { status: 'failed', reason: 'uzak tarafta yok' };
    }
    await c.query(`UPDATE publications SET status='manual_required', error=$2 WHERE id=$1`, [pubId, `Uzlaştırılamadı: ${look.reason}`]);
    await logEvent(c, { brandId, type: 'alert.raised', actor: 'distribution', subjectType: 'publication', subjectId: pubId, payload: { reason: 'Yayın sonucu doğrulanamadı; kurucu kontrol etmeli', detail: look.reason }, simulated: p.is_simulated });
    return { status: 'manual_required', reason: look.reason };
  });
}
