/**
 * Kanal yetenek matrisi (belge kontrol tarihi 14.10.2026). "docs/kanal_yetenek_matrisi.md" ile aynı içeriktir.
 * supported: resmî belgeye göre genel geliştiriciye açık görünen işlem (hesapta yine doğrulanmalı)
 * restricted: onaylı iş ortaklığı gerekir → sistemde taslak/manuel görev
 * unsupported / unverified: kapalı
 */
export type CapState = 'supported' | 'restricted' | 'unsupported' | 'unverified';
export interface ChannelCapabilities {
  research: CapState; publish: CapState; measure: CapState; inbound_message: CapState; first_message: CapState; connection_request: CapState;
  sources: { title: string; url: string; checked: string }[];
  notes: string[];
}

export const CAPABILITIES: Record<string, ChannelCapabilities> = {
  linkedin: {
    research: 'unverified', publish: 'supported', measure: 'restricted', inbound_message: 'restricted', first_message: 'restricted', connection_request: 'restricted',
    sources: [
      { title: 'Posts API', url: 'https://learn.microsoft.com/en-us/linkedin/marketing/community-management/shares/posts-api', checked: '2026-10-14' },
      { title: 'Share on LinkedIn (w_member_social)', url: 'https://learn.microsoft.com/en-us/linkedin/consumer/integrations/self-serve/share-on-linkedin', checked: '2026-10-14' },
      { title: 'Messages API (kısıtlı)', url: 'https://learn.microsoft.com/en-us/linkedin/shared/integrations/communications/messages', checked: '2026-10-14' },
      { title: 'Invitations API (kısıtlı)', url: 'https://learn.microsoft.com/en-us/linkedin/shared/integrations/communications/invitations', checked: '2026-10-14' },
    ],
    notes: ['Yayın erişimi mesaj/bağlantı erişiminin kanıtı değildir.', 'r_member_social kısıtlı: ölçüm manuel/n8n geri bildirimi.'],
  },
  whatsapp: {
    research: 'unsupported', publish: 'unsupported', measure: 'supported', inbound_message: 'supported', first_message: 'restricted', connection_request: 'unsupported',
    sources: [
      { title: 'Webhooks getting started', url: 'https://developers.facebook.com/docs/graph-api/webhooks/getting-started', checked: '2026-10-14' },
      { title: 'Reply buttons', url: 'https://developers.facebook.com/docs/whatsapp/cloud-api/messages/interactive-reply-buttons-messages', checked: '2026-10-14' },
      { title: 'Pricing', url: 'https://developers.facebook.com/docs/whatsapp/pricing', checked: '2026-10-14' },
    ],
    notes: ['Bu sistemde yalnız kurucu rapor/karar kanalı.', '24 saat penceresi dışında yalnız onaylı şablon (ücretli).', 'Müşteriye ilk mesaj kapsam dışı.'],
  },
  instagram: {
    research: 'unverified', publish: 'supported', measure: 'unverified', inbound_message: 'unverified', first_message: 'unverified', connection_request: 'unsupported',
    sources: [{ title: 'Content publishing', url: 'https://developers.facebook.com/docs/instagram-platform/content-publishing', checked: '2026-10-14' }],
    notes: ['Profesyonel hesap gerekir; 24 saatte yayın sınırı var.'],
  },
  x: {
    research: 'unverified', publish: 'supported', measure: 'unverified', inbound_message: 'unverified', first_message: 'unverified', connection_request: 'unsupported',
    sources: [{ title: 'X API pricing', url: 'https://docs.x.com/x-api/getting-started/pricing', checked: '2026-10-14' }],
    notes: ['Kullandıkça öde; ücretsiz katman belirtilmemiş. Fiyat yapılandırmaya girilmeden kapalı.'],
  },
  email: {
    research: 'unsupported', publish: 'unsupported', measure: 'unverified', inbound_message: 'unverified', first_message: 'supported', connection_request: 'unsupported',
    sources: [],
    notes: ['İlk temas için alıcının iş iletişim adresi kaynaklı olmalı; iletişim istemeyenler listesi uygulanır. Ticari ileti mevzuatı kurucu tarafından ayrıca değerlendirilmeli.'],
  },
  web: {
    research: 'unverified', publish: 'unsupported', measure: 'unverified', inbound_message: 'unsupported', first_message: 'unsupported', connection_request: 'unsupported',
    sources: [], notes: ['Analitik aracı seçilmedi.'],
  },
};

export function can(channel: string, op: keyof Omit<ChannelCapabilities, 'sources' | 'notes'>): CapState {
  return CAPABILITIES[channel]?.[op] ?? 'unsupported';
}
