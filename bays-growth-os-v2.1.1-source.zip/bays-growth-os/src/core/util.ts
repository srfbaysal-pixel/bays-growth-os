import crypto from 'node:crypto';

export const sha256 = (s: string) => crypto.createHash('sha256').update(s).digest('hex');

export function stableStringify(v: unknown): string {
  if (v === null || typeof v !== 'object') return JSON.stringify(v);
  if (Array.isArray(v)) return `[${v.map(stableStringify).join(',')}]`;
  const o = v as Record<string, unknown>;
  return `{${Object.keys(o).sort().filter((k) => o[k] !== undefined).map((k) => `${JSON.stringify(k)}:${stableStringify(o[k])}`).join(',')}}`;
}

export function monthKey(d: Date, tz = 'Europe/Istanbul'): string {
  const p = new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit' }).formatToParts(d);
  return `${p.find((x) => x.type === 'year')!.value}-${p.find((x) => x.type === 'month')!.value}`;
}
export function dayKey(d: Date, tz = 'Europe/Istanbul'): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit' }).format(d);
}

/** Türkçe karakterleri sadeleştirip işletme anahtarı üretir (mükerrer temas önleme). */
export function normalizeBusinessKey(input: { name: string; city?: string | null; domain?: string | null; phone?: string | null }): string {
  if (input.domain) return 'd:' + input.domain.toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
  if (input.phone) return 'p:' + normalizePhone(input.phone);
  const fold = (s: string) => s.toLocaleLowerCase('tr-TR')
    .replace(/ı/g, 'i').replace(/ğ/g, 'g').replace(/ü/g, 'u').replace(/ş/g, 's').replace(/ö/g, 'o').replace(/ç/g, 'c')
    .replace(/\b(ltd|şti|sti|a\.ş|as|limited|şirketi|sirketi|ticaret|tic|san)\b\.?/g, '')
    .replace(/[^a-z0-9]+/g, ' ').trim();
  return 'n:' + fold(input.name) + '|' + fold(input.city ?? '');
}
export function normalizePhone(p: string): string {
  let d = p.replace(/\D/g, '');
  if (d.startsWith('0')) d = '90' + d.slice(1);
  return d;
}
export function normalizeEmail(e: string): string {
  return e.trim().toLowerCase();
}

export function shortCode(prefix = 'K'): string {
  // Karışmaya açık harfler (0/O, 1/I) çıkarıldı
  const alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  const bytes = crypto.randomBytes(6);
  let s = '';
  for (const b of bytes) s += alphabet[b % alphabet.length];
  return `${prefix}-${s}`;
}

export const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
