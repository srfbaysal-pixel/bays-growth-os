import crypto from 'node:crypto';
import { config } from '../config.js';
import { withSystem, type Db } from '../db/pool.js';
import { logEvent } from './events.js';
import { dayKey, monthKey } from './util.js';
import { round2, toTry, type Estimate } from './pricing.js';
import { callStateOf, CALL_STATE_TR, type CallState } from './callOutcome.js';

export type Mode = 'live' | 'simulation';

export class BudgetBlockedError extends Error {
  constructor(public readonly reason: 'monthly_limit' | 'daily_limit' | 'simulated_price_in_live' | 'invalid', message: string) { super(message); }
}

export interface Limits { activeLimitTry: number; hardCapTry: number; dailyLimitTry: number; warnPcts: number[] }

export async function getLimits(c: Db): Promise<Limits> {
  const cfg = config();
  const r = await c.query(`SELECT value FROM settings WHERE key = 'budget.active_limit_try'`);
  const stored = r.rows[0]?.value?.amount as number | undefined;
  const hard = cfg.BUDGET_HARD_CAP_TRY;
  // Saklanan değer ne olursa olsun kesin üst sınırı aşamaz
  const active = Math.min(stored ?? cfg.BUDGET_TARGET_TRY, hard);
  return { activeLimitTry: active, hardCapTry: hard, dailyLimitTry: cfg.BUDGET_DAILY_PILOT_LIMIT_TRY, warnPcts: cfg.BUDGET_WARN_PCTS.split(',').map(Number) };
}

/** Ay içi taahhüt edilmiş tutar = gerçekleşen gider + henüz uzlaştırılmamış rezervasyonlar (süresi dolanlar dahil, temkinli). */
export async function committed(c: Db, mode: Mode, month: string, day?: string): Promise<{ ledger: number; reserved: number; total: number; byCategory: Record<string, number> }> {
  const l = await c.query(`SELECT category, coalesce(sum(amount_try),0)::float8 AS s FROM cost_ledger WHERE mode=$1 AND month=$2 ${day ? "AND (occurred_at AT TIME ZONE 'Europe/Istanbul')::date = $3::date" : ''} GROUP BY category`, day ? [mode, month, day] : [mode, month]);
  const rsv = await c.query(`SELECT coalesce(sum(est_try),0)::float8 AS s FROM budget_reservations WHERE mode=$1 AND month=$2 AND status IN ('active','expired','uncertain') ${day ? 'AND day = $3::date' : ''}`, day ? [mode, month, day] : [mode, month]);
  const byCategory: Record<string, number> = {};
  let ledger = 0;
  for (const row of l.rows) { byCategory[row.category] = round2(row.s); ledger += row.s; }
  const reserved = rsv.rows[0].s as number;
  return { ledger: round2(ledger), reserved: round2(reserved), total: round2(ledger + reserved), byCategory };
}

export interface ReserveInput { brandId: string; mode: Mode; provider: string; estimate: Estimate; taskId?: string | null; ttlMinutes?: number; now?: Date; callRef?: string | null }
export interface ReserveResult { reservationId: string; warnings: string[]; totalAfter: number; limit: number }

/**
 * Atomik rezervasyon: aynı ay/kip için danışma kilidi alınır, toplam + yeni tahmin sınırı aşıyorsa reddedilir.
 * Eşzamanlı istekler kilit sırasıyla işlenir; toplam hiçbir zaman sınırı geçemez.
 */
export async function reserveBudget(input: ReserveInput): Promise<ReserveResult> {
  const now = input.now ?? new Date();
  if (!(input.estimate.tryAmount >= 0) || !Number.isFinite(input.estimate.tryAmount)) throw new BudgetBlockedError('invalid', 'Geçersiz maliyet tahmini');
  if (input.mode === 'live' && input.estimate.simulatedOnly) throw new BudgetBlockedError('simulated_price_in_live', 'Simülasyon fiyatı canlı işte kullanılamaz');
  const month = monthKey(now);
  const day = dayKey(now);
  return withSystem(async (c) => {
    await c.query(`SELECT pg_advisory_xact_lock(hashtext($1))`, [`budget:${input.mode}:${month}`]);
    const lim = await getLimits(c);
    const cm = await committed(c, input.mode, month);
    const est = input.estimate.tryAmount;
    if (cm.total + est > lim.activeLimitTry) {
      await logEvent(c, { brandId: input.brandId, type: 'budget.blocked', actor: 'budget', payload: { reason: 'monthly_limit', committed: cm.total, est, limit: lim.activeLimitTry, mode: input.mode }, simulated: input.mode === 'simulation' });
      throw new BudgetBlockedError('monthly_limit', `Aylık bütçe sınırı: ${cm.total} + ${est} > ${lim.activeLimitTry} TL. Yeni ücretli işlem engellendi.`);
    }
    if (input.mode === 'live') {
      const cd = await committed(c, input.mode, month, day);
      if (cd.total + est > lim.dailyLimitTry) {
        await logEvent(c, { brandId: input.brandId, type: 'budget.blocked', actor: 'budget', payload: { reason: 'daily_limit', committed: cd.total, est, limit: lim.dailyLimitTry } });
        throw new BudgetBlockedError('daily_limit', `Günlük pilot sınırı: ${cd.total} + ${est} > ${lim.dailyLimitTry} TL`);
      }
    }
    const expires = new Date(now.getTime() + (input.ttlMinutes ?? 30) * 60_000);
    const r = await c.query(
      `INSERT INTO budget_reservations (brand_id, mode, month, day, category, provider, est_try, task_id, expires_at, call_ref)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING id`,
      [input.brandId, input.mode, month, day, input.estimate.category, input.provider, est, input.taskId ?? null, expires, input.callRef ?? `call:${crypto.randomUUID()}`],
    );
    const after = round2(cm.total + est);
    const warnings: string[] = [];
    for (const pct of lim.warnPcts) {
      const th = (lim.activeLimitTry * pct) / 100;
      if (cm.total < th && after >= th) warnings.push(`Bütçenin %${pct}'i aşıldı (${after}/${lim.activeLimitTry} TL)`);
    }
    for (const w of warnings) await logEvent(c, { brandId: null, type: 'budget.warning', actor: 'budget', payload: { message: w, mode: input.mode }, simulated: input.mode === 'simulation' });
    return { reservationId: r.rows[0].id, warnings, totalAfter: after, limit: lim.activeLimitTry };
  });
}

export interface Actual { amountOriginal: number; currency: string; item: string; externalRef?: string | null; succeeded: boolean; isRetry?: boolean }

/** Gerçek giderle uzlaştırma. Aynı rezervasyon iki kez deftere yazılmaz (idempotency anahtarı). */
export async function reconcileReservation(reservationId: string, actual: Actual): Promise<{ amountTry: number; overrun: boolean }> {
  return withSystem(async (c) => {
    const r = (await c.query(`SELECT * FROM budget_reservations WHERE id = $1 FOR UPDATE`, [reservationId])).rows[0];
    if (!r) throw new Error('Rezervasyon yok');
    if (r.status === 'reconciled') return { amountTry: Number(r.actual_try), overrun: Number(r.actual_try) > Number(r.est_try) };
    if (r.status === 'released') throw new Error('Serbest bırakılmış rezervasyon uzlaştırılamaz');
    const fx = toTry(actual.amountOriginal, actual.currency);
    await c.query(
      `INSERT INTO cost_ledger (brand_id, mode, month, category, provider, item, amount_original, currency, fx_rate, fx_source, fx_date, amount_try,
         reservation_id, task_id, external_ref, idempotency_key, is_retry, succeeded)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18) ON CONFLICT (idempotency_key) DO NOTHING`,
      [r.brand_id, r.mode, r.month, r.category, r.provider, actual.item, actual.amountOriginal, actual.currency, fx.fxRate, fx.fxSource, fx.fxDate, fx.tryAmount,
        reservationId, r.task_id, actual.externalRef ?? null, `res:${reservationId}`, actual.isRetry ?? false, actual.succeeded],
    );
    await c.query(`UPDATE budget_reservations SET status='reconciled', actual_try=$2 WHERE id=$1`, [reservationId, fx.tryAmount]);
    const overrun = fx.tryAmount > Number(r.est_try);
    if (overrun) await logEvent(c, { brandId: r.brand_id, type: 'budget.overrun', actor: 'budget', subjectType: 'reservation', subjectId: reservationId, payload: { est: Number(r.est_try), actual: fx.tryAmount }, simulated: r.mode === 'simulation' });
    return { amountTry: fx.tryAmount, overrun };
  });
}

/**
 * Ücretli çağrı başarısız olduğunda rezervasyonun akıbeti (bkz. core/callOutcome.ts):
 * yalnız "çağrı yapılmadı" veya "sağlayıcı kesin reddetti" ise serbest bırakılır; belirsizse "uncertain" kalır,
 * bütçe toplamında sayılmaya devam eder ve kurucuya uzlaştırma işi açılır.
 */
export async function settleFailedCall(reservationId: string, e: unknown, label: string): Promise<CallState> {
  const state = callStateOf(e);
  const msg = (e as Error)?.message ?? String(e);
  if (state === 'uncertain') await markUncertain(reservationId, `${label}: ${msg}`);
  else await releaseReservation(reservationId, `${label}: ${CALL_STATE_TR[state]} — ${msg}`);
  return state;
}

/** Belirsiz gider: rezervasyon "uncertain" olur (toplamda sayılır), kurucuya tek bir uzlaştırma işi açılır. */
export async function markUncertain(reservationId: string, note: string): Promise<void> {
  await withSystem(async (c) => {
    const r = (await c.query(`UPDATE budget_reservations SET status='uncertain', outcome_note=$2 WHERE id=$1 AND status IN ('active','expired') RETURNING *`, [reservationId, note.slice(0, 500)])).rows[0];
    if (!r) return;
    await c.query(
      `INSERT INTO manual_tasks (brand_id, kind, channel, payload, dedupe_key, is_simulated) VALUES ($1,'reconcile_cost',NULL,$2,$3,$4)
       ON CONFLICT (brand_id, dedupe_key, is_simulated) DO NOTHING`,
      [r.brand_id, { reservationId, provider: r.provider, category: r.category, estimateTry: Number(r.est_try), callRef: r.call_ref, note: `Ücretli çağrının sonucu belirsiz (${note.slice(0, 200)}). Sağlayıcı panelinden/faturadan bu çağrının ücretlenip ücretlenmediğini kontrol edin ve "ücretlendi (tutar)" veya "ücretlenmedi" olarak kapatın. O zamana kadar tahmini tutar (${Number(r.est_try)} TL) bütçede sayılır.` }, `reconcile_cost:${reservationId}`, r.mode === 'simulation']);
    await logEvent(c, { brandId: r.brand_id, type: 'budget.uncertain', actor: 'budget', subjectType: 'reservation', subjectId: reservationId, payload: { note: note.slice(0, 300), est: Number(r.est_try) }, simulated: r.mode === 'simulation' });
  });
}

/**
 * Kurucunun belirsiz gider kararı. İdempotent: rezervasyon bir kez sonuçlanır; ikinci çağrı deftere yazmaz.
 * charged=true → gerçek tutarla deftere bir kez yazılır; charged=false → bırakılır.
 */
export async function resolveUncertainCost(reservationId: string, r: { charged: boolean; amountOriginal?: number; currency?: string; by: string; externalRef?: string | null }): Promise<{ status: 'reconciled' | 'released' | 'already_resolved' }> {
  const cur = await withSystem(async (c) => (await c.query(`SELECT * FROM budget_reservations WHERE id=$1`, [reservationId])).rows[0]);
  if (!cur) throw Object.assign(new Error('Rezervasyon yok'), { statusCode: 404 });
  if (!['uncertain', 'expired', 'active'].includes(cur.status)) return { status: 'already_resolved' };
  if (r.charged) {
    if (!(Number(r.amountOriginal) >= 0) || !r.currency) throw Object.assign(new Error('Ücretlenen tutar ve para birimi gerekli'), { statusCode: 400 });
    await reconcileReservation(reservationId, { amountOriginal: Number(r.amountOriginal), currency: r.currency, item: `${cur.provider}:uzlaştırma`, succeeded: false, externalRef: r.externalRef ?? null });
    await withSystem((c) => c.query(`UPDATE budget_reservations SET resolved_at=now(), resolved_by=$2 WHERE id=$1`, [reservationId, r.by]));
    return { status: 'reconciled' };
  }
  const ok = await withSystem(async (c) => (await c.query(`UPDATE budget_reservations SET status='released', resolved_at=now(), resolved_by=$2 WHERE id=$1 AND status IN ('uncertain','expired','active') RETURNING brand_id, mode`, [reservationId, r.by])).rows[0]);
  if (!ok) return { status: 'already_resolved' };
  await withSystem((c) => logEvent(c, { brandId: ok.brand_id, type: 'budget.released', actor: r.by, subjectId: reservationId, payload: { reason: 'kurucu: ücretlenmedi' }, simulated: ok.mode === 'simulation' }));
  return { status: 'released' };
}

/** Çağrı hiç yapılmadıysa rezervasyon serbest bırakılır. */
export async function releaseReservation(reservationId: string, reason: string): Promise<void> {
  await withSystem(async (c) => {
    const r = await c.query(`UPDATE budget_reservations SET status='released' WHERE id=$1 AND status='active' RETURNING brand_id, mode`, [reservationId]);
    if (r.rows[0]) await logEvent(c, { brandId: r.rows[0].brand_id, type: 'budget.released', actor: 'budget', subjectId: reservationId, payload: { reason }, simulated: r.rows[0].mode === 'simulation' });
  });
}

/** Süresi geçmiş rezervasyonlar "expired" olur ama toplamda sayılmaya devam eder; denetçi uzlaştırma ister. */
export async function markExpiredReservations(now = new Date()): Promise<number> {
  return withSystem(async (c) => (await c.query(`UPDATE budget_reservations SET status='expired' WHERE status='active' AND expires_at < $1`, [now])).rowCount ?? 0);
}

/**
 * Aktif bütçe sınırını değiştirir. Yalnız onaylanmış "budget.change_limit" kurucu kararıyla;
 * kesin üst sınırı (BUDGET_HARD_CAP_TRY) hiçbir koşulda aşamaz.
 */
export async function applyBudgetLimitDecision(c: Db, approvalId: string): Promise<number> {
  const a = (await c.query(`SELECT * FROM approval_requests WHERE id = $1`, [approvalId])).rows[0];
  if (!a || a.action !== 'budget.change_limit' || a.status !== 'approved' || a.decided_option !== 'approve') throw new Error('Geçerli bir kurucu bütçe kararı yok');
  const amount = Number(a.params.newLimitTry);
  const hard = config().BUDGET_HARD_CAP_TRY;
  if (!(amount > 0) || amount > hard) throw new Error(`Yeni sınır ${amount} TL kesin üst sınırı (${hard} TL) aşamaz`);
  await c.query(`INSERT INTO settings (key, value, updated_by) VALUES ('budget.active_limit_try', $1, $2)
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_by = EXCLUDED.updated_by, updated_at = now()`, [{ amount, approvalId }, `founder:${a.decided_via}`]);
  await logEvent(c, { brandId: a.brand_id, type: 'budget.limit_changed', actor: 'founder', subjectType: 'approval', subjectId: approvalId, payload: { amount } });
  return amount;
}
