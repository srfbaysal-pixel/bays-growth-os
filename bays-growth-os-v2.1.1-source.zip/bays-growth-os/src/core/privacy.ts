import fs from 'node:fs';
import path from 'node:path';
import { withBrand, type Db } from '../db/pool.js';
import { logEvent } from './events.js';
import { addSuppression, suppressionKey } from '../crm/crm.js';

/**
 * Kişisel veri silme. Kişi alanları boşaltılır, ilgili etkileşim içerikleri karartılır,
 * kişi tekrar iletişime alınmasın diye özet (hash) iletişim istemeyenler listesine eklenir.
 * Silme kaydı veritabanı dışında da (yalnız özetlerle) tutulur: eski bir yedek geri yüklenirse silme yeniden uygulanır.
 */
export const ERASURE_LEDGER = () => path.resolve(process.env.ERASURE_LEDGER_FILE ?? 'data/erasure-ledger.jsonl');

export async function eraseContact(c: Db, brandId: string, contactId: string, requestedBy: string): Promise<void> {
  const ct = (await c.query(`SELECT * FROM contacts WHERE id=$1 AND brand_id=$2`, [contactId, brandId])).rows[0];
  if (!ct) throw new Error('Kişi bulunamadı');
  const keys: { type: 'email' | 'phone'; value: string }[] = [];
  if (ct.email) keys.push({ type: 'email', value: ct.email });
  if (ct.phone) keys.push({ type: 'phone', value: ct.phone });
  if (keys.length) await addSuppression(c, brandId, keys, 'kişisel veri silme talebi');
  await c.query(`UPDATE contacts SET full_name=NULL, role_title=NULL, email=NULL, phone=NULL, linkedin_url=NULL, erased_at=now() WHERE id=$1`, [contactId]);
  await c.query(`UPDATE interactions SET content='{"redacted": true}'::jsonb WHERE contact_id=$1`, [contactId]);
  const hashes = keys.map((k) => suppressionKey(k.type, k.value));
  for (const h of hashes) await c.query(`INSERT INTO erasure_log (brand_id, subject_key_hash, key_type, requested_by) VALUES ($1,$2,'contact',$3)`, [brandId, h, requestedBy]);
  await c.query(`INSERT INTO erasure_log (brand_id, subject_key_hash, key_type, requested_by) VALUES ($1,$2,'contact_id',$3)`, [brandId, contactId, requestedBy]);
  await logEvent(c, { brandId, type: 'privacy.contact_erased', actor: requestedBy, subjectType: 'contact', subjectId: contactId });
  fs.mkdirSync(path.dirname(ERASURE_LEDGER()), { recursive: true });
  fs.appendFileSync(ERASURE_LEDGER(), JSON.stringify({ brand_id: brandId, contact_id: contactId, key_hashes: hashes, at: new Date().toISOString() }) + '\n');
}

/** Geri yüklemeden sonra çalıştırılır: veritabanı dışı silme kaydındaki kişileri yeniden siler. */
export async function reapplyErasures(): Promise<number> {
  const file = ERASURE_LEDGER();
  if (!fs.existsSync(file)) return 0;
  let n = 0;
  for (const line of fs.readFileSync(file, 'utf8').split('\n').filter(Boolean)) {
    const e = JSON.parse(line);
    await withBrand(e.brand_id, async (c) => {
      const ct = (await c.query(`SELECT id, erased_at FROM contacts WHERE id=$1`, [e.contact_id])).rows[0];
      if (ct && !ct.erased_at) {
        await c.query(`UPDATE contacts SET full_name=NULL, role_title=NULL, email=NULL, phone=NULL, linkedin_url=NULL, erased_at=now() WHERE id=$1`, [e.contact_id]);
        await c.query(`UPDATE interactions SET content='{"redacted": true}'::jsonb WHERE contact_id=$1`, [e.contact_id]);
        n++;
      }
      for (const h of e.key_hashes as string[]) {
        await c.query(`INSERT INTO suppression_entries (brand_id, scope, key_type, key_hash, reason) VALUES ($1,'brand','email',$2,'silme kaydı yeniden uygulandı') ON CONFLICT DO NOTHING`, [e.brand_id, h]);
      }
      if (ct && !ct.erased_at) await logEvent(c, { brandId: e.brand_id, type: 'privacy.erasure_reapplied', actor: 'system', subjectType: 'contact', subjectId: e.contact_id });
    });
  }
  return n;
}

/** Saklama politikası: kaybedilen/beklemedeki adayların kişi bilgileri belirtilen günden sonra silinir. */
export async function applyRetention(c: Db, brandId: string, days = 365): Promise<number> {
  const r = await c.query(`SELECT ct.id FROM contacts ct JOIN leads l ON l.id=ct.lead_id
     WHERE ct.brand_id=$1 AND ct.erased_at IS NULL AND l.stage IN ('lost','on_hold') AND l.updated_at < now() - make_interval(days => $2)`, [brandId, days]);
  for (const row of r.rows) await eraseContact(c, brandId, row.id, 'retention_policy');
  return r.rowCount ?? 0;
}
