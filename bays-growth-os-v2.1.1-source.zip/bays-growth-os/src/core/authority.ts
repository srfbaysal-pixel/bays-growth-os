import type { Db } from '../db/pool.js';
import { activeHaltFor } from './halts.js';
import { config } from '../config.js';

/**
 * Yetki politikası. Bu tablo koddadır ve ajanlar tarafından değiştirilemez.
 * - auto: rutin, kurucu onayı gerektirmez (teknik doğrulama ve denetim yine çalışır)
 * - founder: açık kurucu kararı gerekir (WhatsApp/panel karar talebi)
 * - forbidden: hiçbir koşulda yürütülmez (ücretli reklam vb.)
 */
export const POLICY = {
  'research.sourced': 'auto',
  'draft.create': 'auto',
  'classify': 'auto',
  'report.generate': 'auto',
  'report.send': 'auto',
  'metric.ingest': 'auto',
  'publish.routine': 'auto',
  'reply.routine': 'auto',
  'contact.first': 'auto', // ek uygunluk/kanal/iletişim kuralı kontrolleriyle
  'experiment.start': 'auto', // gider sınırı ve kampanya planı içinde

  'budget.change_limit': 'founder',
  'credit.purchase': 'founder',
  'paid_service.new': 'founder',
  'market.new': 'founder',
  'channel.new_access': 'founder',
  'pricing.quote': 'founder',
  'pricing.discount': 'founder',
  'commitment.delivery': 'founder',
  'commitment.contract': 'founder',
  'offer.major_change': 'founder',
  'permission.change': 'founder',
  'brand.activate': 'founder',
  'meeting.schedule': 'founder',
  'halt.resume': 'founder',

  'ads.create': 'forbidden',
  'ads.spend': 'forbidden',
  'credit.auto_topup': 'forbidden',
  'policy.modify_by_agent': 'forbidden',
  'budget.hard_cap_change': 'forbidden',
  'account.bypass_limits': 'forbidden',
} as const;

export type Action = keyof typeof POLICY;
export type Decision = { decision: 'allow' | 'needs_founder' | 'deny'; reasons: string[] };

export interface ActionContext {
  brandId: string;
  action: string;
  channel?: string | null;
  campaignId?: string | null;
  external?: boolean; // dış sistemde etki yaratır mı (yayın/mesaj)
  approvalId?: string | null; // kurucu kararı varsa
}

export async function evaluateAction(c: Db, ctx: ActionContext): Promise<Decision> {
  const reasons: string[] = [];
  const rule = (POLICY as Record<string, string>)[ctx.action];
  if (!rule) return { decision: 'deny', reasons: [`Tanımsız işlem: ${ctx.action}. Serbest metin yetkiye dönüşmez.`] };
  if (rule === 'forbidden') return { decision: 'deny', reasons: [`${ctx.action} politika gereği kapalı`] };

  const brand = (await c.query(`SELECT status FROM brands WHERE id=$1`, [ctx.brandId])).rows[0];
  if (!brand) return { decision: 'deny', reasons: ['Marka yok'] };
  if (brand.status === 'disabled') return { decision: 'deny', reasons: ['Marka devre dışı'] };
  if (brand.status === 'draft' && ctx.external && config().RUN_MODE === 'live') return { decision: 'deny', reasons: ['Taslak markada canlı dış işlem yapılamaz'] };

  if (ctx.external || ctx.channel || ctx.campaignId) {
    const h = await activeHaltFor(c, { brandId: ctx.brandId, channel: ctx.channel, campaignId: ctx.campaignId });
    if (h) return { decision: 'deny', reasons: [`Durdurma aktif (${h.scope}): ${h.reason}`] };
  }

  if (rule === 'founder') {
    if (!ctx.approvalId) return { decision: 'needs_founder', reasons: [`${ctx.action} kurucu kararı gerektirir`] };
    const a = (await c.query(`SELECT action, status, decided_option, brand_id FROM approval_requests WHERE id=$1`, [ctx.approvalId])).rows[0];
    if (!a || a.action !== ctx.action || a.brand_id !== ctx.brandId) return { decision: 'deny', reasons: ['Karar bu işleme ait değil'] };
    if (a.status !== 'approved' || a.decided_option !== 'approve') return { decision: 'deny', reasons: ['Kurucu onayı yok'] };
    reasons.push('Kurucu kararıyla onaylı');
  }
  return { decision: 'allow', reasons };
}
