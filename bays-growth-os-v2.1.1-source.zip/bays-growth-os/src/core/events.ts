import type { Db } from '../db/pool.js';
import { maskSecrets } from '../config.js';

export interface EventInput {
  brandId: string | null;
  type: string;
  actor: string;
  subjectType?: string;
  subjectId?: string;
  payload?: Record<string, unknown>;
  simulated?: boolean;
}

/** Değişmez işlem günlüğüne kayıt ekler (zincir özeti veritabanı tetikleyicisinde hesaplanır). */
export async function logEvent(c: Db, e: EventInput): Promise<number> {
  const payload = JSON.parse(maskSecrets(JSON.stringify(e.payload ?? {})));
  const r = await c.query(
    `INSERT INTO operation_events (brand_id, event_type, actor, subject_type, subject_id, payload, is_simulated)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id`,
    [e.brandId, e.type, e.actor, e.subjectType ?? null, e.subjectId ?? null, payload, e.simulated ?? false],
  );
  return Number(r.rows[0].id);
}

/**
 * Zincir bütünlüğünü doğrular (sistem/denetçi kapsamında çağrılmalı): sıra numarasına göre her kaydın
 * önceki özeti taşıdığını ve kendi özetinin içerikten yeniden hesaplanınca aynı çıktığını kontrol eder.
 */
export async function verifyEventChain(c: Db): Promise<{ ok: boolean; brokenAt?: number; count: number; reason?: string }> {
  const rows = (await c.query(`SELECT seq, prev_hash, hash,
      operation_events_hash(prev_hash, brand_id, event_type, actor, subject_type, subject_id, payload, created_at, seq) AS recomputed
    FROM operation_events ORDER BY seq`)).rows;
  let prev = 'genesis';
  let expectSeq = 1;
  for (const r of rows) {
    if (Number(r.seq) !== expectSeq) return { ok: false, brokenAt: Number(r.seq), count: rows.length, reason: 'sıra boşluğu' };
    if (r.prev_hash !== prev) return { ok: false, brokenAt: Number(r.seq), count: rows.length, reason: 'önceki özet uyuşmuyor' };
    if (r.recomputed !== r.hash) return { ok: false, brokenAt: Number(r.seq), count: rows.length, reason: 'içerik özeti uyuşmuyor' };
    prev = r.hash;
    expectSeq++;
  }
  return { ok: true, count: rows.length };
}
