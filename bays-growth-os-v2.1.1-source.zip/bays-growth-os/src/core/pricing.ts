import fs from 'node:fs';
import path from 'node:path';
import { z } from 'zod';
import { config } from '../config.js';

/**
 * Fiyat tablosu yapılandırmadan gelir; her kalemde kaynak ve tarih zorunludur.
 * Fiyatı null olan kalem "bilinmiyor" demektir ve sıfır sayılmaz: ücretli iş engellenir.
 */
const fxSchema = z.object({ rate: z.number().positive().nullable(), source: z.string(), date: z.string() });
const itemSchema = z.object({
  category: z.enum(['model', 'research', 'image', 'video', 'hosting', 'notification', 'other']),
  currency: z.string(),
  unit: z.enum(['call', 'mtok', 'image', 'second', 'month', 'message']),
  price: z.number().nonnegative().nullable().optional(),
  inputPerMTok: z.number().nonnegative().nullable().optional(),
  outputPerMTok: z.number().nonnegative().nullable().optional(),
  source: z.string(),
  date: z.string(),
  simulatedOnly: z.boolean().optional(),
});
const fileSchema = z.object({
  _note: z.string().optional(),
  fx: z.record(z.string(), fxSchema),
  items: z.record(z.string(), itemSchema),
});
export type PricingFile = z.infer<typeof fileSchema>;
export type PriceItem = z.infer<typeof itemSchema>;

export class PriceUnknownError extends Error {
  constructor(public readonly key: string, reason: string) {
    super(`Fiyat bilinmiyor (${key}): ${reason}. Ücretli iş başlatılmadı.`);
  }
}

let cache: PricingFile | null = null;
export function loadPricing(file = config().PRICING_FILE): PricingFile {
  if (!cache) cache = fileSchema.parse(JSON.parse(fs.readFileSync(path.resolve(file), 'utf8')));
  return cache;
}
export function setPricingForTests(p: PricingFile | null): void {
  cache = p ? fileSchema.parse(p) : null;
}

export interface Estimate { tryAmount: number; original: number; currency: string; fxRate: number; fxSource: string; fxDate: string; category: PriceItem['category']; simulatedOnly: boolean }

export function toTry(amount: number, currency: string, p = loadPricing()): { tryAmount: number; fxRate: number; fxSource: string; fxDate: string } {
  if (currency === 'TRY') return { tryAmount: amount, fxRate: 1, fxSource: 'TRY', fxDate: new Date().toISOString().slice(0, 10) };
  const fx = p.fx[currency];
  if (!fx || fx.rate == null || !fx.source || !fx.date) throw new PriceUnknownError(`fx:${currency}`, 'kur, kaynağı veya tarihi eksik');
  return { tryAmount: round2(amount * fx.rate), fxRate: fx.rate, fxSource: fx.source, fxDate: fx.date };
}

/** Bir işin tahmini üst maliyeti. Model için: tahmini giriş + azami çıkış token'ı üzerinden üst sınır. */
export function estimateCost(key: string, usage: { inputTokens?: number; maxOutputTokens?: number; units?: number }, p = loadPricing()): Estimate {
  const it = p.items[key];
  if (!it) throw new PriceUnknownError(key, 'fiyat tablosunda kalem yok');
  if (!it.source || !it.date) throw new PriceUnknownError(key, 'fiyat kaynağı/tarihi eksik');
  let original: number;
  if (it.unit === 'mtok') {
    if (it.inputPerMTok == null || it.outputPerMTok == null) throw new PriceUnknownError(key, 'token fiyatı girilmemiş');
    original = ((usage.inputTokens ?? 0) * it.inputPerMTok + (usage.maxOutputTokens ?? 0) * it.outputPerMTok) / 1_000_000;
  } else {
    if (it.price == null) throw new PriceUnknownError(key, 'birim fiyat girilmemiş');
    original = (usage.units ?? 1) * it.price;
  }
  const fx = toTry(original, it.currency, p);
  return { tryAmount: fx.tryAmount, original, currency: it.currency, fxRate: fx.fxRate, fxSource: fx.fxSource, fxDate: fx.fxDate, category: it.category, simulatedOnly: !!it.simulatedOnly };
}

export const round2 = (n: number) => Math.round(n * 100) / 100;
