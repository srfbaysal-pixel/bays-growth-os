import crypto from 'node:crypto';
import { config } from '../config.js';
import { withSystem, type Db } from '../db/pool.js';
import { logEvent } from './events.js';
import { normalizePhone, shortCode } from './util.js';
import { POLICY } from './authority.js';
import { applyBudgetLimitDecision } from './budget.js';

export interface DecisionOption { id: string; label: string }
export interface DecisionRequestInput {
  brandId: string;
  action: string;
  params?: Record<string, unknown>;
  rationale: string;
  costTry?: number | null;
  limitNote?: string | null;
  options?: DecisionOption[];
  ttlHours?: number;
  taskId?: string | null;
  simulated?: boolean;
}

const DEFAULT_OPTIONS: DecisionOption[] = [{ id: 'approve', label: 'Onayla' }, { id: 'reject', label: 'Reddet' }];

export async function createDecisionRequest(c: Db, d: DecisionRequestInput) {
  if ((POLICY as Record<string, string>)[d.action] !== 'founder') throw new Error(`${d.action} kurucu kararı gerektiren bir işlem değil`);
  const options = d.options ?? DEFAULT_OPTIONS;
  if (options.some((o) => !/^[a-z_]{1,20}$/.test(o.id) || o.label.length > 20)) throw new Error('Seçenek kimliği/etiketi geçersiz (WhatsApp buton sınırları)');
  const code = shortCode('K');
  const nonce = crypto.randomBytes(8).toString('hex');
  const expires = new Date(Date.now() + (d.ttlHours ?? config().DECISION_TTL_HOURS) * 3600_000);
  const r = await c.query(
    `INSERT INTO approval_requests (brand_id, code, action, params, rationale, cost_try, limit_note, options, nonce, expires_at, task_id, is_simulated)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [d.brandId, code, d.action, d.params ?? {}, d.rationale, d.costTry ?? null, d.limitNote ?? null, JSON.stringify(options), nonce, expires, d.taskId ?? null, d.simulated ?? false],
  );
  if (d.taskId) await c.query(`UPDATE tasks SET status='waiting_decision', updated_at=now() WHERE id=$1`, [d.taskId]);
  await logEvent(c, { brandId: d.brandId, type: 'decision.requested', actor: 'system', subjectType: 'approval', subjectId: r.rows[0].id, payload: { code, action: d.action }, simulated: d.simulated });
  return r.rows[0];
}

/** WhatsApp buton kimliği: talebe ve tek kullanımlık değere bağlıdır. */
export const buttonId = (code: string, optionId: string, nonce: string) => `dec:${code}:${optionId}:${nonce}`;

export type ReplyOutcome =
  | { status: 'applied'; code: string; option: string }
  | { status: 'rejected'; reason: 'unauthorized' | 'unknown_request' | 'expired' | 'already_decided' | 'invalid_option' | 'ambiguous' | 'bad_nonce' };

export interface DecisionReply {
  via: 'whatsapp' | 'panel';
  from?: string; // whatsapp gönderen numara
  founderAuthenticated?: boolean; // panel
  buttonId?: string;
  text?: string;
  receivedAt?: Date;
}

/**
 * Kurucu yanıtını işler. Yalnız yetkili numaradan/oturumdan, yalnız ilgili talebe, süresi içinde ve bir kez uygulanır.
 * Serbest metin yalnız "K-XXXXXX SEÇENEK" kalıbında kabul edilir; diğer her şey belirsiz sayılır.
 */
export async function handleDecisionReply(reply: DecisionReply): Promise<ReplyOutcome> {
  const now = reply.receivedAt ?? new Date();
  if (reply.via === 'whatsapp') {
    const allowed = config().FOUNDER_WHATSAPP_NUMBER;
    if (!allowed || !reply.from || normalizePhone(reply.from) !== normalizePhone(allowed)) return { status: 'rejected', reason: 'unauthorized' };
  } else if (!reply.founderAuthenticated) return { status: 'rejected', reason: 'unauthorized' };

  let code: string | undefined, option: string | undefined, nonce: string | undefined;
  if (reply.buttonId) {
    const m = /^dec:(K-[A-Z0-9]{6}):([a-z_]{1,20}):([0-9a-f]{16})$/.exec(reply.buttonId);
    if (!m) return { status: 'rejected', reason: 'ambiguous' };
    [, code, option, nonce] = m;
  } else if (reply.text) {
    const m = /^\s*(K-[A-Z0-9]{6})\s+([A-Za-zçÇğĞıİöÖşŞüÜ_]{2,20})\s*$/.exec(reply.text.toLocaleUpperCase('tr-TR'));
    if (!m) return { status: 'rejected', reason: 'ambiguous' };
    code = m[1];
    option = ({ ONAYLA: 'approve', ONAY: 'approve', REDDET: 'reject', RED: 'reject' } as Record<string, string>)[m[2]] ?? m[2].toLocaleLowerCase('tr-TR');
  } else return { status: 'rejected', reason: 'ambiguous' };

  return withSystem(async (c) => {
    const a = (await c.query(`SELECT * FROM approval_requests WHERE code=$1 FOR UPDATE`, [code])).rows[0];
    const reject = async (reason: Extract<ReplyOutcome, { status: 'rejected' }>['reason']) => {
      await logEvent(c, { brandId: a?.brand_id ?? null, type: 'decision.reply_rejected', actor: `founder:${reply.via}`, subjectType: 'approval', subjectId: a?.id, payload: { reason, code } });
      return { status: 'rejected', reason } as const;
    };
    if (!a) return reject('unknown_request');
    if (a.status !== 'pending') return reject('already_decided');
    if (new Date(a.expires_at) < now) {
      await c.query(`UPDATE approval_requests SET status='expired' WHERE id=$1`, [a.id]);
      return reject('expired');
    }
    if (nonce !== undefined && nonce !== a.nonce) return reject('bad_nonce');
    const opts = a.options as DecisionOption[];
    if (!opts.some((o) => o.id === option)) return reject('invalid_option');
    // Yalnız "approve" onaydır; "reject" reddir; diğer seçenekler talebi işlem yapmadan kapatır (bağlı görev beklemede kalır)
    const status = option === 'approve' ? 'approved' : option === 'reject' ? 'rejected' : 'cancelled';
    await c.query(`UPDATE approval_requests SET status=$2, decided_option=$3, decided_by='founder', decided_via=$4, decided_at=$5 WHERE id=$1`, [a.id, status, option, reply.via, now]);
    await logEvent(c, { brandId: a.brand_id, type: 'decision.applied', actor: `founder:${reply.via}`, subjectType: 'approval', subjectId: a.id, payload: { code, option }, simulated: a.is_simulated });
    await executeDecision(c, a.id);
    return { status: 'applied', code: code!, option: option! };
  });
}

/** Önceden tanımlı işlemlerin karar sonrası yürütülmesi. Tanımsız işlem için yürütme yoktur. */
async function executeDecision(c: Db, approvalId: string): Promise<void> {
  const a = (await c.query(`SELECT * FROM approval_requests WHERE id=$1`, [approvalId])).rows[0];
  if (a.status !== 'approved' || a.decided_option !== 'approve') return;
  if (a.action === 'budget.change_limit') await applyBudgetLimitDecision(c, approvalId);
  if (a.action === 'meeting.schedule' && a.params.meetingId) {
    await c.query(`UPDATE meetings SET status='scheduled', scheduled_at=$2 WHERE id=$1 AND brand_id=$3`, [a.params.meetingId, a.params.slot ?? null, a.brand_id]);
  }
  if (a.task_id && (a.status === 'approved' || a.status === 'rejected')) {
    await c.query(`UPDATE tasks SET status = $2, updated_at=now() WHERE id=$1 AND status='waiting_decision'`, [a.task_id, a.status === 'approved' ? 'queued' : 'cancelled']);
  }
}

export async function expireDecisions(now = new Date()): Promise<number> {
  return withSystem(async (c) => {
    const r = await c.query(`UPDATE approval_requests SET status='expired' WHERE status='pending' AND expires_at < $1 RETURNING id, task_id, brand_id`, [now]);
    for (const row of r.rows) await logEvent(c, { brandId: row.brand_id, type: 'decision.expired', actor: 'system', subjectType: 'approval', subjectId: row.id });
    return r.rowCount ?? 0;
  });
}
