import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { config } from '../config.js';
import { recreateDatabase } from '../db/migrate.js';

/**
 * Yedekleme: pg_dump özel biçim (-Fc). Veritabanında anahtar/parola yoktur (yalnız ortam değişkeni adları).
 * Geri yükleme hedefi ayrı bir veritabanıdır; ardından veritabanı dışı silme kaydı yeniden uygulanmalıdır (reapplyErasures).
 */
function parse(url: string) {
  const u = new URL(url);
  return { host: u.hostname, port: u.port || '5432', user: decodeURIComponent(u.username), password: decodeURIComponent(u.password), db: u.pathname.slice(1) };
}
const env = (p: ReturnType<typeof parse>) => ({ ...process.env, PGPASSWORD: p.password });

export function backupDatabase(outFile?: string, ownerUrl = config().DATABASE_URL_OWNER): string {
  const p = parse(ownerUrl);
  const file = path.resolve(outFile ?? path.join(config().BACKUP_DIR, `bays-${new Date().toISOString().replace(/[:.]/g, '-')}.dump`));
  fs.mkdirSync(path.dirname(file), { recursive: true });
  execFileSync('pg_dump', ['-Fc', '-h', p.host, '-p', p.port, '-U', p.user, '-d', p.db, '-f', file], { env: env(p) });
  return file;
}

/** Yedeği hedef veritabanına geri yükler (hedef sıfırdan oluşturulur). */
export async function restoreDatabase(file: string, targetDb: string, ownerUrl = config().DATABASE_URL_OWNER): Promise<void> {
  const p = parse(ownerUrl);
  const serverUrl = new URL(ownerUrl); serverUrl.pathname = '/postgres';
  await recreateDatabase(targetDb, serverUrl.toString());
  execFileSync('pg_restore', ['-h', p.host, '-p', p.port, '-U', p.user, '-d', targetDb, '--no-owner', '--exit-on-error', file], { env: env(p) });
}
