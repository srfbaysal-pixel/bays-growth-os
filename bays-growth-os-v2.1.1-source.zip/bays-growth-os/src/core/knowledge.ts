import type { Db } from '../db/pool.js';
import { logEvent } from './events.js';

export type KnowledgeKind = 'raw_research' | 'hypothesis' | 'verified_rule' | 'policy' | 'shared_method_summary';

export interface KnowledgeInput {
  brandId: string;
  itemKey: string;
  kind: KnowledgeKind;
  content: Record<string, unknown>;
  sourceUri?: string | null;
  sourceKind: string; // ör. 'web', 'founder_statement', 'experiment', 'sample'
  observedAt?: Date;
  validUntil?: Date | null;
  createdBy: string; // rol veya 'founder'
  experimentId?: string | null;
  isSample?: boolean;
  validity?: 'current' | 'unverified' | 'needs_retest';
}

const PII_PATTERNS = [/[\w.+-]+@[\w-]+\.[\w.]+/, /(\+?90|0)?\s?5\d{2}[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}/, /linkedin\.com\/in\//i];

/** Yeni sürüm ekler; önceki "current" sürüm "superseded" olur. Politika kayıtlarını yalnız kurucu yazabilir. */
export async function addKnowledge(c: Db, k: KnowledgeInput): Promise<{ id: string; version: number }> {
  if (k.kind === 'policy' && k.createdBy !== 'founder') throw new Error('Politika/temel kural ajan tarafından değiştirilemez');
  if (k.kind === 'raw_research' && !k.sourceUri && k.sourceKind !== 'founder_statement') throw new Error('Ham araştırma kaynak gerektirir');
  if (k.kind === 'verified_rule' && !k.experimentId && k.createdBy !== 'founder') throw new Error('Doğrulanmış kural deney kanıtı veya kurucu beyanı gerektirir');
  await c.query(`SELECT pg_advisory_xact_lock(hashtext($1))`, [`kn:${k.brandId}:${k.itemKey}`]);
  const prev = (await c.query(`SELECT id, version, kind FROM knowledge_versions WHERE brand_id=$1 AND item_key=$2 ORDER BY version DESC LIMIT 1`, [k.brandId, k.itemKey])).rows[0];
  if (prev?.kind === 'policy' && k.createdBy !== 'founder') throw new Error('Politika anahtarı ajan tarafından değiştirilemez');
  const version = (prev?.version ?? 0) + 1;
  const r = await c.query(
    `INSERT INTO knowledge_versions (brand_id, item_key, version, kind, content, source_uri, source_kind, observed_at, valid_until, validity, created_by, supersedes, experiment_id, is_sample)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING id`,
    [k.brandId, k.itemKey, version, k.kind, k.content, k.sourceUri ?? null, k.sourceKind, k.observedAt ?? new Date(), k.validUntil ?? null,
      k.validity ?? 'current', k.createdBy, prev?.id ?? null, k.experimentId ?? null, k.isSample ?? false],
  );
  if (prev) await c.query(`UPDATE knowledge_versions SET validity='superseded' WHERE id=$1 AND validity IN ('current','unverified','needs_retest')`, [prev.id]);
  await logEvent(c, { brandId: k.brandId, type: 'knowledge.version_added', actor: k.createdBy, subjectType: 'knowledge', subjectId: r.rows[0].id, payload: { itemKey: k.itemKey, version, kind: k.kind }, simulated: k.isSample });
  return { id: r.rows[0].id, version };
}

/** Bir anahtarın son geçerli sürümünü geri alır; bir önceki sürüm yeniden "current" olur. */
export async function rollbackKnowledge(c: Db, brandId: string, itemKey: string, actor: string, reason: string): Promise<{ restoredVersion: number | null }> {
  const rows = (await c.query(`SELECT id, version, validity, kind FROM knowledge_versions WHERE brand_id=$1 AND item_key=$2 ORDER BY version DESC`, [brandId, itemKey])).rows;
  const cur = rows.find((r) => r.validity === 'current' || r.validity === 'needs_retest' || r.validity === 'unverified');
  if (!cur) throw new Error('Geri alınacak geçerli sürüm yok');
  if (cur.kind === 'policy' && actor !== 'founder') throw new Error('Politika geri alma kurucu işidir');
  await c.query(`UPDATE knowledge_versions SET validity='rolled_back' WHERE id=$1`, [cur.id]);
  const prev = rows.find((r) => r.version < cur.version && r.validity === 'superseded');
  if (prev) await c.query(`UPDATE knowledge_versions SET validity='current' WHERE id=$1`, [prev.id]);
  await logEvent(c, { brandId, type: 'knowledge.rolled_back', actor, subjectType: 'knowledge', subjectId: cur.id, payload: { itemKey, rolledBackVersion: cur.version, restoredVersion: prev?.version ?? null, reason } });
  return { restoredVersion: prev?.version ?? null };
}

export async function currentKnowledge(c: Db, brandId: string, kinds: KnowledgeKind[], now = new Date()) {
  const r = await c.query(
    `SELECT * FROM knowledge_versions WHERE brand_id=$1 AND kind = ANY($2) AND validity IN ('current','needs_retest','unverified')
     ORDER BY item_key, version DESC`, [brandId, kinds]);
  // Güncellik kontrolü: süresi geçmiş bilgi "stale" olarak işaretlenir ve bağlama girmez
  const fresh: any[] = [];
  for (const row of r.rows) {
    if (row.valid_until && new Date(row.valid_until) < now) {
      await c.query(`UPDATE knowledge_versions SET validity='stale' WHERE id=$1`, [row.id]);
      continue;
    }
    fresh.push(row);
  }
  return fresh;
}

/** Markalar arası paylaşım: yalnız kişisel veri içermeyen yöntem/deney özeti. */
export async function shareMethodSummary(c: Db, brandId: string, itemKey: string, summary: { method: string; result: string; conditions: string }, actor: string) {
  const text = JSON.stringify(summary);
  if (PII_PATTERNS.some((p) => p.test(text))) throw new Error('Paylaşılan özette kişisel veri olabilir; paylaşım reddedildi');
  const v = await addKnowledge(c, { brandId, itemKey: `shared:${itemKey}`, kind: 'shared_method_summary', content: summary, sourceKind: 'experiment_summary', createdBy: actor });
  await c.query(`UPDATE knowledge_versions SET is_shared=true WHERE id=$1`, [v.id]);
  return v;
}

/** Başka markanın özeti bu markaya doğrudan kural olarak değil, yeniden denenecek hipotez olarak alınır. */
export async function importSharedAsHypothesis(c: Db, targetBrandId: string, sharedId: string, actor: string) {
  const s = (await c.query(`SELECT * FROM knowledge_versions WHERE id=$1 AND is_shared`, [sharedId])).rows[0];
  if (!s) throw new Error('Paylaşılmış özet yok');
  return addKnowledge(c, { brandId: targetBrandId, itemKey: `imported:${s.item_key}`, kind: 'hypothesis', content: { ...s.content, origin: 'başka marka deneyi — bu markada yeniden denenmeli' }, sourceKind: 'shared_summary', sourceUri: `knowledge:${sharedId}`, createdBy: actor, validity: 'needs_retest' });
}
