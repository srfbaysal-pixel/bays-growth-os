import { config } from '../config.js';
import { clock } from './clock.js';
import { withBrand, withSystem, type Db } from '../db/pool.js';
import { logEvent } from './events.js';
import { activeHaltFor } from './halts.js';
import { sha256, stableStringify } from './util.js';

export type Role = 'strategy' | 'content' | 'distribution' | 'customer_dev' | 'auditor' | 'system';

export interface EnqueueInput {
  brandId: string;
  role: Role;
  kind: string;
  idempotencyKey: string;
  input?: Record<string, unknown>;
  campaignId?: string | null;
  parentTaskId?: string | null;
  channel?: string | null;
  maxModelCalls?: number;
  maxAttempts?: number;
  simulated?: boolean;
  /** Görevin en erken çalışacağı an (UTC). Yoksa hemen. */
  runAt?: Date | null;
  /** operation (varsayılan) | evaluation: değerlendirme görevi kuyruğa/operasyon verisine karışmaz */
  purpose?: 'operation' | 'evaluation';
}

export class LoopDetectedError extends Error {}
export class TransientError extends Error {}
export class ModelCallLimitError extends Error {}

/**
 * İdempotent kuyruklama: aynı (marka, anahtar) ikinci kez gelirse yeni görev oluşmaz, mevcut döner.
 * Döngü algılama: aynı parmak izi zaman penceresinde sınırdan fazla oluşturulursa reddedilir.
 */
export async function enqueueTask(c: Db, t: EnqueueInput): Promise<{ id: string; created: boolean }> {
  const cfg = config();
  const fingerprint = sha256(`${t.role}|${t.kind}|${t.channel ?? ''}|${stableStringify(t.input ?? {})}`);
  // Kip ayrımı: örnek (simülasyon) ve canlı görevler aynı anahtarı paylaşsa da birbirini engellemez
  const sim = t.simulated ?? (cfg.RUN_MODE !== 'live');
  const purpose = t.purpose ?? 'operation';
  const existing = (await c.query(`SELECT id FROM tasks WHERE brand_id=$1 AND idempotency_key=$2 AND is_simulated=$3`, [t.brandId, t.idempotencyKey, sim])).rows[0];
  if (existing) return { id: existing.id, created: false };
  const same = (await c.query(
    `SELECT count(*)::int AS n FROM tasks WHERE brand_id=$1 AND fingerprint=$2 AND created_at > now() - make_interval(hours => $3)`,
    [t.brandId, fingerprint, cfg.LOOP_DETECT_WINDOW_HOURS])).rows[0].n;
  if (same >= cfg.LOOP_DETECT_MAX_SAME_FINGERPRINT) {
    await logEvent(c, { brandId: t.brandId, type: 'task.loop_detected', actor: 'scheduler', payload: { kind: t.kind, role: t.role, fingerprint, count: same }, simulated: sim });
    throw new LoopDetectedError(`Döngü algılandı: aynı içerikli görev ${same} kez oluşturuldu (${t.kind})`);
  }
  const r = await c.query(
    `INSERT INTO tasks (brand_id, campaign_id, parent_task_id, role, kind, channel, idempotency_key, fingerprint, input, max_model_calls, max_attempts, timeout_ms, is_simulated, next_run_at, purpose)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13, COALESCE($14, now()), $15)
     ON CONFLICT (brand_id, idempotency_key, is_simulated) DO NOTHING RETURNING id`,
    [t.brandId, t.campaignId ?? null, t.parentTaskId ?? null, t.role, t.kind, t.channel ?? null, t.idempotencyKey, fingerprint, t.input ?? {},
      t.maxModelCalls ?? cfg.TASK_MAX_MODEL_CALLS, t.maxAttempts ?? cfg.TASK_MAX_RETRIES, cfg.TASK_TIMEOUT_MS, sim, t.runAt ?? clock.now(), purpose],
  );
  if (!r.rows[0]) {
    const again = (await c.query(`SELECT id FROM tasks WHERE brand_id=$1 AND idempotency_key=$2 AND is_simulated=$3`, [t.brandId, t.idempotencyKey, sim])).rows[0];
    return { id: again.id, created: false };
  }
  await logEvent(c, { brandId: t.brandId, type: 'task.enqueued', actor: t.role, subjectType: 'task', subjectId: r.rows[0].id, payload: { kind: t.kind, idempotencyKey: t.idempotencyKey, purpose }, simulated: sim });
  return { id: r.rows[0].id, created: true };
}

/** Sıradaki işi kilitleyerek alır. Durdurma kapsamındaki işler alınmaz, "halted" yapılır. */
export async function claimNextTask(filter: { brandId?: string; role?: Role } = {}): Promise<any | null> {
  return withSystem(async (c) => {
    for (let i = 0; i < 20; i++) {
      const r = await c.query(
        `SELECT * FROM tasks WHERE status='queued' AND next_run_at <= now() AND purpose='operation' AND is_simulated = ${config().RUN_MODE === 'live' ? 'false' : 'true'}
           ${filter.brandId ? 'AND brand_id = $1' : ''} ${filter.role ? `AND role = ${filter.brandId ? '$2' : '$1'}` : ''}
         ORDER BY next_run_at, created_at FOR UPDATE SKIP LOCKED LIMIT 1`,
        [filter.brandId, filter.role].filter(Boolean));
      const t = r.rows[0];
      if (!t) return null;
      const h = await activeHaltFor(c, { brandId: t.brand_id, channel: t.channel, campaignId: t.campaign_id });
      if (h) {
        await c.query(`UPDATE tasks SET status='halted', last_error=$2, updated_at=now() WHERE id=$1`, [t.id, `durduruldu: ${h.reason}`]);
        continue;
      }
      const u = await c.query(`UPDATE tasks SET status='running', attempts=attempts+1, locked_until=now()+make_interval(secs => timeout_ms/1000.0), updated_at=now() WHERE id=$1 RETURNING *`, [t.id]);
      return u.rows[0];
    }
    return null;
  });
}

/** Çalışan iş her dış işlemden önce bunu çağırır: durdurma geldiyse iş kesilir. */
export async function assertNotHalted(c: Db, task: { id: string; brand_id: string; channel?: string | null; campaign_id?: string | null }): Promise<void> {
  const h = await activeHaltFor(c, { brandId: task.brand_id, channel: task.channel, campaignId: task.campaign_id });
  if (h) {
    await c.query(`UPDATE tasks SET status='halted', last_error=$2, updated_at=now() WHERE id=$1`, [task.id, `durduruldu: ${h.reason}`]);
    throw new HaltedError(`Durdurma aktif: ${h.reason}`);
  }
  const st = (await c.query(`SELECT status FROM tasks WHERE id=$1`, [task.id])).rows[0]?.status;
  if (st === 'halted' || st === 'cancelled') throw new HaltedError('Görev durdurulmuş');
}
export class HaltedError extends Error {}

/** Model çağrısı sayacı: sınır aşılırsa çağrı yapılmaz. */
export async function countModelCall(c: Db, taskId: string): Promise<number> {
  const r = await c.query(`UPDATE tasks SET model_calls = model_calls + 1, updated_at=now() WHERE id=$1 AND model_calls < max_model_calls RETURNING model_calls`, [taskId]);
  if (!r.rows[0]) throw new ModelCallLimitError('Görev başına model çağrısı sınırı doldu');
  return r.rows[0].model_calls;
}

export async function completeTask(c: Db, taskId: string, output: Record<string, unknown>, status: 'done' | 'waiting_decision' = 'done'): Promise<void> {
  const r = await c.query(`UPDATE tasks SET status=$3, output=$2, locked_until=NULL, updated_at=now() WHERE id=$1 AND status IN ('running','waiting_decision') RETURNING brand_id, is_simulated`, [taskId, output, status]);
  if (r.rows[0]) await logEvent(c, { brandId: r.rows[0].brand_id, type: `task.${status}`, actor: 'runner', subjectType: 'task', subjectId: taskId, simulated: r.rows[0].is_simulated });
}

/** Geçici hatada üstel geri çekilmeyle yeniden dener; sınırda hata kuyruğuna (dead_letter) alır. */
export async function failTask(brandId: string, taskId: string, err: Error): Promise<'retry' | 'dead_letter' | 'failed' | 'halted'> {
  return withBrand(brandId, async (c) => {
    const t = (await c.query(`SELECT attempts, max_attempts, status, is_simulated FROM tasks WHERE id=$1`, [taskId])).rows[0];
    if (t.status === 'halted') return 'halted';
    let status: 'queued' | 'dead_letter' | 'failed';
    if (err instanceof HaltedError) return 'halted';
    if (err instanceof TransientError && t.attempts < t.max_attempts) status = 'queued';
    else if (err instanceof TransientError) status = 'dead_letter';
    else status = 'failed';
    const backoffSec = Math.min(2 ** t.attempts * 30, 3600);
    await c.query(`UPDATE tasks SET status=$2, last_error=$3, next_run_at = now() + make_interval(secs => $4), locked_until=NULL, updated_at=now() WHERE id=$1`,
      [taskId, status, err.message.slice(0, 500), backoffSec]);
    await logEvent(c, { brandId, type: `task.${status === 'queued' ? 'retry_scheduled' : status}`, actor: 'runner', subjectType: 'task', subjectId: taskId, payload: { error: err.message.slice(0, 300), attempts: t.attempts }, simulated: t.is_simulated });
    return status === 'queued' ? 'retry' : status;
  });
}
