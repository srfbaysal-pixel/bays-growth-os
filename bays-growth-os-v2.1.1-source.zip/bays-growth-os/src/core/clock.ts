/**
 * Uygulama saati. Saklama UTC'dir (timestamptz); işletim saatleri Europe/Istanbul ile hesaplanır.
 * Testler ve simülasyon sahte saat kullanır; üretimde gerçek saat.
 */
let fake: number | null = null;

export const clock = {
  now(): Date { return new Date(fake ?? Date.now()); },
  set(d: Date | string): void { fake = new Date(d).getTime(); },
  advance(ms: number): void { fake = (fake ?? Date.now()) + ms; },
  reset(): void { fake = null; },
  isFake(): boolean { return fake !== null; },
};

const TZ = 'Europe/Istanbul';

/** İstanbul yerel saatindeki gün ve saatten UTC anı üretir (Türkiye yıl boyu UTC+3). */
export function istanbulTime(day: string, hhmm: string): Date {
  return new Date(`${day}T${hhmm}:00+03:00`);
}

export function istanbulHour(d: Date): number {
  return Number(new Intl.DateTimeFormat('en-GB', { timeZone: TZ, hour: '2-digit', hour12: false }).format(d));
}

/** Sessiz saatler (ör. "20:00-09:00") içindeyse bir sonraki açılış anını döndürür, değilse null. */
export function quietUntil(d: Date, quiet = '20:00-09:00'): Date | null {
  const [s, e] = quiet.split('-').map((x) => Number(x.split(':')[0]));
  const h = istanbulHour(d);
  const inQuiet = s > e ? (h >= s || h < e) : (h >= s && h < e);
  if (!inQuiet) return null;
  const day = new Intl.DateTimeFormat('en-CA', { timeZone: TZ }).format(d);
  const open = istanbulTime(day, `${String(e).padStart(2, '0')}:00`);
  return open > d ? open : new Date(open.getTime() + 86400_000);
}
