import { EgressBlockedError } from '../integrations/egress.js';
import { PriceUnknownError } from './pricing.js';
import { BudgetBlockedError } from './budget.js';

/**
 * Ücretli dış çağrı başarısız olduğunda sağlayıcının ücretlendirip ücretlendirmediği:
 * - not_sent    : istek hiç gönderilmedi (egress/bütçe/fiyat/anahtar engeli, geçersiz URL) → rezervasyon bırakılır
 * - not_charged : sağlayıcı isteği kesin reddetti (HTTP 4xx: kimlik, kota, kredi, doğrulama) → rezervasyon bırakılır
 * - uncertain   : istek ulaşmış olabilir, yanıt kayboldu (zaman aşımı, bağlantı kopması, 5xx, bilinmeyen hata)
 *                 → rezervasyon "uncertain" kalır, bütçe toplamında sayılır, kurucuya uzlaştırma işi açılır.
 * Bilinmeyen hata temkinli olarak "uncertain" sayılır (gider sıfır varsayılmaz).
 */
export type CallState = 'not_sent' | 'not_charged' | 'uncertain';

export function callStateOf(e: unknown): CallState {
  const err = e as any;
  if (!err) return 'uncertain';
  if (err.callState === 'not_sent' || err.callState === 'not_charged' || err.callState === 'uncertain') return err.callState;
  if (e instanceof EgressBlockedError || e instanceof PriceUnknownError || e instanceof BudgetBlockedError || err.name === 'UnsafeUrlError') return 'not_sent';
  const status = Number(err.httpStatus ?? err.status ?? NaN);
  if (Number.isFinite(status)) {
    if (status >= 400 && status < 500) return 'not_charged';
    return 'uncertain';
  }
  return 'uncertain';
}

export const CALL_STATE_TR: Record<CallState, string> = {
  not_sent: 'çağrı yapılmadı',
  not_charged: 'sağlayıcı reddetti (ücretlenmedi)',
  uncertain: 'ücretlenmesi belirsiz',
};
