import type { Db } from '../db/pool.js';
import { logEvent } from './events.js';

export type HaltScope = 'global' | 'brand' | 'channel' | 'campaign';
export interface HaltTarget { brandId: string; channel?: string | null; campaignId?: string | null }

/** Bir işin herhangi bir aktif durdurmaya takılıp takılmadığını döndürür. */
export async function activeHaltFor(c: Db, t: HaltTarget): Promise<{ id: string; scope: HaltScope; reason: string } | null> {
  const r = await c.query(
    `SELECT id, scope, reason FROM halts WHERE active AND (
        scope = 'global'
        OR (scope = 'brand' AND brand_id = $1)
        OR (scope = 'channel' AND brand_id = $1 AND scope_value = $2)
        OR (scope = 'campaign' AND brand_id = $1 AND scope_value = $3)
     ) ORDER BY created_at LIMIT 1`,
    [t.brandId, t.channel ?? '__none__', t.campaignId ?? '__none__'],
  );
  return r.rows[0] ?? null;
}

/**
 * Durdurma oluşturur ve kapsamdaki kuyruktaki/çalışan işleri "halted" yapar.
 * Çalışan işler ayrıca her dış işlemden önce activeHaltFor ile kontrol edilir.
 */
export async function createHalt(c: Db, input: { scope: HaltScope; brandId?: string | null; scopeValue?: string | null; reason: string; by: string }): Promise<string> {
  if (input.scope !== 'global' && !input.brandId) throw new Error('Marka/kanal/kampanya durdurması brand_id gerektirir');
  const r = await c.query(
    `INSERT INTO halts (scope, brand_id, scope_value, reason, created_by) VALUES ($1,$2,$3,$4,$5) RETURNING id`,
    [input.scope, input.brandId ?? null, input.scopeValue ?? null, input.reason, input.by],
  );
  const id = r.rows[0].id as string;
  await logEvent(c, { brandId: input.brandId ?? null, type: 'halt.created', actor: input.by, subjectType: 'halt', subjectId: id, payload: { scope: input.scope, scopeValue: input.scopeValue, reason: input.reason } });
  return id;
}

/** Kapsamdaki kuyruk/çalışan görevleri ve bekleyen yayınları durdurulmuş duruma alır. */
export async function applyHaltToQueue(c: Db, haltId: string): Promise<{ tasks: number; publications: number }> {
  const h = (await c.query(`SELECT * FROM halts WHERE id = $1`, [haltId])).rows[0];
  const cond = h.scope === 'global' ? 'TRUE'
    : h.scope === 'brand' ? 'brand_id = $1'
    : h.scope === 'channel' ? 'brand_id = $1 AND channel = $2'
    : 'brand_id = $1 AND campaign_id::text = $2';
  const params = h.scope === 'global' ? [] : h.scope === 'brand' ? [h.brand_id] : [h.brand_id, h.scope_value];
  const t = await c.query(`UPDATE tasks SET status='halted', last_error = 'durduruldu: ' || ${h.scope === 'global' ? "'global'" : `'${h.scope}'`}, updated_at = now()
    WHERE status IN ('queued','running','waiting_decision') AND ${cond}`, params);
  const p = await c.query(`UPDATE publications SET status='halted' WHERE status = 'queued' AND ${cond}`, params);
  return { tasks: t.rowCount ?? 0, publications: p.rowCount ?? 0 };
}

/** Yeniden başlatma yalnız kurucu kimliğiyle; görevler kendiliğinden değil, açıkça kuyruğa döner. */
export async function resumeHalt(c: Db, haltId: string, founder: { authenticated: boolean; actor: string }, requeue: boolean): Promise<void> {
  if (!founder.authenticated) throw new Error('Yeniden başlatma kurucu yetkisi gerektirir');
  const h = (await c.query(`UPDATE halts SET active=false, resumed_at=now(), resumed_by=$2 WHERE id=$1 AND active RETURNING *`, [haltId, founder.actor])).rows[0];
  if (!h) throw new Error('Aktif durdurma bulunamadı');
  if (requeue) {
    const cond = h.scope === 'global' ? 'TRUE' : h.scope === 'brand' ? 'brand_id = $1' : h.scope === 'channel' ? 'brand_id = $1 AND channel = $2' : 'brand_id = $1 AND campaign_id::text = $2';
    const params = h.scope === 'global' ? [] : h.scope === 'brand' ? [h.brand_id] : [h.brand_id, h.scope_value];
    await c.query(`UPDATE tasks SET status='queued', updated_at=now() WHERE status='halted' AND ${cond}`, params);
    await c.query(`UPDATE publications SET status='queued' WHERE status='halted' AND ${cond}`, params);
  }
  await logEvent(c, { brandId: h.brand_id, type: 'halt.resumed', actor: founder.actor, subjectType: 'halt', subjectId: haltId, payload: { requeue } });
}
