import dns from 'node:dns';
import net from 'node:net';
import { Agent, fetch as ufetch } from 'undici';
import { assertEgressAllowed, type AdapterStatus } from '../integrations/egress.js';

/**
 * Güvenli kaynak okuyucu. Dış sayfalar güvenilmeyen veridir.
 * Korumalar: yalnız http/https ve 80/443; URL'de kullanıcı bilgisi yasak; özel/yerel/meta-veri ağ adresleri
 * hem IP literalinde hem DNS çözümlemesinde (bağlantı anında, DNS rebinding'e karşı) reddedilir;
 * yönlendirmeler elle ve en fazla 3 kez, her adımda yeniden denetlenir; zaman aşımı; boyut sınırı;
 * yalnız metin/HTML içerik; robots.txt'de yasaklı yol okunmaz; 401/403/429 aşılmaya çalışılmaz.
 */
export const USER_AGENT = 'BaysSystemsResearchBot/1.0 (+kaynakli-arastirma; robots.txt uyumlu)';
const MAX_BYTES = 1_000_000;
const TIMEOUT_MS = 10_000;
const MAX_REDIRECTS = 3;
const TEXT_TYPES = ['text/html', 'text/plain', 'application/xhtml+xml'];

export class UnsafeUrlError extends Error { constructor(m: string) { super(m); this.name = 'UnsafeUrlError'; } }

/** Özel, yerel, bağlantı-yerel, CGNAT, çok noktaya yayın, ayrılmış ve meta-veri adresleri */
export function isPrivateAddress(ip: string): boolean {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 192 && b === 0) || (a === 198 && (b === 18 || b === 19)) || a >= 224;
  }
  if (net.isIPv6(ip)) {
    const g = expandIPv6(ip);
    if (!g) return true;
    // IPv4 gömülü biçimler: ::ffff:a.b.c.d (eşlemeli) ve ::a.b.c.d (uyumlu, kullanımdan kalkmış)
    if (g.slice(0, 5).every((x) => x === 0) && (g[5] === 0xffff || g[5] === 0)) {
      if (g[5] === 0 && g[6] === 0 && g[7] <= 1) return true; // :: ve ::1
      return isPrivateAddress(`${g[6] >> 8}.${g[6] & 255}.${g[7] >> 8}.${g[7] & 255}`) || g[5] === 0;
    }
    // Yalnız küresel tek noktaya yayın 2000::/3 kabul edilir; fc00::/7, fe80::/10, fec0::/10, ff00::/8, 64:ff9b::/96 vb. dışarıda kalır
    if ((g[0] & 0xe000) !== 0x2000) return true;
    if (g[0] === 0x2002) return true;                 // 6to4 (gömülü IPv4'e tünel)
    if (g[0] === 0x2001 && g[1] === 0) return true;   // Teredo 2001:0::/32
    if (g[0] === 0x2001 && g[1] === 0x0db8) return true; // belgeleme
    if (g[0] === 0x2001 && g[1] < 0x0200) return true; // IETF protokol atamaları 2001::/23
    return false;
  }
  return true; // tanınmayan biçim: güvenli değil
}

/** IPv6 adresini 8 adet 16 bitlik gruba açar (gömülü IPv4 ve bölge kimliği desteklenir) */
export function expandIPv6(ip: string): number[] | null {
  let x = ip.toLowerCase().split('%')[0];
  const v4 = /(\d+\.\d+\.\d+\.\d+)$/.exec(x);
  if (v4) { const o = v4[1].split('.').map(Number); x = x.slice(0, -v4[1].length) + `${((o[0] << 8) | o[1]).toString(16)}:${((o[2] << 8) | o[3]).toString(16)}`; }
  const parts = x.split('::');
  if (parts.length > 2) return null;
  const head = parts[0] ? parts[0].split(':') : [];
  const tail = parts.length === 2 && parts[1] ? parts[1].split(':') : [];
  const fill = parts.length === 2 ? 8 - head.length - tail.length : 0;
  if (fill < 0 || (parts.length === 1 && head.length !== 8)) return null;
  const all = [...head, ...Array(fill).fill('0'), ...tail].map((h) => parseInt(h, 16));
  return all.length === 8 && all.every((n) => Number.isInteger(n) && n >= 0 && n <= 0xffff) ? all : null;
}

/** DNS'in döndürdüğü adres listesinin denetimi (bağlantı anında kullanılır; testte DNS rebinding senaryosu için dışa açık) */
export function checkResolvedAddresses(hostname: string, addrs: { address: string; family?: number }[]): void {
  if (addrs.length === 0) throw new UnsafeUrlError(`DNS adres döndürmedi: ${hostname}`);
  const bad = addrs.find((a) => isPrivateAddress(a.address));
  if (bad) throw new UnsafeUrlError(`DNS özel adrese çözümlendi: ${hostname} → ${bad.address}`);
}

/** URL'nin ağa çıkmadan önceki biçimsel denetimi */
export function validateUrl(raw: string): URL {
  let u: URL;
  try { u = new URL(raw); } catch { throw new UnsafeUrlError('Geçersiz URL'); }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new UnsafeUrlError(`İzinsiz şema: ${u.protocol}`);
  if (u.username || u.password) throw new UnsafeUrlError('URL içinde kullanıcı bilgisi yasak');
  const port = u.port ? Number(u.port) : (u.protocol === 'https:' ? 443 : 80);
  if (port !== 80 && port !== 443) throw new UnsafeUrlError(`İzinsiz port: ${port}`);
  const host = u.hostname.replace(/^\[|\]$/g, '');
  if (!host || host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local') || host.endsWith('.internal')) throw new UnsafeUrlError(`Yerel ad reddedildi: ${host}`);
  if (net.isIP(host) && isPrivateAddress(host)) throw new UnsafeUrlError(`Özel ağ adresi reddedildi: ${host}`);
  if (/^\d+$/.test(host) || /^0x/i.test(host)) throw new UnsafeUrlError('Sayısal/onaltılık host biçimi reddedildi');
  return u;
}

/** Bağlantı anında çözümlenen tüm adresleri denetleyen DNS araması (DNS rebinding'e karşı) */
export function safeLookup(hostname: string, options: any, cb: (err: Error | null, address: any, family?: number) => void, resolver: typeof dns.lookup = dns.lookup) {
  (resolver as any)(hostname, { all: true }, (err: Error | null, addrs: dns.LookupAddress[]) => {
    if (err) return cb(err, undefined as any);
    try { checkResolvedAddresses(hostname, addrs); } catch (e) { return cb(e as Error, undefined as any); }
    if (options?.all) return cb(null, addrs);
    cb(null, addrs[0].address, addrs[0].family);
  });
}
const agent = new Agent({ connect: { lookup: safeLookup as any, timeout: TIMEOUT_MS }, headersTimeout: TIMEOUT_MS, bodyTimeout: TIMEOUT_MS });

export type ReadStatus = 'ok' | 'unreachable' | 'blocked' | 'too_large' | 'unsupported' | 'disallowed';
export interface ReadResult { url: string; finalUrl: string; status: ReadStatus; httpStatus?: number; contentType?: string; body?: string; bytes?: number; error?: string }

export interface PageReader { name: string; simulated: boolean; read(url: string): Promise<ReadResult> }

const robotsCache = new Map<string, { at: number; disallow: string[]; allow: string[] }>();

async function rawGet(url: string, accept: string, checkRobots = true): Promise<{ res?: Awaited<ReturnType<typeof ufetch>>; finalUrl: string; error?: string; disallowed?: boolean }> {
  let current = url;
  for (let hop = 0; hop <= MAX_REDIRECTS; hop++) {
    const cu = validateUrl(current);
    // Yönlendirilen her adres için robots.txt yeniden denetlenir (ilk adres çağıran tarafından denetlendi)
    if (checkRobots && hop > 0 && !(await robotsAllows(cu))) return { finalUrl: current, disallowed: true, error: 'yönlendirilen adres robots.txt ile yasak' };
    const res = await ufetch(current, { dispatcher: agent, redirect: 'manual', headers: { 'user-agent': USER_AGENT, accept }, signal: AbortSignal.timeout(TIMEOUT_MS) });
    if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
      current = new URL(res.headers.get('location')!, current).toString();
      await res.body?.cancel();
      continue;
    }
    return { res, finalUrl: current };
  }
  return { finalUrl: current, error: 'çok fazla yönlendirme' };
}

async function readLimited(res: Awaited<ReturnType<typeof ufetch>>, limit: number): Promise<{ text?: string; bytes: number; tooLarge: boolean }> {
  const len = Number(res.headers.get('content-length') ?? 0);
  if (len > limit) { await res.body?.cancel(); return { bytes: len, tooLarge: true }; }
  const reader = res.body!.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.byteLength;
    if (total > limit) { await reader.cancel(); return { bytes: total, tooLarge: true }; }
    chunks.push(value);
  }
  return { text: Buffer.concat(chunks).toString('utf8'), bytes: total, tooLarge: false };
}

/**
 * robots.txt (RFC 9309): 2xx → kurallar uygulanır; 4xx → kısıt yok; 5xx/ağ hatası → tüm site yasak sayılır.
 * Kendi ajan grubumuz varsa yalnız o grup, yoksa "*" grubu uygulanır; ardışık User-agent satırları tek grup oluşturur.
 */
export function parseRobots(text: string, agentToken = 'bayssystemsresearchbot'): { disallow: string[]; allow: string[] } {
  type Group = { agents: string[]; disallow: string[]; allow: string[] };
  const groups: Group[] = [];
  let cur: Group | null = null; let lastWasAgent = false;
  for (const raw of text.split(/\r?\n/)) {
    const line = raw.replace(/#.*/, '').trim();
    if (!line) continue;
    const idx = line.indexOf(':'); if (idx < 0) continue;
    const k = line.slice(0, idx).trim().toLowerCase(); const v = line.slice(idx + 1).trim();
    if (k === 'user-agent') {
      if (!cur || !lastWasAgent) { cur = { agents: [], disallow: [], allow: [] }; groups.push(cur); }
      cur.agents.push(v.toLowerCase()); lastWasAgent = true; continue;
    }
    lastWasAgent = false;
    if (!cur) continue;
    if (k === 'disallow' && v) cur.disallow.push(v);
    if (k === 'allow' && v) cur.allow.push(v);
  }
  const own = groups.filter((g) => g.agents.some((a) => a !== '*' && a.replace(/\/.*$/, '').length > 0 && agentToken.startsWith(a.replace(/\/.*$/, ''))));
  const pick = own.length ? own : groups.filter((g) => g.agents.includes('*'));
  return { disallow: pick.flatMap((g) => g.disallow), allow: pick.flatMap((g) => g.allow) };
}

export function robotsMatch(path: string, rules: { disallow: string[]; allow: string[] }): boolean {
  const m = (p: string) => {
    const anchored = p.endsWith('$'); const body = anchored ? p.slice(0, -1) : p;
    const re = new RegExp('^' + body.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*') + (anchored ? '$' : ''));
    return re.test(path) ? p.length : -1;
  };
  const d = Math.max(-1, ...rules.disallow.map(m)); const a = Math.max(-1, ...rules.allow.map(m));
  return !(d >= 0 && d > a); // en uzun eşleşme kazanır; eşitlikte izin
}

async function robotsAllows(u: URL): Promise<boolean> {
  const key = u.origin;
  let entry = robotsCache.get(key);
  if (!entry || Date.now() - entry.at > 86400_000) {
    let rules = { disallow: [] as string[], allow: [] as string[] };
    try {
      const { res } = await rawGet(`${u.origin}/robots.txt`, 'text/plain', false);
      if (!res) rules = { disallow: ['/'], allow: [] };
      else if (res.status >= 200 && res.status < 300) { const { text } = await readLimited(res, 500_000); rules = parseRobots(text ?? ''); }
      else if (res.status >= 500) { await res.body?.cancel(); rules = { disallow: ['/'], allow: [] }; }
      else await res.body?.cancel();
    } catch { rules = { disallow: ['/'], allow: [] }; }
    entry = { at: Date.now(), ...rules };
    robotsCache.set(key, entry);
  }
  return robotsMatch(u.pathname + u.search, entry);
}

/** Canlı okuyucu: egress politikası (RUN_MODE=live, EGRESS_ENABLED, araştırma bağlantısı live) + SSRF korumaları */
export class SafeHttpReader implements PageReader {
  name = 'safe-http'; simulated = false;
  constructor(private status: AdapterStatus) {}
  async read(url: string): Promise<ReadResult> {
    assertEgressAllowed({ adapter: 'research-reader', status: this.status, purpose: 'live', allowedHosts: 'public', credentialPresent: true, url });
    let u: URL;
    try { u = validateUrl(url); } catch (e) { return { url, finalUrl: url, status: 'blocked', error: (e as Error).message }; }
    try {
      if (!(await robotsAllows(u))) return { url, finalUrl: url, status: 'disallowed', error: 'robots.txt bu yolu yasaklıyor' };
      const { res, finalUrl, error, disallowed } = await rawGet(url, 'text/html,text/plain;q=0.9');
      if (disallowed) return { url, finalUrl, status: 'disallowed', error };
      if (!res) return { url, finalUrl, status: 'unreachable', error };
      if ([401, 403, 429, 451].includes(res.status)) { await res.body?.cancel(); return { url, finalUrl, status: 'blocked', httpStatus: res.status, error: 'erişim engeli/kota; aşılmaya çalışılmadı' }; }
      if (res.status >= 400) { await res.body?.cancel(); return { url, finalUrl, status: 'unreachable', httpStatus: res.status }; }
      const ct = (res.headers.get('content-type') ?? '').split(';')[0].trim().toLowerCase();
      if (!TEXT_TYPES.includes(ct)) { await res.body?.cancel(); return { url, finalUrl, status: 'unsupported', httpStatus: res.status, contentType: ct }; }
      const body = await readLimited(res, MAX_BYTES);
      if (body.tooLarge) return { url, finalUrl, status: 'too_large', httpStatus: res.status, bytes: body.bytes };
      return { url, finalUrl, status: 'ok', httpStatus: res.status, contentType: ct, body: body.text, bytes: body.bytes };
    } catch (e) {
      if (e instanceof UnsafeUrlError || (e as any)?.cause instanceof UnsafeUrlError) return { url, finalUrl: url, status: 'blocked', error: ((e as any).cause ?? e).message };
      return { url, finalUrl: url, status: 'unreachable', error: (e as Error).message };
    }
  }
}
