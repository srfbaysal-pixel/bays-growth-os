import fs from 'node:fs';
import path from 'node:path';
import { detectInjection } from '../agents/guards.js';

/**
 * Kaynak metinden deterministik çıkarım. Kural: kaynakta birebir bulunmayan hiçbir alan üretilmez.
 * Her sinyal ve iletişim bilgisi, kaynaktan alınmış bir alıntı (excerpt) ile birlikte döner.
 */
const CFG = JSON.parse(fs.readFileSync(path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../config/need_signals.json'), 'utf8'));
export const NEED_SIGNALS_VERSION: string = CFG.version;

export interface Extracted {
  title: string | null;
  siteName: string | null;
  text: string;
  domain: string;
  emails: { value: string; excerpt: string }[];
  phones: { value: string; excerpt: string }[];
  city: { value: string; excerpt: string } | null;
  signals: { id: string; label: string; offer: string; confidence: 'low' | 'medium' | 'high'; excerpt: string }[];
  competitorHits: { phrase: string; excerpt: string }[];
  injection: boolean;
}

const decode = (s: string) => s.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)));

export function htmlToText(html: string): string {
  return decode(html.replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<(br|p|div|li|h\d|tr)[^>]*>/gi, '\n').replace(/<[^>]+>/g, ' ')).replace(/[ \t]+/g, ' ').replace(/\n\s*/g, '\n').trim();
}

function excerptAround(text: string, idx: number, len: number): string {
  const s = Math.max(0, idx - 60), e = Math.min(text.length, idx + len + 60);
  return text.slice(s, e).replace(/\s+/g, ' ').trim();
}

export function extract(html: string, url: string): Extracted {
  const text = htmlToText(html);
  const lower = text.toLocaleLowerCase('tr-TR');
  const domain = new URL(url).hostname.replace(/^www\./, '').toLowerCase();
  const title = (/<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)?.[1] ?? '').trim() || null;
  const siteName = /<meta[^>]+property=["']og:site_name["'][^>]+content=["']([^"']+)["']/i.exec(html)?.[1]?.trim() ?? null;

  const emails: Extracted['emails'] = [];
  const seenE = new Set<string>();
  const emailRe = /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/g;
  for (const src of [html.replace(/mailto:/gi, ' '), text]) {
    for (const m of src.matchAll(emailRe)) {
      const v = m[0].toLowerCase();
      if (seenE.has(v) || /\.(png|jpg|jpeg|gif|svg|webp)$/.test(v)) continue;
      const i = text.toLowerCase().indexOf(v);
      if (i < 0) continue; // yalnız görünür metinde yayımlanmış adresler
      seenE.add(v);
      emails.push({ value: v, excerpt: excerptAround(text, i, v.length) });
    }
  }
  // Telefon: yalnız 0 veya +90 önekli Türkiye numaraları; değer kaynakta yazıldığı biçimiyle saklanır
  const phones: Extracted['phones'] = [];
  for (const m of text.matchAll(/(?<![\d+])(?:\+90[\s-]?|0)\(?[2-5]\d{2}\)?[\s-]?\d{3}[\s-]?\d{2}[\s-]?\d{2}(?!\d)/g)) {
    if (phones.length >= 3) break;
    phones.push({ value: m[0].trim(), excerpt: excerptAround(text, m.index!, m[0].length) });
  }
  // Şehir: Türkçe harfleri dikkate alan kelime sınırı (ör. "Batmanlı" Batman değildir; "Vanilya" Van değildir)
  let city: Extracted['city'] = null;
  const L = 'a-zçğıöşüâîû';
  for (const c of CFG.cities as string[]) {
    const lc = c.toLocaleLowerCase('tr-TR').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const m = new RegExp(`(?<![${L}])${lc}(?:'[${L}]+)?(?![${L}])`, 'u').exec(lower);
    if (m) { city = { value: c, excerpt: excerptAround(text, m.index, m[0].length) }; break; }
  }
  const signals: Extracted['signals'] = [];
  for (const s of CFG.signals) {
    const m = new RegExp(s.pattern, 'iu').exec(lower);
    if (m) signals.push({ id: s.id, label: s.label, offer: s.offer, confidence: s.confidence, excerpt: excerptAround(text, m.index, m[0].length) });
  }
  const competitorHits: Extracted['competitorHits'] = [];
  for (const p of CFG.competitor_patterns as string[]) {
    const i = lower.indexOf(p);
    if (i >= 0) competitorHits.push({ phrase: p, excerpt: excerptAround(text, i, p.length) });
  }
  return { title, siteName, text, domain, emails, phones, city, signals, competitorHits, injection: !detectInjection(text).ok };
}

/** İşletme adı: önce og:site_name, sonra başlığın ilk parçası. İkisi de yoksa ad yoktur (uydurulmaz). */
export function businessName(x: Extracted): string | null {
  if (x.siteName) return x.siteName;
  if (!x.title) return null;
  return x.title.split(/\s[|–\-—·:]\s/)[0].trim() || null;
}
