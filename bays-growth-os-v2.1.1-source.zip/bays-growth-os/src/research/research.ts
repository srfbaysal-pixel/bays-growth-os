import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { withBrand, type Db } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { activeHaltFor } from '../core/halts.js';
import { estimateCost, PriceUnknownError } from '../core/pricing.js';
import { reserveBudget, reconcileReservation, releaseReservation, settleFailedCall, markUncertain, BudgetBlockedError } from '../core/budget.js';
import { sha256 } from '../core/util.js';
import { upsertLead } from '../crm/crm.js';
import { BraveSearchProvider, FixturePageReader, FixtureSearchProvider, type SearchProvider } from './providers.js';
import { SafeHttpReader, type PageReader, type ReadResult } from './safeReader.js';
import { extract, businessName, type Extracted } from './extract.js';
import type { AdapterStatus } from '../integrations/egress.js';

const PLAN = JSON.parse(fs.readFileSync(path.resolve(path.dirname(new URL(import.meta.url).pathname), '../../config/research_plan.json'), 'utf8'));

export interface ResearchStack { provider: SearchProvider | null; reader: PageReader | null; reason?: string }

/** Yapılandırmaya göre sağlayıcı seçimi. Bağlı değilse keşif yapılmaz ve bu açıkça raporlanır. */
export async function researchStack(c: Db, brandId: string): Promise<ResearchStack> {
  const p = config().RESEARCH_PROVIDER;
  if (p === 'fixture') {
    if (config().RUN_MODE === 'live') return { provider: null, reader: null, reason: 'ÖRNEK (fixture) sağlayıcı canlı kipte kullanılamaz' };
    return { provider: new FixtureSearchProvider(), reader: new FixturePageReader() };
  }
  if (p === 'brave') {
    const st = ((await c.query(`SELECT status FROM channel_connections WHERE brand_id=$1 AND channel='research' AND adapter='brave-search'`, [brandId])).rows[0]?.status ?? 'disconnected') as AdapterStatus;
    if (st !== 'live') return { provider: null, reader: null, reason: `Brave araştırma bağlantısı ${st}; keşif yapılmadı` };
    return { provider: new BraveSearchProvider(st), reader: new SafeHttpReader(st) };
  }
  return { provider: null, reader: null, reason: 'Araştırma sağlayıcısı bağlı değil (RESEARCH_PROVIDER=none); keşif yapılmadı' };
}

export interface ResearchRunResult {
  runId: string; status: string; queries: number; results: number; documents: number; findings: number;
  newLeadIds: string[]; existingLeadIds: string[]; notes: string[];
}

function pickQueries(day: string, focus: string[] | null, max: number): { sector: string; q: string }[] {
  const sectors = Object.keys(PLAN.sectors);
  const ordered = focus?.length ? [...focus.filter((s) => sectors.includes(s)), ...sectors.filter((s) => !focus.includes(s))] : sectors;
  const dayIdx = Math.floor(new Date(`${day}T00:00:00Z`).getTime() / 86400_000);
  const out: { sector: string; q: string }[] = [];
  // Her gün sektörler arasında dönüşümlü; odak sektörler öne alınır
  for (let i = 0; out.length < max && i < 50; i++) {
    const sector = ordered[i % ordered.length];
    const qs: string[] = PLAN.sectors[sector];
    const q = qs[(dayIdx + Math.floor(i / ordered.length)) % qs.length];
    if (!out.some((x) => x.q === q)) out.push({ sector, q });
  }
  return out;
}

/** Kaynaklı araştırma ve müşteri keşfi. Her kayıt URL, erişim zamanı, alıntı, gözlenen olgu, çıkarım, güven ve tazelik taşır. */
export async function runResearch(opts: { brandId: string; day: string; now: Date; simulated: boolean; focus?: string[] | null; stack?: ResearchStack; maxQueries?: number }): Promise<ResearchRunResult> {
  const cfg = config();
  const brandId = opts.brandId;
  const notes: string[] = [];
  const stack = opts.stack ?? await withBrand(brandId, (c) => researchStack(c, brandId));
  const providerName = stack.provider?.name ?? 'none';
  const mode = opts.simulated || stack.provider?.simulated ? 'simulation' : 'live';

  const finish = (status: string, extra: Partial<ResearchRunResult> & { counts?: any } = {}) => withBrand(brandId, async (c) => {
    const k = extra.counts ?? {};
    const r = await c.query(
      `INSERT INTO research_runs (brand_id, day, provider, status, queries, results, documents, findings, candidates, notes, is_simulated)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
       ON CONFLICT (brand_id, day, provider, is_simulated) DO UPDATE SET status=EXCLUDED.status, queries=EXCLUDED.queries, results=EXCLUDED.results, documents=EXCLUDED.documents, findings=EXCLUDED.findings, candidates=EXCLUDED.candidates, notes=EXCLUDED.notes
       RETURNING id`,
      [brandId, opts.day, providerName, status, k.queries ?? 0, k.results ?? 0, k.documents ?? 0, k.findings ?? 0, (extra.newLeadIds ?? []).length, JSON.stringify(notes), mode === 'simulation']);
    await logEvent(c, { brandId, type: `research.${status}`, actor: 'strategy', subjectType: 'research_run', subjectId: r.rows[0].id, payload: { provider: providerName, ...k, notes }, simulated: mode === 'simulation' });
    return r.rows[0].id as string;
  });

  // Kip ayrımı: örnek (simülasyon) çalıştırma canlı sağlayıcıyı çağıramaz
  if (opts.simulated && stack.provider && (!stack.provider.simulated || (stack.reader && !stack.reader.simulated))) {
    notes.push('Örnek (simülasyon) görev canlı araştırma sağlayıcısını çağıramaz; çalıştırma yapılmadı');
    const runId = await finish('disabled');
    return { runId, status: 'disabled', queries: 0, results: 0, documents: 0, findings: 0, newLeadIds: [], existingLeadIds: [], notes };
  }
  if (!stack.provider || !stack.reader) {
    notes.push(stack.reason ?? 'Araştırma sağlayıcısı yok');
    const runId = await finish('disabled');
    return { runId, status: 'disabled', queries: 0, results: 0, documents: 0, findings: 0, newLeadIds: [], existingLeadIds: [], notes };
  }
  const halt = await withBrand(brandId, (c) => activeHaltFor(c, { brandId, channel: 'research' }));
  if (halt) {
    notes.push(`Durdurma aktif: ${halt.reason}`);
    const runId = await finish('blocked_halt');
    return { runId, status: 'blocked_halt', queries: 0, results: 0, documents: 0, findings: 0, newLeadIds: [], existingLeadIds: [], notes };
  }

  const counts = { queries: 0, results: 0, documents: 0, findings: 0 };
  let status = 'done';
  const urls = new Map<string, { sector: string; q: string; title: string; snippet: string }>();
  for (const { sector, q } of pickQueries(opts.day, opts.focus ?? null, opts.maxQueries ?? cfg.RESEARCH_MAX_QUERIES_PER_DAY)) {
    const params = { country: cfg.RESEARCH_COUNTRY, lang: cfg.RESEARCH_LANG, count: 10 };
    const qh = sha256(`${q}|${JSON.stringify(params)}`);
    // Önbellek yalnız aynı kipteki kayıtlardan okunur: ÖRNEK sonuç canlı süreçte kullanılmaz
    const cached = await withBrand(brandId, async (c) => (await c.query(`SELECT results FROM research_queries WHERE brand_id=$1 AND provider=$2 AND query_hash=$3 AND expires_at > $4 AND is_simulated=$5`, [brandId, providerName, qh, opts.now, mode === 'simulation'])).rows[0]);
    let results: any[];
    if (cached) { results = cached.results; notes.push(`önbellek: "${q}"`); }
    else {
      // Her dış aramadan önce durdurma yeniden denetlenir (çalışma sırasında verilen durdurma hemen etkili olur)
      const h = await withBrand(brandId, (c) => activeHaltFor(c, { brandId, channel: 'research' }));
      if (h) { status = 'blocked_halt'; notes.push(`Durdurma (çalışma sırasında): ${h.reason}`); break; }
      // Bütçe → çağrı → uzlaştırma (her dış arama çağrısı)
      // Her deneme ayrı rezervasyon ve ayrı çağrı kimliği (call_ref) taşır; tekrar deneme önceki belirsiz kaydı değiştirmez
      let rsv: { reservationId: string } | null = null;
      try {
        const est = estimateCost(stack.provider.pricingKey, { units: 1 });
        rsv = await reserveBudget({ brandId, mode, provider: providerName, estimate: est, now: opts.now, callRef: `research:${providerName}:${qh.slice(0, 16)}:${opts.day}:${crypto.randomUUID().slice(0, 8)}` });
        results = await stack.provider.search(q, params);
        await reconcileReservation(rsv.reservationId, { amountOriginal: est.original, currency: est.currency, item: stack.provider.pricingKey, succeeded: true });
      } catch (e) {
        if (rsv) {
          const st = await settleFailedCall(rsv.reservationId, e, `arama "${q}"`).catch(() => 'uncertain' as const);
          if (st === 'uncertain') notes.push(`Arama gideri belirsiz "${q}": sağlayıcı isteği almış olabilir; tahmini tutar bütçede sayıldı, kurucuya uzlaştırma işi açıldı`);
        }
        if (e instanceof PriceUnknownError || e instanceof BudgetBlockedError) { status = 'blocked_budget'; notes.push(`Arama engellendi: ${(e as Error).message}`); break; }
        status = 'partial'; notes.push(`Arama hatası "${q}": ${(e as Error).message}`); continue;
      }
      counts.queries++;
      await withBrand(brandId, (c) => c.query(
        `INSERT INTO research_queries (brand_id, provider, query_hash, query, params, results, fetched_at, expires_at, is_simulated) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
         ON CONFLICT (brand_id, provider, query_hash, is_simulated) DO UPDATE SET results=EXCLUDED.results, fetched_at=EXCLUDED.fetched_at, expires_at=EXCLUDED.expires_at`,
        [brandId, providerName, qh, q, params, JSON.stringify(results), opts.now, new Date(opts.now.getTime() + cfg.RESEARCH_CACHE_DAYS * 86400_000), mode === 'simulation']));
    }
    counts.results += results.length;
    for (const r of results) if (!urls.has(r.url)) urls.set(r.url, { sector, q, title: r.title, snippet: r.snippet });
  }

  const newLeadIds: string[] = [], existingLeadIds: string[] = [];
  const signalTally = new Map<string, { label: string; offer: string; n: number; sample: { url: string; excerpt: string } }>();
  let pages = 0;
  for (const [url, meta] of urls) {
    if (pages >= cfg.RESEARCH_MAX_PAGES_PER_DAY) { notes.push('günlük sayfa sınırına ulaşıldı'); break; }
    if (status === 'blocked_halt') break;
    const h = await withBrand(brandId, (c) => activeHaltFor(c, { brandId, channel: 'research' }));
    if (h) { status = 'blocked_halt'; notes.push(`Durdurma (sayfa okumadan önce): ${h.reason}`); break; }
    const doc = await readDocument(brandId, url, stack.reader, opts.now, mode);
    if (doc.fetched) pages++;
    counts.documents++;
    if (doc.status !== 'ok' || !doc.extracted) continue;
    const x = doc.extracted;
    const accessed = doc.fetchedAt;
    const fresh = opts.now.getTime() - accessed.getTime() <= cfg.SOURCE_REFETCH_DAYS * 86400_000 ? 'fresh' : 'stale';
    for (const s of x.signals) {
      const t = signalTally.get(s.id) ?? { label: s.label, offer: s.offer, n: 0, sample: { url, excerpt: s.excerpt } };
      t.n++; signalTally.set(s.id, t);
    }
    await withBrand(brandId, async (c) => {
      if (x.competitorHits.length && x.signals.length === 0) {
        await insertFinding(c, { brandId, docId: doc.id, kind: 'competitor', url, accessed, excerpt: x.competitorHits[0].excerpt, observed: `Sayfada "${x.competitorHits[0].phrase}" ifadesi geçiyor`, inference: 'Benzer hizmet sunan bir işletme/ajans olabilir (doğrulanmadı)', confidence: 'medium', freshness: fresh, data: { domain: x.domain, title: x.title, sector: meta.sector }, simulated: mode === 'simulation' });
        counts.findings++;
        return;
      }
      const name = businessName(x);
      if (!x.signals.length || !name) return; // ihtiyaç sinyali veya işletme adı yoksa aday yok
      // Çelişki: aynı alan adı daha önce farklı adla/iletişimle kaydedildiyse işaretle
      const prev = (await c.query(`SELECT data FROM research_findings WHERE brand_id=$1 AND kind='business_candidate' AND data->>'domain'=$2 AND is_simulated=$3 ORDER BY created_at DESC LIMIT 1`, [brandId, x.domain, mode === 'simulation'])).rows[0];
      const conflicting = prev && (prev.data.name !== name || JSON.stringify(prev.data.emails ?? []) !== JSON.stringify(x.emails.map((e) => e.value)));
      const recentDup = prev && !conflicting && (await c.query(`SELECT 1 FROM research_findings WHERE brand_id=$1 AND kind='business_candidate' AND data->>'domain'=$2 AND accessed_at > $3 AND is_simulated=$4 LIMIT 1`, [brandId, x.domain, new Date(opts.now.getTime() - cfg.SOURCE_REFETCH_DAYS * 86400_000), mode === 'simulation'])).rowCount;
      const lead = await upsertLead(c, {
        brandId, businessName: name, domain: x.domain, city: x.city?.value ?? null, sector: meta.sector,
        sourceUri: url, sourceNote: `Kaynak: ${url} (erişim ${accessed.toISOString()}) — "${x.signals[0].excerpt}"`,
        needSignals: x.signals.map((s) => s.label), isSample: mode === 'simulation',
      });
      if (lead.duplicate) existingLeadIds.push(lead.id); else newLeadIds.push(lead.id);
      if (!lead.duplicate) {
        // İletişim: yalnız kaynak sayfada yayımlanmış adres. Yoksa kişi kaydı açılmaz (uydurulmaz).
        // Yalnız işletmenin KENDİ alan adındaki (veya alt alan adındaki) adres doğrulanmış iletişim sayılır
        const email = x.emails.find((e) => { const d = e.value.split('@')[1]; return d === x.domain || d.endsWith(`.${x.domain}`); });
        if (email) await c.query(`INSERT INTO contacts (brand_id, lead_id, email, contact_basis, is_sample) VALUES ($1,$2,$3,$4,$5)`,
          [brandId, lead.id, email.value, `Kaynak sayfada yayımlanmış iletişim adresi: ${url} — "${email.excerpt}"`, mode === 'simulation']);
      }
      if (recentDup) return; // yeniden keşif: aynı bulgu tekrar yazılmaz
      await insertFinding(c, {
        brandId, docId: doc.id, kind: 'business_candidate', url, accessed, excerpt: x.signals[0].excerpt,
        observed: `${name} sayfasında: ${x.signals.map((s) => s.label).join('; ')}`,
        inference: `Uyumlu hizmet olabilir: ${[...new Set(x.signals.map((s) => s.offer))].join(', ')} (doğrulanmış ihtiyaç değil; görüşmede teyit edilmeli)`,
        confidence: x.signals.some((s) => s.confidence === 'high') ? 'high' : 'medium', freshness: conflicting ? 'conflicting' : fresh,
        data: { name, domain: x.domain, city: x.city?.value ?? null, sector: meta.sector, signals: x.signals, emails: x.emails.map((e) => e.value), phones: x.phones.map((p) => p.value), contactVerified: x.emails.some((e) => { const d = e.value.split('@')[1]; return d === x.domain || d.endsWith(`.${x.domain}`); }) },
        leadId: lead.id, simulated: mode === 'simulation',
      });
      counts.findings++;
    });
  }
  // Pazar ihtiyacı ve içerik fırsatı: birden çok kaynakta görülen sinyaller (sayı gözlemdir, genelleme değildir)
  await withBrand(brandId, async (c) => {
    const sorted = [...signalTally.entries()].sort((a, b) => b[1].n - a[1].n);
    for (const [id, t] of sorted) {
      await insertFinding(c, { brandId, kind: 'market_need', url: t.sample.url, accessed: opts.now, excerpt: t.sample.excerpt, observed: `Bu çalıştırmada ${t.n} kaynakta "${t.label}" sinyali görüldü`, inference: 'Örneklem sorgu sonuçlarıyla sınırlı; pazar geneline genellenemez', confidence: t.n >= 3 ? 'medium' : 'low', freshness: 'fresh', data: { signal: id, count: t.n, offer: t.offer }, simulated: mode === 'simulation' });
      counts.findings++;
    }
    if (sorted[0]) {
      await insertFinding(c, { brandId, kind: 'content_opportunity', url: sorted[0][1].sample.url, accessed: opts.now, excerpt: sorted[0][1].sample.excerpt, observed: `En sık sinyal: "${sorted[0][1].label}" (${sorted[0][1].n} kaynak)`, inference: 'Bu tekrarlı işi ve otomasyona uygun kısmını açıklayan içerik hipotezi', confidence: 'low', freshness: 'fresh', data: { signal: sorted[0][0] }, simulated: mode === 'simulation' });
      counts.findings++;
    }
  });
  if (status === 'done' && counts.queries === 0 && urls.size === 0) status = 'partial';
  const runId = await finish(status, { counts, newLeadIds });
  return { runId, status, ...counts, newLeadIds, existingLeadIds, notes };
}

async function insertFinding(c: Db, f: { brandId: string; docId?: string; kind: string; url: string; accessed: Date; excerpt: string; observed: string; inference: string; confidence: string; freshness: string; data: any; leadId?: string; simulated: boolean }) {
  await c.query(`INSERT INTO research_findings (brand_id, document_id, kind, source_url, accessed_at, excerpt, observed_fact, inference, confidence, freshness, data, lead_id, is_simulated)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`, [f.brandId, f.docId ?? null, f.kind, f.url, f.accessed, f.excerpt.slice(0, 500), f.observed.slice(0, 500), f.inference, f.confidence, f.freshness, f.data, f.leadId ?? null, f.simulated]);
}

/** Kaynak belge önbelleği: aynı URL tazelik süresi içinde yeniden okunmaz. */
async function readDocument(brandId: string, url: string, reader: PageReader, now: Date, mode: 'live' | 'simulation'): Promise<{ id: string; status: string; extracted: Extracted | null; fetchedAt: Date; fetched: boolean }> {
  const uh = sha256(url);
  const cached = await withBrand(brandId, async (c) => (await c.query(`SELECT * FROM source_documents WHERE brand_id=$1 AND url_hash=$2 AND is_simulated=$3`, [brandId, uh, mode === 'simulation'])).rows[0]);
  if (cached && now.getTime() - new Date(cached.fetched_at).getTime() < config().SOURCE_REFETCH_DAYS * 86400_000) {
    return { id: cached.id, status: cached.status, extracted: cached.extracted, fetchedAt: new Date(cached.fetched_at), fetched: false };
  }
  let r: ReadResult;
  let rsv: { reservationId: string } | null = null;
  try {
    const key = reader.simulated ? 'fixture:page_read' : 'research:page_read';
    const est = estimateCost(key, { units: 1 });
    rsv = await reserveBudget({ brandId, mode, provider: reader.name, estimate: est, now, callRef: `page:${uh.slice(0, 16)}:${crypto.randomUUID().slice(0, 8)}` });
    r = await reader.read(url);
    // Okuyucu hata yerine durum döndürür: yanıtsız ulaşılamama (zaman aşımı/bağlantı) ücretli bir okuyucuda belirsizdir
    if (r.status === 'unreachable' && r.httpStatus == null && est.tryAmount > 0) await markUncertain(rsv.reservationId, `sayfa okuma ${url}: ${r.error ?? 'yanıt yok'}`);
    else if (r.status === 'blocked' && r.httpStatus == null) await releaseReservation(rsv.reservationId, `sayfa okunmadı (güvenlik/engel): ${r.error ?? ''}`);
    else await reconcileReservation(rsv.reservationId, { amountOriginal: est.original, currency: est.currency, item: key, succeeded: r.status === 'ok' });
  } catch (e) {
    if (rsv) await settleFailedCall(rsv.reservationId, e, `sayfa okuma ${url}`).catch(() => undefined);
    r = { url, finalUrl: url, status: e instanceof PriceUnknownError || e instanceof BudgetBlockedError ? 'blocked' : 'unreachable', error: (e as Error).message };
  }
  let status: string = r.status;
  let x: Extracted | null = null;
  if (r.status === 'ok' && r.body) {
    x = extract(r.body, r.finalUrl);
    if (x.injection) status = 'injection_flagged';
  }
  return withBrand(brandId, async (c) => {
    const row = (await c.query(
      `INSERT INTO source_documents (brand_id, url, url_hash, final_url, domain, status, http_status, content_hash, bytes, title, text_excerpt, extracted, error, fetched_at, is_simulated)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
       ON CONFLICT (brand_id, url_hash, is_simulated) DO UPDATE SET status=EXCLUDED.status, http_status=EXCLUDED.http_status, content_hash=EXCLUDED.content_hash, bytes=EXCLUDED.bytes, title=EXCLUDED.title, text_excerpt=EXCLUDED.text_excerpt, extracted=EXCLUDED.extracted, error=EXCLUDED.error, fetched_at=EXCLUDED.fetched_at
       RETURNING id`,
      [brandId, url, uh, r.finalUrl, safeDomain(r.finalUrl), status, r.httpStatus ?? null, r.body ? sha256(r.body) : null, r.bytes ?? null, x?.title ?? null, x?.text.slice(0, 5000) ?? null, status === 'ok' ? x : null, r.error ?? null, now, mode === 'simulation'])).rows[0];
    if (status === 'injection_flagged') await logEvent(c, { brandId, type: 'security.injection_detected', actor: 'research', subjectType: 'source_document', subjectId: row.id, payload: { url }, simulated: mode === 'simulation' });
    if (r.status === 'blocked' || r.status === 'disallowed') await logEvent(c, { brandId, type: 'research.source_blocked', actor: 'research', subjectType: 'source_document', subjectId: row.id, payload: { url, reason: r.error ?? r.status }, simulated: mode === 'simulation' });
    return { id: row.id, status, extracted: status === 'ok' ? x : null, fetchedAt: now, fetched: true };
  });
}

const safeDomain = (u: string) => { try { return new URL(u).hostname.replace(/^www\./, ''); } catch { return null; } };
