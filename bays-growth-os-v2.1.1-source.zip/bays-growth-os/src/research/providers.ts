import fs from 'node:fs';
import path from 'node:path';
import { config } from '../config.js';
import { egressFetch, type AdapterStatus } from '../integrations/egress.js';
import type { PageReader, ReadResult } from './safeReader.js';
import { validateUrl } from './safeReader.js';

/**
 * Arama sağlayıcısı sözleşmesi. Sonuç yalnız sağlayıcının döndürdüğü URL/başlık/özettir;
 * işletme bilgisi bunlardan değil, kaynağın kendisi okunarak çıkarılır.
 *
 * Seçim (belge kontrolü 14.10.2026):
 * - Brave Search API: resmî web arama API'si; 1.000 istek 5 USD, aylık 5 USD ücretsiz kredi; 50 sorgu/sn.
 *   (https://brave.com/search/api/ — sayfa güncelleme 2026-07-01). Ek abonelik gerektirmez; varsayılan kapalıdır.
 * - Google Custom Search JSON API yeni müşteriye kapalı ve 1 Ocak 2027'de kapanıyor → seçilmedi.
 * - Tavily: aylık 1.000 ücretsiz kredi; alternatif olarak not edildi, uygulanmadı.
 * Brave için TR ülke kodu ve tr dil kodu desteği belgede liste olarak görülmedi → canlı doğrulamada kontrol edilecek.
 */
export interface SearchResult { url: string; title: string; snippet: string; age?: string | null }
export interface SearchProvider { name: string; simulated: boolean; pricingKey: string; search(q: string, opts: { country: string; lang: string; count: number }): Promise<SearchResult[]> }

export class BraveSearchProvider implements SearchProvider {
  name = 'brave'; simulated = false; pricingKey = 'brave:web_search';
  constructor(private status: AdapterStatus) {}
  async search(q: string, opts: { country: string; lang: string; count: number }): Promise<SearchResult[]> {
    const key = config().BRAVE_SEARCH_API_KEY;
    const url = new URL('https://api.search.brave.com/res/v1/web/search');
    url.searchParams.set('q', q.slice(0, 400));
    url.searchParams.set('country', opts.country);
    url.searchParams.set('search_lang', opts.lang);
    url.searchParams.set('count', String(Math.min(opts.count, 20)));
    const res = await egressFetch({ adapter: 'brave-search', status: this.status, purpose: 'live', allowedHosts: ['api.search.brave.com'], credentialPresent: !!key,
      url: url.toString(), init: { headers: { accept: 'application/json', 'X-Subscription-Token': key } }, timeoutMs: 15000 });
    if (res.status === 429 || res.status >= 500) throw Object.assign(new Error(`brave ${res.status}`), { transient: true, httpStatus: res.status });
    if (res.status === 401 || res.status === 403) throw Object.assign(new Error(`brave ${res.status}: anahtar/izin geçersiz`), { httpStatus: res.status });
    if (!res.ok) throw Object.assign(new Error(`brave ${res.status}`), { httpStatus: res.status });
    const j: any = await res.json();
    return (j?.web?.results ?? []).map((r: any) => ({ url: String(r.url), title: String(r.title ?? ''), snippet: String(r.description ?? ''), age: r.age ?? r.page_age ?? null }))
      .filter((r: SearchResult) => { try { validateUrl(r.url); return true; } catch { return false; } });
  }
}

/** ÖRNEK veri sağlayıcısı (test/simülasyon): sorgu → sonuç eşlemesi dosyadan; ağ yok. */
export class FixtureSearchProvider implements SearchProvider {
  name = 'fixture'; simulated = true; pricingKey = 'fixture:search';
  calls: string[] = [];
  constructor(private dir = config().RESEARCH_FIXTURE_DIR) {}
  async search(q: string): Promise<SearchResult[]> {
    this.calls.push(q);
    const map = JSON.parse(fs.readFileSync(path.resolve(this.dir, 'search.json'), 'utf8'));
    return (map.queries[q] ?? map.default ?? []) as SearchResult[];
  }
}

export class FixturePageReader implements PageReader {
  name = 'fixture-pages'; simulated = true;
  reads: string[] = [];
  constructor(private dir = config().RESEARCH_FIXTURE_DIR) {}
  async read(url: string): Promise<ReadResult> {
    this.reads.push(url);
    try { validateUrl(url); } catch (e) { return { url, finalUrl: url, status: 'blocked', error: (e as Error).message }; }
    const idx = JSON.parse(fs.readFileSync(path.resolve(this.dir, 'pages.json'), 'utf8'));
    const p = idx[url];
    if (!p) return { url, finalUrl: url, status: 'unreachable', httpStatus: 404 };
    if (p.status && p.status !== 'ok') return { url, finalUrl: url, status: p.status, httpStatus: p.httpStatus, error: p.error };
    const body = fs.readFileSync(path.resolve(this.dir, 'pages', p.file), 'utf8');
    return { url, finalUrl: p.finalUrl ?? url, status: 'ok', httpStatus: 200, contentType: 'text/html', body, bytes: Buffer.byteLength(body) };
  }
}
