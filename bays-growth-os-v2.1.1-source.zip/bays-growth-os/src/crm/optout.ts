import type { Db } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { addSuppression, advanceStage } from './crm.js';

/**
 * Açık iletişim reddi: modelden ÖNCE, deterministik ve model/bütçe gerektirmeden işlenir.
 * Kesin ifadeler (listeden çıkarın, bir daha yazmayın, iletişime geçmeyin, rahatsız etmeyin, abonelikten çıkar…)
 * her durumda ret sayılır. Tek başına "istemiyorum/istemiyoruz" yalnız kısa ve çekincesiz bir yanıtsa veya
 * bizim iletilerimize yöneliyorsa ret sayılır. Çekinceli/belirsiz ifadeler ("şimdilik istemiyoruz, belki ileride",
 * "fiyat istemiyorum, önce demo") ret sayılmaz; mevcut model sınıflandırma yoluna gider.
 * Alıntılanan önceki ileti (">" satırları, "… yazdı:" sonrası) değerlendirmeye girmez: bizim altbilgimizdeki
 * "İSTEMİYORUM" talimatı yanıtın alıntısında geçebilir.
 */
// Türkçe kelime sınırı: JavaScript'in \b'si yalnız ASCII harfleri tanır ("önce", "şimdilik" gibi Türkçe karakterle
// başlayan/biten sözcüklerde yanlış sonuç verir). Bunun yerine Unicode harf/rakam bakışları kullanılır.
const L = String.raw`[\p{L}\p{N}]`;
/** Sözcük(ler)i Unicode kelime sınırıyla saran düzenli ifade üretir. */
const word = (src: string) => new RegExp(`(?<!${L})(?:${src})(?!${L})`, 'u');
const wordPrefix = (src: string) => new RegExp(`(?<!${L})(?:${src})`, 'u'); // ek alabilen kökler (çıkar → çıkarın)

const STRONG = [
  wordPrefix(String.raw`listeden\s+(beni\s+|bizi\s+)?(çıkar|sil)`),
  wordPrefix(String.raw`bir\s+daha\s+(bize\s+|bana\s+)?(yazma|mesaj\s+atma|e-?posta\s+(gönderme|atma)|ulaşma|aramayın|aramayınız)`),
  word(String.raw`(iletişime|irtibata)\s+geçme(yin|yiniz)?`),
  word(String.raw`rahatsız\s+etme(yin|yiniz)?`),
  wordPrefix(String.raw`abonelikten\s+çık`),
  wordPrefix(String.raw`(e-?posta|mail|ileti|mesaj)\s*(ları|leri)?\s*(göndermeyin|atmayın|almak\s+istemiyorum|almak\s+istemiyoruz)`),
  word(String.raw`unsubscribe|spam`),
];
const WEAK = word(String.raw`istemiyor(um|uz)`);
const HEDGE = word(String.raw`şimdilik|şu\s+an|şu\s+anda|şu\s+sıralar|belki|ileride|daha\s+sonra|sonra(\s+tekrar)?\s+(yazın|yazarız|konuşuruz|konuşalım|arayın|ararız|döneriz|dönün)|sonra|bu\s+(ay|hafta|dönem|yıl)|ama|fakat|ancak|önce|yerine`);
const ABOUT_US = wordPrefix(String.raw`(bu\s+tür|bu|sizin|sizden)\s+(e-?postalar|e-?posta|mesajlar|iletiler|ileti|mailler|teklifler)`);

export function stripQuoted(text: string): string {
  const lines = text.replace(/\r/g, '').split('\n');
  const out: string[] = [];
  for (const l of lines) {
    if (/^\s*>/.test(l)) break;
    if (/(yazdı|wrote)\s*:\s*$/i.test(l.trim())) break;
    if (/^-{2,}\s*(original message|orijinal ileti|özgün ileti)/i.test(l.trim())) break;
    out.push(l);
  }
  return out.join('\n');
}

export function detectExplicitOptOut(text: string): boolean {
  const t = stripQuoted(text ?? '').toLocaleLowerCase('tr-TR').replace(/\s+/g, ' ').trim();
  if (!t) return false;
  if (STRONG.some((re) => re.test(t))) return true;
  if (!WEAK.test(t)) return false;
  if (HEDGE.test(t)) return false;
  const words = t.replace(/[^\p{L}\p{N}\s-]/gu, ' ').split(' ').filter(Boolean);
  if (words.length <= 6) return true;          // "Hayır, istemiyorum. Teşekkürler."
  return ABOUT_US.test(t);                    // "Bu tür e-postalar istemiyorum"
}

/**
 * Açık reddi uygular (yanıt kaydıyla aynı veritabanı işleminde çağrılır). İdempotent: aynı aday için ikinci kez
 * olay, görev veya durum değişikliği üretmez.
 */
export async function applyExplicitOptOut(c: Db, a: { brandId: string; leadId: string; interactionId: string | null; simulated: boolean; actor?: string }): Promise<{ applied: boolean; cancelledTasks: number; skippedManual: number }> {
  const lead = (await c.query(`SELECT id, business_key, stage FROM leads WHERE id=$1 FOR UPDATE`, [a.leadId])).rows[0];
  if (!lead) return { applied: false, cancelledTasks: 0, skippedManual: 0 };
  const done = (await c.query(`SELECT 1 FROM operation_events WHERE event_type='contact.opted_out' AND subject_type='lead' AND subject_id=$1 LIMIT 1`, [a.leadId])).rowCount;
  if (a.interactionId) await c.query(`UPDATE interactions SET content = content || '{"opt_out": true}'::jsonb WHERE id=$1`, [a.interactionId]);
  if (done) return { applied: false, cancelledTasks: 0, skippedManual: 0 };
  const contacts = (await c.query(`SELECT email FROM contacts WHERE lead_id=$1 AND email IS NOT NULL`, [a.leadId])).rows;
  await addSuppression(c, a.brandId, [{ type: 'business_key', value: lead.business_key }, ...contacts.map((x) => ({ type: 'email' as const, value: x.email }))], `açık ret (yanıt${a.interactionId ? ': interaction:' + a.interactionId : ''})`);
  if (lead.stage !== 'lost' && lead.stage !== 'won') {
    if (lead.stage === 'found' || lead.stage === 'fit_verified' || lead.stage === 'evaluated' || lead.stage === 'contact_planned' || lead.stage === 'contacted' || lead.stage === 'replied' || lead.stage === 'meeting' || lead.stage === 'proposal' || lead.stage === 'on_hold') {
      await advanceStage(c, a.leadId, 'lost', 'açık iletişim reddi', a.actor ?? 'customer_dev');
    }
  }
  const t = await c.query(`UPDATE tasks SET status='cancelled', last_error='İletişim reddi: aday iletişim istemiyor', updated_at=now()
     WHERE brand_id=$1 AND status IN ('queued','halted') AND kind IN ('contact_send','follow_up_check','lead_assess') AND input->>'leadId'=$2`, [a.brandId, a.leadId]);
  const m = await c.query(`UPDATE manual_tasks SET status='skipped', result = coalesce(result,'{}'::jsonb) || '{"reason":"aday iletişim istemiyor (açık ret)"}'::jsonb
     WHERE brand_id=$1 AND lead_id=$2 AND status='open' AND kind IN ('send_first_contact','send_follow_up','linkedin_message','linkedin_connection','add_contact')`, [a.brandId, a.leadId]);
  await logEvent(c, { brandId: a.brandId, type: 'contact.opted_out', actor: a.actor ?? 'customer_dev', subjectType: 'lead', subjectId: a.leadId,
    payload: { interactionId: a.interactionId, cancelledTasks: t.rowCount, skippedManual: m.rowCount, modelCalled: false }, simulated: a.simulated });
  return { applied: true, cancelledTasks: t.rowCount ?? 0, skippedManual: m.rowCount ?? 0 };
}
