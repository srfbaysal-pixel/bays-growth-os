import { config } from '../config.js';
import type { Db } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { normalizeBusinessKey, normalizeEmail, normalizePhone, sha256, dayKey } from '../core/util.js';
import { can } from '../integrations/capabilities.js';
import { clock } from '../core/clock.js';

export type Stage = 'found' | 'fit_verified' | 'evaluated' | 'contact_planned' | 'contacted' | 'replied' | 'meeting' | 'proposal' | 'won' | 'lost' | 'on_hold';

/** İzinli aşama geçişleri (bulundu → uygunluk doğrulandı → değerlendirildi → iletişim planlandı → kuruldu → yanıt → görüşme → teklif → sonuç) */
const TRANSITIONS: Record<Stage, Stage[]> = {
  found: ['fit_verified', 'lost', 'on_hold'],
  fit_verified: ['evaluated', 'lost', 'on_hold'],
  evaluated: ['contact_planned', 'lost', 'on_hold'],
  contact_planned: ['contacted', 'on_hold', 'lost'],
  contacted: ['replied', 'on_hold', 'lost'],
  replied: ['meeting', 'on_hold', 'lost'],
  meeting: ['proposal', 'on_hold', 'lost'],
  proposal: ['won', 'lost', 'on_hold'],
  won: [], lost: ['on_hold'], on_hold: ['evaluated', 'contact_planned', 'replied', 'meeting', 'proposal', 'lost'],
};

export interface LeadInput {
  brandId: string; campaignId?: string | null; businessName: string; city?: string | null; domain?: string | null; phone?: string | null;
  sector?: string | null; sizeBand?: string | null; sourceUri?: string | null; sourceNote: string; needSignals?: string[]; isSample?: boolean;
}

/** Aday ekler. Aynı işletme (alan adı/telefon/ad+şehir) ikinci kez eklenmez; mevcut kayıt döner. */
export async function upsertLead(c: Db, l: LeadInput): Promise<{ id: string; duplicate: boolean }> {
  if (!l.sourceUri && !l.sourceNote) throw new Error('Aday kaynak gerektirir');
  const key = normalizeBusinessKey({ name: l.businessName, city: l.city, domain: l.domain, phone: l.phone });
  // Kip ayrımı: örnek aday canlı adayı (ve tersi) tekilleştirmede engellemez; kip belirtilmemişse çalışma kipine göre
  const sample = l.isSample ?? (config().RUN_MODE !== 'live');
  const ex = (await c.query(`SELECT id FROM leads WHERE brand_id=$1 AND business_key=$2 AND is_sample=$3`, [l.brandId, key, sample])).rows[0];
  if (ex) return { id: ex.id, duplicate: true };
  const r = await c.query(
    `INSERT INTO leads (brand_id, campaign_id, business_name, business_key, sector, city, size_band, source_uri, source_note, need_signals, is_sample)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT (brand_id, business_key, is_sample) DO NOTHING RETURNING id`,
    [l.brandId, l.campaignId ?? null, l.businessName, key, l.sector ?? null, l.city ?? null, l.sizeBand ?? null, l.sourceUri ?? null, l.sourceNote, JSON.stringify(l.needSignals ?? []), sample]);
  if (!r.rows[0]) return { id: (await c.query(`SELECT id FROM leads WHERE brand_id=$1 AND business_key=$2 AND is_sample=$3`, [l.brandId, key, sample])).rows[0].id, duplicate: true };
  await logEvent(c, { brandId: l.brandId, type: 'lead.found', actor: 'customer_dev', subjectType: 'lead', subjectId: r.rows[0].id, payload: { source: l.sourceUri ?? l.sourceNote }, simulated: sample });
  return { id: r.rows[0].id, duplicate: false };
}

export async function advanceStage(c: Db, leadId: string, to: Stage, reason: string, actor = 'customer_dev'): Promise<void> {
  const l = (await c.query(`SELECT brand_id, stage, is_sample FROM leads WHERE id=$1 FOR UPDATE`, [leadId])).rows[0];
  if (!l) throw new Error('Aday yok');
  if (l.stage === to) return;
  if (!TRANSITIONS[l.stage as Stage].includes(to)) throw new Error(`Geçersiz aşama geçişi: ${l.stage} → ${to}`);
  await c.query(`UPDATE leads SET stage=$2, updated_at=now() WHERE id=$1`, [leadId, to]);
  await logEvent(c, { brandId: l.brand_id, type: 'lead.stage_changed', actor, subjectType: 'lead', subjectId: leadId, payload: { from: l.stage, to, reason }, simulated: l.is_sample });
}

export function suppressionKey(type: 'email' | 'phone' | 'business_key' | 'linkedin', value: string): string {
  const v = type === 'email' ? normalizeEmail(value) : type === 'phone' ? normalizePhone(value) : value.trim().toLowerCase();
  return sha256(`${type}:${v}`);
}

/** İletişim istemeyen kişi/işletme: özet (hash) olarak saklanır, kişisel veri silinse de geçerli kalır. */
export async function addSuppression(c: Db, brandId: string, keys: { type: 'email' | 'phone' | 'business_key' | 'linkedin'; value: string }[], reason: string, scope: 'brand' | 'all_brands' = 'brand'): Promise<void> {
  for (const k of keys) {
    await c.query(`INSERT INTO suppression_entries (brand_id, scope, key_type, key_hash, reason) VALUES ($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING`, [brandId, scope, k.type, suppressionKey(k.type, k.value), reason]);
  }
  await logEvent(c, { brandId, type: 'suppression.added', actor: 'customer_dev', payload: { count: keys.length, scope, reason } });
}

export async function isSuppressed(c: Db, brandId: string, keys: { type: 'email' | 'phone' | 'business_key' | 'linkedin'; value: string }[]): Promise<boolean> {
  if (!keys.length) return false;
  const hashes = keys.map((k) => suppressionKey(k.type, k.value));
  const r = await c.query(`SELECT 1 FROM suppression_entries WHERE key_hash = ANY($2) AND (brand_id = $1 OR scope = 'all_brands') LIMIT 1`, [brandId, hashes]);
  return r.rowCount! > 0;
}

export interface ContactCheck { allowed: boolean; manualOnly: boolean; reasons: string[] }

/**
 * İlk temas kontrolü: hedef uygunluğu, kanal desteği ve iletişim kuralları ayrı ayrı denetlenir.
 * Kanal API'si desteklemiyorsa (ör. LinkedIn mesajı) yalnız manuel görev olur.
 */
export async function checkFirstContact(c: Db, input: { leadId: string; contactId?: string | null; channel: string; minFitScore?: number; now?: Date }): Promise<ContactCheck> {
  const reasons: string[] = [];
  const lead = (await c.query(`SELECT * FROM leads WHERE id=$1`, [input.leadId])).rows[0];
  if (!lead) return { allowed: false, manualOnly: false, reasons: ['Aday yok'] };
  const profile = (await c.query(`SELECT profile FROM brand_profiles WHERE brand_id=$1 AND validity='current' ORDER BY version DESC LIMIT 1`, [lead.brand_id])).rows[0]?.profile;
  const rules = profile?.contact_rules ?? { first_contact_daily_cap: 0 };

  if (!['evaluated', 'contact_planned'].includes(lead.stage)) reasons.push(`Aşama uygun değil: ${lead.stage}`);
  if (lead.fit_score == null || Number(lead.fit_score) < (input.minFitScore ?? 60)) reasons.push(`Uygunluk puanı yetersiz (${lead.fit_score ?? 'yok'})`);
  if ((lead.need_signals ?? []).length === 0) reasons.push('Kaynaklı ihtiyaç sinyali yok');

  const contact = input.contactId ? (await c.query(`SELECT * FROM contacts WHERE id=$1 AND lead_id=$2`, [input.contactId, input.leadId])).rows[0] : null;
  if (contact?.erased_at) reasons.push('Kişi verisi silinmiş');
  const keys: { type: 'email' | 'phone' | 'business_key' | 'linkedin'; value: string }[] = [{ type: 'business_key', value: lead.business_key }];
  if (contact?.email) keys.push({ type: 'email', value: contact.email });
  if (contact?.phone) keys.push({ type: 'phone', value: contact.phone });
  if (await isSuppressed(c, lead.brand_id, keys)) reasons.push('İletişim istemeyenler listesinde');

  // Kesin gönderilmemiş (failed) kayıtlar temas sayılmaz; gönderiliyor/gönderildi kayıtları mükerrer ilk temas engelidir
  const prior = (await c.query(`SELECT count(*)::int n FROM interactions WHERE brand_id=$1 AND lead_id=$2 AND direction='outbound' AND status <> 'failed'`, [lead.brand_id, input.leadId])).rows[0].n;
  if (prior > 0) reasons.push('Bu işletmeyle daha önce temas kurulmuş (mükerrer ilk temas engeli)');

  const today = dayKey(input.now ?? new Date());
  const sentToday = (await c.query(`SELECT count(*)::int n FROM interactions WHERE brand_id=$1 AND direction='outbound' AND kind='first_contact' AND (occurred_at AT TIME ZONE 'Europe/Istanbul')::date = $2::date`, [lead.brand_id, today])).rows[0].n;
  if (sentToday >= rules.first_contact_daily_cap) reasons.push(`Günlük ilk temas sınırı (${rules.first_contact_daily_cap}) doldu`);

  const cap = can(input.channel, 'first_message');
  const manualOnly = cap === 'restricted' || cap === 'unverified';
  if (cap === 'unsupported') reasons.push(`${input.channel} kanalı ilk mesajı desteklemiyor`);
  if (input.channel === 'email' && !contact?.email) reasons.push('Kaynaklı iş e-posta adresi yok');

  return { allowed: reasons.length === 0, manualOnly: reasons.length === 0 && manualOnly, reasons };
}

export async function recordInteraction(c: Db, i: { brandId: string; leadId: string; contactId?: string | null; campaignId?: string | null; taskId?: string | null; channel: string; direction: 'outbound' | 'inbound'; kind: string; content: any; idempotencyKey: string; simulated: boolean; externalId?: string | null; status?: string }): Promise<{ id: string; duplicate: boolean }> {
  const r = await c.query(
    `INSERT INTO interactions (brand_id, lead_id, contact_id, campaign_id, task_id, channel, direction, kind, content, idempotency_key, is_simulated, external_id, status, occurred_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) ON CONFLICT (brand_id, idempotency_key) DO NOTHING RETURNING id`,
    [i.brandId, i.leadId, i.contactId ?? null, i.campaignId ?? null, i.taskId ?? null, i.channel, i.direction, i.kind, i.content, i.idempotencyKey, i.simulated, i.externalId ?? null, i.status ?? 'recorded', clock.now()]);
  if (!r.rows[0]) return { id: (await c.query(`SELECT id FROM interactions WHERE brand_id=$1 AND idempotency_key=$2`, [i.brandId, i.idempotencyKey])).rows[0].id, duplicate: true };
  await logEvent(c, { brandId: i.brandId, type: `interaction.${i.direction}`, actor: 'customer_dev', subjectType: 'interaction', subjectId: r.rows[0].id, payload: { lead: i.leadId, channel: i.channel, kind: i.kind }, simulated: i.simulated });
  return { id: r.rows[0].id, duplicate: false };
}

/**
 * Nitelikli fırsat: ilgili ihtiyacı ve görüşmeye açık olduğu bilinen kayıt.
 * Bütçe ve karar yetkisi bilinmiyorsa "unknowns" içinde açıkça yazılır.
 */
export async function createQualifiedOpportunity(c: Db, o: { brandId: string; leadId: string; campaignId?: string | null; offerCode?: string | null; need: string; openToMeeting: boolean; evidence: string[]; unknowns: string[]; nextStep: string; simulated: boolean }): Promise<string> {
  if (!o.need || !o.openToMeeting) throw new Error('Nitelikli fırsat için ihtiyaç ve görüşmeye açıklık bilinmeli');
  if (!o.evidence.length) throw new Error('Fırsat kanıt gerektirir');
  const offer = o.offerCode ? (await c.query(`SELECT id FROM offers WHERE brand_id=$1 AND code=$2`, [o.brandId, o.offerCode])).rows[0]?.id ?? null : null;
  const unknowns = Array.from(new Set([...o.unknowns]));
  const r = await c.query(
    `INSERT INTO opportunities (brand_id, lead_id, campaign_id, offer_id, need_summary, evidence, unknowns, next_step, is_simulated) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
    [o.brandId, o.leadId, o.campaignId ?? null, offer, o.need, JSON.stringify(o.evidence), JSON.stringify(unknowns), o.nextStep, o.simulated]);
  await logEvent(c, { brandId: o.brandId, type: 'opportunity.qualified', actor: 'customer_dev', subjectType: 'opportunity', subjectId: r.rows[0].id, payload: { lead: o.leadId, unknowns }, simulated: o.simulated });
  return r.rows[0].id;
}

/** Gelir yalnız kurucu doğrularsa ve kampanyaya bağlantısı teyitliyse kampanya sonucu sayılır. */
export async function recordRevenue(c: Db, oppId: string, v: { valueTry: number; verifiedByFounder: boolean; attribution: 'campaign_confirmed' | 'unattributed' | 'unknown' }): Promise<void> {
  if (v.attribution === 'campaign_confirmed' && !v.verifiedByFounder) throw new Error('Kampanyaya bağlı gelir kurucu doğrulaması gerektirir');
  const o = (await c.query(`UPDATE opportunities SET status='won', value_try=$2, revenue_verified_by_founder=$3, attribution=$4, updated_at=now() WHERE id=$1 RETURNING brand_id, is_simulated`, [oppId, v.valueTry, v.verifiedByFounder, v.attribution])).rows[0];
  await logEvent(c, { brandId: o.brand_id, type: 'revenue.recorded', actor: v.verifiedByFounder ? 'founder' : 'system', subjectType: 'opportunity', subjectId: oppId, payload: v, simulated: o.is_simulated });
}
