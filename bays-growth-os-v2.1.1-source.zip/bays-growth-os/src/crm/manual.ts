import type { Db } from '../db/pool.js';
import { withBrand } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { enqueueTask } from '../core/tasks.js';
import { recordInteraction, advanceStage } from './crm.js';
import { resolveUncertainCost } from '../core/budget.js';
import { applyExplicitOptOut, detectExplicitOptOut } from './optout.js';

/**
 * Manuel görevler: sistemin yapamadığı veya yapmaması gereken işler (kısıtlı kanal, kapalı canlı gönderim, doğrulama).
 * Kurucu sonucu girince zincir devam eder: "gönderildi" → temas kaydı + takip görevi; "yanıt geldi" → yanıt sınıflandırma görevi.
 */
export async function createManualTask(c: Db, t: { brandId: string; kind: string; leadId?: string | null; contactId?: string | null; publicationId?: string | null; channel?: string | null; payload: any; dedupeKey: string; simulated: boolean }): Promise<string> {
  const r = await c.query(
    `INSERT INTO manual_tasks (brand_id, lead_id, contact_id, publication_id, kind, channel, payload, dedupe_key, is_simulated) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
     ON CONFLICT (brand_id, dedupe_key, is_simulated) DO NOTHING RETURNING id`,
    [t.brandId, t.leadId ?? null, t.contactId ?? null, t.publicationId ?? null, t.kind, t.channel ?? null, t.payload, t.dedupeKey, t.simulated]);
  if (r.rows[0]) {
    await logEvent(c, { brandId: t.brandId, type: 'manual_task.created', actor: 'system', subjectType: 'manual_task', subjectId: r.rows[0].id, payload: { kind: t.kind }, simulated: t.simulated });
    return r.rows[0].id;
  }
  return (await c.query(`SELECT id FROM manual_tasks WHERE brand_id=$1 AND dedupe_key=$2 AND is_simulated=$3`, [t.brandId, t.dedupeKey, t.simulated])).rows[0].id;
}

export interface ManualResult { outcome: 'sent' | 'not_sent' | 'reply_received' | 'done' | 'skipped'; sentAt?: string; replyText?: string; messageRef?: string; email?: string; note?: string; charged?: boolean; amountOriginal?: number; currency?: string }

export async function completeManualTask(brandId: string, id: string, result: ManualResult, by: string, now = new Date()): Promise<{ status: string; next: string[] }> {
  // Belirsiz gider uzlaştırması: defter işlemi kendi (sistem) işleminde ve idempotent; manuel iş sonra kapatılır
  const pre = await withBrand(brandId, async (c) => (await c.query(`SELECT kind, status, payload FROM manual_tasks WHERE id=$1`, [id])).rows[0]);
  if (pre?.kind === 'reconcile_cost' && pre.status === 'open' && result.outcome === 'done') {
    if (typeof result.charged !== 'boolean') throw Object.assign(new Error('Uzlaştırma için "ücretlendi mi" (charged) bilgisi gerekli'), { statusCode: 400 });
    await resolveUncertainCost(pre.payload.reservationId, { charged: result.charged, amountOriginal: result.amountOriginal, currency: result.currency, by });
  }
  return withBrand(brandId, async (c) => {
    const m = (await c.query(`SELECT * FROM manual_tasks WHERE id=$1 FOR UPDATE`, [id])).rows[0];
    if (!m) throw Object.assign(new Error('Manuel görev yok'), { statusCode: 404 });
    if (m.status !== 'open') return { status: m.status, next: [] }; // tekrar kapatma yeni işlem üretmez
    const next: string[] = [];
    const profile = (await c.query(`SELECT profile FROM brand_profiles WHERE brand_id=$1 AND validity='current' ORDER BY version DESC LIMIT 1`, [brandId])).rows[0]?.profile;
    const gapDays = profile?.contact_rules?.follow_up_gap_days ?? 5;
    if ((m.kind === 'send_first_contact' || m.kind === 'send_follow_up' || m.kind === 'linkedin_message') && result.outcome === 'sent') {
      const sentAt = result.sentAt ? new Date(result.sentAt) : now;
      const kind = m.kind === 'send_follow_up' ? 'follow_up' : 'first_contact';
      const n = m.payload?.followUpNo ?? 1;
      const idem = kind === 'first_contact' ? `first_contact:${m.lead_id}` : `follow_up:${m.lead_id}:${n}`;
      const i = await recordInteraction(c, { brandId, leadId: m.lead_id, contactId: m.contact_id, channel: m.channel ?? 'email', direction: 'outbound', kind, content: { via: 'manual', note: result.note ?? null }, idempotencyKey: idem, simulated: m.is_simulated, status: 'manual_sent' });
      if (!i.duplicate) {
        const st = (await c.query(`SELECT stage FROM leads WHERE id=$1`, [m.lead_id])).rows[0].stage;
        if (kind === 'first_contact') {
          if (st === 'evaluated') await advanceStage(c, m.lead_id, 'contact_planned', 'manuel gönderim', by);
          if (['evaluated', 'contact_planned'].includes(st)) await advanceStage(c, m.lead_id, 'contacted', 'kurucu gönderdi', by);
        }
        const t = await enqueueTask(c, { brandId, role: 'customer_dev', kind: 'follow_up_check', idempotencyKey: `follow_up_check:${m.lead_id}:${kind === 'first_contact' ? 1 : n + 1}`, input: { leadId: m.lead_id, followUpNo: kind === 'first_contact' ? 1 : n + 1 }, runAt: new Date(sentAt.getTime() + gapDays * 86400_000), simulated: m.is_simulated });
        next.push(`follow_up_check:${t.id}`);
      }
    }
    if (m.kind === 'add_contact' && result.outcome === 'done' && result.email) {
      // Kurucunun doğruladığı adres: kaynağı "kurucu tarafından doğrulandı" olarak işaretlenir
      await c.query(`INSERT INTO contacts (brand_id, lead_id, email, contact_basis, is_sample) VALUES ($1,$2,$3,$4,$5)`, [brandId, m.lead_id, result.email.trim().toLowerCase(), `kurucu tarafından doğrulandı (${now.toISOString()})`, m.is_simulated]);
      const t = await enqueueTask(c, { brandId, role: 'customer_dev', kind: 'contact_send', idempotencyKey: `contact_send:${m.lead_id}:after_add_contact`, input: { leadId: m.lead_id, kind: 'first_contact' }, simulated: m.is_simulated });
      next.push(`contact_send:${t.id}`);
    }
    if (result.outcome === 'reply_received' && result.replyText) {
      const msgId = result.messageRef ?? `manual:${id}`;
      const i = await recordInteraction(c, { brandId, leadId: m.lead_id, contactId: m.contact_id, channel: m.channel ?? 'email', direction: 'inbound', kind: 'reply', content: { text: result.replyText, via: 'manual' }, idempotencyKey: `reply:${msgId}`, simulated: m.is_simulated, externalId: msgId, status: 'received' });
      if (!i.duplicate) {
        // Açık ret modelden önce ve yanıt kaydıyla aynı işlemde
        if (detectExplicitOptOut(result.replyText)) await applyExplicitOptOut(c, { brandId, leadId: m.lead_id, interactionId: i.id, simulated: m.is_simulated, actor: by });
        const t = await enqueueTask(c, { brandId, role: 'customer_dev', kind: 'reply_classify', idempotencyKey: `reply:${msgId}`, input: { leadId: m.lead_id, interactionId: i.id }, simulated: m.is_simulated });
        next.push(`reply_classify:${t.id}`);
      }
    }
    await c.query(`UPDATE manual_tasks SET status=$2, result=$3, completed_by=$4, completed_at=$5 WHERE id=$1`, [id, result.outcome === 'skipped' || result.outcome === 'not_sent' ? 'skipped' : 'done', result, by, now]);
    await logEvent(c, { brandId, type: 'manual_task.completed', actor: by, subjectType: 'manual_task', subjectId: id, payload: { outcome: result.outcome, next }, simulated: m.is_simulated });
    return { status: 'done', next };
  });
}
