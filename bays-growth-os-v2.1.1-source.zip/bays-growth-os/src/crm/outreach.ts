import crypto from 'node:crypto';
import { config } from '../config.js';
import { withBrand, type Db } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { quietUntil } from '../core/clock.js';
import { evaluateAction } from '../core/authority.js';
import { egressFetch, EgressBlockedError } from '../integrations/egress.js';
import { signBody } from '../integrations/linkedin.js';
import { checkFirstContact, isSuppressed, recordInteraction, advanceStage } from './crm.js';
import { createManualTask } from './manual.js';
import { applyExplicitOptOut, detectExplicitOptOut } from './optout.js';
import { enqueueTask } from '../core/tasks.js';

/**
 * Müşteriye ilk temas ve takip. Kurallar:
 * - Hiçbir kanalda ilk temas kendiliğinden "açık" değildir: e-posta canlı gönderimi için kanal "live" + CUSTOMER_EMAIL_LIVE=true
 *   + alıcı adresi kaynakta doğrulanmış + iletişim istemeyenlerde değil + günlük sınır + sessiz saat dışı olmalı.
 * - Koşullardan biri yoksa: manuel görev (taslakla). Taslak gönderilmiş sayılmaz; manuel görev "gönderildi" diye kapatılınca temas kaydı oluşur.
 * - LinkedIn mesaj/davet: daima manuel görev (API kısıtlı; tarayıcı otomasyonu kullanılmaz).
 * - Simülasyonda "mock" e-posta bağlantısı gönderimi örnek olarak kaydeder (is_simulated).
 */
export type ContactKind = 'first_contact' | 'follow_up';
export type ContactOutcome =
  | { result: 'sent'; interactionId: string; messageId: string; simulated: boolean }
  | { result: 'manual'; manualTaskId: string; reason: string }
  | { result: 'deferred'; until: Date; reason: string }
  | { result: 'blocked'; reasons: string[] }
  | { result: 'uncertain'; manualTaskId: string; reason: string };

type Pending = { live: true; interactionId: string; messageId: string; body: string; contactId: string; lead: any; draft: any };

/**
 * Canlı gönderim çift gönderime karşı korunur:
 * 1) "sending" kaydı yazılır ve işlem kapanır (dış çağrıdan ÖNCE);
 * 2) dış çağrı işlem dışında yapılır; worker kirası kaybedilmişse çağrı yapılmaz;
 * 3) yanıt kesinse "sent"/"failed" yazılır; belirsizse (zaman aşımı/5xx) kayıt "sending" kalır ve kurucuya doğrulama görevi açılır.
 * Yeniden denemede "sending" kayıt görülürse tekrar gönderilmez.
 */
export async function contactLead(input: { brandId: string; leadId: string; kind: ContactKind; followUpNo?: number; draftAssetId: string; now: Date; simulated: boolean; taskId?: string | null; signal?: AbortSignal }): Promise<ContactOutcome> {
  const { brandId, leadId } = input;
  const idem = input.kind === 'first_contact' ? `first_contact:${leadId}` : `follow_up:${leadId}:${input.followUpNo ?? 1}`;
  const step1 = await withBrand(brandId, async (c): Promise<ContactOutcome | Pending> => {
    await c.query(`SELECT pg_advisory_xact_lock(hashtext($1))`, [`contact:${brandId}:${leadId}`]);
    // Yetki ve durdurma her şeyden önce: durdurma varken önceki sonuç bile yeniden raporlanmaz
    const d = await evaluateAction(c, { brandId, action: input.kind === 'first_contact' ? 'contact.first' : 'reply.routine', channel: 'email', external: true });
    if (d.decision !== 'allow') return { result: 'blocked', reasons: d.reasons };
    const prior = (await c.query(`SELECT id, status, external_id FROM interactions WHERE brand_id=$1 AND idempotency_key=$2`, [brandId, idem])).rows[0];
    if (prior?.status === 'sending') {
      const m = await createManualTask(c, { brandId, kind: 'verify_publication', leadId, channel: 'email', payload: { note: 'Önceki gönderim sonucu belirsiz; e-postanın gidip gitmediğini gönderilenler kutusundan kontrol edin. Sistem yeniden göndermez.', interactionId: prior.id }, dedupeKey: `verify_send:${prior.id}`, simulated: input.simulated });
      return { result: 'uncertain', manualTaskId: m, reason: 'önceki gönderim sonucu belirsiz; yeniden gönderilmedi' };
    }
    if (prior && ['sent', 'manual_sent', 'delivered'].includes(prior.status)) return { result: 'sent', interactionId: prior.id, messageId: prior.external_id, simulated: input.simulated };
    const lead = (await c.query(`SELECT * FROM leads WHERE id=$1`, [leadId])).rows[0];
    const contact = (await c.query(`SELECT * FROM contacts WHERE lead_id=$1 AND erased_at IS NULL ORDER BY created_at LIMIT 1`, [leadId])).rows[0];
    const draft = (await c.query(`SELECT content FROM assets WHERE id=$1`, [input.draftAssetId])).rows[0]?.content;
    const profile = (await c.query(`SELECT profile FROM brand_profiles WHERE brand_id=$1 AND validity='current' ORDER BY version DESC LIMIT 1`, [brandId])).rows[0]?.profile;
    const rules = profile?.contact_rules ?? {};

    if (input.kind === 'first_contact') {
      const chk = await checkFirstContact(c, { leadId, contactId: contact?.id ?? null, channel: 'email', now: input.now });
      const missingContact = chk.reasons.some((r) => /e-posta adresi yok/.test(r));
      const hardBlocks = chk.reasons.filter((r) => !/e-posta adresi yok/.test(r));
      if (hardBlocks.length) return { result: 'blocked', reasons: hardBlocks };
      if (missingContact) {
        const m = await createManualTask(c, { brandId, kind: 'add_contact', leadId, channel: 'email', payload: { draft, note: 'Kaynakta işletmenin kendi alan adında yayımlanmış iletişim adresi bulunamadı; adres uydurulmadı. Doğrulanmış adres eklerseniz taslak gönderilebilir veya LinkedIn mesajını elle gönderebilirsiniz.' }, dedupeKey: `add_contact:${leadId}`, simulated: input.simulated });
        await createManualTask(c, { brandId, kind: 'linkedin_message', leadId, channel: 'linkedin', payload: { draft, note: 'LinkedIn mesajı API ile gönderilemez (kısıtlı); elle gönderip sonucu girin' }, dedupeKey: `linkedin_message:${leadId}`, simulated: input.simulated });
        return { result: 'manual', manualTaskId: m, reason: 'iletişim adresi doğrulanmadı' };
      }
    } else {
      const replied = (await c.query(`SELECT 1 FROM interactions WHERE brand_id=$1 AND lead_id=$2 AND direction='inbound' LIMIT 1`, [brandId, leadId])).rowCount;
      const keys: any[] = [{ type: 'business_key', value: lead.business_key }];
      if (contact?.email) keys.push({ type: 'email', value: contact.email });
      if (replied) return { result: 'blocked', reasons: ['Aday yanıt vermiş; takip gönderilmez'] };
      if (await isSuppressed(c, brandId, keys)) return { result: 'blocked', reasons: ['İletişim istemeyenler listesinde'] };
      if ((input.followUpNo ?? 1) > (rules.follow_up_max ?? 0)) return { result: 'blocked', reasons: ['Takip sınırı doldu'] };
      if (['lost', 'on_hold', 'replied', 'meeting'].includes(lead.stage)) return { result: 'blocked', reasons: [`Aşama: ${lead.stage}`] };
    }
    const quiet = quietUntil(input.now, rules.quiet_hours ?? '20:00-09:00');
    if (quiet) return { result: 'deferred', until: quiet, reason: 'sessiz saat' };

    const conn = (await c.query(`SELECT status FROM channel_connections WHERE brand_id=$1 AND channel='email' ORDER BY (status='live') DESC, (status='mock') DESC, updated_at DESC LIMIT 1`, [brandId])).rows[0]?.status;
    // Doğrulanmış alıcı: işletmenin kendi alan adında, kaynakta yayımlanmış adres veya kurucunun doğruladığı adres
    const verifiedRecipient = !!contact?.email && /^(Kaynak sayfada yayımlanmış|kurucu tarafından doğrulandı)/.test(contact.contact_basis ?? '');
    // Kip ayrımı: ÖRNEK görev/aday canlı bağlantıyla asla yürütülmez; canlı görev de mock kanalı "gönderildi" sayamaz
    if (input.simulated && (conn === 'live' || config().RUN_MODE === 'live')) return { result: 'blocked', reasons: ['Örnek (simülasyon) görev canlı kipte/canlı bağlantıyla yürütülmez'] };
    if (!input.simulated && lead.is_sample) return { result: 'blocked', reasons: ['Örnek aday canlı temasa konu olamaz'] };
    const live = conn === 'live' && config().CUSTOMER_EMAIL_LIVE === 'true' && config().RUN_MODE === 'live' && verifiedRecipient;
    const messageId = `<bays-${crypto.randomUUID()}@bayssystems.local>`;

    if (conn === 'mock' && input.simulated) {
      const i = await recordInteraction(c, { brandId, leadId, contactId: contact?.id ?? null, taskId: input.taskId ?? null, channel: 'email', direction: 'outbound', kind: input.kind, content: { draft, note: 'SİMÜLASYON: gönderilmedi' }, idempotencyKey: idem, simulated: true, externalId: messageId, status: 'sent' });
      if (input.kind === 'first_contact') {
        if (lead.stage === 'evaluated') await advanceStage(c, leadId, 'contact_planned', 'kontroller geçti');
        await advanceStage(c, leadId, 'contacted', 'mock gönderim (SİMÜLASYON)');
      }
      return { result: 'sent', interactionId: i.id, messageId, simulated: true };
    }
    if (!live) {
      const reason = conn !== 'live' ? `e-posta bağlantısı ${conn ?? 'yok'}` : config().CUSTOMER_EMAIL_LIVE !== 'true' ? 'CUSTOMER_EMAIL_LIVE kapalı' : !verifiedRecipient ? 'alıcı adresi kaynakla doğrulanmadı' : 'canlı kip değil';
      const m = await createManualTask(c, { brandId, kind: input.kind === 'first_contact' ? 'send_first_contact' : 'send_follow_up', leadId, contactId: contact?.id ?? null, channel: 'email', payload: { draft, to: contact?.email ?? null, followUpNo: input.followUpNo ?? null, note: `Otomatik gönderim yapılmadı (${reason}). Gönderirseniz "gönderildi" olarak kapatın; taslak tek başına temas sayılmaz.` }, dedupeKey: idem, simulated: input.simulated });
      if (input.kind === 'first_contact' && lead.stage === 'evaluated') await advanceStage(c, leadId, 'contact_planned', 'taslak hazır, manuel gönderim bekliyor');
      return { result: 'manual', manualTaskId: m, reason };
    }
    // Canlı: önce "sending" kaydı (kesin olarak gönderilmemiş önceki "failed" kayıt yeniden kullanılır)
    const body = JSON.stringify({ contract: 'bays.outreach.v1', to: contact.email, subject: draft.subject ?? 'Kısa bir soru', text: `${draft.draft}\n\n—\nBu tür e-postaları almak istemiyorsanız "İSTEMİYORUM" yazarak yanıtlamanız yeterli.`, message_id: messageId });
    let interactionId: string;
    if (prior?.status === 'failed') {
      await c.query(`UPDATE interactions SET status='sending', external_id=$2, occurred_at=$3 WHERE id=$1`, [prior.id, messageId, input.now]);
      interactionId = prior.id;
    } else {
      interactionId = (await recordInteraction(c, { brandId, leadId, contactId: contact.id, taskId: input.taskId ?? null, channel: 'email', direction: 'outbound', kind: input.kind, content: { subject: draft.subject }, idempotencyKey: idem, simulated: false, externalId: messageId, status: 'sending' })).id;
    }
    return { live: true, interactionId, messageId, body, contactId: contact.id, lead, draft };
  });
  if (!('live' in step1)) return step1;

  // Dış çağrı işlem dışında; kira kaybedildiyse çağrı yapılmaz (kayıt "sending" kalır → sonraki denemede doğrulama görevi)
  if (input.signal?.aborted) throw new Error('worker kirası kaybedildi; gönderim yapılmadı');
  const cfg = config();
  let outcome: 'sent' | 'failed' | 'uncertain';
  let detail = '';
  try {
    const res = await egressFetch({ adapter: 'n8n-email', status: 'live', purpose: 'live', allowedHosts: [new URL(cfg.N8N_BASE_URL).host], credentialPresent: !!cfg.N8N_SHARED_SECRET,
      url: `${cfg.N8N_BASE_URL.replace(/\/$/, '')}/webhook/${cfg.N8N_EMAIL_WEBHOOK_PATH}`, init: { method: 'POST', headers: { 'content-type': 'application/json', 'X-Bays-Signature': signBody(step1.body, cfg.N8N_SHARED_SECRET) }, body: step1.body } });
    if (res.ok) outcome = 'sent';
    else if (res.status >= 500) { outcome = 'uncertain'; detail = `n8n ${res.status}`; }
    else { outcome = 'failed'; detail = `n8n ${res.status}`; }
  } catch (e) {
    if (e instanceof EgressBlockedError) { outcome = 'failed'; detail = e.message; }
    else { outcome = 'uncertain'; detail = (e as Error).message; }
  }
  return withBrand(brandId, async (c) => {
    if (outcome === 'sent') {
      await c.query(`UPDATE interactions SET status='sent' WHERE id=$1`, [step1.interactionId]);
      if (input.kind === 'first_contact') { if (step1.lead.stage === 'evaluated') await advanceStage(c, leadId, 'contact_planned', 'kontroller geçti'); await advanceStage(c, leadId, 'contacted', 'e-posta gönderildi'); }
      await logEvent(c, { brandId, type: 'outreach.sent', actor: 'customer_dev', subjectType: 'interaction', subjectId: step1.interactionId, payload: { kind: input.kind } });
      return { result: 'sent', interactionId: step1.interactionId, messageId: step1.messageId, simulated: false } as ContactOutcome;
    }
    if (outcome === 'failed') {
      await c.query(`UPDATE interactions SET status='failed', content = content || $2::jsonb WHERE id=$1`, [step1.interactionId, JSON.stringify({ error: detail })]);
      const m = await createManualTask(c, { brandId, kind: input.kind === 'first_contact' ? 'send_first_contact' : 'send_follow_up', leadId, contactId: step1.contactId, channel: 'email', payload: { draft: step1.draft, note: `Otomatik gönderim yapılamadı (${detail}); gönderilmedi.` }, dedupeKey: `${idem}:failed`, simulated: input.simulated });
      return { result: 'manual', manualTaskId: m, reason: detail } as ContactOutcome;
    }
    const m = await createManualTask(c, { brandId, kind: 'verify_publication', leadId, channel: 'email', payload: { note: `Gönderim sonucu belirsiz (${detail}); gönderilenler kutusundan kontrol edin. Sistem yeniden göndermez.`, interactionId: step1.interactionId }, dedupeKey: `verify_send:${step1.interactionId}`, simulated: input.simulated });
    return { result: 'uncertain', manualTaskId: m, reason: detail } as ContactOutcome;
  });
}

/**
 * Gelen yanıtı kaydeder: imzalı webhook (n8n IMAP) veya kurucunun manuel girişi.
 * Eşleştirme: In-Reply-To = gönderdiğimiz Message-ID, yoksa gönderen adresi. Eşleşmezse "match_reply" manuel görevi.
 * Aynı mesaj kimliği ikinci kez gelirse yeni işlem üretmez.
 */
export async function ingestReply(r: { brandId: string; messageId: string; from?: string | null; inReplyTo?: string | null; text: string; receivedAt: Date; via: 'webhook' | 'manual'; leadId?: string | null; simulated: boolean; enqueueClassify?: boolean }): Promise<{ status: 'recorded' | 'duplicate' | 'unmatched'; leadId?: string; interactionId?: string; manualTaskId?: string; optOut?: boolean }> {
  return withBrand(r.brandId, async (c) => {
    let leadId = r.leadId ?? null;
    let contactId: string | null = null;
    if (leadId) {
      // Elle girilen aday kimliği bu markaya ait olmalı (RLS'e ek açık denetim)
      const own = (await c.query(`SELECT 1 FROM leads WHERE id=$1 AND brand_id=$2`, [leadId, r.brandId])).rowCount;
      if (!own) throw Object.assign(new Error('Aday bu markaya ait değil'), { statusCode: 404 });
    }
    if (!leadId && r.inReplyTo) {
      const m = (await c.query(`SELECT lead_id, contact_id FROM interactions WHERE brand_id=$1 AND direction='outbound' AND external_id=$2 LIMIT 1`, [r.brandId, r.inReplyTo])).rows[0];
      if (m) { leadId = m.lead_id; contactId = m.contact_id; }
    }
    if (!leadId && r.from) {
      const m = (await c.query(`SELECT lead_id, id FROM contacts WHERE brand_id=$1 AND lower(email)=lower($2) AND erased_at IS NULL ORDER BY created_at DESC LIMIT 1`, [r.brandId, r.from])).rows[0];
      if (m) { leadId = m.lead_id; contactId = m.id; }
    }
    if (!leadId) {
      const m = await createManualTask(c, { brandId: r.brandId, kind: 'match_reply', channel: 'email', payload: { messageId: r.messageId, text: r.text.slice(0, 2000), receivedAt: r.receivedAt }, dedupeKey: `match_reply:${r.messageId}`, simulated: r.simulated });
      return { status: 'unmatched', manualTaskId: m };
    }
    const i = await recordInteraction(c, { brandId: r.brandId, leadId, contactId, channel: 'email', direction: 'inbound', kind: 'reply', content: { text: r.text, via: r.via }, idempotencyKey: `reply:${r.messageId}`, simulated: r.simulated, externalId: r.messageId, status: 'received' });
    if (i.duplicate) {
      // Yeniden teslimde sınıflandırma görevi yoksa (önceki deneme yarıda kaldıysa) yine de kuyruğa alınır
      if (r.enqueueClassify) await enqueueTask(c, { brandId: r.brandId, role: 'customer_dev', kind: 'reply_classify', idempotencyKey: `reply:${r.messageId}`, input: { leadId, interactionId: i.id }, simulated: r.simulated });
      return { status: 'duplicate', leadId, interactionId: i.id };
    }
    // Açık ret: modelden önce, yanıt kaydıyla AYNI işlemde (model anahtarı/bütçe gerekmez)
    let optOut = false;
    if (detectExplicitOptOut(r.text)) { await applyExplicitOptOut(c, { brandId: r.brandId, leadId, interactionId: i.id, simulated: r.simulated, actor: `reply:${r.via}` }); optOut = true; }
    // Yanıt kaydı ve sınıflandırma görevi AYNI işlemde: çökmede yanıt kaybolmaz
    if (r.enqueueClassify) await enqueueTask(c, { brandId: r.brandId, role: 'customer_dev', kind: 'reply_classify', idempotencyKey: `reply:${r.messageId}`, input: { leadId, interactionId: i.id }, simulated: r.simulated });
    return { status: 'recorded', leadId, interactionId: i.id, optOut };
  });
}

export type { Db };
