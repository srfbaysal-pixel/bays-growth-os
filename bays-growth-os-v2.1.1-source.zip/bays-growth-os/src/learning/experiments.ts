import type { Db } from '../db/pool.js';
import { logEvent } from '../core/events.js';
import { addKnowledge, rollbackKnowledge } from '../core/knowledge.js';
import { assertLearnable } from './rules.js';
import { clock } from '../core/clock.js';

export interface ExperimentSpec {
  brandId: string; campaignId?: string | null;
  hypothesis: string; primary_variable: string;
  comparison: { control: string; variant: string };
  sample_condition: { min_per_arm: number; min_days: number; min_relative_effect: number; justification: string };
  target_metric: string; cost_limit_try: number; stop_rule: string; rollback_plan: string; confounders: string[];
  simulated: boolean;
}

/** Deney kaydı: tüm alanlar zorunlu; örnek eşiği gerekçesiz kabul edilmez. */
export async function createExperiment(c: Db, s: ExperimentSpec): Promise<string> {
  const missing = (['hypothesis', 'primary_variable', 'target_metric', 'stop_rule', 'rollback_plan'] as const).filter((k) => !s[k] || String(s[k]).trim().length < 3);
  if (missing.length) throw new Error(`Deney eksik alan: ${missing.join(', ')}`);
  if (!s.sample_condition?.justification || s.sample_condition.justification.length < 10) throw new Error('Örnek/süre eşiği gerekçe gerektirir');
  if (!(s.cost_limit_try >= 0)) throw new Error('Gider sınırı gerekli');
  if (/saat|zaman/i.test(s.primary_variable) && !s.confounders.some((x) => /içerik|format/i.test(x))) throw new Error('Saat denemesinde içerik/format karıştırıcı olarak belirtilmeli');
  const r = await c.query(
    `INSERT INTO experiments (brand_id, campaign_id, hypothesis, primary_variable, comparison, sample_condition, target_metric, cost_limit_try, stop_rule, rollback_plan, confounders, status, started_at, is_simulated)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'running',$13,$12) RETURNING id`,
    [s.brandId, s.campaignId ?? null, s.hypothesis, s.primary_variable, s.comparison, s.sample_condition, s.target_metric, s.cost_limit_try, s.stop_rule, s.rollback_plan, JSON.stringify(s.confounders), s.simulated, clock.now()]);
  await logEvent(c, { brandId: s.brandId, type: 'experiment.started', actor: 'strategy', subjectType: 'experiment', subjectId: r.rows[0].id, payload: { hypothesis: s.hypothesis }, simulated: s.simulated });
  return r.rows[0].id;
}

export interface Evaluation {
  status: 'insufficient_data' | 'supported' | 'not_supported' | 'inconclusive';
  arms: Record<string, { n: number; mean: number | null; liveN: number }>;
  days: number;
  notes: string[];
  simulatedData: boolean;
}

/**
 * Deney değerlendirmesi. Kol başına örnek veya süre koşulu sağlanmadıysa hüküm verilmez.
 * Kollar arasında içerik türü dağılımı farklıysa (saat denemesi) sonuç "inconclusive" olur.
 * Mock ölçümler canlı sonuç sayılmaz; yalnız simülasyon deneyinde kullanılır.
 */
export async function evaluateExperiment(c: Db, experimentId: string, now = new Date()): Promise<Evaluation> {
  const e = (await c.query(`SELECT * FROM experiments WHERE id=$1`, [experimentId])).rows[0];
  if (!e) throw new Error('Deney yok');
  const sc = e.sample_condition;
  const rows = (await c.query(
    `SELECT m.arm, m.value::float8 AS value, m.source, m.is_simulated, a.content->>'content_type' AS content_type
     FROM metrics m LEFT JOIN publications p ON p.id=m.publication_id LEFT JOIN assets a ON a.id=p.asset_id
     WHERE m.experiment_id=$1 AND m.metric=$2 AND m.is_current`, [experimentId, e.target_metric])).rows;
  // V2.1: yayın başına yalnız güncel anlık görüntü sayılır (aynı gönderinin farklı zamanlardaki ölçümleri ayrı örnek değildir).
  // Canlı deney yalnız gerçek ölçümü, örnek deney yalnız örnek ölçümü kullanır (karma ortalama yok).
  const usable = e.is_simulated ? rows.filter((r) => r.is_simulated) : rows.filter((r) => !r.is_simulated && r.source !== 'mock');
  const arms: Evaluation['arms'] = {};
  for (const armName of [e.comparison.control, e.comparison.variant]) {
    const xs = usable.filter((r) => r.arm === armName).map((r) => r.value);
    arms[armName] = { n: xs.length, mean: xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : null, liveN: rows.filter((r) => r.arm === armName && !r.is_simulated).length };
  }
  const days = Math.floor((now.getTime() - new Date(e.started_at).getTime()) / 86400_000);
  const notes: string[] = [];
  let status: Evaluation['status'];
  const ctl = arms[e.comparison.control], vr = arms[e.comparison.variant];
  if (ctl.n < sc.min_per_arm || vr.n < sc.min_per_arm || days < sc.min_days) {
    status = 'insufficient_data';
    notes.push(`Koşul: kol başına ≥${sc.min_per_arm} ölçüm ve ≥${sc.min_days} gün. Mevcut: ${ctl.n}/${vr.n} ölçüm, ${days} gün. Hüküm verilmedi.`);
  } else {
    const typesBy = (arm: string) => new Set(usable.filter((r) => r.arm === arm).map((r) => r.content_type ?? 'bilinmiyor'));
    const tc = typesBy(e.comparison.control), tv = typesBy(e.comparison.variant);
    const sameMix = tc.size === tv.size && [...tc].every((x) => tv.has(x));
    if (!sameMix) {
      status = 'inconclusive';
      notes.push('Kollar arasında içerik türü farklı; ana değişkenin etkisi formattan ayrılamıyor.');
    } else {
      const rel = ctl.mean! === 0 ? (vr.mean! > 0 ? Infinity : 0) : (vr.mean! - ctl.mean!) / Math.abs(ctl.mean!);
      if (rel >= sc.min_relative_effect) status = 'supported';
      else if (rel <= -sc.min_relative_effect) status = 'not_supported';
      else status = 'inconclusive';
      notes.push(`Göreli fark: ${Number.isFinite(rel) ? (rel * 100).toFixed(1) + '%' : '∞'} (eşik ${(sc.min_relative_effect * 100).toFixed(0)}%). Bu istatistiksel kesinlik değildir; küçük örnekte yönsel kanıttır.`);
    }
  }
  const simulatedData = usable.some((r) => r.is_simulated);
  if (simulatedData) notes.push('Ölçümler simülasyon verisidir; canlı sonuç değildir.');
  await c.query(`UPDATE experiments SET status=$2, result=$3 WHERE id=$1`, [experimentId, status, { arms, days, notes, simulatedData, evaluated_at: now.toISOString() }]);
  await logEvent(c, { brandId: e.brand_id, type: 'experiment.evaluated', actor: 'auditor', subjectType: 'experiment', subjectId: experimentId, payload: { status, arms, days }, simulated: e.is_simulated });
  return { status, arms, days, notes, simulatedData };
}

/**
 * Desteklenen yöntem sürümlü bilgiye "verified_rule" olarak eklenir ve geri alınabilir.
 * V2: kural yapılandırılmıştır ({rule_type, value, scope}); değer deneyin kazanan kolundan gelir ve
 * sonraki planlama/yürütme bunu resolveRule ile uygular. Yalnız öğrenilebilir kural türleri yazılabilir.
 */
export async function promoteSupportedMethod(c: Db, experimentId: string, itemKey: string, rule: { rule_type: string; scope?: Record<string, string>; [k: string]: unknown }): Promise<{ id: string; version: number }> {
  const e = (await c.query(`SELECT * FROM experiments WHERE id=$1`, [experimentId])).rows[0];
  if (e.status !== 'supported') throw new Error('Yalnız desteklenen deney sonucu kurala dönüşebilir');
  if (e.result?.simulatedData && !e.is_simulated) throw new Error('Simülasyon ölçümleriyle canlı kural oluşturulamaz');
  // Kural türü zorunlu ve öğrenilebilir türlerden biri olmalı: yapısız (uygulanamayan) kural yazılmaz
  if (!rule?.rule_type) throw new Error('Kural türü (rule_type) zorunlu');
  assertLearnable(rule.rule_type);
  const content = { rule_type: rule.rule_type, value: e.comparison.variant, scope: rule.scope ?? {}, basis: { experiment: experimentId, arms: e.result?.arms, notes: e.result?.notes }, causal_claim: false, note: 'Yönsel kanıt; nedensellik iddiası değildir' };
  return addKnowledge(c, { brandId: e.brand_id, itemKey, kind: 'verified_rule', content, sourceKind: 'experiment', createdBy: 'auditor', experimentId, isSample: e.is_simulated });
}

export async function rollbackMethod(c: Db, brandId: string, itemKey: string, reason: string) {
  return rollbackKnowledge(c, brandId, itemKey, 'auditor', reason);
}
