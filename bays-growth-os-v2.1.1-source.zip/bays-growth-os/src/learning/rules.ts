import type { Db } from '../db/pool.js';
import { logEvent } from '../core/events.js';

/**
 * Uygulanan öğrenme: geçerli (verified_rule) kurallar sonraki plan ve yürütmeyi değiştirir.
 * Kural içeriği yapılandırılmıştır: { rule_type, value, scope: {channel?, content_type?}, ... }.
 * Öncelik sırası: (1) kapsam özgüllüğü (daha çok eşleşen alan önce), (2) tazelik (valid_until geçmemiş; daha yeni gözlem önce),
 * (3) sürüm. Aynı özgüllük ve tazelikte farklı değer veren iki kural "çelişki"dir: hiçbiri uygulanmaz, varsayılan kullanılır ve kayda geçer.
 * Hipotezler (kind=hypothesis) asla kural olarak uygulanmaz. Politika anahtarları öğrenmeyle değiştirilemez.
 */
export const LEARNABLE_RULE_TYPES = ['publish_time', 'content_type_priority', 'outreach_cta'] as const;
export type RuleType = (typeof LEARNABLE_RULE_TYPES)[number];

export interface ResolvedRule<T = unknown> { value: T | null; source: 'rule' | 'default' | 'conflict'; ruleId?: string; version?: number; itemKey?: string; reason: string; candidates?: number }

export async function resolveRule<T>(c: Db, brandId: string, ruleType: RuleType, scope: { channel?: string; content_type?: string }, fallback: T, now = new Date(), opts: { simulated?: boolean } = {}): Promise<ResolvedRule<T>> {
  const rows = (await c.query(
    `SELECT id, item_key, version, content, observed_at, valid_until, is_sample FROM knowledge_versions
     WHERE brand_id=$1 AND kind='verified_rule' AND validity='current' AND content->>'rule_type' = $2`, [brandId, ruleType])).rows
    .filter((r) => !r.valid_until || new Date(r.valid_until) > now)
    // Simülasyon/örnek veriyle öğrenilen kural canlı yürütmede uygulanmaz
    .filter((r) => opts.simulated !== false || !r.is_sample);
  const matching = rows.filter((r) => {
    const s = r.content.scope ?? {};
    return Object.entries(s).every(([k, v]) => (scope as any)[k] === v);
  }).map((r) => ({ ...r, specificity: Object.keys(r.content.scope ?? {}).length }));
  if (!matching.length) return { value: fallback, source: 'default', reason: 'Geçerli kural yok; varsayılan kullanıldı' };
  matching.sort((a, b) => b.specificity - a.specificity || new Date(b.observed_at).getTime() - new Date(a.observed_at).getTime() || b.version - a.version);
  const top = matching[0];
  const rivals = matching.filter((m) => m.specificity === top.specificity && m.id !== top.id && JSON.stringify(m.content.value) !== JSON.stringify(top.content.value)
    && Math.abs(new Date(m.observed_at).getTime() - new Date(top.observed_at).getTime()) < 86400_000);
  if (rivals.length) {
    await logEvent(c, { brandId, type: 'learning.rule_conflict', actor: 'learning', payload: { ruleType, scope, keys: [top.item_key, ...rivals.map((r) => r.item_key)] }, simulated: opts.simulated });
    return { value: fallback, source: 'conflict', reason: `Çelişen kurallar (${[top.item_key, ...rivals.map((r) => r.item_key)].join(', ')}); varsayılan kullanıldı`, candidates: matching.length };
  }
  return { value: top.content.value as T, source: 'rule', ruleId: top.id, version: top.version, itemKey: top.item_key, reason: `${top.item_key} v${top.version} uygulandı`, candidates: matching.length };
}

export function assertLearnable(ruleType: string): asserts ruleType is RuleType {
  if (!(LEARNABLE_RULE_TYPES as readonly string[]).includes(ruleType)) throw new Error(`Öğrenmeyle değiştirilemeyen kural türü: ${ruleType}`);
}
