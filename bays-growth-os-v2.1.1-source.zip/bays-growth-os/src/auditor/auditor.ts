import { withAuditor, type Db } from '../db/pool.js';
import { createHalt } from '../core/halts.js';
import { logEvent, verifyEventChain } from '../core/events.js';
import { checkClaims } from '../agents/guards.js';
import { config } from '../config.js';
import { monthKey } from '../core/util.js';

/**
 * Bağımsız iç denetim. Denetçi ayrı veritabanı rolüyle bağlanır: her şeyi okur, yalnız bulgu,
 * durdurma kaydı ve olay günlüğü yazabilir. Müşteri, yayın ve maliyet kayıtlarını değiştiremez.
 * Kontroller deterministiktir; önemli bulgular ikinci, bağımsız bir sorguyla yeniden doğrulanır.
 */
export interface Finding {
  brand_id: string | null; check_id: string; severity: 'info' | 'low' | 'medium' | 'high' | 'critical';
  category: string; title: string; detail: Record<string, unknown>; evidence_refs: string[]; dedupe_key: string;
  bottleneck_area?: string; halt?: { scope: 'global' | 'brand' | 'channel' | 'campaign'; scopeValue?: string | null; reason: string };
  is_simulated?: boolean;
}

export interface AuditResult { findings: Finding[]; written: number; halts: string[] }

export async function runAudit(opts: { brandId?: string; now?: Date } = {}): Promise<AuditResult> {
  const now = opts.now ?? new Date();
  return withAuditor(async (c) => {
    const f: Finding[] = [];
    const B = opts.brandId ? 'AND brand_id = $1' : '';
    const P = opts.brandId ? [opts.brandId] : [];

    // 1) Çift yayın
    for (const r of (await c.query(`SELECT brand_id, asset_id, channel, array_agg(id::text) ids, bool_and(is_simulated) sim FROM publications
        WHERE status IN ('published','sending','outcome_unknown') ${B} GROUP BY brand_id, asset_id, channel HAVING count(*) > 1`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'dup_publication', severity: 'critical', category: 'operations', title: 'Aynı içerik aynı kanalda birden fazla kez yayına gitti', detail: { asset: r.asset_id, channel: r.channel }, evidence_refs: r.ids.map((i: string) => `publication:${i}`), dedupe_key: `dup_publication:${r.asset_id}:${r.channel}`, halt: { scope: 'channel', scopeValue: r.channel, reason: 'Çift yayın tespit edildi' }, is_simulated: r.sim });
    }
    // 2) Mükerrer ilk temas
    for (const r of (await c.query(`SELECT brand_id, lead_id, array_agg(id::text) ids, bool_and(is_simulated) sim FROM interactions WHERE direction='outbound' AND kind='first_contact' ${B} GROUP BY brand_id, lead_id HAVING count(*) > 1`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'dup_first_contact', severity: 'high', category: 'customer', title: 'Aynı işletmeye birden fazla ilk temas', detail: { lead: r.lead_id }, evidence_refs: r.ids.map((i: string) => `interaction:${i}`), dedupe_key: `dup_first_contact:${r.lead_id}`, is_simulated: r.sim });
    }
    // 3) İletişim istemeyen adaya temas
    for (const r of (await c.query(`SELECT i.brand_id, i.id::text iid, i.lead_id, i.is_simulated sim FROM interactions i JOIN leads l ON l.id=i.lead_id
        JOIN suppression_entries s ON (s.brand_id=i.brand_id OR s.scope='all_brands') AND s.key_hash = encode(sha256(convert_to('business_key:' || lower(trim(l.business_key)), 'UTF8')), 'hex')
        WHERE i.direction='outbound' AND i.occurred_at > s.created_at ${opts.brandId ? 'AND i.brand_id = $1' : ''}`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'suppressed_contacted', severity: 'critical', category: 'customer', title: 'İletişim istemeyen işletmeye temas kuruldu', detail: { lead: r.lead_id }, evidence_refs: [`interaction:${r.iid}`], dedupe_key: `suppressed_contacted:${r.iid}`, halt: { scope: 'brand', reason: 'İletişim tercihi ihlali' }, is_simulated: r.sim });
    }
    // 4) Bütçe ihlali ve uzlaştırılmamış rezervasyon
    const month = monthKey(now);
    const limit = Math.min(Number((await c.query(`SELECT value FROM settings WHERE key='budget.active_limit_try'`)).rows[0]?.value?.amount ?? config().BUDGET_TARGET_TRY), config().BUDGET_HARD_CAP_TRY);
    for (const r of (await c.query(`SELECT mode, coalesce(sum(amount_try),0)::float8 total, array_agg(id::text) ids FROM cost_ledger WHERE month=$1 GROUP BY mode`, [month])).rows) {
      if (r.total > limit) f.push({ brand_id: null, check_id: 'budget_breach', severity: 'critical', category: 'budget', title: `Aylık gider sınırı aşıldı (${r.mode})`, detail: { total: r.total, limit, mode: r.mode }, evidence_refs: r.ids.slice(0, 20).map((i: string) => `cost:${i}`), dedupe_key: `budget_breach:${r.mode}:${month}`, halt: r.mode === 'live' ? { scope: 'global', reason: 'Bütçe ihlali' } : undefined, is_simulated: r.mode === 'simulation' });
    }
    for (const r of (await c.query(`SELECT brand_id, id::text id, mode, est_try::float8 est, provider FROM budget_reservations WHERE status='uncertain' ${B}`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'uncertain_cost', severity: 'medium', category: 'budget', title: `Gideri belirsiz ücretli çağrı (${r.provider}): tahmini ${r.est} TL bütçede sayılıyor; kurucu uzlaştırması bekleniyor`, detail: { est: r.est }, evidence_refs: [`reservation:${r.id}`], dedupe_key: `uncertain_cost:${r.id}`, is_simulated: r.mode === 'simulation' });
    }
    for (const r of (await c.query(`SELECT brand_id, id::text id, mode FROM budget_reservations WHERE status='expired' ${B}`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'unreconciled_reservation', severity: 'medium', category: 'budget', title: 'Süresi dolmuş, gerçek giderle uzlaştırılmamış rezervasyon (toplamda sayılmaya devam ediyor)', detail: {}, evidence_refs: [`reservation:${r.id}`], dedupe_key: `unreconciled:${r.id}`, is_simulated: r.mode === 'simulation' });
    }
    // 5) Yayına giden/kontrolden geçmiş içerikte iddia kontrolünün bağımsız tekrarı
    const brands = (await c.query(`SELECT id, name FROM brands`)).rows;
    for (const a of (await c.query(`SELECT a.id::text id, a.brand_id, a.status, a.content, a.is_sample FROM assets a WHERE a.status IN ('passed_checks','published') AND a.kind IN ('post_text','outreach_draft') ${opts.brandId ? 'AND a.brand_id = $1' : ''}`, P)).rows) {
      const offers = (await c.query(`SELECT code, title, readiness FROM offers WHERE brand_id=$1`, [a.brand_id])).rows;
      const evidence = (await c.query(`SELECT 'ev:' || id AS ref FROM evidence WHERE brand_id=$1`, [a.brand_id])).rows.map((r) => r.ref);
      const brand = brands.find((b) => b.id === a.brand_id)!;
      const text = a.content.post_text ?? a.content.draft ?? '';
      const g = checkClaims(text, { brandName: brand.name, otherBrandNames: brands.filter((b) => b.id !== a.brand_id).map((b) => b.name), offers, evidenceIds: evidence }, a.content.claims_used ?? []);
      if (!g.ok) {
        const sev = g.violations.some((v) => v.severity === 'critical') ? 'critical' : 'high';
        f.push({ brand_id: a.brand_id, check_id: 'claim_recheck', severity: sev, category: 'content', title: `Kontrolden geçmiş içerikte ihlal: ${g.violations.map((v) => v.code).join(', ')}`, detail: { violations: g.violations, status: a.status }, evidence_refs: [`asset:${a.id}`], dedupe_key: `claim_recheck:${a.id}`, halt: a.status === 'published' && sev === 'critical' ? { scope: 'channel', scopeValue: a.content.channel ?? 'linkedin', reason: 'Yayınlanmış içerikte kritik iddia ihlali' } : undefined, is_simulated: a.is_sample });
      }
    }
    // 6) Marka karışması (veri sızıntısı): görev/varlık ile kampanyanın markası farklı
    for (const r of (await c.query(`SELECT t.id::text id, t.brand_id FROM tasks t JOIN campaigns k ON k.id=t.campaign_id WHERE k.brand_id <> t.brand_id ${opts.brandId ? 'AND t.brand_id = $1' : ''}
        UNION ALL SELECT a.id::text, a.brand_id FROM assets a JOIN campaigns k ON k.id=a.campaign_id WHERE k.brand_id <> a.brand_id ${opts.brandId ? 'AND a.brand_id = $1' : ''}`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'cross_brand_link', severity: 'critical', category: 'security', title: 'Kayıt başka markanın kampanyasına bağlanmış (marka karışması)', detail: {}, evidence_refs: [`record:${r.id}`], dedupe_key: `cross_brand:${r.id}`, halt: { scope: 'brand', reason: 'Marka izolasyonu ihlali' } });
    }
    // 7) Simülasyonun canlı gibi raporlanması / doğrulanmamış gelir
    for (const r of (await c.query(`SELECT p.id::text id, p.brand_id FROM publications p WHERE p.is_simulated = false AND p.adapter LIKE 'mock%' ${opts.brandId ? 'AND p.brand_id = $1' : ''}`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'mock_as_live', severity: 'critical', category: 'reporting', title: 'Mock adaptör kaydı canlı olarak işaretlenmiş', detail: {}, evidence_refs: [`publication:${r.id}`], dedupe_key: `mock_as_live:${r.id}` });
    }
    for (const r of (await c.query(`SELECT id::text id, brand_id, attribution, revenue_verified_by_founder v, is_simulated sim FROM opportunities WHERE status='won' ${B}`, P)).rows) {
      if (r.attribution !== 'campaign_confirmed' || !r.v) f.push({ brand_id: r.brand_id, check_id: 'unattributed_revenue', severity: 'info', category: 'reporting', title: 'Gelir kampanyaya kesin bağlanamaz (kaynak belirsiz veya kurucu doğrulaması yok); raporda ayrı gösterilir', detail: { attribution: r.attribution, verified: r.v }, evidence_refs: [`opportunity:${r.id}`], dedupe_key: `unattributed:${r.id}`, is_simulated: r.sim });
    }
    // 8) Operasyon sağlığı
    for (const r of (await c.query(`SELECT brand_id, status, count(*)::int n, array_agg(id::text) ids, bool_and(is_simulated) sim FROM tasks WHERE status IN ('dead_letter','failed') AND purpose='operation' ${B} GROUP BY brand_id, status`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: `tasks_${r.status}`, severity: 'medium', category: 'operations', title: `${r.n} görev ${r.status === 'dead_letter' ? 'hata kuyruğunda' : 'başarısız'}`, detail: { n: r.n }, evidence_refs: r.ids.slice(0, 10).map((i: string) => `task:${i}`), dedupe_key: `tasks_${r.status}:${r.brand_id}:${r.n}`, is_simulated: r.sim });
    }
    for (const r of (await c.query(`SELECT id::text id, brand_id, is_simulated sim FROM publications WHERE status='outcome_unknown' AND sent_at < $1::timestamptz - interval '1 hour' ${opts.brandId ? 'AND brand_id = $2' : ''}`, opts.brandId ? [now, opts.brandId] : [now])).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'unknown_outcome', severity: 'medium', category: 'operations', title: 'Yayın sonucu 1 saattir belirsiz; tekrar gönderilmedi, manuel uzlaştırma gerekli', detail: {}, evidence_refs: [`publication:${r.id}`], dedupe_key: `unknown_outcome:${r.id}`, is_simulated: r.sim });
    }
    for (const r of (await c.query(`SELECT brand_id, count(*)::int n, array_agg(subject_id) ids, bool_and(is_simulated) sim FROM operation_events WHERE event_type='security.injection_detected' ${B} GROUP BY brand_id`, P)).rows) {
      f.push({ brand_id: r.brand_id, check_id: 'injection_attempts', severity: 'medium', category: 'security', title: `${r.n} dış içerikte talimat girişimi tespit edildi ve bağlamdan çıkarıldı`, detail: { n: r.n }, evidence_refs: r.ids.slice(0, 10).map((i: string) => `task:${i}`), dedupe_key: `injection:${r.brand_id}:${r.n}`, is_simulated: r.sim });
    }
    // 9) Darboğazlar: pazarlamayla gizlenmemesi gereken ürün/kanıt/kapasite sorunları
    for (const b of brands.filter((x) => !opts.brandId || x.id === opts.brandId)) {
      const st = (await c.query(`SELECT status FROM brands WHERE id=$1`, [b.id])).rows[0].status;
      if (st !== 'active') continue;
      const offers = (await c.query(`SELECT readiness, count(*)::int n FROM offers WHERE brand_id=$1 GROUP BY readiness`, [b.id])).rows;
      if (!offers.some((o) => o.readiness === 'test_verified' || o.readiness === 'demo')) {
        f.push({ brand_id: b.id, check_id: 'trust_proof_gap', severity: 'medium', category: 'bottleneck', bottleneck_area: 'trust_proof', title: 'Hiçbir hizmet demo veya testle doğrulanmış değil: güven kanıtı darboğazı. İçerik bu eksiği kapatamaz; önce çalışan demo/test kaydı gerekli.', detail: { offers }, evidence_refs: [`brand:${b.id}`], dedupe_key: `trust_proof_gap:${b.id}` });
      }
      const pubs = (await c.query(`SELECT p.id::text id FROM publications p WHERE p.brand_id=$1 AND p.status='published' AND NOT EXISTS (SELECT 1 FROM metrics m WHERE m.publication_id=p.id)`, [b.id])).rows;
      if (pubs.length) f.push({ brand_id: b.id, check_id: 'measurement_gap', severity: 'low', category: 'bottleneck', bottleneck_area: 'channel', title: `${pubs.length} yayının ölçümü yok (eksik ölçüm sıfır sonuç değildir)`, detail: { n: pubs.length }, evidence_refs: pubs.slice(0, 10).map((p) => `publication:${p.id}`), dedupe_key: `measurement_gap:${b.id}:${pubs.length}` });
      const mtg = (await c.query(`SELECT id::text id FROM meetings WHERE brand_id=$1 AND status IN ('proposed','awaiting_founder')`, [b.id])).rows;
      const capacity = (await c.query(`SELECT value FROM settings WHERE key='founder.meeting_capacity_per_week'`)).rows[0];
      if (mtg.length && !capacity) f.push({ brand_id: b.id, check_id: 'meeting_capacity_unknown', severity: 'low', category: 'bottleneck', bottleneck_area: 'delivery_capacity', title: 'Kurucu görüşme kapasitesi tanımlı değil; görüşmeler kurucu kararına bırakıldı', detail: { pending: mtg.length }, evidence_refs: mtg.map((m) => `meeting:${m.id}`), dedupe_key: `meeting_capacity:${b.id}` });
      const funnel = (await c.query(`SELECT stage, count(*)::int n FROM leads WHERE brand_id=$1 GROUP BY stage`, [b.id])).rows;
      if (funnel.length) f.push({ brand_id: b.id, check_id: 'funnel_snapshot', severity: 'info', category: 'bottleneck', bottleneck_area: 'none', title: 'Müşteri hunisi anlık görüntüsü', detail: { funnel }, evidence_refs: [`brand:${b.id}`], dedupe_key: `funnel:${b.id}:${now.toISOString().slice(0, 10)}` });
    }
    // 11) V2: kaynak–sonuç–karar tutarlılığı ve günün en önemli darboğazı (somut düzeltme işiyle)
    for (const b of brands.filter((x) => !opts.brandId || x.id === opts.brandId)) {
      if ((await c.query(`SELECT status FROM brands WHERE id=$1`, [b.id])).rows[0].status !== 'active') continue;
      for (const r of (await c.query(`SELECT id::text id FROM leads WHERE brand_id=$1 AND jsonb_array_length(need_signals) > 0 AND source_uri IS NULL AND NOT is_sample`, [b.id])).rows) {
        f.push({ brand_id: b.id, check_id: 'unsourced_lead', severity: 'high', category: 'consistency', title: 'İhtiyaç sinyali olan aday kaynaksız (ihtiyaç uydurulmuş olabilir)', detail: {}, evidence_refs: [`lead:${r.id}`], dedupe_key: `unsourced_lead:${r.id}` });
      }
      const st = (await c.query(`SELECT id::text id, output FROM tasks WHERE brand_id=$1 AND kind='strategy_plan' AND status='done' ORDER BY updated_at DESC LIMIT 1`, [b.id])).rows[0];
      const bad = (st?.output?.violations ?? []).filter((v: string) => ['invented_number', 'objective_without_basis', 'unknown_basis_ref', 'unsupported_priority'].includes(v));
      if (st && bad.length) f.push({ brand_id: b.id, check_id: 'strategy_inconsistency', severity: 'medium', category: 'consistency', title: `Strateji çıktısında dayanak tutarsızlığı: ${bad.join(', ')}`, detail: { violations: bad }, evidence_refs: [`task:${st.id}`], dedupe_key: `strategy_inconsistency:${st.id}`, is_simulated: true });
      const one = async (sql: string) => Number((await c.query(sql, [b.id])).rows[0].n);
      const funnel = {
        sourced: await one(`SELECT count(*)::int n FROM leads WHERE brand_id=$1 AND source_uri IS NOT NULL`),
        fit: await one(`SELECT count(*)::int n FROM leads WHERE brand_id=$1 AND fit_score >= 60`),
        drafts: await one(`SELECT count(*)::int n FROM assets WHERE brand_id=$1 AND kind='outreach_draft'`),
        sent: await one(`SELECT count(*)::int n FROM interactions WHERE brand_id=$1 AND direction='outbound' AND status IN ('sent','manual_sent')`),
        replies: await one(`SELECT count(*)::int n FROM interactions WHERE brand_id=$1 AND direction='inbound'`),
        qualified: await one(`SELECT count(*)::int n FROM opportunities WHERE brand_id=$1`),
        meetingsHeld: await one(`SELECT count(*)::int n FROM meetings WHERE brand_id=$1 AND status='held'`),
        openManualSends: await one(`SELECT count(*)::int n FROM manual_tasks WHERE brand_id=$1 AND status='open' AND kind IN ('send_first_contact','send_follow_up','linkedin_message','add_contact')`),
      };
      const demo = await one(`SELECT count(*)::int n FROM offers WHERE brand_id=$1 AND (readiness IN ('demo','test_verified') OR demo_evidence_id IS NOT NULL)`);
      const lastRun = (await c.query(`SELECT status FROM research_runs WHERE brand_id=$1 ORDER BY created_at DESC LIMIT 1`, [b.id])).rows[0]?.status ?? null;
      const capacity = (await c.query(`SELECT 1 FROM settings WHERE key='founder.meeting_capacity_per_week'`)).rowCount;
      let top: { area: string; title: string; fix: string } | null = null;
      if (!demo) top = { area: 'trust_proof', title: 'Güven kanıtı yok: hiçbir hizmette çalışan demo/test kaydı yok', fix: 'İlk LinkedIn hizmeti için ekran kaydı + test notu ekleyin (Panel → Hizmetler → Demo bağla). İçerik bu eksiği kapatamaz.' };
      else if (!lastRun || lastRun === 'disabled') top = { area: 'audience', title: 'Kaynaklı keşif yapılmıyor (araştırma sağlayıcısı bağlı değil)', fix: 'BRAVE_SEARCH_API_KEY ekleyip araştırma bağlantısını verified → live yapın; o zamana kadar aday yalnız manuel girilir.' };
      else if (funnel.sourced === 0) top = { area: 'audience', title: 'Kaynaklı aday yok', fix: 'Araştırma planındaki sorguları/sektörleri gözden geçirin (config/research_plan.json).' };
      else if (funnel.fit > 0 && funnel.sent === 0) top = { area: 'channel', title: `Uygun aday var ama gönderilmiş temas yok (açık manuel gönderim: ${funnel.openManualSends})`, fix: 'Manuel işlerdeki taslakları gönderip "Gönderdim" ile kapatın veya doğrulanmış adres ekleyin. Taslak temas sayılmaz.' };
      else if (funnel.sent >= 5 && funnel.replies === 0) top = { area: 'messaging', title: `${funnel.sent} gönderilmiş temasa yanıt yok`, fix: 'İlk mesajı tek soruya indirin; hedef sektörü daraltın; 10 temas sonra yeniden değerlendirin.' };
      else if (funnel.replies > 0 && funnel.qualified === 0) top = { area: 'offer', title: 'Yanıt var, nitelikli fırsat yok', fix: 'Yanıtlardaki itirazları teklif kartına yansıtın; kapsamı netleştirin.' };
      else if (funnel.qualified > 0 && funnel.meetingsHeld === 0 && !capacity) top = { area: 'delivery_capacity', title: 'Fırsat var, görüşme kapasitesi tanımsız', fix: 'Haftalık görüşme kapasitesini ayarlayın (settings: founder.meeting_capacity_per_week).' };
      if (top) f.push({ brand_id: b.id, check_id: 'top_bottleneck', severity: 'medium', category: 'bottleneck', bottleneck_area: top.area, title: `Günün darboğazı: ${top.title}`, detail: { fix: top.fix, funnel, demo, lastResearch: lastRun }, evidence_refs: [`brand:${b.id}`], dedupe_key: `top_bottleneck:${b.id}:${now.toISOString().slice(0, 10)}` });
    }

    // 10) Olay günlüğü bütünlüğü
    const chain = await verifyEventChain(c);
    if (!chain.ok) f.push({ brand_id: null, check_id: 'event_chain_broken', severity: 'critical', category: 'security', title: 'İşlem günlüğü zinciri bozulmuş', detail: { brokenAt: chain.brokenAt }, evidence_refs: [`event:${chain.brokenAt}`], dedupe_key: `chain:${chain.brokenAt}`, halt: { scope: 'global', reason: 'Günlük bütünlüğü bozuldu' } });

    // Yazma + önemli bulgularda ikinci, bağımsız doğrulama + gerekirse durdurma
    let written = 0;
    const halts: string[] = [];
    for (const x of f) {
      const second = (x.severity === 'high' || x.severity === 'critical') ? await secondReview(c, x) : null;
      const r = await c.query(
        `INSERT INTO audit_findings (brand_id, check_id, severity, category, title, detail, evidence_refs, second_review, dedupe_key, is_simulated)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT (dedupe_key) DO NOTHING RETURNING id`,
        [x.brand_id, x.check_id, x.severity, x.category, x.title, { ...x.detail, bottleneck_area: x.bottleneck_area ?? null }, JSON.stringify(x.evidence_refs), second, x.dedupe_key, x.is_simulated ?? (config().RUN_MODE !== 'live')]);
      if (!r.rows[0]) continue;
      written++;
      await logEvent(c, { brandId: x.brand_id, type: 'audit.finding', actor: 'auditor', subjectType: 'audit_finding', subjectId: r.rows[0].id, payload: { check: x.check_id, severity: x.severity, evidence: x.evidence_refs.slice(0, 5) }, simulated: x.is_simulated });
      // Durdurma yalnız ikinci doğrulama bulguyu teyit ederse uygulanır (yanlış alarm kontrolü)
      if (x.halt && second?.confirmed) {
        if (x.halt.scope !== 'global' && !x.brand_id) continue;
        const hid = await createHalt(c, { scope: x.halt.scope, brandId: x.brand_id, scopeValue: x.halt.scope === 'brand' ? null : x.halt.scopeValue ?? null, reason: `Denetçi: ${x.halt.reason}`, by: 'auditor' });
        await c.query(`UPDATE audit_findings SET halt_id=$2 WHERE id=$1`, [r.rows[0].id, hid]);
        await logEvent(c, { brandId: x.brand_id, type: 'alert.raised', actor: 'auditor', subjectType: 'halt', subjectId: hid, payload: { reason: x.halt.reason, finding: r.rows[0].id } });
        halts.push(hid);
      }
    }
    return { findings: f, written, halts };
  });
}

/** İkinci değerlendirme: bulguyu farklı bir sorgu yoluyla ham kayıtlardan yeniden doğrular. */
async function secondReview(c: Db, x: Finding): Promise<{ method: string; confirmed: boolean; note: string }> {
  const ids = x.evidence_refs.map((r) => r.split(':')[1]).filter(Boolean);
  switch (x.check_id) {
    case 'dup_publication': {
      const n = (await c.query(`SELECT count(DISTINCT id)::int n FROM publications WHERE id::text = ANY($1) AND status IN ('published','sending','outcome_unknown')`, [ids])).rows[0].n;
      return { method: 'ham yayın kayıtlarının yeniden sayımı', confirmed: n > 1, note: `${n} etkin yayın kaydı` };
    }
    case 'budget_breach': {
      const s = (await c.query(`SELECT coalesce(sum(amount_try),0)::float8 s FROM cost_ledger WHERE month=$1 AND mode=$2`, [monthKey(new Date()), x.detail.mode])).rows[0].s;
      return { method: 'defter toplamının bağımsız hesabı', confirmed: s > Number(x.detail.limit), note: `toplam ${s}` };
    }
    case 'suppressed_contacted':
    case 'dup_first_contact': {
      const n = (await c.query(`SELECT count(*)::int n FROM interactions WHERE id::text = ANY($1) AND direction='outbound'`, [ids])).rows[0].n;
      return { method: 'etkileşim kayıtlarının yeniden okunması', confirmed: n >= 1, note: `${n} giden kayıt` };
    }
    case 'claim_recheck':
      return { method: 'deterministik iddia kontrolünün içerik ham metni üzerinde tekrarı', confirmed: (x.detail.violations as any[]).length > 0, note: 'ihlal listesi ham metinden üretildi' };
    case 'cross_brand_link': {
      const n = (await c.query(`SELECT count(*)::int n FROM (
          SELECT t.id FROM tasks t JOIN campaigns k ON k.id = t.campaign_id WHERE t.id::text = ANY($1) AND k.brand_id IS DISTINCT FROM t.brand_id
          UNION ALL SELECT a.id FROM assets a JOIN campaigns k ON k.id = a.campaign_id WHERE a.id::text = ANY($1) AND k.brand_id IS DISTINCT FROM a.brand_id) x`, [ids])).rows[0].n;
      return { method: 'marka eşleşmesinin kayıt bazında yeniden sorgulanması', confirmed: n > 0, note: `${n} uyumsuz kayıt` };
    }
    case 'mock_as_live': {
      const n = (await c.query(`SELECT count(*)::int n FROM publications p LEFT JOIN channel_connections cc ON cc.brand_id = p.brand_id AND cc.channel = p.channel AND cc.status = 'live'
          WHERE p.id::text = ANY($1) AND p.is_simulated = false AND (p.adapter LIKE 'mock%' OR cc.id IS NULL)`, [ids])).rows[0].n;
      return { method: 'yayın kaydı ve canlı bağlantı durumunun yeniden okunması', confirmed: n > 0, note: `${n} kayıt canlı işaretli ama canlı bağlantı yok` };
    }
    case 'event_chain_broken': {
      const again = await verifyEventChain(c);
      return { method: 'zincirin tüm kayıtlarda yeniden hesaplanması', confirmed: !again.ok, note: again.reason ?? '' };
    }
    default:
      return { method: 'yok', confirmed: false, note: 'Bu kontrol için ikinci değerlendirme tanımlı değil' };
  }
}
