import { recreateDatabase, migrate } from '../src/db/migrate.js';
import { seed } from '../src/db/seed.js';
import { closePools } from '../src/db/pool.js';

export default async function setup() {
  const db = process.env.TEST_DB_NAME ?? 'bays_test';
  process.env.DATABASE_URL_OWNER = `postgres://postgres:postgres_local_dev@localhost:5432/${db}`;
  process.env.DATABASE_URL_APP = `postgres://bays_app:bays_app_local_dev@localhost:5432/${db}`;
  process.env.DATABASE_URL_AUDITOR = `postgres://bays_auditor:bays_auditor_local_dev@localhost:5432/${db}`;
  await recreateDatabase(db, 'postgres://postgres:postgres_local_dev@localhost:5432/postgres');
  await migrate(process.env.DATABASE_URL_OWNER);
  await seed();
  await closePools();
}
