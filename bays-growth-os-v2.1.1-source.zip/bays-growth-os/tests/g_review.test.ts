/**
 * Bağımsız V2 incelemesinin bulguları için düzeltme testleri (R-01 … R-12).
 * Tümü yerel PostgreSQL 16 + yerel sahte n8n HTTP sunucusu (127.0.0.1) ile; gerçek dış servis çağrısı yoktur.
 */
import http from 'node:http';
import crypto from 'node:crypto';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { closePools, withBrand, withSystem } from '../src/db/pool.js';
import { reloadConfig } from '../src/config.js';
import { clock, istanbulTime } from '../src/core/clock.js';
import { enqueueTask, HaltedError, TransientError } from '../src/core/tasks.js';
import { createHalt } from '../src/core/halts.js';
import { contactLead, ingestReply } from '../src/crm/outreach.js';
import { choosePublishTime } from '../src/orchestrator/chain.js';
import { claimDue, drain, executeClaimed, recoverExpiredLeases, registerHandler } from '../src/worker/worker.js';
import { runResearch } from '../src/research/research.js';
import { FixturePageReader, FixtureSearchProvider, type SearchProvider } from '../src/research/providers.js';
import { extract } from '../src/research/extract.js';
import { checkResolvedAddresses, isPrivateAddress, parseRobots, robotsMatch, safeLookup, validateUrl, UnsafeUrlError } from '../src/research/safeReader.js';
import { createExperiment } from '../src/learning/experiments.js';
import { buildServer } from '../src/api/server.js';
import { brandId, useTestPricing, resetBudget } from './helpers.js';

let bays: string, alma: string;
const q = async (b: string, sql: string, p: unknown[] = []) => withBrand(b, async (c) => (await c.query(sql, p)).rows);
const AUTH = { authorization: 'Bearer test-founder-token', 'content-type': 'application/json' };
const DAY = '2026-10-05';

/** Sahte n8n e-posta uç noktası: davranışı test sırasında değiştirilebilir, gelen istekleri sayar. */
let n8nMode: 'ok' | '503' | '400' | 'hang' = 'ok';
let n8nHits = 0;
const server = http.createServer((req, res) => {
  n8nHits++;
  req.resume();
  if (n8nMode === 'hang') return; // yanıt yok → istemci zaman aşımı (belirsiz sonuç)
  res.statusCode = n8nMode === 'ok' ? 200 : n8nMode === '503' ? 503 : 400;
  res.end('{}');
});
let port = 0;

// V2.1: canlı gönderim testleri canlı (ÖRNEK olmayan) aday kullanır; V2.1 kuralı örnek adayın canlı kanaldan temasını engeller.
async function leadWithContact(tag: string, brand = bays, sample = true) {
  return withBrand(brand, async (c) => {
    const l = (await c.query(`INSERT INTO leads (brand_id, business_name, business_key, source_uri, source_note, stage, fit_score, need_signals, is_sample) VALUES ($1,$2,$3,$4,'ÖRNEK','evaluated',80,'["randevular telefonla alınıyor"]',$5) RETURNING id`,
      [brand, `R ${tag}`, `d:${tag}.invalid`, `https://${tag}.invalid`, sample])).rows[0].id;
    await c.query(`INSERT INTO contacts (brand_id, lead_id, email, contact_basis, is_sample) VALUES ($1,$2,$3,$4,$5)`, [brand, l, `iletisim@${tag}.invalid`, `Kaynak sayfada yayımlanmış iletişim adresi: https://${tag}.invalid`, sample]);
    const d = (await c.query(`INSERT INTO assets (brand_id, kind, content, status, is_sample) VALUES ($1,'outreach_draft',$2,'passed_checks',$3) RETURNING id`, [brand, JSON.stringify({ draft: 'ÖRNEK taslak', subject: 'Kısa soru' }), sample])).rows[0].id;
    return { leadId: l as string, draftId: d as string };
  });
}

function goLive() {
  Object.assign(process.env, { RUN_MODE: 'live', EGRESS_ENABLED: 'true', CUSTOMER_EMAIL_LIVE: 'true', N8N_BASE_URL: `http://127.0.0.1:${port}` });
  reloadConfig();
}
function goSim() {
  Object.assign(process.env, { RUN_MODE: 'simulation', EGRESS_ENABLED: 'false', CUSTOMER_EMAIL_LIVE: 'false' });
  reloadConfig();
}

beforeAll(async () => {
  bays = await brandId('bayssystems'); alma = await brandId('almakistiyorum');
  useTestPricing(); await resetBudget();
  process.env.RESEARCH_PROVIDER = 'fixture'; reloadConfig();
  await withSystem((c) => c.query(`UPDATE halts SET active=false WHERE active`));
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => { port = (server.address() as any).port; r(); }));
});
afterAll(async () => {
  goSim(); clock.reset(); delete process.env.RESEARCH_PROVIDER; delete process.env.TASK_TIMEOUT_MS; reloadConfig();
  await withSystem((c) => c.query(`UPDATE channel_connections SET status='mock' WHERE channel='email'`));
  server.closeAllConnections(); server.close(); await closePools();
});

describe('Kritik — canlı e-posta gönderiminde çift gönderim engeli', () => {
  it('R-01 belirsiz sonuç (5xx/zaman aşımı) "sending" kaydında kalır; yeniden denemede tekrar gönderilmez, doğrulama görevi açılır', async () => {
    await withSystem((c) => c.query(`UPDATE channel_connections SET status='live' WHERE brand_id=$1 AND channel='email'`, [bays]));
    const { leadId, draftId } = await leadWithContact('r01', bays, false);
    goLive();
    try {
      n8nMode = '503'; n8nHits = 0;
      const now = istanbulTime(DAY, '10:00');
      const o1 = await contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now, simulated: false });
      expect(o1.result).toBe('uncertain');
      expect(n8nHits).toBe(1);
      expect((await q(bays, `SELECT status FROM interactions WHERE lead_id=$1 AND direction='outbound'`, [leadId])).map((r) => r.status)).toEqual(['sending']);
      // Yeniden deneme (worker tekrar çalıştırdı): n8n'e İKİNCİ istek gitmez
      n8nMode = 'ok';
      const o2 = await contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now, simulated: false });
      expect(o2.result).toBe('uncertain');
      expect(n8nHits).toBe(1);
      const mt = await q(bays, `SELECT kind, status FROM manual_tasks WHERE lead_id=$1 AND kind='verify_publication'`, [leadId]);
      expect(mt.length).toBe(1); // aynı doğrulama görevi tekrar açılmaz
      // Aday "contacted" sayılmaz (sonuç belirsiz)
      expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [leadId]))[0].stage).not.toBe('contacted');
    } finally { goSim(); }
  });

  it('R-02 kesin hata (4xx) "failed" olur ve yeniden denenebilir; başarılı denemede tek kayıt "sent" olur', async () => {
    const { leadId, draftId } = await leadWithContact('r02', bays, false);
    goLive();
    try {
      n8nMode = '400'; n8nHits = 0;
      const now = istanbulTime(DAY, '10:00');
      const o1 = await contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now, simulated: false });
      expect(o1.result).toBe('manual');
      expect((await q(bays, `SELECT status FROM interactions WHERE lead_id=$1 AND direction='outbound'`, [leadId]))[0].status).toBe('failed');
      n8nMode = 'ok';
      const o2 = await contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now, simulated: false });
      expect(o2.result).toBe('sent');
      expect(n8nHits).toBe(2);
      const rows = await q(bays, `SELECT status FROM interactions WHERE lead_id=$1 AND direction='outbound'`, [leadId]);
      expect(rows.map((r) => r.status)).toEqual(['sent']);
      // Üçüncü çağrı: zaten gönderildi → istek yok
      await contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now, simulated: false });
      expect(n8nHits).toBe(2);
    } finally { goSim(); }
  });

  it('R-03 yan etki sırasında çökme: kira kaybı sinyali varsa dış çağrı yapılmaz; sonraki deneme kör tekrar yerine doğrulamaya gider', async () => {
    const { leadId, draftId } = await leadWithContact('r03', bays, false);
    goLive();
    try {
      n8nMode = 'ok'; n8nHits = 0;
      const ac = new AbortController(); ac.abort();
      await expect(contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now: istanbulTime(DAY, '10:00'), simulated: false, signal: ac.signal })).rejects.toThrow(/kira/);
      expect(n8nHits).toBe(0);
      const o = await contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now: istanbulTime(DAY, '10:05'), simulated: false });
      expect(o.result).toBe('uncertain');
      expect(n8nHits).toBe(0);
    } finally { goSim(); await withSystem((c) => c.query(`UPDATE channel_connections SET status='mock' WHERE brand_id=$1 AND channel='email'`, [bays])); }
  });
});

describe('Yüksek — yanıt işleme ve çıkarım', () => {
  it('R-04 büyük harfli Türkçe "İSTEMİYORUM" iletişim yasağına dönüşür (tr-TR küçük harf)', async () => {
    const { leadId } = await leadWithContact('r04');
    clock.set(istanbulTime(DAY, '11:00'));
    await ingestReply({ brandId: bays, leadId, messageId: '<r04@ornek.invalid>', text: 'LÜTFEN BİR DAHA YAZMAYIN, İSTEMİYORUM.', receivedAt: istanbulTime(DAY, '11:00'), via: 'manual', simulated: true, enqueueClassify: true });
    clock.set(istanbulTime(DAY, '11:01'));
    await drain({ now: () => clock.now(), brandId: bays });
    expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [leadId]))[0].stage).toBe('lost');
    // V2.1: açık ret gerekçe metni "açık ret" oldu; e-posta anahtarıyla yasak kaydı yine zorunlu
    expect((await q(bays, `SELECT count(*)::int n FROM suppression_entries WHERE key_type='email' AND reason LIKE '%açık ret%'`))[0].n).toBeGreaterThan(0);
  });

  it('R-05 aynı yanıt için sınıflandırma ikinci kez çalışsa da ikinci fırsat/karar açılmaz', async () => {
    const { leadId } = await leadWithContact('r05');
    await withBrand(bays, (c) => c.query(`UPDATE leads SET stage='contacted' WHERE id=$1`, [leadId]));
    clock.set(istanbulTime(DAY, '12:00'));
    const r = await ingestReply({ brandId: bays, leadId, messageId: '<r05@ornek.invalid>', text: 'Merhaba, evet sorun. Gelecek hafta görüşebiliriz.', receivedAt: istanbulTime(DAY, '12:00'), via: 'manual', simulated: true, enqueueClassify: true });
    clock.set(istanbulTime(DAY, '12:01'));
    await drain({ now: () => clock.now(), brandId: bays });
    // Aynı yanıt için farklı anahtarlı ikinci görev (ör. elle yeniden kuyruklama)
    await withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'customer_dev', kind: 'reply_classify', idempotencyKey: 'r05-tekrar', input: { leadId, interactionId: r.interactionId }, simulated: true }));
    await drain({ now: () => clock.now(), brandId: bays });
    const opp = await q(bays, `SELECT id FROM opportunities WHERE lead_id=$1`, [leadId]);
    expect(opp.length).toBe(1);
    expect((await q(bays, `SELECT count(*)::int n FROM approval_requests WHERE params->>'opportunityId'=$1`, [opp[0].id]))[0].n).toBe(1);
    expect((await q(bays, `SELECT count(*)::int n FROM meetings WHERE lead_id=$1`, [leadId]))[0].n).toBe(1);
  });

  it('R-06 şehir Türkçe kelime sınırıyla, telefon 0/+90 önekiyle ve yazıldığı biçimde çıkarılır', () => {
    const page = (body: string) => `<html><head><title>T</title></head><body>${body}</body></html>`;
    expect(extract(page('Batmanlı ustalarımızla vanilya kokulu sabunlar'), 'https://a.invalid/').city).toBeNull();
    expect(extract(page("Şubemiz İzmir'de hizmet veriyor"), 'https://a.invalid/').city?.value).toBe('İzmir');
    const x = extract(page('Tel: 0232 123 45 67 · Mobil +90 532 765 43 21 · Sipariş no 12345678901 · Kod 532 111 22 33'), 'https://a.invalid/');
    expect(x.phones.map((p) => p.value)).toEqual(['0232 123 45 67', '+90 532 765 43 21']);
  });

  it('R-07 yalnız işletmenin kendi alan adındaki e-posta doğrulanmış kişi olur; üçüncü taraf adres kişi yapılmaz', async () => {
    const html = `<html><head><title>Örnek Diş Kliniği R07</title></head><body>Randevu için bizi arayın. İletişim: ornekdis@gmail.com · Ankara</body></html>`;
    const provider: SearchProvider = { name: 'fixture', simulated: true, pricingKey: 'fixture:search', search: async () => [{ url: 'https://r07-dis.invalid/', title: 'Örnek Diş Kliniği R07', snippet: 'randevu' }] };
    const reader = { name: 'fixture-page', simulated: true, read: async (url: string) => ({ url, finalUrl: url, status: 'ok' as const, httpStatus: 200, contentType: 'text/html', body: html, bytes: html.length }) };
    const res = await runResearch({ brandId: alma, day: '2026-10-06', now: istanbulTime('2026-10-06', '08:00'), simulated: true, stack: { provider, reader }, maxQueries: 1 });
    const lead = (await q(alma, `SELECT id FROM leads WHERE business_key LIKE '%r07-dis.invalid%'`))[0];
    expect(lead).toBeTruthy();
    expect((await q(alma, `SELECT count(*)::int n FROM contacts WHERE lead_id=$1`, [lead.id]))[0].n).toBe(0);
    const f = (await q(alma, `SELECT data FROM research_findings WHERE source_url='https://r07-dis.invalid/' AND kind='business_candidate'`))[0];
    expect(f.data.contactVerified).toBe(false);
    expect(f.data.emails).toContain('ornekdis@gmail.com'); // gözlem kaydedilir ama doğrulanmış kişi sayılmaz
    expect(res.status).toBe('done');
  });
});

describe('Orta — SSRF, durdurma, deney izolasyonu, worker sahipliği', () => {
  it('R-08 IPv6 özel/tünel/ayrılmış biçimleri ve DNS rebinding reddedilir; küresel adresler kabul edilir', async () => {
    const bad = ['::', '::1', '::ffff:127.0.0.1', '::ffff:7f00:1', '::ffff:a9fe:a9fe', '::127.0.0.1', 'fe80::1', 'fec0::1', 'fc00::1', 'fd12::1', 'ff02::1', '64:ff9b::7f00:1', '2002:7f00:1::1', '2001:0:4136:e378::1', '2001:db8::1', '100::1', '::ffff:0:7f00:1'];
    for (const a of bad) expect(isPrivateAddress(a), a).toBe(true);
    for (const a of ['2606:4700:4700::1111', '2a00:1450:4001:80b::200e', '1.1.1.1']) expect(isPrivateAddress(a), a).toBe(false);
    for (const u of ['http://[::ffff:a9fe:a9fe]/', 'http://[fec0::1]/', 'http://[2002:7f00:1::1]/', 'http://[64:ff9b::a00:1]/']) expect(() => validateUrl(u), u).toThrow(UnsafeUrlError);
    // DNS rebinding: ad, bağlantı anında özel adrese çözülürse bağlantı reddedilir
    expect(() => checkResolvedAddresses('rebind.example', [{ address: '93.184.216.34' }, { address: '127.0.0.1' }])).toThrow(/özel adrese/);
    const fakeResolver: any = (_h: string, _o: any, cb: any) => cb(null, [{ address: '::ffff:10.0.0.1', family: 6 }]);
    const err = await new Promise<Error | null>((r) => safeLookup('rebind.example', {}, (e) => r(e), fakeResolver));
    expect(err).toBeInstanceOf(UnsafeUrlError);
    const ok = await new Promise<any>((r) => safeLookup('ok.example', {}, (e, a) => r(e ?? a), ((_h: string, _o: any, cb: any) => cb(null, [{ address: '93.184.216.34', family: 4 }])) as any));
    expect(ok).toBe('93.184.216.34');
  });

  it('R-09 robots.txt: kendi ajan grubu öncelikli, ardışık User-agent tek grup, en uzun eşleşme ve Allow', () => {
    const r = parseRobots('User-agent: *\nDisallow: /\n\nUser-agent: Googlebot\nUser-agent: BaysSystemsResearchBot\nDisallow: /ozel\nAllow: /ozel/acik$\n');
    expect(robotsMatch('/hizmetler', r)).toBe(true);
    expect(robotsMatch('/ozel/x', r)).toBe(false);
    expect(robotsMatch('/ozel/acik', r)).toBe(true);
    const star = parseRobots('User-agent: *\nDisallow: /iletisim\n');
    expect(robotsMatch('/iletisim', star)).toBe(false);
    expect(robotsMatch('/', star)).toBe(true);
  });

  it('R-10 çalışma sırasında verilen durdurma sonraki aramayı ve sayfa okumayı keser', async () => {
    let haltId = '';
    const p = new FixtureSearchProvider();
    const orig = p.search.bind(p);
    p.search = async (qq: string) => {
      const r = await orig(qq);
      if (!haltId) haltId = await withSystem((c) => createHalt(c, { scope: 'channel', brandId: alma, scopeValue: 'research', reason: 'R-10 çalışma sırasında', by: 'founder' }));
      return r;
    };
    const reader = new FixturePageReader();
    let reads = 0; const origRead = reader.read.bind(reader); reader.read = async (u: string) => { reads++; return origRead(u); };
    const res = await runResearch({ brandId: alma, day: '2026-10-07', now: istanbulTime('2026-10-07', '08:00'), simulated: true, stack: { provider: p, reader }, maxQueries: 3 });
    expect(p.calls.length).toBe(1);
    expect(reads).toBe(0);
    expect(res.status).toBe('blocked_halt');
    await withSystem((c) => c.query(`UPDATE halts SET active=false WHERE id=$1`, [haltId]));
  });

  it('R-11 canlı deney simülasyon zamanlamasını (veya tersi) etkilemez', async () => {
    const out = await withBrand(bays, async (c) => {
      const id = await createExperiment(c, { brandId: bays, hypothesis: 'R-11 canlı', primary_variable: 'yayın saati', comparison: { control: '07:00', variant: '07:30' }, sample_condition: { min_per_arm: 3, min_days: 7, min_relative_effect: 0.2, justification: 'R-11 izolasyon testi' }, target_metric: 'engagement_rate', cost_limit_try: 0, stop_rule: 'hata olursa dur', rollback_plan: 'önceki kurala dön', confounders: ['içerik türü'], simulated: false });
      return { sim: await choosePublishTime(c, bays, id, true, istanbulTime(DAY, '08:00')), live: await choosePublishTime(c, bays, id, false, istanbulTime(DAY, '08:00')) };
    });
    expect(out.sim.arm).toBeNull();
    expect(['07:00', '07:30']).toContain(out.live.arm);
  });

  it('R-12 eski worker kira kaybından sonra durum yazamaz; uzun işte kira kaybı handler\'a iptal sinyali olarak ulaşır', async () => {
    process.env.TASK_TIMEOUT_MS = '3000'; reloadConfig();
    try {
      // (a) Fencing: A'nın kirası doldu, B devraldı; A'nın geç gelen hatası/durdurması B'nin işini bozmaz
      let phase = 0;
      registerHandler('r12_fence', async () => { phase++; if (phase === 1) throw new TransientError('A geç hata'); if (phase === 2) throw new HaltedError('A geç durdurma'); return { ok: true }; });
      await drain({ brandId: alma });
      const t = await withBrand(alma, (c) => enqueueTask(c, { brandId: alma, role: 'strategy', kind: 'r12_fence', idempotencyKey: `r12:${crypto.randomUUID()}`, input: {}, simulated: true }));
      const base = new Date();
      let a: any; for (let i = 0; i < 20 && (!a || a.id !== t.id); i++) a = await claimDue('worker-A', base, 1000, { brandId: alma });
      expect(a.id).toBe(t.id);
      await recoverExpiredLeases(new Date(base.getTime() + 5000));
      await withSystem((c) => c.query(`UPDATE tasks SET next_run_at=$2 WHERE id=$1`, [t.id, base]));
      let b: any; for (let i = 0; i < 20 && (!b || b.id !== t.id); i++) b = await claimDue('worker-B', new Date(base.getTime() + 6000), 60_000, { brandId: alma });
      expect(b.id).toBe(t.id);
      expect(await executeClaimed(a, 'worker-A')).toBe('lost_lease');
      expect(await executeClaimed(a, 'worker-A')).toBe('lost_lease');
      const row = (await q(alma, `SELECT status, locked_by FROM tasks WHERE id=$1`, [t.id]))[0];
      expect(row).toMatchObject({ status: 'running', locked_by: 'worker-B' });
      expect(await executeClaimed(b, 'worker-B')).toBe('done');

      // (b) Kira kaybı sinyali
      let sawAbort = false;
      registerHandler('r12_abort', async (task, ctx) => {
        await withSystem((c) => c.query(`UPDATE tasks SET locked_by='baska-worker' WHERE id=$1`, [task.id]));
        for (let i = 0; i < 40 && !ctx.signal.aborted; i++) await new Promise((r) => setTimeout(r, 100));
        sawAbort = ctx.signal.aborted;
        return { aborted: sawAbort };
      });
      const t2 = await withBrand(alma, (c) => enqueueTask(c, { brandId: alma, role: 'strategy', kind: 'r12_abort', idempotencyKey: `r12b:${crypto.randomUUID()}`, input: {}, simulated: true }));
      let c2: any; for (let i = 0; i < 20 && (!c2 || c2.id !== t2.id); i++) c2 = await claimDue('worker-C', new Date(), 3000, { brandId: alma });
      expect(await executeClaimed(c2, 'worker-C')).toBe('lost_lease');
      expect(sawAbort).toBe(true);
    } finally { delete process.env.TASK_TIMEOUT_MS; reloadConfig(); }
  }, 20_000);
});

describe('Düşük — API ve gelen yanıt atomikliği', () => {
  it('R-13 manuel yanıt uç noktası başka markanın adayını kabul etmez', async () => {
    const { leadId } = await leadWithContact('r13', alma);
    const app = await buildServer();
    const r = await app.inject({ method: 'POST', url: `/api/brands/${bays}/leads/${leadId}/replies`, headers: AUTH, payload: JSON.stringify({ text: 'merhaba' }) });
    expect(r.statusCode).toBe(404);
    expect((await q(alma, `SELECT count(*)::int n FROM interactions WHERE lead_id=$1`, [leadId]))[0].n).toBe(0);
    await app.close();
  });

  it('R-14 gelen yanıt ve sınıflandırma görevi aynı işlemde; yeniden teslim eksik görevi tamamlar, çift görev açmaz', async () => {
    const { leadId } = await leadWithContact('r14');
    // Eski akış: yanıt kaydedildi ama görev kuyruğa girmeden süreç çöktü (enqueueClassify yok)
    const r1 = await ingestReply({ brandId: bays, leadId, messageId: '<r14@ornek.invalid>', text: 'Bilgi alabilir miyim?', receivedAt: istanbulTime(DAY, '13:00'), via: 'webhook', simulated: true });
    expect(r1.status).toBe('recorded');
    expect((await q(bays, `SELECT count(*)::int n FROM tasks WHERE idempotency_key='reply:<r14@ornek.invalid>'`))[0].n).toBe(0);
    // n8n yeniden teslim eder: yanıt mükerrer sayılır ama eksik sınıflandırma görevi tamamlanır
    const r2 = await ingestReply({ brandId: bays, leadId, messageId: '<r14@ornek.invalid>', text: 'Bilgi alabilir miyim?', receivedAt: istanbulTime(DAY, '13:00'), via: 'webhook', simulated: true, enqueueClassify: true });
    expect(r2.status).toBe('duplicate');
    expect((await q(bays, `SELECT count(*)::int n FROM tasks WHERE idempotency_key='reply:<r14@ornek.invalid>'`))[0].n).toBe(1);
    await ingestReply({ brandId: bays, leadId, messageId: '<r14@ornek.invalid>', text: 'x', receivedAt: istanbulTime(DAY, '13:00'), via: 'webhook', simulated: true, enqueueClassify: true });
    expect((await q(bays, `SELECT count(*)::int n FROM tasks WHERE idempotency_key='reply:<r14@ornek.invalid>'`))[0].n).toBe(1);
  });

  it('R-15 yalnız e-posta kanalı durdurulduğunda ilk temas engellenir, diğer kanallar etkilenmez', async () => {
    const { leadId, draftId } = await leadWithContact('r15');
    const h = await withSystem((c) => createHalt(c, { scope: 'channel', brandId: bays, scopeValue: 'email', reason: 'R-15', by: 'founder' }));
    try {
      const o = await contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now: istanbulTime(DAY, '10:00'), simulated: true });
      expect(o.result).toBe('blocked');
      expect((await q(bays, `SELECT count(*)::int n FROM interactions WHERE lead_id=$1`, [leadId]))[0].n).toBe(0);
      const t = await withBrand(bays, async (c) => (await choosePublishTime(c, bays, null, true, istanbulTime(DAY, '08:00'))).time);
      expect(t).toMatch(/^\d{2}:\d{2}$/);
    } finally { await withSystem((c) => c.query(`UPDATE halts SET active=false WHERE id=$1`, [h])); }
  });
});
