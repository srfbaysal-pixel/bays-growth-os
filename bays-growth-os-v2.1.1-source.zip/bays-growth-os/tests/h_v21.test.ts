/**
 * V2.1 düzeltme görevi — regresyon testleri (önce yazıldı, düzeltmeden önce kırmızıydı).
 * M: gerçek ölçüm girişi · K: simülasyon/değerlendirme/canlı ayrımı · O: açık iletişim reddi · B: belirsiz gider uzlaştırması.
 * Tümü yerel PostgreSQL 16 üzerinde; dış servis çağrısı yoktur (n8n e-posta ucu yerel sahte sunucu).
 */
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { closePools, withBrand, withSystem } from '../src/db/pool.js';
import { reloadConfig } from '../src/config.js';
import { clock, istanbulTime } from '../src/core/clock.js';
import { enqueueTask } from '../src/core/tasks.js';
import { createHalt } from '../src/core/halts.js';
import { reserveBudget, committed } from '../src/core/budget.js';
import { estimateCost } from '../src/core/pricing.js';
import { EgressBlockedError } from '../src/integrations/egress.js';
import { contactLead, ingestReply } from '../src/crm/outreach.js';
import { completeManualTask } from '../src/crm/manual.js';
import { enqueueScheduled, campaignFor } from '../src/orchestrator/chain.js';
import { claimDue, drain } from '../src/worker/worker.js';
import { runResearch } from '../src/research/research.js';
import { FixturePageReader, FixtureSearchProvider, type SearchProvider } from '../src/research/providers.js';
import { createExperiment, evaluateExperiment } from '../src/learning/experiments.js';
import { buildStrategyContext } from '../src/agents/strategyContext.js';
import { buildContext, runAgent } from '../src/agents/runner.js';
import { mockModelControl } from '../src/agents/providers.js';
import { resolveUncertainCost } from '../src/core/budget.js';
import { detectExplicitOptOut } from '../src/crm/optout.js';
import { callStateOf } from '../src/core/callOutcome.js';
import { BudgetBlockedError } from '../src/core/budget.js';
import { runQuality } from '../src/evals/quality.js';
import { buildReport } from '../src/reports/reports.js';
import { buildServer } from '../src/api/server.js';
import { brandId, useTestPricing, resetBudget, ownerQuery } from './helpers.js';

let bays: string, alma: string;
const q = async (b: string, sql: string, p: unknown[] = []) => withBrand(b, async (c) => (await c.query(sql, p)).rows);
const AUTH = { authorization: 'Bearer test-founder-token', 'content-type': 'application/json' };
const sign = (raw: string) => 'sha256=' + crypto.createHmac('sha256', 'test_n8n_secret_not_real').update(raw).digest('hex');
const DAY = '2026-10-12';
const uid = () => crypto.randomUUID().slice(0, 8);

let n8nHits = 0;
const server = http.createServer((req, res) => { n8nHits++; req.resume(); res.statusCode = 200; res.end('{}'); });
let port = 0;

/** Canlı (gerçek) yayın: deney kolu varlık içeriğinde. Test verisidir, ÖRNEK değildir ama gerçek bir hesaba ait değildir. */
async function livePub(brand: string, opts: { experimentId?: string | null; arm?: string | null; contentType?: string; status?: string; simulated?: boolean } = {}) {
  return withBrand(brand, async (c) => {
    const sim = opts.simulated ?? false;
    const a = (await c.query(`INSERT INTO assets (brand_id, kind, content, status, is_sample) VALUES ($1,'post_text',$2,'published',$3) RETURNING id`,
      [brand, JSON.stringify({ post_text: 'test', content_type: opts.contentType ?? 'need', experiment_id: opts.experimentId ?? null, arm: opts.arm ?? null }), sim])).rows[0].id;
    const p = (await c.query(`INSERT INTO publications (brand_id, asset_id, channel, adapter, idempotency_key, status, external_id, is_simulated, scheduled_at, sent_at) VALUES ($1,$2,'linkedin','linkedin-api',$3,$4,$5,$6,$7,$7) RETURNING id, idempotency_key`,
      [brand, a, `v21:${uid()}`, opts.status ?? 'published', `urn:li:share:v21-${uid()}`, sim, istanbulTime(DAY, '09:00')])).rows[0];
    return { pubId: p.id as string, key: p.idempotency_key as string, assetId: a as string };
  });
}

async function leadWithContact(tag: string, brand: string, sample = true) {
  return withBrand(brand, async (c) => {
    const l = (await c.query(`INSERT INTO leads (brand_id, business_name, business_key, source_uri, source_note, stage, fit_score, need_signals, is_sample) VALUES ($1,$2,$3,$4,'ÖRNEK','contacted',80,'["randevular telefonla alınıyor"]',$5) RETURNING id`,
      [brand, `V21 ${tag}`, `d:${tag}-${uid()}.invalid`, `https://${tag}.invalid`, sample])).rows[0].id;
    await c.query(`INSERT INTO contacts (brand_id, lead_id, email, contact_basis, is_sample) VALUES ($1,$2,$3,$4,$5)`, [brand, l, `iletisim@${tag}.invalid`, `Kaynak sayfada yayımlanmış iletişim adresi: https://${tag}.invalid`, sample]);
    const d = (await c.query(`INSERT INTO assets (brand_id, kind, content, status, is_sample) VALUES ($1,'outreach_draft',$2,'passed_checks',$3) RETURNING id`, [brand, JSON.stringify({ draft: 'ÖRNEK', subject: 'Soru' }), sample])).rows[0].id;
    return { leadId: l as string, draftId: d as string };
  });
}

beforeAll(async () => {
  bays = await brandId('bayssystems'); alma = await brandId('almakistiyorum');
  useTestPricing(); await resetBudget();
  process.env.RESEARCH_PROVIDER = 'fixture'; reloadConfig();
  await withSystem((c) => c.query(`UPDATE halts SET active=false WHERE active`));
  await new Promise<void>((r) => server.listen(0, '127.0.0.1', () => { port = (server.address() as any).port; r(); }));
});
beforeEach(() => { mockModelControl.reset(); });
afterAll(async () => {
  Object.assign(process.env, { RUN_MODE: 'simulation', EGRESS_ENABLED: 'false', CUSTOMER_EMAIL_LIVE: 'false' });
  delete process.env.RESEARCH_PROVIDER; delete process.env.MODEL_ECONOMY; reloadConfig(); clock.reset();
  await withSystem((c) => c.query(`UPDATE channel_connections SET status='mock' WHERE channel='email'`));
  server.closeAllConnections(); server.close(); await closePools();
});

// ───────────────────────────── 1. Gerçek ölçüm girişi ─────────────────────────────
describe('V2.1-1 gerçek performans ölçümleri', () => {
  it('M-01 yetkisiz ölçüm girişi ve imzasız webhook reddedilir', async () => {
    const { pubId, key } = await livePub(bays);
    const app = await buildServer();
    const body = JSON.stringify({ publicationId: pubId, measuredAt: istanbulTime(DAY, '12:00').toISOString(), values: { impressions: 100 }, evidence: { note: 'LinkedIn analiz ekranı' } });
    expect((await app.inject({ method: 'POST', url: `/api/brands/${bays}/metrics`, payload: body, headers: { 'content-type': 'application/json' } })).statusCode).toBe(401);
    const wh = JSON.stringify({ contract: 'bays.metrics.v1', brand: 'bayssystems', publication: { idempotency_key: key }, delivery_id: 'm01', measured_at: istanbulTime(DAY, '12:00').toISOString(), values: { impressions: 100 } });
    expect((await app.inject({ method: 'POST', url: '/webhooks/n8n/metrics', payload: wh, headers: { 'content-type': 'application/json', 'x-bays-signature': 'sha256=00' } })).statusCode).toBe(401);
    await app.close();
    expect((await q(bays, `SELECT count(*)::int n FROM metrics WHERE publication_id=$1`, [pubId]))[0].n).toBe(0);
  });

  it('M-02 başka markanın yayınına ölçüm yazılamaz (API ve webhook)', async () => {
    const { pubId, key } = await livePub(bays);
    const app = await buildServer();
    const body = JSON.stringify({ publicationId: pubId, measuredAt: istanbulTime(DAY, '12:00').toISOString(), values: { impressions: 100 }, evidence: { note: 'LinkedIn analiz ekranı' } });
    expect((await app.inject({ method: 'POST', url: `/api/brands/${alma}/metrics`, payload: body, headers: AUTH })).statusCode).toBe(404);
    const wh = JSON.stringify({ contract: 'bays.metrics.v1', brand: 'almakistiyorum', publication: { idempotency_key: key }, delivery_id: `m02-${uid()}`, measured_at: istanbulTime(DAY, '12:00').toISOString(), values: { impressions: 100 } });
    expect((await app.inject({ method: 'POST', url: '/webhooks/n8n/metrics', payload: wh, headers: { 'content-type': 'application/json', 'x-bays-signature': sign(wh) } })).statusCode).toBe(404);
    await app.close();
    expect((await q(bays, `SELECT count(*)::int n FROM metrics WHERE publication_id=$1`, [pubId]))[0].n).toBe(0);
  });

  it('M-03 geçersiz değer, eksik kanıt, gelecek zaman ve ÖRNEK yayın reddedilir; eksik değer sıfır sayılmaz', async () => {
    const { pubId } = await livePub(bays);
    const sample = await livePub(bays, { simulated: true });
    const app = await buildServer();
    const post = (payload: any, brand = bays) => app.inject({ method: 'POST', url: `/api/brands/${brand}/metrics`, payload: JSON.stringify(payload), headers: AUTH });
    const at = istanbulTime(DAY, '12:00').toISOString();
    const ev = { note: 'LinkedIn analiz ekranı' };
    expect((await post({ publicationId: pubId, measuredAt: at, values: { impressions: -5 }, evidence: ev })).statusCode).toBe(400);
    expect((await post({ publicationId: pubId, measuredAt: at, values: { impressions: 'çok' }, evidence: ev })).statusCode).toBe(400);
    expect((await post({ publicationId: pubId, measuredAt: at, values: { impressions: 10.5 }, evidence: ev })).statusCode).toBe(400);
    expect((await post({ publicationId: pubId, measuredAt: at, values: { engagement_rate: 1.5 }, evidence: ev })).statusCode).toBe(400);
    expect((await post({ publicationId: pubId, measuredAt: at, values: { begeni_sayisi: 3 }, evidence: ev })).statusCode).toBe(400);
    expect((await post({ publicationId: pubId, measuredAt: at, values: { impressions: 10 } })).statusCode).toBe(400);
    expect((await post({ publicationId: pubId, measuredAt: new Date(Date.now() + 86400_000).toISOString(), values: { impressions: 10 }, evidence: ev })).statusCode).toBe(400);
    expect((await post({ publicationId: pubId, measuredAt: istanbulTime(DAY, '08:00').toISOString(), values: { impressions: 10 }, evidence: ev })).statusCode).toBe(400); // yayından önce
    expect((await post({ publicationId: sample.pubId, measuredAt: at, values: { impressions: 10 }, evidence: ev })).statusCode).toBe(422);
    expect((await q(bays, `SELECT count(*)::int n FROM metrics WHERE publication_id = ANY($1)`, [[pubId, sample.pubId]]))[0].n).toBe(0);
    // Eksik değer: yalnız verilen ölçüm yazılır; boş olan sıfır olarak kaydedilmez
    const ok = await post({ publicationId: pubId, measuredAt: at, values: { impressions: 120, comments: null, clicks: '' }, evidence: ev });
    expect(ok.statusCode).toBe(200);
    expect(ok.json().skipped.map((s: any) => s.metric).sort()).toEqual(['clicks', 'comments']);
    const rows = await q(bays, `SELECT metric, value::float8 v, source, is_simulated FROM metrics WHERE publication_id=$1`, [pubId]);
    expect(rows).toEqual([{ metric: 'impressions', v: 120, source: 'manual', is_simulated: false }]);
    await app.close();
  });

  it('M-04 aynı ölçümün tekrar teslimi örnek sayısını şişirmez (webhook teslim kimliği ve aynı içerik)', async () => {
    const { pubId, key } = await livePub(bays);
    const app = await buildServer();
    const wh = JSON.stringify({ contract: 'bays.metrics.v1', brand: 'bayssystems', publication: { idempotency_key: key }, delivery_id: `m04-${uid()}`, measured_at: istanbulTime(DAY, '18:00').toISOString(), values: { impressions: 300, engagement_rate: 0.04 }, evidence_url: 'https://www.linkedin.com/analytics/ornek' });
    const h = { 'content-type': 'application/json', 'x-bays-signature': sign(wh) };
    const r1 = await app.inject({ method: 'POST', url: '/webhooks/n8n/metrics', payload: wh, headers: h });
    const r2 = await app.inject({ method: 'POST', url: '/webhooks/n8n/metrics', payload: wh, headers: h });
    expect(r1.json().status).toBe('recorded'); expect(r2.json().status).toBe('duplicate');
    // Farklı teslim kimliği ama aynı zaman ve değer: yine tekrar sayılır
    const wh2 = JSON.stringify({ ...JSON.parse(wh), delivery_id: `m04b-${uid()}` });
    const r3 = await app.inject({ method: 'POST', url: '/webhooks/n8n/metrics', payload: wh2, headers: { 'content-type': 'application/json', 'x-bays-signature': sign(wh2) } });
    expect(r3.json().status).toBe('duplicate');
    await app.close();
    expect((await q(bays, `SELECT count(*)::int n FROM metrics WHERE publication_id=$1`, [pubId]))[0].n).toBe(2);
  });

  it('M-05 kümülatif güncelleme: yeni anlık görüntü günceli değiştirir, eski geç gelen tarihçeye düşer, örnek sayısı değişmez', async () => {
    const { pubId } = await livePub(bays);
    const app = await buildServer();
    const post = (measuredAt: string, values: any) => app.inject({ method: 'POST', url: `/api/brands/${bays}/metrics`, payload: JSON.stringify({ publicationId: pubId, measuredAt, values, evidence: { note: 'LinkedIn analiz ekranı' } }), headers: AUTH });
    expect((await post(istanbulTime(DAY, '12:00').toISOString(), { impressions: 100 })).json().status).toBe('recorded');
    expect((await post(istanbulTime(DAY, '20:00').toISOString(), { impressions: 150 })).json().status).toBe('recorded');
    const late = (await post(istanbulTime(DAY, '10:00').toISOString(), { impressions: 60 })).json();
    expect(late.recorded[0].current).toBe(false);
    await app.close();
    const cur = await q(bays, `SELECT value::float8 v FROM metrics WHERE publication_id=$1 AND metric='impressions' AND is_current`, [pubId]);
    expect(cur).toEqual([{ v: 150 }]);
    expect((await q(bays, `SELECT count(*)::int n FROM metrics WHERE publication_id=$1 AND metric='impressions'`, [pubId]))[0].n).toBe(3);
  });

  it('M-06 gerçek ölçüm doğru deney koluna bağlanır; aynı gönderinin birden çok ölçümü tek örnek sayılır; strateji bağlamına ulaşır', async () => {
    const expId = await withBrand(bays, (c) => createExperiment(c, { brandId: bays, hypothesis: 'M-06 kısa çağrı daha çok etkileşim alır', primary_variable: 'çağrı cümlesi', comparison: { control: 'A', variant: 'B' }, sample_condition: { min_per_arm: 2, min_days: 0, min_relative_effect: 0.2, justification: 'test için küçük eşik' }, target_metric: 'engagement_rate', cost_limit_try: 0, stop_rule: 'hata olursa dur', rollback_plan: 'önceki kurala dön', confounders: ['içerik türü'], simulated: false }));
    const a1 = await livePub(bays, { experimentId: expId, arm: 'A' });
    const b1 = await livePub(bays, { experimentId: expId, arm: 'B' });
    const app = await buildServer();
    const post = (pubId: string, measuredAt: string, v: number, arm?: string) => app.inject({ method: 'POST', url: `/api/brands/${bays}/metrics`, payload: JSON.stringify({ publicationId: pubId, measuredAt, arm, values: { engagement_rate: v }, evidence: { note: 'LinkedIn analiz ekranı' } }), headers: AUTH });
    await post(a1.pubId, istanbulTime(DAY, '12:00').toISOString(), 0.02, 'B'); // istemcinin verdiği kol yok sayılır
    await post(a1.pubId, istanbulTime(DAY, '20:00').toISOString(), 0.03);
    await post(a1.pubId, istanbulTime(DAY, '22:00').toISOString(), 0.035);
    await post(b1.pubId, istanbulTime(DAY, '20:00').toISOString(), 0.05);
    await app.close();
    const rows = await q(bays, `SELECT arm, experiment_id FROM metrics WHERE publication_id=$1`, [a1.pubId]);
    expect(rows.every((r) => r.arm === 'A' && r.experiment_id === expId)).toBe(true);
    const ev = await withBrand(bays, (c) => evaluateExperiment(c, expId, istanbulTime(DAY, '23:00')));
    expect(ev.arms.A.n).toBe(1); expect(ev.arms.B.n).toBe(1); // 3 ölçüm ≠ 3 örnek
    expect(ev.status).toBe('insufficient_data');
    expect(ev.arms.A.mean).toBeCloseTo(0.035);
    expect(ev.simulatedData).toBe(false);
    const ctx = await withBrand(bays, (c) => buildStrategyContext(c, bays, istanbulTime(DAY, '23:00'), 14, false));
    const er = ctx.metricsByContentType.find((m) => m.metric === 'engagement_rate');
    expect(er && er.simulated).toBe(false);
    expect(ctx.missing).not.toContain('canlı ölçüm yok');
  });
});

describe('V2.1-1b n8n ölçüm akışı sözleşmesi', () => {
  it('M-07 n8n akışındaki imzalama kodu servisin kabul ettiği gövdeyi üretir; aynı öğe ikinci kez gönderilince tekrar sayılır (n8n çalıştırılmadan, kod düğümü Node ile çalıştırıldı)', async () => {
    const { pubId, key } = await livePub(bays);
    const flow = JSON.parse(fs.readFileSync('n8n/bays-metrics-push.json', 'utf8'));
    const jsCode = flow.nodes.find((n: any) => n.type === 'n8n-nodes-base.code').parameters.jsCode as string;
    const run = new Function('require', '$input', '$env', jsCode);
    const items = [{ json: { idempotency_key: key, measured_at: istanbulTime(DAY, '19:00').toISOString(), values: { impressions: 410, comments: null } } }];
    const out = run(require, { all: () => items }, { BAYS_N8N_SHARED_SECRET: 'test_n8n_secret_not_real', BAYS_BRAND_SLUG: 'bayssystems' }) as { json: { body: string; sig: string } }[];
    const app = await buildServer();
    const send = () => app.inject({ method: 'POST', url: '/webhooks/n8n/metrics', payload: out[0].json.body, headers: { 'content-type': 'application/json', 'x-bays-signature': out[0].json.sig } });
    const r1 = await send(); const r2 = await send();
    await app.close();
    expect(r1.statusCode).toBe(200); expect(r1.json().status).toBe('recorded');
    expect(r1.json().skipped.map((x: any) => x.metric)).toEqual(['comments']);
    expect(r2.json().status).toBe('duplicate');
    expect((await q(bays, `SELECT source, value::float8 v FROM metrics WHERE publication_id=$1`, [pubId]))).toEqual([{ source: 'n8n', v: 410 }]);
  });
});

// ───────────────────────────── 2. Kip ayrımı ─────────────────────────────
describe('V2.1-2 simülasyon, değerlendirme ve canlı veri ayrımı', () => {
  it('K-01 aynı markada örnek ve gerçek veri: canlı strateji bağlamı yalnız gerçek veriyi, örnek bağlam yalnız örneği görür', async () => {
    const brand = await brandId('mentora'); // başka test dosyalarının verisinden bağımsız marka
    const real = await livePub(brand);
    const fake = await livePub(brand, { simulated: true });
    await withBrand(brand, async (c) => {
      await c.query(`INSERT INTO metrics (brand_id, publication_id, metric, value, source, is_simulated, measured_at) VALUES ($1,$2,'engagement_rate',0.9,'mock',true,$3)`, [brand, fake.pubId, istanbulTime(DAY, '12:00')]);
      await c.query(`INSERT INTO metrics (brand_id, publication_id, metric, value, source, is_simulated, measured_at) VALUES ($1,$2,'engagement_rate',0.01,'manual',false,$3)`, [brand, real.pubId, istanbulTime(DAY, '12:00')]);
      await c.query(`INSERT INTO leads (brand_id, business_name, business_key, source_note, stage, is_sample) VALUES ($1,'K01 örnek','k01-ornek-${uid()}','ÖRNEK','found',true)`, [brand]);
      await c.query(`INSERT INTO interactions (brand_id, lead_id, channel, direction, kind, content, idempotency_key, is_simulated, status, occurred_at)
        SELECT $1, id, 'email','outbound','first_contact','{}', 'k01:'||id, true, 'sent', $2 FROM leads WHERE brand_id=$1 AND business_name='K01 örnek'`, [brand, istanbulTime(DAY, '10:00')]);
      await c.query(`INSERT INTO research_runs (brand_id, day, provider, status, is_simulated) VALUES ($1,$2,'fixture','done',true) ON CONFLICT DO NOTHING`, [brand, DAY]);
    });
    const live = await withBrand(brand, (c) => buildStrategyContext(c, brand, istanbulTime(DAY, '23:00'), 14, false));
    const er = live.metricsByContentType.filter((m) => m.metric === 'engagement_rate');
    expect(er.length).toBe(1); expect(er[0].mean).toBeCloseTo(0.01); expect(er[0].simulated).toBe(false);
    expect(live.crm.sentContacts).toBe(0);
    expect(live.crm.stages.some((s) => s.n > 0)).toBe(false);
    expect(live.research.runs.length).toBe(0);
    expect(live.publications.every((p) => p.simulated === false)).toBe(true);
    const sim = await withBrand(brand, (c) => buildStrategyContext(c, brand, istanbulTime(DAY, '23:00'), 14, true));
    expect(sim.metricsByContentType.find((m) => m.metric === 'engagement_rate')!.mean).toBeCloseTo(0.9);
    expect(sim.publications.every((p) => p.simulated === true)).toBe(true);
  });

  it('K-02 kip bilinmeyen eski kayıt canlı sayılmaz; yeni kayıt kip belirtmeden yazılamaz', async () => {
    await withBrand(alma, (c) => c.query(`INSERT INTO leads (brand_id, business_name, business_key, source_note, stage, is_sample, mode_unknown) VALUES ($1,'K02 eski','k02-eski-${uid()}','V1 kaydı','found',false,true)`, [alma]));
    const live = await withBrand(alma, (c) => buildStrategyContext(c, alma, istanbulTime(DAY, '23:00'), 14, false));
    expect(live.crm.stages.reduce((a, s) => a + s.n, 0)).toBe(0);
    expect(live.missing.some((m) => /kipi bilinmeyen/.test(m))).toBe(true);
    await expect(withBrand(alma, (c) => c.query(`INSERT INTO leads (brand_id, business_name, business_key, source_note) VALUES ($1,'K02 kipsiz','k02-kipsiz-${uid()}','x')`, [alma]))).rejects.toThrow(/is_sample/);
  });

  it('K-03 aynı gün simülasyondan canlıya geçişte canlı kök görev ayrı açılır, örnek görev canlı worker tarafından alınmaz', async () => {
    const now = istanbulTime('2026-10-13', '08:00');
    const s = await enqueueScheduled('daily-plan', now, bays); // yalnız etkin marka kök görev alır
    Object.assign(process.env, { RUN_MODE: 'live' }); reloadConfig();
    try {
      const l = await enqueueScheduled('daily-plan', now, bays);
      expect(l[0].created).toBe(true);
      expect(l[0].taskId).not.toBe(s[0].taskId);
      const kinds = await q(bays, `SELECT is_simulated FROM tasks WHERE idempotency_key='2026-10-13:daily_plan' ORDER BY is_simulated`);
      expect(kinds.map((k) => k.is_simulated)).toEqual([false, true]);
      // Canlı worker örnek görevi almaz
      let got: any; const seen: string[] = [];
      for (let i = 0; i < 30; i++) { got = await claimDue('worker-live', new Date(now.getTime() + 60_000), 60_000, { brandId: bays }); if (!got) break; seen.push(got.id); expect(got.is_simulated).toBe(false); await withSystem((c) => c.query(`UPDATE tasks SET status='done', locked_by=NULL WHERE id=$1`, [got.id])); }
      expect(seen).not.toContain(s[0].taskId);
      expect((await q(bays, `SELECT status FROM tasks WHERE id=$1`, [s[0].taskId]))[0].status).toBe('queued');
      // temizlik: bu testin açtığı örnek kök görev sonraki testleri etkilemesin
      await withSystem((c) => c.query(`UPDATE tasks SET status='cancelled' WHERE id=$1`, [s[0].taskId]));
    } finally { Object.assign(process.env, { RUN_MODE: 'simulation' }); reloadConfig(); }
  });

  it('K-04 bekleyen örnek gönderim görevi, e-posta bağlantısı canlıyken bile canlı kanaldan yürütülmez', async () => {
    const { leadId, draftId } = await leadWithContact('k04', bays, true);
    await withBrand(bays, (c) => c.query(`UPDATE leads SET stage='evaluated' WHERE id=$1`, [leadId]));
    await withSystem((c) => c.query(`UPDATE channel_connections SET status='live' WHERE brand_id=$1 AND channel='email'`, [bays]));
    Object.assign(process.env, { RUN_MODE: 'live', EGRESS_ENABLED: 'true', CUSTOMER_EMAIL_LIVE: 'true', N8N_BASE_URL: `http://127.0.0.1:${port}` }); reloadConfig();
    n8nHits = 0;
    try {
      const o = await contactLead({ brandId: bays, leadId, kind: 'first_contact', draftAssetId: draftId, now: istanbulTime(DAY, '10:00'), simulated: true });
      expect(o.result).toBe('blocked');
      expect((o as any).reasons.join(' ')).toMatch(/örnek/i);
      expect(n8nHits).toBe(0);
    } finally {
      Object.assign(process.env, { RUN_MODE: 'simulation', EGRESS_ENABLED: 'false', CUSTOMER_EMAIL_LIVE: 'false' }); reloadConfig();
      await withSystem((c) => c.query(`UPDATE channel_connections SET status='mock' WHERE brand_id=$1 AND channel='email'`, [bays]));
    }
  });

  it('K-05 örnek araştırma önbelleği canlı süreçte kullanılmaz', async () => {
    const day = '2026-10-14';
    await runResearch({ brandId: alma, day, now: istanbulTime(day, '08:00'), simulated: true, maxQueries: 1 }); // ÖRNEK önbellek dolar
    const sim = (await q(alma, `SELECT count(*)::int n FROM source_documents WHERE is_simulated`))[0].n;
    expect(sim).toBeGreaterThan(0);
    // Aynı ad ve sorgularla "canlı" sağlayıcı (gerçek dış çağrı yok; test sağlayıcısı)
    const fx = new FixtureSearchProvider(); (fx as any).simulated = false; (fx as any).pricingKey = 'research:page_read';
    const fr = new FixturePageReader(); (fr as any).simulated = false; let reads = 0; const orig = fr.read.bind(fr); fr.read = async (u: string) => { reads++; return orig(u); };
    const r = await runResearch({ brandId: alma, day, now: istanbulTime(day, '08:30'), simulated: false, maxQueries: 1, stack: { provider: fx, reader: fr } });
    expect(fx.calls.length).toBe(1);             // sorgu önbelleği örnekten okunmadı
    expect(reads).toBeGreaterThan(0);             // sayfa önbelleği örnekten okunmadı
    expect(r.notes.some((n) => n.startsWith('önbellek'))).toBe(false);
    const live = await q(alma, `SELECT count(*)::int n FROM source_documents WHERE NOT is_simulated`);
    expect(live[0].n).toBeGreaterThan(0);
    // Canlı adaylar ÖRNEK işaretli değil, örnek adaylarla birleşmedi
    expect((await q(alma, `SELECT count(*)::int n FROM leads WHERE NOT is_sample AND business_key LIKE 'd:ornek-%'`))[0].n).toBeGreaterThan(0);
  });

  it('K-06 canlı görev örnek kampanyaya, örnek adaya veya örnek kanıta bağlanmaz', async () => {
    const sampleCamp = await withBrand(alma, (c) => campaignFor(c, alma, 'acquisition', true));
    const liveCamp = await withBrand(alma, (c) => campaignFor(c, alma, 'acquisition', false));
    expect(liveCamp).not.toBe(sampleCamp);
    await withBrand(alma, (c) => c.query(`INSERT INTO evidence (brand_id, kind, title, is_sample) VALUES ($1,'metric','K06 ÖRNEK kanıt',true)`, [alma]));
    const live = await withBrand(alma, (c) => buildContext(c, alma, 'content', false));
    expect(live.evidence.some((e: any) => /K06 ÖRNEK/.test(e.title))).toBe(false);
    const sim = await withBrand(alma, (c) => buildContext(c, alma, 'content', true));
    expect(sim.evidence.some((e: any) => /K06 ÖRNEK/.test(e.title))).toBe(true);
  });

  it('K-07 kalite değerlendirmesi operasyon görevlerini ve müşteri/performans verisini kirletmez', async () => {
    const before = await q(bays, `SELECT (SELECT count(*)::int FROM tasks WHERE purpose='operation') t, (SELECT count(*)::int FROM leads) l, (SELECT count(*)::int FROM metrics) m, (SELECT count(*)::int FROM opportunities) o`);
    const r = await runQuality();
    expect(r.status).toBe('done');
    const after = await q(bays, `SELECT (SELECT count(*)::int FROM tasks WHERE purpose='operation') t, (SELECT count(*)::int FROM leads) l, (SELECT count(*)::int FROM metrics) m, (SELECT count(*)::int FROM opportunities) o`);
    expect(after).toEqual(before);
    expect((await q(bays, `SELECT count(*)::int n FROM tasks WHERE purpose='evaluation' AND kind LIKE 'eval:%'`))[0].n).toBeGreaterThanOrEqual(20);
    expect((await q(bays, `SELECT count(*)::int n FROM agent_runs r JOIN tasks t ON t.id=r.task_id WHERE t.purpose='evaluation' AND r.purpose<>'evaluation'`))[0].n).toBe(0);
    // Worker değerlendirme görevini sahiplenmez
    await withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'strategy', kind: 'eval:K07', idempotencyKey: `eval:k07:${uid()}`, input: {}, simulated: true, purpose: 'evaluation' } as any));
    const d = await drain({ brandId: bays });
    expect(Object.keys(d.results)).not.toContain('dead_letter');
  });
});

// ───────────────────────────── 3. Açık iletişim reddi ─────────────────────────────
describe('V2.1-3 açık iletişim reddi modelden önce', () => {
  async function pendingFollowUps(leadId: string) {
    await withBrand(bays, async (c) => {
      await enqueueTask(c, { brandId: bays, role: 'customer_dev', kind: 'follow_up_check', idempotencyKey: `follow_up_check:${leadId}:1`, input: { leadId, followUpNo: 1 }, runAt: istanbulTime('2026-10-20', '10:00'), simulated: true });
      await c.query(`INSERT INTO manual_tasks (brand_id, lead_id, kind, channel, payload, dedupe_key, is_simulated) VALUES ($1,$2,'send_follow_up','email','{}',$3,true)`, [bays, leadId, `follow_up:${leadId}:1`]);
    });
  }

  it('O-01 "İSTEMİYORUM": model çağrılmadan yanıtla aynı işlemde iletişim yasağı, aday kaybı ve bekleyen takiplerin iptali', async () => {
    const { leadId } = await leadWithContact('o01', bays);
    await pendingFollowUps(leadId);
    clock.set(istanbulTime(DAY, '11:00'));
    const r = await ingestReply({ brandId: bays, leadId, messageId: `<o01-${uid()}@ornek.invalid>`, text: 'LÜTFEN BENİ LİSTEDEN ÇIKARIN, İSTEMİYORUM.', receivedAt: clock.now(), via: 'webhook', simulated: true, enqueueClassify: true });
    expect(r.status).toBe('recorded');
    expect((r as any).optOut).toBe(true);
    // Worker çalışmadan önce bile:
    expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [leadId]))[0].stage).toBe('lost');
    expect((await q(bays, `SELECT count(*)::int n FROM suppression_entries WHERE reason LIKE '%açık ret%'`))[0].n).toBeGreaterThan(0);
    expect((await q(bays, `SELECT status FROM tasks WHERE idempotency_key=$1`, [`follow_up_check:${leadId}:1`]))[0].status).toBe('cancelled');
    expect((await q(bays, `SELECT status FROM manual_tasks WHERE dedupe_key=$1`, [`follow_up:${leadId}:1`]))[0].status).toBe('skipped');
    await drain({ now: () => clock.now(), brandId: bays });
    expect(mockModelControl.calls).toBe(0);
    expect((await q(bays, `SELECT count(*)::int n FROM opportunities WHERE lead_id=$1`, [leadId]))[0].n).toBe(0);
  });

  it('O-02 model anahtarı yok / model hatası / bütçe dolu iken de açık ret kaydedilir', async () => {
    for (const mode of ['model_error', 'budget'] as const) {
      const { leadId } = await leadWithContact(`o02${mode}`, bays);
      if (mode === 'model_error') mockModelControl.injectFault('no_key', 5);
      if (mode === 'budget') { await resetBudget(); const est = estimateCost('test:priced', { units: 1 }); for (let i = 0; i < 12; i++) await reserveBudget({ brandId: bays, mode: 'simulation', provider: 'test', estimate: est, now: istanbulTime(DAY, '11:00') }); }
      clock.set(istanbulTime(DAY, '11:00'));
      await ingestReply({ brandId: bays, leadId, messageId: `<o02-${mode}-${uid()}@ornek.invalid>`, text: 'Bir daha yazmayın lütfen.', receivedAt: clock.now(), via: 'webhook', simulated: true, enqueueClassify: true });
      await drain({ now: () => clock.now(), brandId: bays });
      expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [leadId]))[0].stage).toBe('lost');
      expect(mockModelControl.calls).toBe(0);
      if (mode === 'budget') await resetBudget();
    }
  });

  it('O-03 belirsiz ifade kesin ret sayılmaz; mevcut sınıflandırma yoluna gider', async () => {
    expect(detectExplicitOptOut('Şimdilik istemiyoruz, belki ileride konuşuruz')).toBe(false);
    expect(detectExplicitOptOut('İSTEMİYORUM')).toBe(true);
    expect(detectExplicitOptOut('lütfen listeden çıkarın')).toBe(true);
    expect(detectExplicitOptOut('Fiyat bilgisi istemiyorum, önce demo görmek istiyorum')).toBe(false);
    const { leadId } = await leadWithContact('o03', bays);
    clock.set(istanbulTime(DAY, '12:00'));
    const r = await ingestReply({ brandId: bays, leadId, messageId: `<o03-${uid()}@ornek.invalid>`, text: 'Şimdilik istemiyoruz, belki ileride konuşuruz', receivedAt: clock.now(), via: 'webhook', simulated: true, enqueueClassify: true });
    expect((r as any).optOut).toBe(false);
    expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [leadId]))[0].stage).not.toBe('lost');
    await drain({ now: () => clock.now(), brandId: bays });
    expect(mockModelControl.calls).toBeGreaterThan(0);
  });

  it('O-04 açık ret yanıtının tekrar teslimi yeni fırsat, karar veya çelişkili durum üretmez', async () => {
    const { leadId } = await leadWithContact('o04', bays);
    clock.set(istanbulTime(DAY, '13:00'));
    const msg = `<o04-${uid()}@ornek.invalid>`;
    const ev0 = (await q(bays, `SELECT count(*)::int n FROM operation_events WHERE event_type='contact.opted_out' AND subject_id=$1`, [leadId]))[0].n;
    for (let i = 0; i < 3; i++) await ingestReply({ brandId: bays, leadId, messageId: msg, text: 'İletişime geçmeyin.', receivedAt: clock.now(), via: 'webhook', simulated: true, enqueueClassify: true });
    await drain({ now: () => clock.now(), brandId: bays });
    expect((await q(bays, `SELECT count(*)::int n FROM operation_events WHERE event_type='contact.opted_out' AND subject_id=$1`, [leadId]))[0].n).toBe(ev0 + 1);
    expect((await q(bays, `SELECT count(*)::int n FROM opportunities WHERE lead_id=$1`, [leadId]))[0].n).toBe(0);
    expect((await q(bays, `SELECT count(*)::int n FROM approval_requests WHERE params->>'leadId'=$1`, [leadId]))[0].n).toBe(0);
    expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [leadId]))[0].stage).toBe('lost');
    expect(mockModelControl.calls).toBe(0);
  });
  it('O-05 Türkçe karakterle başlayan çekince ("önce") kelime sınırında tanınır: "Fiyat istemiyorum, önce demo" ret sayılmaz; açık retler korunur', async () => {
    for (const t of ['Fiyat istemiyorum, önce demo', 'Fiyat istemiyorum önce demo', 'FİYAT İSTEMİYORUM ÖNCE DEMO']) expect(detectExplicitOptOut(t), t).toBe(false);
    for (const t of ['İSTEMİYORUM', 'Bir daha yazmayın', 'Hayır, istemiyorum.', 'lütfen listeden çıkarın']) expect(detectExplicitOptOut(t), t).toBe(true);
    // Kelime içindeki parçalar çekince sayılmaz ("tamam" içindeki "ama", "öncelik" içindeki "önce")
    expect(detectExplicitOptOut('Tamam, istemiyorum.')).toBe(true);
    expect(detectExplicitOptOut('Öncelikle teşekkürler, istemiyorum.')).toBe(true);
    for (const text of ['Fiyat istemiyorum, önce demo', 'Fiyat istemiyorum önce demo']) {
      const { leadId } = await leadWithContact(`o05${uid()}`, bays);
      clock.set(istanbulTime(DAY, '14:00'));
      const before = mockModelControl.calls;
      const r = await ingestReply({ brandId: bays, leadId, messageId: `<o05-${uid()}@ornek.invalid>`, text, receivedAt: clock.now(), via: 'webhook', simulated: true, enqueueClassify: true });
      expect(r.status).toBe('recorded');
      expect((r as any).optOut).toBe(false);
      const emails = (await q(bays, `SELECT email FROM contacts WHERE lead_id=$1`, [leadId])).map((x) => x.email);
      const sup = await withBrand(bays, async (c) => { const { isSuppressed } = await import('../src/crm/crm.js'); return isSuppressed(c, bays, emails.map((e) => ({ type: 'email' as const, value: e }))); });
      expect(sup, text).toBe(false);
      expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [leadId]))[0].stage).not.toBe('lost');
      expect((await q(bays, `SELECT count(*)::int n FROM operation_events WHERE event_type='contact.opted_out' AND subject_id=$1`, [leadId]))[0].n).toBe(0);
      // Sınıflandırma yoluna devam eder: görev kuyrukta ve model çağrılır
      expect((await q(bays, `SELECT count(*)::int n FROM tasks WHERE kind='reply_classify' AND input->>'interactionId'=$1`, [r.interactionId]))[0].n).toBe(1);
      await drain({ now: () => clock.now(), brandId: bays });
      expect(mockModelControl.calls).toBeGreaterThan(before);
      expect((await q(bays, `SELECT status, output->>'explicit' explicit FROM tasks WHERE kind='reply_classify' AND input->>'interactionId'=$1`, [r.interactionId]))[0]).toMatchObject({ status: 'done', explicit: null });
    }
  });
});

// ───────────────────────────── 4. Belirsiz gider uzlaştırması ─────────────────────────────
describe('V2.1-4 belirsiz araştırma ve model giderleri', () => {
  const day = (n: number) => `2026-10-${String(n).padStart(2, '0')}`;
  function failing(err: () => Error) {
    const p = new FixtureSearchProvider(); (p as any).pricingKey = 'test:priced'; (p as any).name = `test-${uid()}`; // ayrı ad: önceki testlerin sorgu önbelleği kullanılmaz
    const orig = p.search.bind(p); let fail = true;
    p.search = async (qq: string) => { p.calls.push(qq); if (fail) { fail = false; throw err(); } return orig(qq); };
    return p;
  }
  const rsv = async (since: Date) => q(alma, `SELECT id, status, est_try::float8 est, call_ref FROM budget_reservations WHERE brand_id=$1 AND created_at >= $2 ORDER BY created_at`, [alma, since]);

  beforeEach(async () => { await resetBudget(); });

  it('B-01 dış çağrı öncesi engel (fiyat bilinmiyor, egress engeli) rezervasyonu bırakır veya hiç açmaz', async () => {
    const t0 = new Date();
    const unknown = new FixtureSearchProvider(); (unknown as any).pricingKey = 'test:unknown'; (unknown as any).name = `test-${uid()}`;
    expect((await runResearch({ brandId: alma, day: day(1), now: istanbulTime(day(1), '08:00'), simulated: true, maxQueries: 1, stack: { provider: unknown, reader: new FixturePageReader() } })).status).toBe('blocked_budget');
    const blocked = failing(() => new EgressBlockedError('Dış istek engellendi (test): EGRESS_ENABLED kapalı'));
    await runResearch({ brandId: alma, day: day(2), now: istanbulTime(day(2), '08:00'), simulated: true, maxQueries: 1, stack: { provider: blocked, reader: new FixturePageReader() } });
    const r = await rsv(t0);
    expect(r.length).toBe(1); expect(r[0].status).toBe('released');
    expect((await withSystem((c) => committed(c, 'simulation', '2026-10'))).reserved).toBe(0);
  });

  it('B-02 sağlayıcı isteği aldıktan sonra zaman aşımı: rezervasyon "belirsiz" kalır, toplamda sayılır, kurucuya uzlaştırma işi açılır', async () => {
    const t0 = new Date();
    const p = failing(() => Object.assign(new Error('The operation was aborted due to timeout'), { name: 'TimeoutError' }));
    const res = await runResearch({ brandId: alma, day: day(3), now: istanbulTime(day(3), '08:00'), simulated: true, maxQueries: 1, stack: { provider: p, reader: new FixturePageReader() } });
    const r = await rsv(t0);
    expect(r[0].status).toBe('uncertain');
    expect((await withSystem((c) => committed(c, 'simulation', '2026-10'))).reserved).toBe(400);
    expect(res.notes.join(' ')).toMatch(/belirsiz/);
    const mt = await q(alma, `SELECT kind, payload FROM manual_tasks WHERE kind='reconcile_cost' AND payload->>'reservationId'=$1`, [r[0].id]);
    expect(mt.length).toBe(1);
    const rep = await buildReport('daily', { brandId: alma, now: istanbulTime(day(3), '20:00') });
    expect(rep.text).toMatch(/Uzlaştırma bekleyen/);
  });

  it('B-03 belirsiz sunucu hatası (5xx) belirsiz; kesin ret (4xx) ücretlenmedi sayılıp bırakılır', async () => {
    const t0 = new Date();
    await runResearch({ brandId: alma, day: day(4), now: istanbulTime(day(4), '08:00'), simulated: true, maxQueries: 1, stack: { provider: failing(() => Object.assign(new Error('brave 503'), { httpStatus: 503 })), reader: new FixturePageReader() } });
    await runResearch({ brandId: alma, day: day(5), now: istanbulTime(day(5), '08:00'), simulated: true, maxQueries: 1, stack: { provider: failing(() => Object.assign(new Error('brave 401: anahtar geçersiz'), { httpStatus: 401 })), reader: new FixturePageReader() } });
    const r = await rsv(t0);
    expect(r.map((x) => x.status)).toEqual(['uncertain', 'released']);
  });

  it('B-04 tekrar denenen her çağrı ayrı izlenir; tekrarlı uzlaştırma iki kez gider yazmaz', async () => {
    const t0 = new Date();
    const p = failing(() => Object.assign(new Error('socket hang up'), { code: 'ECONNRESET' }));
    await runResearch({ brandId: alma, day: day(6), now: istanbulTime(day(6), '08:00'), simulated: true, maxQueries: 1, stack: { provider: p, reader: new FixturePageReader() } });
    await runResearch({ brandId: alma, day: day(7), now: istanbulTime(day(7), '08:00'), simulated: true, maxQueries: 1, stack: { provider: p, reader: new FixturePageReader() } });
    const r = await rsv(t0);
    const search = r.filter((x) => x.est === 400);
    expect(search.map((x) => x.status)).toEqual(['uncertain', 'reconciled']);
    expect(new Set(search.map((x) => x.call_ref)).size).toBe(2);
    expect(search.every((x) => !!x.call_ref)).toBe(true);
    // Kurucu: "ücretlendi" — iki kez kaydedilse de deftere bir kez yazılır
    const u = search[0].id;
    const a = await resolveUncertainCost(u, { charged: true, amountOriginal: 400, currency: 'TRY', by: 'founder' });
    const b = await resolveUncertainCost(u, { charged: true, amountOriginal: 400, currency: 'TRY', by: 'founder' });
    const c = await resolveUncertainCost(u, { charged: false, by: 'founder' });
    expect(a.status).toBe('reconciled'); expect(b.status).toBe('already_resolved'); expect(c.status).toBe('already_resolved');
    expect((await ownerQuery(`SELECT count(*)::int n FROM cost_ledger WHERE reservation_id=$1`, [u])).rows[0].n).toBe(1);
    // Manuel iş yolu ile kapatma da çift kayıt üretmez
    const mt = (await q(alma, `SELECT id FROM manual_tasks WHERE kind='reconcile_cost' AND payload->>'reservationId'=$1`, [u]))[0];
    await completeManualTask(alma, mt.id, { outcome: 'done', charged: true, amountOriginal: 400, currency: 'TRY' } as any, 'founder');
    expect((await ownerQuery(`SELECT count(*)::int n FROM cost_ledger WHERE reservation_id=$1`, [u])).rows[0].n).toBe(1);
  });

  it('B-05 aynı desen model çağrısında: 5xx belirsiz kalır, 4xx bırakılır', async () => {
    const task = await withBrand(alma, async (c) => { const { id } = await enqueueTask(c, { brandId: alma, role: 'strategy', kind: 'b05', idempotencyKey: `b05:${uid()}`, input: {}, simulated: true }); return (await c.query(`SELECT * FROM tasks WHERE id=$1`, [id])).rows[0]; });
    mockModelControl.injectFault('http500', 1);
    await expect(runAgent({ task, role: 'customer_dev', taskInput: { mode: 'classify_reply', replyText: 'merhaba', interactionRef: 'x', lead: { business_name: 'x', need_signals: [], fit_score: 50, source_uri: null } } })).rejects.toThrow();
    mockModelControl.injectFault('http400', 1);
    await expect(runAgent({ task, role: 'customer_dev', taskInput: { mode: 'classify_reply', replyText: 'merhaba', interactionRef: 'x', lead: { business_name: 'x', need_signals: [], fit_score: 50, source_uri: null } } })).rejects.toThrow();
    const r = await q(alma, `SELECT status FROM budget_reservations WHERE task_id=$1 ORDER BY created_at`, [task.id]);
    expect(r.map((x) => x.status)).toEqual(['uncertain', 'released']);
  });

  it('B-06 aynı sınıflandırma tüm ücretli adaptörlerde: Brave/Anthropic/OpenAI hata biçimleri ve WhatsApp şablon sonucu', () => {
    expect(callStateOf(new EgressBlockedError('engel'))).toBe('not_sent');
    expect(callStateOf(new BudgetBlockedError('monthly_limit', 'sınır'))).toBe('not_sent');
    expect(callStateOf(Object.assign(new Error('brave 429'), { httpStatus: 429, transient: true }))).toBe('not_charged');
    expect(callStateOf(Object.assign(new Error('anthropic 401'), { httpStatus: 401 }))).toBe('not_charged');
    expect(callStateOf(Object.assign(new Error('openai 529'), { httpStatus: 529, transient: true }))).toBe('uncertain');
    expect(callStateOf(Object.assign(new Error('fetch failed'), { name: 'TypeError' }))).toBe('uncertain');
    expect(callStateOf(new Error('Dış istek hatası (anthropic): socket hang up'))).toBe('uncertain');
    expect(callStateOf(Object.assign(new Error('WhatsApp 400'), { callState: 'not_charged' }))).toBe('not_charged');
  });
});
