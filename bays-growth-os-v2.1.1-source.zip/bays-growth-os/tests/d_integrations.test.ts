import crypto from 'node:crypto';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { closePools, withBrand, withSystem } from '../src/db/pool.js';
import { queuePublication, executePublication, reconcilePublication } from '../src/integrations/publisher.js';
import { mockLinkedInControl, LinkedInApiAdapter, N8nLinkedInAdapter } from '../src/integrations/linkedin.js';
import { egressFetch, EgressBlockedError, installGlobalEgressGuard } from '../src/integrations/egress.js';
import { handleWhatsAppWebhook, verifyChallenge, buildDecisionMessage } from '../src/integrations/whatsapp.js';
import { createDecisionRequest, buttonId } from '../src/core/approvals.js';
import { notifyFounder } from '../src/notify/notifier.js';
import { createHalt, applyHaltToQueue } from '../src/core/halts.js';
import { buildServer } from '../src/api/server.js';
import { brandId, useTestPricing } from './helpers.js';

let bays: string;
let n = 0;
async function asset(): Promise<string> {
  return withBrand(bays, async (c) => (await c.query(`INSERT INTO assets (brand_id, kind, content, status, is_sample) VALUES ($1,'post_text',$2,'passed_checks',true) RETURNING id`, [bays, { channel: 'linkedin', post_text: `ÖRNEK gönderi ${++n}: tekrarlı işler hakkında.`, hashtags: ['#ornek'] }])).rows[0].id);
}
const sign = (raw: string) => 'sha256=' + crypto.createHmac('sha256', 'test_app_secret_not_real').update(raw).digest('hex');
const waMsg = (id: string, from: string, extra: any) => JSON.stringify({ object: 'whatsapp_business_account', entry: [{ changes: [{ field: 'messages', value: { messages: [{ id, from, timestamp: String(Math.floor(Date.now() / 1000)), ...extra }] } }] }] });

beforeAll(async () => { bays = await brandId('bayssystems'); useTestPricing(); });
beforeEach(() => mockLinkedInControl.reset());
afterAll(async () => { await closePools(); });

describe('D — LinkedIn yayın, idempotency ve uzlaştırma', () => {
  it('[T2] aynı yayın olayı iki kez gelirse tek kayıt ve tek uzak gönderi olur', async () => {
    const a = await asset();
    const q1 = await withBrand(bays, (c) => queuePublication(c, { brandId: bays, assetId: a, channel: 'linkedin', idempotencyKey: `t2:${a}` }));
    const q2 = await withBrand(bays, (c) => queuePublication(c, { brandId: bays, assetId: a, channel: 'linkedin', idempotencyKey: `t2:${a}` }));
    expect(q2.created).toBe(false); expect(q2.id).toBe(q1.id);
    const [r1, r2] = await Promise.all([executePublication(bays, q1.id, 'bayssystems'), executePublication(bays, q1.id, 'bayssystems')]);
    expect([r1, r2].filter((r) => r.status === 'published' && !r.skipped).length).toBe(1);
    expect(mockLinkedInControl.remoteCount(`t2:${a}`)).toBe(1);
    expect((await executePublication(bays, q1.id, 'bayssystems')).skipped).toBe(true);
  });

  it('[T3] zaman aşımında yayın tekrar gönderilmez; uzlaştırma uzak kaydı bulur', async () => {
    const a = await asset();
    const q = await withBrand(bays, (c) => queuePublication(c, { brandId: bays, assetId: a, channel: 'linkedin', idempotencyKey: `t3:${a}` }));
    mockLinkedInControl.injectFault('timeout_after_send');
    expect((await executePublication(bays, q.id, 'bayssystems')).status).toBe('outcome_unknown');
    expect((await executePublication(bays, q.id, 'bayssystems')).skipped).toBe(true); // yeniden gönderim yok
    const r = await reconcilePublication(bays, q.id, 'bayssystems');
    expect(r.status).toBe('published');
    expect(mockLinkedInControl.remoteCount(`t3:${a}`)).toBe(1);
  });

  it('[T3] istek hiç ulaşmadıysa uzlaştırma "başarısız" der ve otomatik yeniden göndermez', async () => {
    const a = await asset();
    const q = await withBrand(bays, (c) => queuePublication(c, { brandId: bays, assetId: a, channel: 'linkedin', idempotencyKey: `t3b:${a}` }));
    mockLinkedInControl.injectFault('timeout_before_send');
    await executePublication(bays, q.id, 'bayssystems');
    expect((await reconcilePublication(bays, q.id, 'bayssystems')).status).toBe('failed');
    expect(mockLinkedInControl.remoteCount(`t3b:${a}`)).toBe(0);
  });

  it('[T11] kota hatası bağlantıyı "degraded" yapar; sonraki yayın manuel göreve düşer; erişim iptali uyarı üretir', async () => {
    const a = await asset();
    const q = await withBrand(bays, (c) => queuePublication(c, { brandId: bays, assetId: a, channel: 'linkedin', idempotencyKey: `t11:${a}` }));
    mockLinkedInControl.injectFault('quota');
    expect((await executePublication(bays, q.id, 'bayssystems')).status).toBe('queued');
    const st = await withBrand(bays, async (c) => (await c.query(`SELECT status FROM channel_connections WHERE brand_id=$1 AND adapter='linkedin-api'`, [bays])).rows[0].status);
    expect(st).toBe('degraded');
    expect((await executePublication(bays, q.id, 'bayssystems')).status).toBe('manual_required');
    // bağlantıyı geri al (kurucu işlemi simülasyonu) ve erişim iptalini dene
    await withSystem((c) => c.query(`UPDATE channel_connections SET status='mock', last_error=NULL WHERE brand_id=$1 AND adapter='linkedin-api'`, [bays]));
    const a2 = await asset();
    const q2 = await withBrand(bays, (c) => queuePublication(c, { brandId: bays, assetId: a2, channel: 'linkedin', idempotencyKey: `t11b:${a2}` }));
    mockLinkedInControl.injectFault('revoked');
    expect((await executePublication(bays, q2.id, 'bayssystems')).status).toBe('failed');
    const alerts = await withBrand(bays, async (c) => (await c.query(`SELECT count(*)::int n FROM operation_events WHERE event_type='alert.raised' AND subject_type='channel_connection'`)).rows[0].n);
    expect(alerts).toBeGreaterThan(0);
    await withSystem((c) => c.query(`UPDATE channel_connections SET status='mock', last_error=NULL WHERE brand_id=$1 AND adapter='linkedin-api'`, [bays]));
  });

  it('[T7] kanal durdurması kuyruktaki yayını yürütmez', async () => {
    const a = await asset();
    const q = await withBrand(bays, (c) => queuePublication(c, { brandId: bays, assetId: a, channel: 'linkedin', idempotencyKey: `t7:${a}` }));
    const h = await withSystem(async (c) => { const id = await createHalt(c, { scope: 'channel', brandId: bays, scopeValue: 'linkedin', reason: 'test', by: 'founder' }); await applyHaltToQueue(c, id); return id; });
    const r = await executePublication(bays, q.id, 'bayssystems');
    expect(r.skipped).toBe(true);
    expect(mockLinkedInControl.remoteCount(`t7:${a}`)).toBe(0);
    await withSystem((c) => c.query(`UPDATE halts SET active=false WHERE id=$1`, [h]));
  });
});

describe('D — dış çıkış koruması', () => {
  it('[T6] anahtar yokken / simülasyon kipinde gerçek HTTP isteği yapılamaz', async () => {
    await expect(egressFetch({ adapter: 'x', status: 'live', purpose: 'live', allowedHosts: ['api.linkedin.com'], credentialPresent: false, url: 'https://api.linkedin.com/rest/posts' })).rejects.toThrow(EgressBlockedError);
    const out = await new LinkedInApiAdapter().publish({ brandSlug: 'bayssystems', idempotencyKey: 'k', text: 't', hashtags: [] }, 'live');
    expect(out.kind).toBe('failed');
    const n8n = await new N8nLinkedInAdapter().publish({ brandSlug: 'bayssystems', idempotencyKey: 'k', text: 't', hashtags: [] }, 'live');
    expect(n8n.kind).toBe('failed');
    installGlobalEgressGuard();
    await expect(fetch('https://example.com')).rejects.toThrow(/Global çıkış koruması/);
  });
});

describe('D — WhatsApp karar ve rapor akışı', () => {
  it('webhook doğrulama, imza, tekrar önleme ve buton kararı', async () => {
    expect(verifyChallenge({ 'hub.mode': 'subscribe', 'hub.verify_token': 'test_verify_token_not_real', 'hub.challenge': '123' })).toBe('123');
    expect(verifyChallenge({ 'hub.mode': 'subscribe', 'hub.verify_token': 'yanlis', 'hub.challenge': '123' })).toBeNull();
    const a = await withBrand(bays, (c) => createDecisionRequest(c, { brandId: bays, action: 'meeting.schedule', params: {}, rationale: 'test', simulated: true }));
    const raw = waMsg('wamid.T1', '905550000000', { type: 'interactive', interactive: { type: 'button_reply', button_reply: { id: buttonId(a.code, 'approve', a.nonce), title: 'Onayla' } } });
    expect((await handleWhatsAppWebhook(raw, 'sha256=00')).status).toBe(401);
    const r1 = await handleWhatsAppWebhook(raw, sign(raw));
    expect(r1.decisions[0]).toEqual({ status: 'applied', code: a.code, option: 'approve' });
    const r2 = await handleWhatsAppWebhook(raw, sign(raw)); // aynı webhook tekrar
    expect(r2.duplicates).toBe(1); expect(r2.decisions.length).toBe(0);
    const msg = buildDecisionMessage({ ...a, options: a.options }, 'BaysSystems', '905550000000');
    expect(msg.type).toBe('interactive');
    expect(msg.interactive!.action.buttons.every((b: any) => b.reply.title.length <= 20 && b.reply.id.length <= 256)).toBe(true);
  });

  it('[T4] yetkisiz numaradan gelen buton yanıtı karar yürütmez', async () => {
    const a = await withBrand(bays, (c) => createDecisionRequest(c, { brandId: bays, action: 'meeting.schedule', rationale: 'test', simulated: true }));
    const raw = waMsg('wamid.T4', '905559999999', { type: 'interactive', interactive: { type: 'button_reply', button_reply: { id: buttonId(a.code, 'approve', a.nonce) } } });
    const r = await handleWhatsAppWebhook(raw, sign(raw));
    expect(r.decisions[0]).toEqual({ status: 'rejected', reason: 'unauthorized' });
    const st = await withBrand(bays, async (c) => (await c.query(`SELECT status FROM approval_requests WHERE id=$1`, [a.id])).rows[0].status);
    expect(st).toBe('pending');
  });

  it('bildirim aynı anahtarla iki kez gitmez; WhatsApp yoksa e-posta yedeği bir kez çalışır; "okundu" karar değildir', async () => {
    const r1 = await notifyFounder({ kind: 'daily_report', brandId: bays, dedupeKey: 'daily:test:1', text: 'ÖRNEK rapor' });
    const r2 = await notifyFounder({ kind: 'daily_report', brandId: bays, dedupeKey: 'daily:test:1', text: 'ÖRNEK rapor' });
    expect(r1.whatsapp).toBe('sent(mock)'); expect(r2.duplicate).toBe(true);
    await withSystem((c) => c.query(`UPDATE channel_connections SET status='disconnected' WHERE brand_id=$1 AND channel='whatsapp'`, [bays]));
    const r3 = await notifyFounder({ kind: 'daily_report', brandId: bays, dedupeKey: 'daily:test:2', text: 'ÖRNEK rapor' });
    expect(r3.whatsapp).toBe('failed'); expect(r3.email).toBe('sent(mock)');
    const r4 = await notifyFounder({ kind: 'daily_report', brandId: bays, dedupeKey: 'daily:test:2', text: 'ÖRNEK rapor' });
    expect(r4.duplicate).toBe(true);
    await withSystem((c) => c.query(`UPDATE channel_connections SET status='mock' WHERE brand_id=$1 AND channel='whatsapp'`, [bays]));
    // durum webhook'u: read yalnız bildirim durumunu günceller
    const ext = await withSystem(async (c) => (await c.query(`SELECT external_id FROM outbound_notifications WHERE dedupe_key='daily:test:1' AND channel='whatsapp'`)).rows[0].external_id);
    const raw = JSON.stringify({ object: 'whatsapp_business_account', entry: [{ changes: [{ value: { statuses: [{ id: ext, status: 'read', recipient_id: '905550000000', timestamp: '1' }] } }] }] });
    expect((await handleWhatsAppWebhook(raw, sign(raw))).statuses).toBe(1);
    const st = await withSystem(async (c) => (await c.query(`SELECT status FROM outbound_notifications WHERE external_id=$1`, [ext])).rows[0].status);
    expect(st).toBe('read');
  });
});

describe('D — panel API güvenliği', () => {
  it('kurucu token olmadan API erişimi yok; erişim günlüğe yazılır; canlıya geçiş doğrulama ister', async () => {
    const app = await buildServer();
    expect((await app.inject({ method: 'GET', url: '/api/overview' })).statusCode).toBe(401);
    // URL kodlamasıyla atlatma denemeleri
    for (const u of ['/%61pi/overview', '/API/overview', '/api/../api/overview', '/%2Fapi/overview']) {
      expect([401, 404]).toContain((await app.inject({ method: 'GET', url: u })).statusCode);
    }
    expect((await app.inject({ method: 'POST', url: '/%61pi/decisions/K-AAAAAA', payload: '{}', headers: { 'content-type': 'application/json' } })).statusCode).toBe(401);
    const ok = await app.inject({ method: 'GET', url: '/api/overview', headers: { authorization: 'Bearer test-founder-token' } });
    expect(ok.statusCode).toBe(200);
    expect(ok.json().mode).toBe('simulation');
    const conn = ok.json().connections.find((c: any) => c.slug === 'bayssystems' && c.adapter === 'n8n-linkedin');
    const live = await app.inject({ method: 'POST', url: `/api/connections/${conn.id}/status`, headers: { authorization: 'Bearer test-founder-token', 'content-type': 'application/json' }, payload: JSON.stringify({ status: 'live' }) });
    expect(live.statusCode).toBe(400);
    expect((await app.inject({ method: 'POST', url: '/internal/cycle/daily-plan', headers: { 'content-type': 'application/json' }, payload: '{}' })).statusCode).toBe(401);
    expect((await app.inject({ method: 'GET', url: '/panel' })).statusCode).toBe(200);
    // n8n geç gelen "published" geri çağrısı manuel duruma düşmüş yayını kapatır (çift paylaşım önleme)
    const a2 = await asset();
    const pid = await withBrand(bays, async (c) => (await c.query(`INSERT INTO publications (brand_id, asset_id, channel, adapter, idempotency_key, status, is_simulated) VALUES ($1,$2,'linkedin','n8n-linkedin','late-cb','manual_required',false) RETURNING id`, [bays, a2])).rows[0].id);
    const body = JSON.stringify({ idempotency_key: 'late-cb', status: 'published', external_id: 'urn:li:share:ornek' });
    const sig = 'sha256=' + crypto.createHmac('sha256', 'test_n8n_secret_not_real').update(body).digest('hex');
    expect((await app.inject({ method: 'POST', url: '/webhooks/n8n/publication-result', payload: body, headers: { 'content-type': 'application/json', 'x-bays-signature': sig } })).statusCode).toBe(200);
    expect(await withBrand(bays, async (c) => (await c.query(`SELECT status FROM publications WHERE id=$1`, [pid])).rows[0].status)).toBe('published');
    await withSystem((c) => c.query(`UPDATE publications SET is_simulated=true WHERE id=$1`, [pid])).catch(() => undefined);
    // zamanlayıcı: eski zaman damgalı imzalı istek reddedilir
    const old = JSON.stringify({ trigger: 'n8n', job: 'daily-plan', at: '2020-01-01T00:00:00Z' });
    const s2 = 'sha256=' + crypto.createHmac('sha256', 'test_n8n_secret_not_real').update(old).digest('hex');
    expect((await app.inject({ method: 'POST', url: '/internal/cycle/daily-plan', payload: old, headers: { 'content-type': 'application/json', 'x-bays-signature': s2 } })).statusCode).toBe(401);
    await app.close();
    const logs = await withSystem(async (c) => (await c.query(`SELECT count(*)::int n FROM access_log WHERE path='/api/overview'`)).rows[0].n);
    expect(logs).toBeGreaterThanOrEqual(2);
  });
});
