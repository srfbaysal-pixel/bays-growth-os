import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { closePools, withBrand, withSystem, withAuditor } from '../src/db/pool.js';
import { estimateCost, PriceUnknownError } from '../src/core/pricing.js';
import { reserveBudget, reconcileReservation, BudgetBlockedError, committed } from '../src/core/budget.js';
import { createDecisionRequest, handleDecisionReply, buttonId } from '../src/core/approvals.js';
import { evaluateAction } from '../src/core/authority.js';
import { enqueueTask, LoopDetectedError, claimNextTask } from '../src/core/tasks.js';
import { createHalt, applyHaltToQueue, resumeHalt } from '../src/core/halts.js';
import { addKnowledge, rollbackKnowledge, currentKnowledge, shareMethodSummary, importSharedAsHypothesis } from '../src/core/knowledge.js';
import { verifyEventChain } from '../src/core/events.js';
import { monthKey } from '../src/core/util.js';
import { brandId, useTestPricing, resetBudget, ownerQuery } from './helpers.js';

let bays: string, alma: string;
beforeAll(async () => { bays = await brandId('bayssystems'); alma = await brandId('almakistiyorum'); useTestPricing(); });
afterAll(async () => { await closePools(); });

describe('B — bütçe motoru', () => {
  beforeEach(async () => { await resetBudget(); });

  it('[T5] eşzamanlı 20 rezervasyon (her biri 400 TL) aylık 5.000 TL hedefini aşamaz', async () => {
    const est = estimateCost('test:priced', { units: 1 });
    const results = await Promise.allSettled(Array.from({ length: 20 }, () => reserveBudget({ brandId: bays, mode: 'simulation', provider: 'test', estimate: est })));
    const ok = results.filter((r) => r.status === 'fulfilled').length;
    const blocked = results.filter((r) => r.status === 'rejected' && (r.reason as BudgetBlockedError).reason === 'monthly_limit').length;
    const total = await withSystem((c) => committed(c, 'simulation', monthKey(new Date())));
    expect(ok).toBe(12); // 12 × 400 = 4.800 ≤ 5.000
    expect(blocked).toBe(8);
    expect(total.total).toBeLessThanOrEqual(5000);
  });

  it('[T5] iki markanın giderleri aynı toplam sınıra sayılır', async () => {
    const est = estimateCost('test:priced', { units: 1 });
    for (let i = 0; i < 6; i++) await reserveBudget({ brandId: bays, mode: 'simulation', provider: 'test', estimate: est });
    for (let i = 0; i < 6; i++) await reserveBudget({ brandId: alma, mode: 'simulation', provider: 'test', estimate: est });
    await expect(reserveBudget({ brandId: alma, mode: 'simulation', provider: 'test', estimate: est })).rejects.toThrow(/Aylık bütçe/);
  });

  it('[T5] bilinmeyen fiyat ve bilinmeyen kur engellenir, sıfır sayılmaz', () => {
    expect(() => estimateCost('test:unknown', { units: 1 })).toThrow(PriceUnknownError);
    expect(() => estimateCost('hic-olmayan:kalem', { units: 1 })).toThrow(PriceUnknownError);
  });

  it('uyarılar %70 ve %90 eşiklerinde üretilir; uzlaştırma iki kez deftere yazılmaz', async () => {
    const est = estimateCost('test:priced', { units: 1 });
    const warns: string[] = [];
    for (let i = 0; i < 12; i++) warns.push(...(await reserveBudget({ brandId: bays, mode: 'simulation', provider: 'test', estimate: est })).warnings);
    expect(warns.some((w) => w.includes('%70'))).toBe(true);
    expect(warns.some((w) => w.includes('%90'))).toBe(true);
    const r = await reserveBudget({ brandId: bays, mode: 'simulation', provider: 'test', estimate: { ...est, tryAmount: 10 } });
    await reconcileReservation(r.reservationId, { amountOriginal: 8, currency: 'TRY', item: 'x', succeeded: true });
    await reconcileReservation(r.reservationId, { amountOriginal: 8, currency: 'TRY', item: 'x', succeeded: true });
    const n = await withSystem(async (c) => (await c.query(`SELECT count(*)::int n FROM cost_ledger WHERE reservation_id=$1`, [r.reservationId])).rows[0].n);
    expect(n).toBe(1);
  });

  it('simülasyon fiyatı canlı kipte kullanılamaz', async () => {
    const est = estimateCost('mock:mock-economy', { units: 1 });
    await expect(reserveBudget({ brandId: bays, mode: 'live', provider: 'mock', estimate: est })).rejects.toThrow(/Simülasyon fiyatı/);
  });

  it('bütçe artışı kurucu kararı ister ve 10.000 TL kesin sınırı aşamaz', async () => {
    const d1 = await withBrand(bays, (c) => evaluateAction(c, { brandId: bays, action: 'budget.change_limit' }));
    expect(d1.decision).toBe('needs_founder');
    const over = await withBrand(bays, (c) => createDecisionRequest(c, { brandId: bays, action: 'budget.change_limit', params: { newLimitTry: 12000 }, rationale: 'test' }));
    await expect(handleDecisionReply({ via: 'whatsapp', from: '905550000000', buttonId: buttonId(over.code, 'approve', over.nonce) })).rejects.toThrow(/kesin üst sınırı/);
    const ok = await withBrand(bays, (c) => createDecisionRequest(c, { brandId: bays, action: 'budget.change_limit', params: { newLimitTry: 8000 }, rationale: 'test' }));
    expect((await handleDecisionReply({ via: 'whatsapp', from: '905550000000', buttonId: buttonId(ok.code, 'approve', ok.nonce) })).status).toBe('applied');
    const lim = await withSystem(async (c) => (await c.query(`SELECT value FROM settings WHERE key='budget.active_limit_try'`)).rows[0].value.amount);
    expect(lim).toBe(8000);
    expect((await withBrand(bays, (c) => evaluateAction(c, { brandId: bays, action: 'ads.spend' }))).decision).toBe('deny');
    expect((await withBrand(bays, (c) => evaluateAction(c, { brandId: bays, action: 'budget.hard_cap_change' }))).decision).toBe('deny');
  });
});

describe('B — karar talepleri (WhatsApp/panel)', () => {
  it('[T4] yetkisiz numara, süresi dolmuş, tekrarlı, yanlış nonce ve belirsiz yanıt yürütülmez', async () => {
    const mk = () => withBrand(bays, (c) => createDecisionRequest(c, { brandId: bays, action: 'meeting.schedule', params: {}, rationale: 'test', simulated: true }));
    const a = await mk();
    expect(await handleDecisionReply({ via: 'whatsapp', from: '905551112233', buttonId: buttonId(a.code, 'approve', a.nonce) })).toEqual({ status: 'rejected', reason: 'unauthorized' });
    expect(await handleDecisionReply({ via: 'whatsapp', from: '905550000000', buttonId: buttonId(a.code, 'approve', '0000000000000000') })).toEqual({ status: 'rejected', reason: 'bad_nonce' });
    expect(await handleDecisionReply({ via: 'whatsapp', from: '905550000000', text: 'evet olur' })).toEqual({ status: 'rejected', reason: 'ambiguous' });
    expect(await handleDecisionReply({ via: 'whatsapp', from: '905550000000', text: `${a.code} BELKI` })).toEqual({ status: 'rejected', reason: 'invalid_option' });
    expect((await handleDecisionReply({ via: 'whatsapp', from: '+90 555 000 00 00', buttonId: buttonId(a.code, 'approve', a.nonce) })).status).toBe('applied');
    expect(await handleDecisionReply({ via: 'whatsapp', from: '905550000000', buttonId: buttonId(a.code, 'approve', a.nonce) })).toEqual({ status: 'rejected', reason: 'already_decided' });
    const b = await mk();
    const late = new Date(Date.now() + 25 * 3600_000);
    expect(await handleDecisionReply({ via: 'whatsapp', from: '905550000000', text: `${b.code} ONAYLA`, receivedAt: late })).toEqual({ status: 'rejected', reason: 'expired' });
    expect(await handleDecisionReply({ via: 'panel', founderAuthenticated: false, text: `${b.code} ONAYLA` })).toEqual({ status: 'rejected', reason: 'unauthorized' });
  });

  it('serbest metin tanımsız işlem yetkisine dönüşmez', async () => {
    expect((await withBrand(bays, (c) => evaluateAction(c, { brandId: bays, action: 'herkese mesaj at' }))).decision).toBe('deny');
    await expect(withBrand(bays, (c) => createDecisionRequest(c, { brandId: bays, action: 'publish.routine', rationale: 'x' }))).rejects.toThrow(/kurucu kararı gerektiren/);
  });
});

describe('B — görevler, durdurma, izolasyon, bilgi', () => {
  it('[T2-çekirdek] aynı idempotency anahtarı ikinci görevi oluşturmaz; döngü algılanır', async () => {
    const a = await withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'content', kind: 'draft', idempotencyKey: 'k-1', input: { x: 1 } }));
    const b = await withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'content', kind: 'draft', idempotencyKey: 'k-1', input: { x: 1 } }));
    expect(a.created).toBe(true); expect(b.created).toBe(false); expect(b.id).toBe(a.id);
    await withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'content', kind: 'draft', idempotencyKey: 'k-2', input: { x: 1 } }));
    await withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'content', kind: 'draft', idempotencyKey: 'k-3', input: { x: 1 } }));
    await expect(withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'content', kind: 'draft', idempotencyKey: 'k-4', input: { x: 1 } }))).rejects.toThrow(LoopDetectedError);
  });

  it('[T7-çekirdek] marka durdurması kuyruktaki işleri kapsar; yeniden başlatma kurucu ister', async () => {
    const t = await withBrand(alma, (c) => enqueueTask(c, { brandId: alma, role: 'strategy', kind: 'plan', idempotencyKey: 'h-1' }));
    const haltId = await withSystem(async (c) => { const id = await createHalt(c, { scope: 'brand', brandId: alma, reason: 'test', by: 'founder' }); await applyHaltToQueue(c, id); return id; });
    const st = await withBrand(alma, async (c) => (await c.query(`SELECT status FROM tasks WHERE id=$1`, [t.id])).rows[0].status);
    expect(st).toBe('halted');
    const claimedWhileHalted = await claimNextTask({ brandId: alma });
    expect(claimedWhileHalted).toBeNull();
    await expect(withSystem((c) => resumeHalt(c, haltId, { authenticated: false, actor: 'x' }, true))).rejects.toThrow(/kurucu/);
    await withSystem((c) => resumeHalt(c, haltId, { authenticated: true, actor: 'founder' }, true));
    const after = await withBrand(alma, async (c) => (await c.query(`SELECT status FROM tasks WHERE id=$1`, [t.id])).rows[0].status);
    expect(after).toBe('queued');
  });

  it('[T1-çekirdek] RLS: bir markanın oturumu diğer markanın kayıtlarını göremez/yazamaz', async () => {
    await withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'strategy', kind: 'plan', idempotencyKey: 'iso-1' }));
    const seen = await withBrand(alma, async (c) => (await c.query(`SELECT count(*)::int n FROM tasks WHERE brand_id=$1`, [bays])).rows[0].n);
    expect(seen).toBe(0);
    await expect(withBrand(alma, (c) => c.query(`INSERT INTO tasks (brand_id, role, kind, idempotency_key, fingerprint) VALUES ($1,'strategy','x','iso-x','f')`, [bays]))).rejects.toThrow(/row-level security/);
  });

  it('denetçi rolü müşteri/yayın/maliyet kayıtlarını değiştiremez', async () => {
    await expect(withAuditor((c) => c.query(`UPDATE leads SET stage='won'`))).rejects.toThrow(/permission denied/);
    await expect(withAuditor((c) => c.query(`DELETE FROM cost_ledger`))).rejects.toThrow(/permission denied/);
    await expect(withAuditor((c) => c.query(`UPDATE publications SET status='published'`))).rejects.toThrow(/permission denied/);
  });

  it('uygulama rolü maliyet defterini ve olay günlüğünü değiştiremez; zincir bütün', async () => {
    await expect(withSystem((c) => c.query(`UPDATE cost_ledger SET amount_try = 0`))).rejects.toThrow(/permission denied/);
    await expect(withSystem((c) => c.query(`DELETE FROM operation_events`))).rejects.toThrow(/permission denied/);
    const chain = await withSystem((c) => verifyEventChain(c));
    expect(chain.ok).toBe(true);
  });

  it('[T12-çekirdek] bilgi sürümlenir, geri alınır; politika ajan tarafından değiştirilemez; süresi geçen bilgi bağlama girmez', async () => {
    await withBrand(bays, async (c) => {
      await addKnowledge(c, { brandId: bays, itemKey: 'method:post-time', kind: 'hypothesis', content: { rule: 'sabah 09:00' }, sourceKind: 'sample', createdBy: 'strategy' });
      await addKnowledge(c, { brandId: bays, itemKey: 'method:post-time', kind: 'hypothesis', content: { rule: 'öğle 12:30' }, sourceKind: 'sample', createdBy: 'strategy' });
      const r = await rollbackKnowledge(c, bays, 'method:post-time', 'auditor', 'deney desteklemedi');
      expect(r.restoredVersion).toBe(1);
      const cur = (await currentKnowledge(c, bays, ['hypothesis'])).find((k) => k.item_key === 'method:post-time');
      expect(cur!.content.rule).toBe('sabah 09:00');
      await expect(addKnowledge(c, { brandId: bays, itemKey: 'policy:core', kind: 'hypothesis', content: { paid_ads: 'açık' }, sourceKind: 'x', createdBy: 'strategy' })).rejects.toThrow(/Politika/);
      await expect(addKnowledge(c, { brandId: bays, itemKey: 'x', kind: 'policy', content: {}, sourceKind: 'x', createdBy: 'content' })).rejects.toThrow(/Politika/);
      await addKnowledge(c, { brandId: bays, itemKey: 'research:old', kind: 'raw_research', content: { a: 1 }, sourceUri: 'https://example.org', sourceKind: 'web', createdBy: 'strategy', validUntil: new Date(Date.now() - 1000) });
      expect((await currentKnowledge(c, bays, ['raw_research'])).some((k) => k.item_key === 'research:old')).toBe(false);
    });
  });

  it('markalar arası yalnız kişisel veri içermeyen özet paylaşılır ve hedef markada hipotez olur', async () => {
    const s = await withBrand(bays, (c) => shareMethodSummary(c, bays, 'demo-video', { method: 'demo videolu gönderi', result: 'yetersiz veri', conditions: 'örnek' }, 'auditor'));
    await expect(withBrand(bays, (c) => shareMethodSummary(c, bays, 'pii', { method: 'ali@ornek.com ile görüş', result: '', conditions: '' }, 'auditor'))).rejects.toThrow(/kişisel veri/);
    const imp = await withBrand(alma, (c) => importSharedAsHypothesis(c, alma, s.id, 'strategy'));
    const row = await withBrand(alma, async (c) => (await c.query(`SELECT kind, validity FROM knowledge_versions WHERE id=$1`, [imp.id])).rows[0]);
    expect(row).toEqual({ kind: 'hypothesis', validity: 'needs_retest' });
    void ownerQuery;
  });
});
