import { withSystem } from '../src/db/pool.js';
import { setPricingForTests, type PricingFile } from '../src/core/pricing.js';

export async function brandId(slug: string): Promise<string> {
  return withSystem(async (c) => (await c.query(`SELECT id FROM brands WHERE slug=$1`, [slug])).rows[0].id);
}

/** Test fiyat tablosu: "test:priced" kalemi 400 TL sabit; "test:unknown" fiyatsız. Gerçek fiyat değildir. */
export function useTestPricing(): void {
  const p: PricingFile = {
    fx: { USD: { rate: 40, source: 'TEST — gerçek kur değil', date: '2026-10-14' } },
    items: {
      'mock:mock-economy': { category: 'model', currency: 'TRY', unit: 'call', price: 0, source: 'sim', date: '2026-10-14', simulatedOnly: true },
      'mock:mock-strong': { category: 'model', currency: 'TRY', unit: 'call', price: 0, source: 'sim', date: '2026-10-14', simulatedOnly: true },
      'mock:research': { category: 'research', currency: 'TRY', unit: 'call', price: 0, source: 'sim', date: '2026-10-14', simulatedOnly: true },
      'mock:whatsapp': { category: 'notification', currency: 'TRY', unit: 'message', price: 0, source: 'sim', date: '2026-10-14', simulatedOnly: true },
      'test:priced': { category: 'model', currency: 'TRY', unit: 'call', price: 400, source: 'TEST', date: '2026-10-14' },
      'test:usd-tokens': { category: 'model', currency: 'USD', unit: 'mtok', inputPerMTok: 1, outputPerMTok: 5, source: 'TEST', date: '2026-10-14' },
      'test:unknown': { category: 'image', currency: 'USD', unit: 'image', price: null, source: '', date: '' },
      'fixture:search': { category: 'research', currency: 'TRY', unit: 'call', price: 0, source: 'sim', date: '2026-10-14', simulatedOnly: true },
      'fixture:page_read': { category: 'research', currency: 'TRY', unit: 'call', price: 0, source: 'sim', date: '2026-10-14', simulatedOnly: true },
      'brave:web_search': { category: 'research', currency: 'USD', unit: 'call', price: 0.005, source: 'TEST', date: '2026-10-14' },
      'research:page_read': { category: 'research', currency: 'TRY', unit: 'call', price: 0, source: 'TEST', date: '2026-10-14' },
    },
  };
  setPricingForTests(p);
}

export async function resetBudget(): Promise<void> {
  // Testler arası temizlik: yalnız sahibi (owner) bağlantısıyla yapılabilir; uygulama rolü defter silemez.
  const pg = (await import('pg')).default;
  const c = new pg.Client({ connectionString: process.env.DATABASE_URL_OWNER });
  await c.connect();
  await c.query(`DELETE FROM cost_ledger; DELETE FROM budget_reservations; DELETE FROM settings WHERE key='budget.active_limit_try'`);
  await c.end();
}

export async function ownerQuery(sql: string, params: unknown[] = []) {
  const pg = (await import('pg')).default;
  const c = new pg.Client({ connectionString: process.env.DATABASE_URL_OWNER });
  await c.connect();
  try { return await c.query(sql, params); } finally { await c.end(); }
}
