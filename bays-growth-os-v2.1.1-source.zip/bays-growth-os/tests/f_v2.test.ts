/**
 * V2 görev dosyası §9 — 18 yeni davranış testi. Tümü yerel PostgreSQL 16 üzerinde, mock/fixture sağlayıcılarla (ÖRNEK veri).
 * Canlı sağlayıcı/LinkedIn/WhatsApp/n8n çağrısı YOKTUR; bunlar test raporunda "bekleyen canlı sınama" olarak ayrıca listelenir.
 */
import crypto from 'node:crypto';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { closePools, withBrand, withSystem } from '../src/db/pool.js';
import { reloadConfig } from '../src/config.js';
import { clock, istanbulTime } from '../src/core/clock.js';
import { enqueueTask } from '../src/core/tasks.js';
import { createHalt } from '../src/core/halts.js';
import { reserveBudget } from '../src/core/budget.js';
import { estimateCost } from '../src/core/pricing.js';
import { addKnowledge } from '../src/core/knowledge.js';
import { runScheduled } from '../src/orchestrator/schedule.js';
import { advanceTo, simulateDay, ingestMockMetrics } from '../src/orchestrator/cycle.js';
import { choosePublishTime } from '../src/orchestrator/chain.js';
import { drain, claimDue, executeClaimed, recoverExpiredLeases, registerHandler } from '../src/worker/worker.js';
import { TransientError } from '../src/core/tasks.js';
import { runResearch } from '../src/research/research.js';
import { FixturePageReader, FixtureSearchProvider } from '../src/research/providers.js';
import { validateUrl, isPrivateAddress, SafeHttpReader, UnsafeUrlError } from '../src/research/safeReader.js';
import { buildStrategyContext } from '../src/agents/strategyContext.js';
import { runAgent } from '../src/agents/runner.js';
import { completeManualTask } from '../src/crm/manual.js';
import { contactLead } from '../src/crm/outreach.js';
import { queuePublication } from '../src/integrations/publisher.js';
import { mockLinkedInControl } from '../src/integrations/linkedin.js';
import { createExperiment, evaluateExperiment, promoteSupportedMethod, rollbackMethod } from '../src/learning/experiments.js';
import { buildReport } from '../src/reports/reports.js';
import { assertLearnable } from '../src/learning/rules.js';
import { runQuality, score } from '../src/evals/quality.js';
import { simulate } from '../src/sim/simulate.js';
import { buildServer } from '../src/api/server.js';
import { brandId, useTestPricing, resetBudget } from './helpers.js';
import fs from 'node:fs';

let bays: string, alma: string;
const D1 = '2026-09-01', D2 = '2026-09-02';
const sign = (raw: string) => 'sha256=' + crypto.createHmac('sha256', 'test_n8n_secret_not_real').update(raw).digest('hex');
const q = async (b: string, sql: string, p: unknown[] = []) => withBrand(b, async (c) => (await c.query(sql, p)).rows);

beforeAll(async () => {
  bays = await brandId('bayssystems'); alma = await brandId('almakistiyorum');
  useTestPricing(); await resetBudget(); mockLinkedInControl.reset();
  process.env.RESEARCH_PROVIDER = 'fixture'; reloadConfig();
  await withSystem((c) => c.query(`UPDATE halts SET active=false WHERE active`));
});
afterAll(async () => { clock.reset(); delete process.env.RESEARCH_PROVIDER; reloadConfig(); await closePools(); });

describe('V2 §9 — araştırma, CRM ve günlük döngü', () => {
  it('V2-01 günlük tetikleme fixture araştırmayı çağırır; kaynaklı aday üretip CRM\'e taşır', async () => {
    const r = await simulateDay(bays, D1);
    const runs = await q(bays, `SELECT provider, status, queries, documents FROM research_runs WHERE day=$1`, [D1]);
    expect(runs[0]).toMatchObject({ provider: 'fixture', status: 'done' });
    expect(runs[0].queries).toBeGreaterThan(0);
    const leads = await q(bays, `SELECT business_name, source_uri, need_signals, is_sample FROM leads WHERE source_uri LIKE 'https://ornek-%' ORDER BY business_name`);
    expect(leads.map((l) => l.business_name)).toEqual(expect.arrayContaining(['Örnek Dil Kursu', 'Örnek Butik Otel', 'Örnek Fizyoterapi Merkezi']));
    expect(leads.every((l) => l.is_sample && l.need_signals.length > 0)).toBe(true);
    const f = (await q(bays, `SELECT source_url, accessed_at, excerpt, observed_fact, inference, confidence, freshness FROM research_findings WHERE kind='business_candidate' AND source_url LIKE '%dilkursu%'`))[0];
    expect(f.excerpt).toMatch(/randevu için bizi arayın/i);
    expect(['high', 'medium', 'low']).toContain(f.confidence); expect(f.freshness).toBe('fresh'); expect(f.accessed_at).toBeTruthy();
    expect(r.tasks.find((t) => t.kind === 'research_discover')?.status).toBe('done');
  });

  it('V2-02 aynı kaynak/işletmenin yeniden keşfi mükerrer aday ve ilk temas üretmez', async () => {
    const before = (await q(bays, `SELECT count(*)::int n FROM leads WHERE source_uri LIKE 'https://ornek-%'`))[0].n;
    await simulateDay(bays, D2);
    const after = (await q(bays, `SELECT count(*)::int n FROM leads WHERE source_uri LIKE 'https://ornek-%'`))[0].n;
    expect(after).toBe(before);
    const fc = await q(bays, `SELECT lead_id, count(*)::int n FROM interactions WHERE kind='first_contact' AND direction='outbound' GROUP BY lead_id HAVING count(*) > 1`);
    expect(fc.length).toBe(0);
    const cand = (await q(bays, `SELECT count(*)::int n FROM research_findings WHERE kind='business_candidate' AND data->>'domain'='ornek-dilkursu.invalid'`))[0].n;
    expect(cand).toBe(1);
    const cached = (await q(bays, `SELECT notes FROM research_runs WHERE day=$1`, [D2]))[0].notes;
    expect(cached.some((n: string) => n.startsWith('önbellek'))).toBe(true);
  });

  it('V2-03 kanıtsız ihtiyaç/iletişim uydurulmaz; araştırma engeli rapora yansır', async () => {
    const fizyo = (await q(bays, `SELECT id FROM leads WHERE business_name='Örnek Fizyoterapi Merkezi'`))[0];
    expect((await q(bays, `SELECT count(*)::int n FROM contacts WHERE lead_id=$1`, [fizyo.id]))[0].n).toBe(0); // sayfada e-posta yok → kişi yok
    expect((await q(bays, `SELECT kind FROM manual_tasks WHERE lead_id=$1`, [fizyo.id])).map((m) => m.kind)).toEqual(expect.arrayContaining(['add_contact', 'linkedin_message']));
    const docs = await q(bays, `SELECT url, status FROM source_documents`);
    expect(docs.find((d) => d.url.includes('kotusayfa'))?.status).toBe('injection_flagged');
    expect(docs.find((d) => d.url.includes('erisilemez'))?.status).toBe('unreachable');
    expect(docs.find((d) => d.url.includes('169.254'))?.status).toBe('blocked');
    expect((await q(bays, `SELECT count(*)::int n FROM leads WHERE source_uri LIKE '%kotusayfa%' OR source_uri LIKE '%veteriner%'`))[0].n).toBe(0);
    // Model aday değerlendirmesi kaynakta olmayan sinyal ekleyemez: tüm sinyaller bulgu alıntısıyla eşleşir
    const leads = await q(bays, `SELECT l.need_signals, f.data FROM leads l JOIN research_findings f ON f.lead_id=l.id WHERE f.kind='business_candidate'`);
    for (const l of leads) for (const s of l.need_signals) expect(l.data.signals.map((x: any) => x.label)).toContain(s);
    // Sağlayıcı kapalıysa keşif yapılmadığı dürüstçe raporlanır
    process.env.RESEARCH_PROVIDER = 'none'; reloadConfig();
    const r = await runResearch({ brandId: alma, day: D1, now: istanbulTime(D1, '08:00'), simulated: true });
    expect(r.status).toBe('disabled');
    const rep = await buildReport('daily', { brandId: alma, now: istanbulTime(D1, '20:00') });
    expect(rep.text).toMatch(/Araştırma yapılmadı/);
    process.env.RESEARCH_PROVIDER = 'fixture'; reloadConfig();
  });

  it('V2-04 müşteri geliştirme ve kampanya görevleri günlük döngüde gerçekten yürütülür', async () => {
    const kinds = await q(bays, `SELECT kind, status FROM tasks WHERE input->>'day'=$1 OR kind IN ('lead_assess','contact_send')`, [D1]);
    const done = (k: string) => kinds.some((t) => t.kind === k && t.status === 'done');
    for (const k of ['daily_plan', 'research_discover', 'strategy_plan', 'campaign_plan', 'content_create', 'distribution_schedule', 'lead_assess', 'contact_send', 'evening']) expect(done(k), k).toBe(true);
    const pubs = await q(bays, `SELECT status FROM publications WHERE (scheduled_at AT TIME ZONE 'Europe/Istanbul')::date=$1::date`, [D1]);
    expect(pubs.map((p) => p.status)).toContain('published');
  });

  it('V2-05 izinli test kanalından gelen yanıt fırsata ve kurucu kararına dönüşür; tekrar yanıt mükerrer işlem üretmez', async () => {
    const sent = (await q(bays, `SELECT i.lead_id, i.external_id FROM interactions i JOIN leads l ON l.id=i.lead_id WHERE i.kind='first_contact' AND i.status='sent' AND l.business_name='Örnek Dil Kursu'`))[0];
    expect(sent).toBeTruthy();
    const app = await buildServer();
    const body = JSON.stringify({ brand: 'bayssystems', message_id: '<v2-05@ornek.invalid>', in_reply_to: sent.external_id, from: 'iletisim@ornek-dilkursu.invalid', text: 'Merhaba, evet sorun. Gelecek hafta görüşebiliriz.' });
    expect((await app.inject({ method: 'POST', url: '/webhooks/email/inbound', payload: body, headers: { 'content-type': 'application/json', 'x-bays-signature': 'sha256=00' } })).statusCode).toBe(401);
    const r1 = await app.inject({ method: 'POST', url: '/webhooks/email/inbound', payload: body, headers: { 'content-type': 'application/json', 'x-bays-signature': sign(body) } });
    const r2 = await app.inject({ method: 'POST', url: '/webhooks/email/inbound', payload: body, headers: { 'content-type': 'application/json', 'x-bays-signature': sign(body) } });
    expect(r1.json().status).toBe('recorded'); expect(r2.json().status).toBe('duplicate');
    await app.close();
    clock.set(istanbulTime(D2, '21:00'));
    await drain({ now: () => clock.now() });
    const opp = await q(bays, `SELECT o.id, o.unknowns FROM opportunities o WHERE o.lead_id=$1`, [sent.lead_id]);
    expect(opp.length).toBe(1);
    expect(opp[0].unknowns).toEqual(expect.arrayContaining(['bütçe', 'karar yetkisi']));
    const dec = await q(bays, `SELECT status, action FROM approval_requests WHERE params->>'opportunityId'=$1`, [opp[0].id]);
    expect(dec[0]).toMatchObject({ status: 'pending', action: 'meeting.schedule' });
    expect((await q(bays, `SELECT count(*)::int n FROM tasks WHERE kind='reply_classify' AND idempotency_key='reply:<v2-05@ornek.invalid>'`))[0].n).toBe(1);
  });

  it('V2-06 manuel gönderim/yanıt kaydı zinciri doğru devam ettirir; taslak gönderilmiş sayılmaz', async () => {
    // E-posta bağlantısı mock değilken (ör. disconnected) gönderim manuel göreve düşer
    await withSystem((c) => c.query(`UPDATE channel_connections SET status='disconnected' WHERE brand_id=$1 AND channel='email'`, [bays]));
    const lead = (await q(bays, `SELECT id FROM leads WHERE business_name='Örnek Butik Otel'`))[0];
    const draft = (await q(bays, `SELECT id FROM assets WHERE kind='outreach_draft' LIMIT 1`))[0];
    // Butik otel daha önce mock ile temas almış olabilir; temiz bir aday oluştur
    const nl = await withBrand(bays, async (c) => {
      const l = (await c.query(`INSERT INTO leads (brand_id, business_name, business_key, source_uri, source_note, stage, fit_score, need_signals, is_sample) VALUES ($1,'V2-06 Örnek','d:v2-06.invalid','https://v2-06.invalid','ÖRNEK','evaluated',80,'["randevular telefonla alınıyor"]',true) RETURNING id`, [bays])).rows[0].id;
      await c.query(`INSERT INTO contacts (brand_id, lead_id, email, contact_basis, is_sample) VALUES ($1,$2,'a@v2-06.invalid','Kaynak sayfada yayımlanmış iletişim adresi: https://v2-06.invalid',true)`, [bays, l]);
      return l;
    });
    void lead;
    const o = await contactLead({ brandId: bays, leadId: nl, kind: 'first_contact', draftAssetId: draft.id, now: istanbulTime(D2, '10:00'), simulated: true });
    expect(o.result).toBe('manual');
    expect((await q(bays, `SELECT count(*)::int n FROM interactions WHERE lead_id=$1`, [nl]))[0].n).toBe(0); // taslak ≠ temas
    const m = (await q(bays, `SELECT id FROM manual_tasks WHERE lead_id=$1 AND kind='send_first_contact'`, [nl]))[0];
    const r = await completeManualTask(bays, m.id, { outcome: 'sent', sentAt: istanbulTime(D2, '11:00').toISOString() }, 'founder');
    expect(r.next[0]).toMatch(/^follow_up_check:/);
    expect((await q(bays, `SELECT status FROM interactions WHERE lead_id=$1`, [nl]))[0].status).toBe('manual_sent');
    expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [nl]))[0].stage).toBe('contacted');
    const again = await completeManualTask(bays, m.id, { outcome: 'sent' }, 'founder');
    expect(again.next.length).toBe(0);
    // Manuel yanıt girişi zinciri sürdürür
    const m2 = (await q(bays, `SELECT id FROM manual_tasks WHERE lead_id=$1`, [nl]))[0];
    await withBrand(bays, (c) => c.query(`UPDATE manual_tasks SET status='open' WHERE id=$1`, [m2.id]));
    const r2 = await completeManualTask(bays, m2.id, { outcome: 'reply_received', replyText: 'Lütfen bir daha yazmayın, istemiyorum.' }, 'founder');
    expect(r2.next[0]).toMatch(/^reply_classify:/);
    clock.set(istanbulTime(D2, '21:30')); await drain({ now: () => clock.now() });
    expect((await q(bays, `SELECT stage FROM leads WHERE id=$1`, [nl]))[0].stage).toBe('lost');
    await withSystem((c) => c.query(`UPDATE channel_connections SET status='mock' WHERE brand_id=$1 AND channel='email'`, [bays]));
  });
});

describe('V2 §9 — strateji geri bildirimi ve uygulanan öğrenme', () => {
  it('V2-07 strateji girdisi ölçüm, denetim, maliyet ve CRM özetlerini içerir; marka izolasyonu korunur', async () => {
    await withBrand(alma, (c) => c.query(`INSERT INTO leads (brand_id, business_name, business_key, source_note, is_sample) VALUES ($1,'ALMA-GİZLİ-ADAY','n:alma gizli|','ÖRNEK',true)`, [alma]));
    const ctx = await withBrand(bays, (c) => buildStrategyContext(c, bays, istanbulTime(D2, '08:00')));
    for (const k of ['publications', 'metricsByContentType', 'research', 'crm', 'costs', 'offers', 'experiments', 'rules', 'audit', 'missing', 'period']) expect(ctx).toHaveProperty(k);
    expect(ctx.crm.stages.length).toBeGreaterThan(0);
    expect(ctx.research.runs.length).toBeGreaterThan(0);
    // Sızıntı denetimi: alma'nın ad, anahtar ve kimlikleri bays bağlamında hiçbir biçimde geçmez
    const almaIds = (await q(alma, `SELECT id::text id FROM leads UNION ALL SELECT id::text FROM research_findings UNION ALL SELECT id::text FROM campaigns`)).map((r) => r.id);
    const ser = JSON.stringify(ctx);
    for (const needle of ['ALMA-GİZLİ-ADAY', 'alma gizli', alma, ...almaIds]) expect(ser.includes(needle), needle).toBe(false);
    const almaCtx = await withBrand(alma, (c) => buildStrategyContext(c, alma, istanbulTime(D2, '08:00')));
    expect(almaCtx.research.findings.length).toBe(0); // bays bulguları alma'ya sızmaz
    const st = (await q(bays, `SELECT output FROM tasks WHERE kind='strategy_plan' AND input->>'day'=$1`, [D1]))[0].output;
    expect(st).toHaveProperty('objectives'); expect(st).toHaveProperty('dataGaps');
  });

  it('V2-08 farklı performans kanıtı planı gerekçeli değiştirir; bilinmeyen veri sonuç uydurtmaz', async () => {
    const base = await withBrand(bays, (c) => buildStrategyContext(c, bays, istanbulTime(D2, '08:00')));
    const mk = async (ctx: any, k: string) => {
      const t = await withBrand(bays, async (c) => { const { id } = await enqueueTask(c, { brandId: bays, role: 'strategy', kind: 'v2-08', idempotencyKey: `v2-08:${k}`, input: { k } }); return (await c.query(`UPDATE tasks SET status='running' WHERE id=$1 RETURNING *`, [id])).rows[0]; });
      return runAgent({ task: t, role: 'strategy', taskInput: { objective: 'awareness', context: ctx } });
    };
    const a = await mk({ ...base, metricsByContentType: [{ content_type: 'objection', metric: 'engagement_rate', n: 4, mean: 0.061, simulated: true }, { content_type: 'need_explainer', metric: 'engagement_rate', n: 4, mean: 0.032, simulated: true }] }, 'a');
    const b = await mk({ ...base, metricsByContentType: [{ content_type: 'objection', metric: 'engagement_rate', n: 4, mean: 0.02, simulated: true }, { content_type: 'need_explainer', metric: 'engagement_rate', n: 4, mean: 0.07, simulated: true }] }, 'b');
    const none = await mk({ ...base, metricsByContentType: [] }, 'none');
    expect(a.output.campaign_brief.content_type).toBe('objection');
    expect(b.output.campaign_brief.content_type).toBe('need_explainer');
    expect(a.output.decision_changes[0].because).toMatch(/0\.061/);
    expect(none.output.decision_changes.filter((d: any) => /içerik türü/.test(d.change)).length).toBe(0);
    expect(none.output.data_gaps.join(' ')).toMatch(/yeterli ölçüm yok/);
    for (const r of [a, b, none]) expect(r.guard.violations.filter((v) => v.code === 'invented_number')).toEqual([]);
  });

  it('V2-09 onaylanmış deney kuralı sonraki zamanlamayı değiştirir; geri alma eski davranışı getirir', async () => {
    const before = await withBrand(alalmaGuard(alma), (c) => choosePublishTime(c, alma, null, true, istanbulTime(D2, '08:00')));
    expect(before).toMatchObject({ time: '10:00' });
    await withBrand(alma, async (c) => {
      const id = await createExperiment(c, { brandId: alma, hypothesis: 'Sabah saati daha iyi', primary_variable: 'yayın saati', comparison: { control: '12:30', variant: '08:30' }, sample_condition: { min_per_arm: 2, min_days: 1, min_relative_effect: 0.2, justification: 'test için küçük eşik (yalnız simülasyon)' }, target_metric: 'engagement_rate', cost_limit_try: 0, stop_rule: 'hata olursa dur', rollback_plan: 'varsayılan saate dön', confounders: ['içerik türü'], simulated: true });
      await c.query(`INSERT INTO metrics (brand_id, experiment_id, arm, metric, value, source, is_simulated) VALUES ($1,$2,'12:30','engagement_rate',0.03,'mock',true),($1,$2,'12:30','engagement_rate',0.03,'mock',true),($1,$2,'08:30','engagement_rate',0.06,'mock',true),($1,$2,'08:30','engagement_rate',0.06,'mock',true)`, [alma, id]);
      expect((await evaluateExperiment(c, id, new Date(clock.now().getTime() + 3 * 86400_000))).status).toBe('supported');
      await promoteSupportedMethod(c, id, 'rule:linkedin:publish_time', { rule_type: 'publish_time', scope: { channel: 'linkedin' } });
      // Hipotez kural olarak uygulanmaz
      await addKnowledge(c, { brandId: alma, itemKey: 'hyp:time', kind: 'hypothesis', content: { rule_type: 'publish_time', value: '23:00', scope: { channel: 'linkedin' } }, sourceKind: 'sample', createdBy: 'strategy' });
    });
    const after = await withBrand(alma, (c) => choosePublishTime(c, alma, null, true, istanbulTime(D2, '08:00')));
    expect(after.time).toBe('08:30'); expect(after.basis).toMatch(/rule:linkedin:publish_time v1/);
    // Canlı yürütmede örnek veriyle öğrenilmiş kural uygulanmaz
    expect((await withBrand(alma, (c) => choosePublishTime(c, alma, null, false, istanbulTime(D2, '08:00')))).time).toBe('10:00');
    await withBrand(alma, (c) => rollbackMethod(c, alma, 'rule:linkedin:publish_time', 'test: geri al'));
    expect((await withBrand(alma, (c) => choosePublishTime(c, alma, null, true, istanbulTime(D2, '08:00')))).time).toBe('10:00');
    // Politika anahtarı öğrenme adı altında değiştirilemez
    expect(() => assertLearnable('budget_limit')).toThrow(/Öğrenmeyle değiştirilemeyen/);
    expect(() => assertLearnable('authority')).toThrow();
  });
});

describe('V2 §9 — zamanlama, worker ve belirsiz sonuç', () => {
  async function pubAt(key: string, at: Date) {
    const asset = (await q(bays, `INSERT INTO assets (brand_id, kind, content, status, is_sample) VALUES ($1,'post_text',$2,'passed_checks',true) RETURNING id`, [bays, { post_text: `ÖRNEK ${key}`, hashtags: [] }]))[0].id;
    return withBrand(bays, async (c) => {
      const p = await queuePublication(c, { brandId: bays, assetId: asset, channel: 'linkedin', idempotencyKey: key, scheduledAt: at });
      const t = await enqueueTask(c, { brandId: bays, role: 'distribution', kind: 'publish_due', channel: 'linkedin', idempotencyKey: `publish_due:${p.id}`, input: { publicationId: p.id }, runAt: at, simulated: true });
      return { pubId: p.id, taskId: t.id };
    });
  }

  it('V2-10 sahte saatle: planlanan saatten önce yayın çağrısı yok; saat gelince bir kez', async () => {
    const at = istanbulTime('2026-09-05', '10:00');
    const { pubId } = await pubAt('v2-10', at);
    await advanceTo(new Date(at.getTime() - 60_000));
    expect(mockLinkedInControl.publishCalls('v2-10')).toBe(0);
    // Görev erken zorla çalıştırılsa bile (ör. elle) dış çağrı yapılmaz
    const { executePublication } = await import('../src/integrations/publisher.js');
    expect((await executePublication(bays, pubId, 'bayssystems', new Date(at.getTime() - 60_000))).reason).toBe('not_due');
    expect(mockLinkedInControl.publishCalls('v2-10')).toBe(0);
    await advanceTo(at);
    expect(mockLinkedInControl.publishCalls('v2-10')).toBe(1);
    await advanceTo(new Date(at.getTime() + 3600_000));
    expect(mockLinkedInControl.publishCalls('v2-10')).toBe(1);
    // Kaçırılmış yayın gönderilmez ve bir kez yeniden planlanır
    const late = istanbulTime('2026-09-05', '07:00');
    const m = await pubAt('v2-10-missed', late);
    await advanceTo(new Date(late.getTime() + 4 * 3600_000));
    expect((await q(bays, `SELECT status FROM publications WHERE id=$1`, [m.pubId]))[0].status).toBe('missed');
    expect(mockLinkedInControl.publishCalls('v2-10-missed')).toBe(0);
    // Yeniden planlama tam BİR kez: tekrar eden işleme yeni bir yeniden planlama açmaz
    const replans = async () => (await q(bays, `SELECT count(*)::int n FROM tasks WHERE idempotency_key=$1`, [`distribution_schedule:replan:${m.pubId}`]))[0].n;
    expect(await replans()).toBe(1);
    await advanceTo(new Date(late.getTime() + 8 * 3600_000));
    expect(await replans()).toBe(1);
    expect((await q(bays, `SELECT count(*)::int n FROM publications WHERE replan_of=$1`, [m.pubId]))[0].n).toBeLessThanOrEqual(1);
  });

  it('V2-11 iki worker, çökme ve yeniden başlama: doğru sahiplenme, yayımlanmış işi tekrar göndermez', async () => {
    const at = istanbulTime('2026-09-06', '10:00');
    const { taskId } = await pubAt('v2-11', at);
    await advanceTo(new Date(at.getTime() - 1000)); // önceki tüm zamanı gelmiş işleri bitir
    clock.set(at);
    // Aynı anda zamanı gelmiş başka işler varsa önce onları normal yürüt (testin işi ayrık kalsın)
    let a = await claimDue('worker-A', at);
    while (a && a.id !== taskId) { await executeClaimed(a, 'worker-A', at); a = await claimDue('worker-A', at); }
    expect(a?.id).toBe(taskId);
    expect(await claimDue('worker-B', at)).toBeNull(); // A sahipken B alamaz
    // A "çöker" (yürütmeden kaybolur); kira süresi dolunca kurtarılır, B alır ve yürütür
    const afterLease = new Date(at.getTime() + 10 * 60_000);
    const rec = await recoverExpiredLeases(afterLease);
    expect(rec.requeued).toBeGreaterThanOrEqual(1);
    const bt = new Date(afterLease.getTime() + 5 * 60_000);
    let b = await claimDue('worker-B', bt);
    while (b && b.id !== taskId) { await executeClaimed(b, 'worker-B', bt); b = await claimDue('worker-B', bt); }
    expect(b?.id).toBe(taskId);
    expect(await executeClaimed(b, 'worker-B', afterLease)).toBe('done');
    expect(mockLinkedInControl.publishCalls('v2-11')).toBe(1);
    // A geri döner ve elindeki eski görevi bitirmeye çalışır: sahipliği yok, sonucu yazılmaz, tekrar gönderim yok
    expect(await executeClaimed(a, 'worker-A', afterLease)).toBe('lost_lease');
    expect(mockLinkedInControl.publishCalls('v2-11')).toBe(1);
    // Eşzamanlı iki worker: tek sahip
    const at2 = istanbulTime('2026-09-06', '11:00');
    await pubAt('v2-11b', at2);
    clock.set(at2);
    await Promise.all([drain({ workerId: 'w1', now: () => at2 }), drain({ workerId: 'w2', now: () => at2 })]);
    expect(mockLinkedInControl.publishCalls('v2-11b')).toBe(1);
  });

  it('V2-12 geçici hata zamanında yeniden denenir; kalıcı hata ve sınır aşımı hata kuyruğuna gider', async () => {
    let calls = 0;
    registerHandler('test_flaky', async () => { calls++; if (calls < 3) throw new TransientError('geçici: ağ'); return { ok: true }; });
    registerHandler('test_permanent', async () => { throw new Error('kalıcı: geçersiz girdi'); });
    registerHandler('test_always_transient', async () => { throw new TransientError('geçici: kota'); });
    const t0 = istanbulTime('2026-09-07', '10:00');
    clock.set(t0);
    const mk = (kind: string) => withBrand(bays, (c) => enqueueTask(c, { brandId: bays, role: 'system', kind, idempotencyKey: `v2-12:${kind}`, input: { kind }, maxAttempts: 3, runAt: t0 }));
    const fl = await mk('test_flaky'); const pe = await mk('test_permanent'); const at = await mk('test_always_transient');
    await drain({ now: () => t0 });
    expect(calls).toBe(1);
    const row = (id: string) => q(bays, `SELECT status, attempts, next_run_at, dead_reason FROM tasks WHERE id=$1`, [id]).then((r) => r[0]);
    const f1 = await row(fl.id);
    expect(f1.status).toBe('queued');
    expect(new Date(f1.next_run_at).getTime()).toBeGreaterThan(t0.getTime()); // geri çekilme
    await drain({ now: () => new Date(t0.getTime() + 10_000) });
    expect(calls).toBe(1); // zamanı gelmeden tekrar denenmez
    await drain({ now: () => new Date(t0.getTime() + 2 * 3600_000) });
    await drain({ now: () => new Date(t0.getTime() + 4 * 3600_000) });
    expect((await row(fl.id)).status).toBe('done');
    expect(calls).toBe(3);
    const p = await row(pe.id);
    expect(p.status).toBe('dead_letter'); expect(p.dead_reason).toMatch(/kalıcı hata/);
    const a = await row(at.id);
    expect(a.status).toBe('dead_letter'); expect(a.dead_reason).toMatch(/deneme sınırı aşıldı \(3\/3\)/);
  });

  it('V2-13 belirsiz yayın sonucu kör tekrar yerine uzlaştırmaya gider; geç/tekrar callback doğru işlenir', async () => {
    const at = istanbulTime('2026-09-08', '10:00');
    const { pubId } = await pubAt('v2-13', at);
    await advanceTo(new Date(at.getTime() - 1000)); // önceki işler hatayı tüketmesin
    mockLinkedInControl.injectFault('timeout_after_send');
    await advanceTo(at);
    expect((await q(bays, `SELECT status FROM publications WHERE id=$1`, [pubId]))[0].status).toBe('outcome_unknown');
    expect((await q(bays, `SELECT next_run_at FROM tasks WHERE idempotency_key=$1`, [`reconcile:${pubId}`])).length).toBe(1);
    await advanceTo(new Date(at.getTime() + 20 * 60_000));
    expect((await q(bays, `SELECT status FROM publications WHERE id=$1`, [pubId]))[0].status).toBe('published');
    expect(mockLinkedInControl.publishCalls('v2-13')).toBe(1);
    // n8n köprüsü: geç ve tekrarlanan geri çağrı
    const asset = (await q(bays, `INSERT INTO assets (brand_id, kind, content, status, is_sample) VALUES ($1,'post_text','{"post_text":"ÖRNEK"}','passed_checks',true) RETURNING id`, [bays]))[0].id;
    const p2 = (await q(bays, `INSERT INTO publications (brand_id, asset_id, channel, adapter, idempotency_key, status, is_simulated) VALUES ($1,$2,'linkedin','n8n-linkedin','v2-13-n8n','outcome_unknown',true) RETURNING id`, [bays, asset]))[0].id;
    const app = await buildServer();
    const body = JSON.stringify({ idempotency_key: 'v2-13-n8n', status: 'published', external_id: 'urn:li:share:ornek-v2-13' });
    const h = { 'content-type': 'application/json', 'x-bays-signature': sign(body) };
    expect((await app.inject({ method: 'POST', url: '/webhooks/n8n/publication-result', payload: body, headers: h })).json().ok).toBe(true);
    expect((await app.inject({ method: 'POST', url: '/webhooks/n8n/publication-result', payload: body, headers: h })).json().duplicate).toBe(true);
    await app.close();
    expect((await q(bays, `SELECT status, external_id FROM publications WHERE id=$1`, [p2]))[0]).toMatchObject({ status: 'published', external_id: 'urn:li:share:ornek-v2-13' });
  });

  it('V2-14 bütçe, kredi bitişi, fiyat bilinmemesi ve durdurma yeni dış çağrı yollarında uygulanır', async () => {
    const base = { brandId: alma, now: istanbulTime('2026-09-09', '08:00'), simulated: true, maxQueries: 2 };
    // Fiyatı bilinmeyen arama sağlayıcısı: çağrı yapılmaz
    const unknown = new FixtureSearchProvider(); (unknown as any).pricingKey = 'test:unknown';
    const r1 = await runResearch({ ...base, day: '2026-09-09', stack: { provider: unknown, reader: new FixturePageReader() } });
    expect(r1.status).toBe('blocked_budget'); expect(unknown.calls.length).toBe(0);
    // Kredi bitişi (sağlayıcı 402): çağrı başarısız sayılır, rezervasyon bırakılır, rapor notu düşülür
    const broke = new FixtureSearchProvider(); broke.search = async () => { throw new Error('402 kredi yetersiz'); };
    const r2 = await runResearch({ ...base, day: '2026-09-10', stack: { provider: broke, reader: new FixturePageReader() } });
    expect(r2.status).toBe('partial'); expect(r2.notes.join(' ')).toMatch(/kredi yetersiz/);
    // Bütçe tükenmişse: rezervasyon engeli
    await resetBudget();
    const est = estimateCost('test:priced', { units: 1 });
    for (let i = 0; i < 12; i++) await reserveBudget({ brandId: alma, mode: 'simulation', provider: 'test', estimate: est, now: base.now });
    const pricey = new FixtureSearchProvider(); (pricey as any).pricingKey = 'test:priced';
    const r3 = await runResearch({ ...base, day: '2026-09-11', stack: { provider: pricey, reader: new FixturePageReader() } });
    expect(r3.status).toBe('blocked_budget'); expect(pricey.calls.length).toBe(0);
    await resetBudget();
    // Durdurma: araştırma kanalı ve marka
    const h = await withSystem((c) => createHalt(c, { scope: 'channel', brandId: alma, scopeValue: 'research', reason: 'V2-14', by: 'founder' }));
    const live = new FixtureSearchProvider();
    const r4 = await runResearch({ ...base, day: '2026-09-12', stack: { provider: live, reader: new FixturePageReader() } });
    expect(r4.status).toBe('blocked_halt'); expect(live.calls.length).toBe(0);
    await withSystem((c) => c.query(`UPDATE halts SET active=false WHERE id=$1`, [h]));
    const hb = await withSystem((c) => createHalt(c, { scope: 'brand', brandId: bays, reason: 'V2-14b', by: 'founder' }));
    const draft = (await q(bays, `SELECT id FROM assets WHERE kind='outreach_draft' LIMIT 1`))[0];
    const lead = (await q(bays, `SELECT id FROM leads LIMIT 1`))[0];
    const o = await contactLead({ brandId: bays, leadId: lead.id, kind: 'first_contact', draftAssetId: draft.id, now: istanbulTime('2026-09-12', '10:00'), simulated: true });
    expect(o.result).toBe('blocked');
    await withSystem((c) => c.query(`UPDATE halts SET active=false WHERE id=$1`, [hb]));
  });

  it('V2-15 talimat enjeksiyonu, SSRF ve marka sızıntısı saldırı örnekleri engellenir', async () => {
    for (const u of ['http://127.0.0.1/', 'http://localhost/', 'http://169.254.169.254/latest', 'http://10.0.0.5/', 'http://[::1]/', 'file:///etc/passwd', 'https://example.com:8443/', 'https://user:pw@example.com/', 'http://2130706433/', 'http://internal.local/', 'http://[::ffff:127.0.0.1]/']) {
      expect(() => validateUrl(u), u).toThrow(UnsafeUrlError);
    }
    expect(isPrivateAddress('192.168.1.10')).toBe(true); expect(isPrivateAddress('100.64.0.1')).toBe(true); expect(isPrivateAddress('8.8.8.8')).toBe(false);
    // Simülasyon kipinde canlı okuyucu hiç ağa çıkmaz
    await expect(new SafeHttpReader('live').read('https://example.com/')).rejects.toThrow(/engellendi/);
    // Kaynak sayfadaki talimat girişimi işaretlenir ve aday üretmez (V2-03), ajan bağlamından çıkarılır
    const flagged = await q(bays, `SELECT count(*)::int n FROM operation_events WHERE event_type='security.injection_detected' AND subject_type='source_document'`);
    expect(flagged[0].n).toBeGreaterThan(0);
    // Marka sızıntısı: alma oturumu bays araştırma bulgularını göremez
    expect((await q(alma, `SELECT count(*)::int n FROM research_findings WHERE brand_id=$1`, [bays]))[0].n).toBe(0);
    expect((await q(alma, `SELECT count(*)::int n FROM manual_tasks WHERE brand_id=$1`, [bays]))[0].n).toBe(0);
  });
});

describe('V2 §9 — uçtan uca senaryolar ve kalite değerlendirmesi', () => {
  let simBrand: string;
  beforeAll(async () => {
    // Ayrı ÖRNEK marka: diğer testlerin verisinden bağımsız 16 günlük senaryo
    simBrand = await withSystem(async (c) => {
      const id = (await c.query(`INSERT INTO brands (slug, name, status) VALUES ('v2-sim','V2 Simülasyon ÖRNEK','active') RETURNING id`)).rows[0].id;
      await c.query(`INSERT INTO brand_profiles (brand_id, version, profile, source) SELECT $1, 1, profile, 'test kopyası' FROM brand_profiles WHERE brand_id=$2 ORDER BY version DESC LIMIT 1`, [id, bays]);
      await c.query(`INSERT INTO offers (brand_id, code, title, description, readiness, delivery_note, source, scope, required_connections) SELECT $1, code, title, description, readiness, delivery_note, source, scope, required_connections FROM offers WHERE brand_id=$2`, [id, bays]);
      await c.query(`INSERT INTO channel_connections (brand_id, channel, adapter, status, capabilities, secret_refs) SELECT $1, channel, adapter, status, capabilities, secret_refs FROM channel_connections WHERE brand_id=$2`, [id, bays]);
      await c.query(`UPDATE channel_connections SET status='mock' WHERE brand_id=$1 AND adapter IN ('linkedin-api','whatsapp-cloud','n8n-email')`, [id]);
      return id;
    });
  });

  it('V2-16 16 günlük fixture senaryosu araştırmadan plana, zamanlı yayına, ölçüme, öğrenmeye ve değişen davranışa ulaşır', async () => {
    const out = await simulate({ days: 16, brandSlug: 'v2-sim', log: () => undefined });
    const days = out.scenario1;
    expect(days.length).toBe(16);
    expect(days.every((d: any) => d.publication === 'published')).toBe(true);
    expect(days.slice(0, 14).every((d: any) => /deney kolu/.test(d.basis))).toBe(true);
    const last = days[15];
    expect(last.basis).toMatch(/rule:linkedin:publish_time v1/);
    expect(last.time).toBe('09:00');
    const runs = await q(simBrand, `SELECT count(*)::int n FROM research_runs WHERE brand_id=$1 AND status='done'`, [simBrand]);
    expect(runs[0].n).toBe(16);
    const metrics = await q(simBrand, `SELECT count(*)::int n FROM metrics WHERE brand_id=$1 AND is_simulated`, [simBrand]);
    expect(metrics[0].n).toBeGreaterThanOrEqual(30);
    expect(out.learning.some((k: any) => k.value === '09:00' && k.is_sample)).toBe(true);
    (globalThis as any).__v2sim = out;
  }, 300_000);

  it('V2-17 ikinci senaryo keşiften yanıta, fırsata ve kurucu kararına ulaşır; tüm fixture veriler ÖRNEK işaretli', async () => {
    const out = (globalThis as any).__v2sim;
    expect(out.scenario2.reply.classification).toBe('positive_meeting');
    expect(out.scenario2.decision[0]).toMatchObject({ status: 'applied', option: 'approve' });
    const nonSample = await q(simBrand, `SELECT
      (SELECT count(*) FROM leads WHERE brand_id=$1 AND NOT is_sample)::int leads,
      (SELECT count(*) FROM interactions WHERE brand_id=$1 AND NOT is_simulated)::int inter,
      (SELECT count(*) FROM opportunities WHERE brand_id=$1 AND NOT is_simulated)::int opps,
      (SELECT count(*) FROM publications WHERE brand_id=$1 AND NOT is_simulated)::int pubs,
      (SELECT count(*) FROM research_findings WHERE brand_id=$1 AND NOT is_simulated)::int finds`, [simBrand]);
    expect(nonSample[0]).toEqual({ leads: 0, inter: 0, opps: 0, pubs: 0, finds: 0 });
    const domains = await q(simBrand, `SELECT source_uri FROM leads WHERE brand_id=$1`, [simBrand]);
    expect(domains.every((d) => /\.invalid/.test(d.source_uri))).toBe(true);
    expect(out.lastReport).toMatch(/Canlı yayın: yok/);
    expect(out.lastReport).toMatch(/Kurucunun doğruladığı satış: 0/);
  });

  it('V2-18 gerçek model kalite değerlendirmesi ayrı komutla çalışır; anahtar yokken açık bekleyen durumu verir', async () => {
    const live = await runQuality({ live: true });
    expect(live.status).toBe('pending');
    expect(live.note).toMatch(/BEKLEMEDE/); expect(live.note).toMatch(/Model kalitesi sınanmadı/);
    const mock = await runQuality({ live: false });
    expect(mock.mode).toBe('mock_contract'); expect(mock.note).toMatch(/GÖSTERMEZ/);
    expect(mock.results!.length).toBeGreaterThanOrEqual(20);
    const roles = new Set(mock.results!.map((r: any) => r.role));
    expect(roles.size).toBe(5);
    // Puanlayıcı ayırt edicidir: bilerek kötü çıktılar başarısız olur
    const sc = JSON.parse(fs.readFileSync('evals/quality/scenarios.json', 'utf8')).scenarios;
    const s1 = sc.find((s: any) => s.id === 'S1-veri-yok');
    const bad = { ...mock.results!.find((r: any) => r.id === 'S1-veri-yok').output, decision_changes: [{ change: 'x', because: 'yanıt oranı %37 arttı' }], data_gaps: [] };
    expect(Object.values(score(s1, bad)).some((x: any) => !x.pass)).toBe(true);
    const cd1 = sc.find((s: any) => s.id === 'CD1-sinyalli-aday');
    expect(score(cd1, { lead_assessment: { unknowns: [] }, outreach: { draft: 'Sayın yetkili, müşterilerimiz %80 tasarruf etti.', personalization_basis: [] } }).koruma.pass).toBe(false);
    const rows = await withSystem(async (c) => (await c.query(`SELECT mode, status FROM eval_runs ORDER BY created_at DESC LIMIT 2`)).rows);
    expect(rows.map((r) => `${r.mode}:${r.status}`)).toEqual(['mock_contract:done', 'live_model:pending']);
  });
});

function alalmaGuard(id: string) { return id; }
void ingestMockMetrics; void runScheduled;
