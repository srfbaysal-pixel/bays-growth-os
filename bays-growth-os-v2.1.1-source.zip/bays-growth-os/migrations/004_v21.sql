-- V2.1: gerçek ölçüm girişi, kip ayrımı, açık ret, belirsiz gider uzlaştırması.
-- Yalnız ekler/genişletir; mevcut veri silinmez. Geri dönüş: tools/rollback/004_v21_down.sql (önce yedek).

-- ── 1. Ölçümler: kümülatif anlık görüntü politikası ve tekrar teslim koruması ──
ALTER TABLE metrics ADD COLUMN is_current boolean NOT NULL DEFAULT true;
ALTER TABLE metrics ADD COLUMN external_key text;
ALTER TABLE metrics ADD COLUMN received_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE metrics ADD COLUMN recorded_by text;
-- Mevcut veride aynı yayın+ölçüm için birden fazla satır varsa yalnız en son ölçülen "güncel" kalır
UPDATE metrics m SET is_current = false
WHERE m.publication_id IS NOT NULL AND EXISTS (
  SELECT 1 FROM metrics x WHERE x.publication_id = m.publication_id AND x.metric = m.metric AND x.is_simulated = m.is_simulated
    AND (x.measured_at, x.id::text) > (m.measured_at, m.id::text));
CREATE UNIQUE INDEX metrics_one_current_idx ON metrics (publication_id, metric, is_simulated) WHERE is_current AND publication_id IS NOT NULL;
CREATE UNIQUE INDEX metrics_external_key_idx ON metrics (brand_id, source, external_key, metric) WHERE external_key IS NOT NULL;
GRANT UPDATE ON metrics TO bays_app;

-- ── 2. Kip ayrımı ──
-- 2a. Görev amacı: değerlendirme görevleri operasyon kuyruğuna ve verisine karışmaz
ALTER TABLE tasks ADD COLUMN purpose text NOT NULL DEFAULT 'operation' CHECK (purpose IN ('operation','evaluation'));
UPDATE tasks SET purpose = 'evaluation' WHERE kind LIKE 'eval:%';
ALTER TABLE agent_runs ADD COLUMN purpose text NOT NULL DEFAULT 'operation' CHECK (purpose IN ('operation','evaluation'));
UPDATE agent_runs r SET purpose = 'evaluation' FROM tasks t WHERE t.id = r.task_id AND t.purpose = 'evaluation';

-- 2b. Kip bazlı tekillik: aynı gün örnek görev/önbellek/aday canlı işi engellemez
ALTER TABLE tasks DROP CONSTRAINT tasks_brand_id_idempotency_key_key;
ALTER TABLE tasks ADD CONSTRAINT tasks_brand_key_mode_key UNIQUE (brand_id, idempotency_key, is_simulated);
ALTER TABLE manual_tasks DROP CONSTRAINT manual_tasks_brand_id_dedupe_key_key;
ALTER TABLE manual_tasks ADD CONSTRAINT manual_tasks_brand_key_mode_key UNIQUE (brand_id, dedupe_key, is_simulated);
ALTER TABLE leads DROP CONSTRAINT leads_brand_id_business_key_key;
ALTER TABLE leads ADD CONSTRAINT leads_brand_key_mode_key UNIQUE (brand_id, business_key, is_sample);
ALTER TABLE source_documents DROP CONSTRAINT source_documents_brand_id_url_hash_key;
ALTER TABLE source_documents ADD CONSTRAINT source_documents_brand_url_mode_key UNIQUE (brand_id, url_hash, is_simulated);
ALTER TABLE research_queries DROP CONSTRAINT research_queries_brand_id_provider_query_hash_key;
ALTER TABLE research_queries ADD CONSTRAINT research_queries_brand_q_mode_key UNIQUE (brand_id, provider, query_hash, is_simulated);
ALTER TABLE research_runs DROP CONSTRAINT research_runs_brand_id_day_provider_key;
ALTER TABLE research_runs ADD CONSTRAINT research_runs_brand_day_mode_key UNIQUE (brand_id, day, provider, is_simulated);

-- 2c. Kipi bilinmeyen eski kayıtlar: varsayılan "false" ile yazılmış satırlar sessizce canlı sayılmaz.
--     Veritabanında hiçbir canlı işlem kanıtı yoksa (canlı gider, canlı yayın, canlı temas, canlı ölçüm) bu satırlar
--     "mode_unknown" işaretlenir; canlı kararlara girmez, raporda ayrıca sayılır. Kanıt varsa işaretlenmez (kurucu gözden geçirir).
DO $$
DECLARE t text; f text; live_proof boolean;
BEGIN
  SELECT EXISTS (SELECT 1 FROM cost_ledger WHERE mode='live') OR EXISTS (SELECT 1 FROM publications WHERE NOT is_simulated)
      OR EXISTS (SELECT 1 FROM interactions WHERE NOT is_simulated) OR EXISTS (SELECT 1 FROM metrics WHERE NOT is_simulated)
    INTO live_proof;
  FOR t, f IN SELECT * FROM (VALUES ('leads','is_sample'),('contacts','is_sample'),('assets','is_sample'),('campaigns','is_sample'),('evidence','is_sample'),
      ('opportunities','is_simulated'),('meetings','is_simulated'),('experiments','is_simulated'),('manual_tasks','is_simulated'),
      ('approval_requests','is_simulated'),('audit_findings','is_simulated')) v(t, f)
  LOOP
    EXECUTE format('ALTER TABLE %I ADD COLUMN mode_unknown boolean NOT NULL DEFAULT false', t);
    IF NOT live_proof THEN
      EXECUTE format('UPDATE %I SET mode_unknown = true WHERE %I = false', t, f);
    END IF;
    -- Yeni kayıtlar kipi açıkça belirtmek zorunda (varsayılan kaldırıldı)
    EXECUTE format('ALTER TABLE %I ALTER COLUMN %I DROP DEFAULT', t, f);
  END LOOP;
  INSERT INTO settings (key, value, updated_by) VALUES ('migration.004.live_proof', jsonb_build_object('live_proof', live_proof), 'migration')
    ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;
END $$;
-- Kurucu beyanı / doğrulaması olan evidence ve hizmet kanıtı kurucu kararıyla açılır; eski "demo" kanıtları kurucu doğrulamalı ise bilinir sayılır
UPDATE evidence e SET mode_unknown = false FROM offers o WHERE o.demo_evidence_id = e.id AND o.founder_verified;

-- ── 3. Açık ret: manuel iş iptali ──
-- (manual_tasks.status 'skipped' zaten var; görevler 'cancelled' kullanır)

-- ── 4. Belirsiz gider ──
ALTER TABLE budget_reservations DROP CONSTRAINT budget_reservations_status_check;
ALTER TABLE budget_reservations ADD CONSTRAINT budget_reservations_status_check CHECK (status IN ('active','reconciled','released','expired','uncertain'));
ALTER TABLE budget_reservations ADD COLUMN call_ref text;
ALTER TABLE budget_reservations ADD COLUMN outcome_note text;
ALTER TABLE budget_reservations ADD COLUMN resolved_at timestamptz;
ALTER TABLE budget_reservations ADD COLUMN resolved_by text;
ALTER TABLE manual_tasks DROP CONSTRAINT manual_tasks_kind_check;
ALTER TABLE manual_tasks ADD CONSTRAINT manual_tasks_kind_check CHECK (kind IN ('send_first_contact','send_follow_up','linkedin_message','linkedin_connection','verify_publication','match_reply','add_contact','record_demo','fix_bottleneck','reconcile_cost'));

INSERT INTO settings (key, value, updated_by) VALUES ('schema.version', '"2.1"', 'migration')
  ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value;
