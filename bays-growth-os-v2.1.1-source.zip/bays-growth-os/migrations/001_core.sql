-- BaysSystems Growth OS — çekirdek şema (V1)
-- Tüm marka kayıtları brand_id taşır; izolasyon satır düzeyi güvenlik (RLS) ile de uygulanır.
-- Bu dosya migration sahibi (owner) rolüyle çalışır. Uygulama "bays_app", denetçi "bays_auditor" rolüyle bağlanır.

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE brands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9-]+$'),
  name text NOT NULL,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('active','draft','disabled')),
  market text NOT NULL DEFAULT 'TR',
  language text NOT NULL DEFAULT 'tr',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE brand_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  version int NOT NULL,
  profile jsonb NOT NULL,
  source text NOT NULL,
  validity text NOT NULL DEFAULT 'current' CHECK (validity IN ('current','superseded','unverified')),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, version)
);

CREATE TABLE evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  kind text NOT NULL CHECK (kind IN ('source_url','test_result','founder_statement','raw_event','metric','channel_doc')),
  title text NOT NULL,
  uri text,
  content_hash text,
  payload jsonb NOT NULL DEFAULT '{}',
  captured_at timestamptz NOT NULL DEFAULT now(),
  valid_until timestamptz,
  is_sample boolean NOT NULL DEFAULT false
);

CREATE TABLE offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  code text NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  readiness text NOT NULL CHECK (readiness IN ('user_declared','demo','test_verified','in_development','not_for_sale')),
  delivery_note text,
  price_note text,
  evidence_ids uuid[] NOT NULL DEFAULT '{}',
  source text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, code)
);

CREATE TABLE knowledge_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  item_key text NOT NULL,
  version int NOT NULL,
  kind text NOT NULL CHECK (kind IN ('raw_research','hypothesis','verified_rule','policy','shared_method_summary')),
  content jsonb NOT NULL,
  source_uri text,
  source_kind text NOT NULL,
  observed_at timestamptz NOT NULL DEFAULT now(),
  valid_until timestamptz,
  validity text NOT NULL DEFAULT 'current' CHECK (validity IN ('current','stale','superseded','rolled_back','unverified','needs_retest')),
  created_by text NOT NULL,
  supersedes uuid REFERENCES knowledge_versions(id),
  experiment_id uuid,
  is_shared boolean NOT NULL DEFAULT false,
  is_sample boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, item_key, version),
  CHECK (NOT is_shared OR kind = 'shared_method_summary')
);

CREATE TABLE campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  name text NOT NULL,
  objective text NOT NULL CHECK (objective IN ('awareness','acquisition')),
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','active','paused','done')),
  hypothesis text,
  plan jsonb NOT NULL DEFAULT '{}',
  is_sample boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, id)
);

CREATE TABLE tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  campaign_id uuid REFERENCES campaigns(id),
  parent_task_id uuid REFERENCES tasks(id),
  role text NOT NULL CHECK (role IN ('strategy','content','distribution','customer_dev','auditor','system')),
  kind text NOT NULL,
  channel text,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','running','waiting_decision','done','failed','halted','dead_letter','cancelled')),
  idempotency_key text NOT NULL,
  fingerprint text NOT NULL,
  input jsonb NOT NULL DEFAULT '{}',
  output jsonb,
  model_calls int NOT NULL DEFAULT 0,
  max_model_calls int NOT NULL DEFAULT 6,
  attempts int NOT NULL DEFAULT 0,
  max_attempts int NOT NULL DEFAULT 3,
  timeout_ms int NOT NULL DEFAULT 120000,
  next_run_at timestamptz NOT NULL DEFAULT now(),
  locked_until timestamptz,
  last_error text,
  is_simulated boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, idempotency_key)
);
CREATE INDEX tasks_queue_idx ON tasks (status, next_run_at);

CREATE TABLE assets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  campaign_id uuid REFERENCES campaigns(id),
  task_id uuid REFERENCES tasks(id),
  kind text NOT NULL CHECK (kind IN ('post_text','image_brief','video_script','demo_narrative','outreach_draft','report')),
  content jsonb NOT NULL,
  guard_result jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','passed_checks','blocked','published','manual_required')),
  is_sample boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE publications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  campaign_id uuid REFERENCES campaigns(id),
  task_id uuid REFERENCES tasks(id),
  asset_id uuid REFERENCES assets(id),
  channel text NOT NULL,
  adapter text NOT NULL,
  idempotency_key text NOT NULL,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sending','outcome_unknown','published','failed','cancelled','manual_required','halted')),
  external_id text,
  is_simulated boolean NOT NULL,
  scheduled_at timestamptz,
  sent_at timestamptz,
  last_checked_at timestamptz,
  attempts int NOT NULL DEFAULT 0,
  error text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, idempotency_key),
  UNIQUE (channel, external_id)
);

CREATE TABLE leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  campaign_id uuid REFERENCES campaigns(id),
  business_name text NOT NULL,
  business_key text NOT NULL,
  sector text,
  city text,
  size_band text,
  source_uri text,
  source_note text NOT NULL,
  stage text NOT NULL DEFAULT 'found' CHECK (stage IN ('found','fit_verified','evaluated','contact_planned','contacted','replied','meeting','proposal','won','lost','on_hold')),
  fit_score numeric,
  fit_reasons jsonb NOT NULL DEFAULT '[]',
  need_signals jsonb NOT NULL DEFAULT '[]',
  is_sample boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, business_key)
);

CREATE TABLE contacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  lead_id uuid NOT NULL REFERENCES leads(id),
  full_name text,
  role_title text,
  email text,
  phone text,
  linkedin_url text,
  contact_basis text NOT NULL,
  erased_at timestamptz,
  is_sample boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE interactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  lead_id uuid REFERENCES leads(id),
  contact_id uuid REFERENCES contacts(id),
  campaign_id uuid REFERENCES campaigns(id),
  task_id uuid REFERENCES tasks(id),
  channel text NOT NULL,
  direction text NOT NULL CHECK (direction IN ('outbound','inbound')),
  kind text NOT NULL,
  content jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'recorded',
  external_id text,
  idempotency_key text NOT NULL,
  is_simulated boolean NOT NULL,
  occurred_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, idempotency_key)
);

CREATE TABLE opportunities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  lead_id uuid NOT NULL REFERENCES leads(id),
  campaign_id uuid REFERENCES campaigns(id),
  offer_id uuid REFERENCES offers(id),
  status text NOT NULL DEFAULT 'qualified' CHECK (status IN ('qualified','meeting','proposal','won','lost','on_hold')),
  need_summary text NOT NULL,
  evidence jsonb NOT NULL DEFAULT '[]',
  unknowns jsonb NOT NULL DEFAULT '[]',
  next_step text,
  value_try numeric,
  revenue_verified_by_founder boolean NOT NULL DEFAULT false,
  attribution text NOT NULL DEFAULT 'unknown' CHECK (attribution IN ('campaign_confirmed','unattributed','unknown')),
  is_simulated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE meetings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  lead_id uuid NOT NULL REFERENCES leads(id),
  opportunity_id uuid REFERENCES opportunities(id),
  status text NOT NULL DEFAULT 'proposed' CHECK (status IN ('proposed','awaiting_founder','scheduled','held','cancelled')),
  proposed_slots jsonb NOT NULL DEFAULT '[]',
  scheduled_at timestamptz,
  notes text,
  is_simulated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE experiments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  campaign_id uuid REFERENCES campaigns(id),
  hypothesis text NOT NULL,
  primary_variable text NOT NULL,
  comparison jsonb NOT NULL,
  sample_condition jsonb NOT NULL,
  target_metric text NOT NULL,
  cost_limit_try numeric NOT NULL,
  stop_rule text NOT NULL,
  rollback_plan text NOT NULL,
  confounders jsonb NOT NULL DEFAULT '[]',
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','running','insufficient_data','supported','not_supported','inconclusive','stopped')),
  result jsonb,
  is_simulated boolean NOT NULL DEFAULT false,
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  campaign_id uuid REFERENCES campaigns(id),
  publication_id uuid REFERENCES publications(id),
  experiment_id uuid REFERENCES experiments(id),
  arm text,
  metric text NOT NULL,
  value numeric NOT NULL,
  source text NOT NULL CHECK (source IN ('mock','live','manual','n8n')),
  is_simulated boolean NOT NULL,
  evidence_id uuid REFERENCES evidence(id),
  measured_at timestamptz NOT NULL DEFAULT now(),
  CHECK (NOT (source = 'mock' AND NOT is_simulated))
);

CREATE TABLE halts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  scope text NOT NULL CHECK (scope IN ('global','brand','channel','campaign')),
  brand_id uuid REFERENCES brands(id),
  scope_value text,
  reason text NOT NULL,
  created_by text NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  resumed_at timestamptz,
  resumed_by text,
  CHECK (scope = 'global' OR brand_id IS NOT NULL)
);

CREATE TABLE audit_findings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid REFERENCES brands(id),
  check_id text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('info','low','medium','high','critical')),
  category text NOT NULL,
  title text NOT NULL,
  detail jsonb NOT NULL DEFAULT '{}',
  evidence_refs jsonb NOT NULL DEFAULT '[]',
  second_review jsonb,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','acknowledged','resolved','false_positive')),
  halt_id uuid REFERENCES halts(id),
  dedupe_key text NOT NULL UNIQUE,
  is_simulated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE approval_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  code text NOT NULL UNIQUE,
  action text NOT NULL,
  params jsonb NOT NULL DEFAULT '{}',
  rationale text NOT NULL,
  cost_try numeric,
  limit_note text,
  options jsonb NOT NULL,
  nonce text NOT NULL,
  expires_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','expired','cancelled')),
  decided_option text,
  decided_by text,
  decided_via text,
  decided_at timestamptz,
  task_id uuid REFERENCES tasks(id),
  is_simulated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE budget_reservations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  mode text NOT NULL CHECK (mode IN ('live','simulation')),
  month char(7) NOT NULL,
  day date NOT NULL,
  category text NOT NULL,
  provider text NOT NULL,
  est_try numeric NOT NULL CHECK (est_try >= 0),
  actual_try numeric,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','reconciled','released','expired')),
  task_id uuid REFERENCES tasks(id),
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE cost_ledger (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  mode text NOT NULL CHECK (mode IN ('live','simulation')),
  month char(7) NOT NULL,
  category text NOT NULL CHECK (category IN ('model','research','image','video','hosting','notification','other')),
  provider text NOT NULL,
  item text NOT NULL,
  amount_original numeric NOT NULL,
  currency text NOT NULL,
  fx_rate numeric NOT NULL,
  fx_source text NOT NULL,
  fx_date date NOT NULL,
  amount_try numeric NOT NULL,
  reservation_id uuid REFERENCES budget_reservations(id),
  task_id uuid REFERENCES tasks(id),
  external_ref text,
  idempotency_key text NOT NULL UNIQUE,
  is_retry boolean NOT NULL DEFAULT false,
  succeeded boolean NOT NULL DEFAULT true,
  occurred_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE channel_connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  channel text NOT NULL,
  adapter text NOT NULL,
  status text NOT NULL DEFAULT 'disconnected' CHECK (status IN ('disconnected','mock','configured','verified','live','degraded')),
  capabilities jsonb NOT NULL DEFAULT '{}',
  secret_refs jsonb NOT NULL DEFAULT '[]',
  verified_at timestamptz,
  verification_source text,
  last_error text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, channel, adapter)
);

CREATE TABLE suppression_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  scope text NOT NULL DEFAULT 'brand' CHECK (scope IN ('brand','all_brands')),
  key_type text NOT NULL CHECK (key_type IN ('email','phone','business_key','linkedin')),
  key_hash text NOT NULL,
  reason text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, key_type, key_hash)
);

CREATE TABLE operation_events (
  id bigserial PRIMARY KEY,
  brand_id uuid REFERENCES brands(id),
  event_type text NOT NULL,
  actor text NOT NULL,
  subject_type text,
  subject_id text,
  payload jsonb NOT NULL DEFAULT '{}',
  is_simulated boolean NOT NULL DEFAULT false,
  seq bigint UNIQUE,
  prev_hash text,
  hash text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX operation_events_subject_idx ON operation_events (subject_type, subject_id);

-- Yardımcı tablolar (asgari listenin dışında, güvenilirlik için gerekli)
CREATE TABLE agent_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  task_id uuid REFERENCES tasks(id),
  role text NOT NULL,
  role_version text NOT NULL,
  prompt_hash text NOT NULL,
  provider text NOT NULL,
  model text NOT NULL,
  input_hash text NOT NULL,
  output jsonb,
  schema_valid boolean NOT NULL,
  guard_result jsonb NOT NULL DEFAULT '{}',
  reservation_id uuid REFERENCES budget_reservations(id),
  is_simulated boolean NOT NULL,
  error text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE inbound_webhooks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider text NOT NULL,
  event_key text NOT NULL,
  payload_hash text NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider, event_key)
);

CREATE TABLE outbound_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid REFERENCES brands(id),
  kind text NOT NULL CHECK (kind IN ('daily_report','weekly_report','decision','alert')),
  dedupe_key text NOT NULL,
  channel text NOT NULL CHECK (channel IN ('whatsapp','email','panel')),
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','delivered','read','failed','skipped')),
  external_id text,
  payload jsonb NOT NULL,
  is_simulated boolean NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (dedupe_key, channel)
);

CREATE TABLE erasure_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  subject_key_hash text NOT NULL,
  key_type text NOT NULL,
  requested_by text NOT NULL,
  executed_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE access_log (
  id bigserial PRIMARY KEY,
  actor text NOT NULL,
  method text NOT NULL,
  path text NOT NULL,
  status int NOT NULL,
  ip_hash text,
  at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL,
  updated_by text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- İşlem günlüğü: değişmez zincir. Sıra numarası (seq) kilit alındıktan SONRA tetikleyicide verilir;
-- böylece eşzamanlı yazımlarda zincir sırası ile seq sırası her zaman aynıdır.
CREATE FUNCTION operation_events_hash(prev text, brand uuid, etype text, actor text, stype text, sid text, payload jsonb, created timestamptz, seq bigint)
RETURNS text LANGUAGE sql IMMUTABLE AS $$
  SELECT encode(sha256(convert_to(
    prev || '|' || seq::text || '|' || coalesce(brand::text,'') || '|' || etype || '|' || actor || '|' ||
    coalesce(stype,'') || '|' || coalesce(sid,'') || '|' || payload::text || '|' || extract(epoch from created)::text,
    'UTF8')), 'hex')
$$;

CREATE FUNCTION operation_events_chain() RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE last_hash text; last_seq bigint;
BEGIN
  PERFORM pg_advisory_xact_lock(777001);
  SELECT hash, seq INTO last_hash, last_seq FROM operation_events ORDER BY seq DESC NULLS LAST LIMIT 1;
  NEW.seq := coalesce(last_seq, 0) + 1;
  NEW.prev_hash := coalesce(last_hash, 'genesis');
  NEW.hash := operation_events_hash(NEW.prev_hash, NEW.brand_id, NEW.event_type, NEW.actor, NEW.subject_type, NEW.subject_id, NEW.payload, NEW.created_at, NEW.seq);
  RETURN NEW;
END $$;
CREATE TRIGGER operation_events_chain_trg BEFORE INSERT ON operation_events
  FOR EACH ROW EXECUTE FUNCTION operation_events_chain();
