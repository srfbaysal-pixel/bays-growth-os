-- V2: kalıcı worker, zamanlı yayın, kaynaklı araştırma, manuel görevler, hizmet kartları, değerlendirme kayıtları

-- Görev kuyruğu: sahiplik (fencing), kira, hata kuyruğu nedeni
ALTER TABLE tasks ADD COLUMN locked_by text;
ALTER TABLE tasks ADD COLUMN dead_reason text;
ALTER TABLE tasks ADD COLUMN started_at timestamptz;
CREATE INDEX tasks_due_idx ON tasks (next_run_at) WHERE status = 'queued';
CREATE INDEX tasks_lease_idx ON tasks (locked_until) WHERE status = 'running';

-- Yayın: kaçırılmış yayın durumu ve uzlaştırma bağlantısı
ALTER TABLE publications DROP CONSTRAINT publications_status_check;
ALTER TABLE publications ADD CONSTRAINT publications_status_check CHECK (status IN ('queued','sending','outcome_unknown','published','failed','cancelled','manual_required','halted','missed'));
ALTER TABLE publications ADD COLUMN replan_of uuid REFERENCES publications(id);

-- Etkileşim durumu: taslak hiçbir zaman "gönderildi" sayılmaz; manuel gönderim ayrı işaretlenir
ALTER TABLE interactions ADD CONSTRAINT interactions_status_check CHECK (status IN ('recorded','sending','sent','manual_sent','delivered','failed','received'));

-- Hizmet kartı: gerçek kapsam, hazır oluş, kanıt, gerekli bağlantılar, kurucu doğrulaması
ALTER TABLE offers ADD COLUMN scope text;
ALTER TABLE offers ADD COLUMN required_connections jsonb NOT NULL DEFAULT '[]';
ALTER TABLE offers ADD COLUMN founder_verified boolean NOT NULL DEFAULT false;
ALTER TABLE offers ADD COLUMN demo_evidence_id uuid REFERENCES evidence(id);

-- Araştırma: sorgu önbelleği, kaynak belgeleri, bulgular, çalıştırma kaydı
CREATE TABLE research_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  day date NOT NULL,
  provider text NOT NULL,
  status text NOT NULL CHECK (status IN ('done','partial','disabled','blocked_budget','blocked_halt','error')),
  queries int NOT NULL DEFAULT 0,
  results int NOT NULL DEFAULT 0,
  documents int NOT NULL DEFAULT 0,
  findings int NOT NULL DEFAULT 0,
  candidates int NOT NULL DEFAULT 0,
  notes jsonb NOT NULL DEFAULT '[]',
  is_simulated boolean NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, day, provider)
);

CREATE TABLE research_queries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  provider text NOT NULL,
  query_hash text NOT NULL,
  query text NOT NULL,
  params jsonb NOT NULL DEFAULT '{}',
  results jsonb NOT NULL,
  fetched_at timestamptz NOT NULL,
  expires_at timestamptz NOT NULL,
  is_simulated boolean NOT NULL,
  UNIQUE (brand_id, provider, query_hash)
);

CREATE TABLE source_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  url text NOT NULL,
  url_hash text NOT NULL,
  final_url text,
  domain text,
  status text NOT NULL CHECK (status IN ('ok','unreachable','blocked','too_large','unsupported','disallowed','injection_flagged')),
  http_status int,
  content_hash text,
  bytes int,
  title text,
  text_excerpt text,
  extracted jsonb,
  error text,
  fetched_at timestamptz NOT NULL,
  is_simulated boolean NOT NULL,
  UNIQUE (brand_id, url_hash)
);

CREATE TABLE research_findings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  run_id uuid REFERENCES research_runs(id),
  document_id uuid REFERENCES source_documents(id),
  kind text NOT NULL CHECK (kind IN ('market_need','competitor','content_opportunity','business_candidate')),
  source_url text NOT NULL,
  accessed_at timestamptz NOT NULL,
  excerpt text NOT NULL,
  observed_fact text NOT NULL,
  inference text,
  confidence text NOT NULL CHECK (confidence IN ('low','medium','high')),
  freshness text NOT NULL CHECK (freshness IN ('fresh','stale','unreachable','conflicting')),
  data jsonb NOT NULL DEFAULT '{}',
  lead_id uuid REFERENCES leads(id),
  is_simulated boolean NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX research_findings_brand_idx ON research_findings (brand_id, kind, created_at);

-- Manuel görevler: kısıtlı kanallar (LinkedIn mesaj/davet), canlı gönderim kapalıyken e-posta, doğrulama işleri
CREATE TABLE manual_tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id uuid NOT NULL REFERENCES brands(id),
  lead_id uuid REFERENCES leads(id),
  contact_id uuid REFERENCES contacts(id),
  publication_id uuid REFERENCES publications(id),
  kind text NOT NULL CHECK (kind IN ('send_first_contact','send_follow_up','linkedin_message','linkedin_connection','verify_publication','match_reply','add_contact','record_demo','fix_bottleneck')),
  channel text,
  payload jsonb NOT NULL DEFAULT '{}',
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','done','skipped','expired')),
  result jsonb,
  dedupe_key text NOT NULL,
  completed_by text,
  completed_at timestamptz,
  is_simulated boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (brand_id, dedupe_key)
);

-- Ajan kalite değerlendirmesi kayıtları
CREATE TABLE eval_runs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  suite text NOT NULL,
  mode text NOT NULL CHECK (mode IN ('mock_contract','live_model')),
  status text NOT NULL CHECK (status IN ('pending','running','done','error')),
  model text,
  judge_model text,
  prompt_versions jsonb NOT NULL DEFAULT '{}',
  thresholds jsonb NOT NULL,
  results jsonb NOT NULL DEFAULT '[]',
  summary jsonb NOT NULL DEFAULT '{}',
  cost_try numeric,
  note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- RLS ve izinler
DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY['research_runs','research_queries','source_documents','research_findings','manual_tasks']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY brand_isolation ON %I USING (app_brand_visible(brand_id)) WITH CHECK (app_brand_visible(brand_id))', t);
    EXECUTE format('GRANT SELECT, INSERT, UPDATE ON %I TO bays_app', t);
    EXECUTE format('GRANT SELECT ON %I TO bays_auditor', t);
  END LOOP;
END $$;
GRANT SELECT, INSERT, UPDATE ON eval_runs TO bays_app;

-- Araştırma bağlantısı (her marka için; başlangıçta kapalı)
INSERT INTO channel_connections (brand_id, channel, adapter, status, capabilities, secret_refs)
SELECT id, 'research', 'brave-search', 'disconnected', '{}'::jsonb, '["BRAVE_SEARCH_API_KEY"]'::jsonb FROM brands
ON CONFLICT DO NOTHING;
GRANT SELECT ON eval_runs TO bays_auditor;
