-- Rol izinleri ve marka izolasyonu (RLS)
-- bays_app ve bays_auditor rolleri migration çalıştırıcısı tarafından (parolaları ortam değişkeninden) oluşturulur.

-- Marka kapsamı: oturumda app.brand_id ayarlı olmalı. Sistem işleri (bütçe toplamı, global rapor) app.scope='system' kullanır.
CREATE FUNCTION app_brand_visible(row_brand uuid) RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT current_setting('app.scope', true) = 'system'
      OR (row_brand IS NOT NULL AND row_brand = nullif(current_setting('app.brand_id', true), '')::uuid)
$$;

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'brand_profiles','evidence','offers','campaigns','tasks','assets','publications','leads','contacts',
    'interactions','opportunities','meetings','experiments','metrics','approval_requests','budget_reservations',
    'cost_ledger','channel_connections','agent_runs','erasure_log','audit_findings','operation_events',
    'outbound_notifications']
  LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY brand_isolation ON %I USING (app_brand_visible(brand_id)) WITH CHECK (app_brand_visible(brand_id))', t);
  END LOOP;
END $$;

-- Bilgi: kendi markası + diğer markalardan yalnız paylaşılmış (kişisel veri içermeyen) yöntem özetleri okunabilir
ALTER TABLE knowledge_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY knowledge_read ON knowledge_versions FOR SELECT USING (app_brand_visible(brand_id) OR is_shared);
CREATE POLICY knowledge_write ON knowledge_versions FOR INSERT WITH CHECK (app_brand_visible(brand_id));
CREATE POLICY knowledge_update ON knowledge_versions FOR UPDATE USING (app_brand_visible(brand_id)) WITH CHECK (app_brand_visible(brand_id));

-- İletişim istemeyenler: marka kaydı + "tüm markalar" kapsamlı kayıtlar her markaya görünür
ALTER TABLE suppression_entries ENABLE ROW LEVEL SECURITY;
CREATE POLICY suppression_read ON suppression_entries FOR SELECT USING (app_brand_visible(brand_id) OR scope = 'all_brands');
CREATE POLICY suppression_write ON suppression_entries FOR INSERT WITH CHECK (app_brand_visible(brand_id));

-- Uygulama rolü
GRANT USAGE ON SCHEMA public TO bays_app, bays_auditor;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO bays_app;
GRANT INSERT, UPDATE ON
  brands, brand_profiles, evidence, offers, knowledge_versions, campaigns, tasks, assets, publications, leads, contacts,
  interactions, opportunities, meetings, experiments, metrics, approval_requests, budget_reservations,
  channel_connections, agent_runs, outbound_notifications, settings, halts
TO bays_app;
-- Değişmez kayıtlar: yalnız ekleme
GRANT INSERT ON cost_ledger, operation_events, inbound_webhooks, suppression_entries, erasure_log, access_log TO bays_app;
-- Denetim bulgusunu uygulama yazamaz; yalnız kurucu panelinden durumunu değiştirebilir
GRANT UPDATE (status) ON audit_findings TO bays_app;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO bays_app;

-- Denetçi rolü: her şeyi okur; yalnız kendi bulgularını, durdurma kayıtlarını ve olay günlüğünü yazar.
-- Müşteri, yayın ve maliyet kayıtlarını değiştiremez.
GRANT SELECT ON ALL TABLES IN SCHEMA public TO bays_auditor;
GRANT INSERT ON audit_findings, halts, operation_events TO bays_auditor;
GRANT UPDATE (second_review) ON audit_findings TO bays_auditor;
GRANT UPDATE (halt_id) ON audit_findings TO bays_auditor;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO bays_auditor;

REVOKE ALL ON FUNCTION operation_events_chain() FROM PUBLIC;
